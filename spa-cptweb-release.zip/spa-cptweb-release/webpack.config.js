var devConfig = require('./webpack/webpack.dev.js');
var prodConfig = require('./webpack/webpack.prod.js');
var homologConfig = require('./webpack/webpack.hk.js');
var mockConfig = require('./webpack/webpack.mock');
var localConfig = require('./webpack/webpack.local');
var config;
switch (process.env.npm_lifecycle_event) {
  case 'start':
    config = devConfig;
    break;
  case 'build':
    config = prodConfig;
    break;
  case 'start:homolog':
    config = homologConfig;
    break;
  case 'start:mock':
    config = mockConfig;
    break;
  case 'start:local':
    config = localConfig;
    break;
  default:
    config = devConfig;
    break;
}
module.exports = config;
