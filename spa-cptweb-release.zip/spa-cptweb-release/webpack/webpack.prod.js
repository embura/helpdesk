var webpackMerge = require('webpack-merge');
var commonConfig = require('./webpack.common.js');
var UglifyJSPlugin = require('uglifyjs-webpack-plugin');
var webpack = require('webpack');

module.exports = webpackMerge(commonConfig, {

  plugins: [
    new UglifyJSPlugin(),
    new webpack.NormalModuleReplacementPlugin(/\.\/environment\.dev/, './environment.prod')
  ]
});