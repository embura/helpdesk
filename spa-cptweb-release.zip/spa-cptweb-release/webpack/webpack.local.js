var webpackMerge = require('webpack-merge');
var commonConfig = require('./webpack.common.js');
var webpack = require('webpack');

module.exports = webpackMerge(commonConfig, {
    "devServer": {
        historyApiFallback: true,
        host: 'local.santanderbr.pre.corp',
        port: 80
    },
    plugins: [
        new webpack.NormalModuleReplacementPlugin(/\.\/environment\.dev/, './environment.local')
    ]
});
