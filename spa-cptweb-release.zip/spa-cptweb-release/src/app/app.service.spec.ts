// // tslint:disable-next-line:snt-file-name-suffix
// import { TestBed, async, inject } from '@angular/core/testing';
// import { AppComponent } from './app.component';
// import { AppService } from './app.service';
// import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
// import { HubConnectorModule } from 'angl-spawebbgrl/spa-http-module/hub-connector.module';
// import { AppModule } from './app.module';
// import { Observable } from 'rxjs/Observable';
// import 'rxjs/add/observable/of';
// import { Http } from '@angular/http';

// /**
//  * @todo: Ta dando erro ao mockar este componente
//  */

// class MockedHubConnectionComponent {
//     public authenticate(): Observable<any> {
//         return Observable.of('Teste');
//     }
//     public getJson(url: string): Observable<any> {
//         return Observable.of('Teste');
//     }
// }

// // nao esta sendo testado
// describe('AppService', () => {
//     let service: AppService;

//     beforeEach(() => {
//         TestBed.configureTestingModule({
//             imports: [AppModule],
//             providers: [
//                 {
//                     provide: HubConnectorComponent,
//                     useClass: MockedHubConnectionComponent
//                 }
//             ]
//         }).compileComponents();
//     });

//     beforeEach(() => {
//         service = TestBed.get(AppService);
//     });

//     it('Should create Appservice', () => {
//         expect(service).toBeDefined();
//     });

//     it('Should authenticate', async(() => {
//       service.authentication().subscribe((data: string) => {
//         expect(data).toBe('Teste');
//       });
//     }));

//     it('Should get profile', async(() => {
//       service.getProfile('Teste').subscribe((data: string) => {
//         expect(data).toBe('Teste');
//       });
//     }));
// });
