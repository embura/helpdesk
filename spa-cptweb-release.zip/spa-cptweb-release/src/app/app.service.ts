import { Injectable } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { environment } from '../environments/environment';
import { ObservableRetryHandler } from './modules/catalog/shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class AppService {

  constructor(private hubConnector: HubConnectorComponent) { }

  authentication() {
    return this.hubConnector.authenticate();
  }

  getProfile(login: string) {
    return this.hubConnector.getJson(environment.urls.security.MBS_SERVER_URL(login))
    .retryWhen(ObservableRetryHandler);
  }
}
