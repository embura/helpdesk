import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ProductDialogComponent, IProductDialogParam } from './components/product/product-dialog.component';
import { IProduct } from './models/product/product.interface';
import { ProductService } from './services/product/product.service';
import { ToastrService } from 'ngx-toastr';
import { SearchComponent } from './components/search/search.component';
import { CustomErrorToastComponent } from './components/toast/custom-error-toast.component';

@Component({
  selector: 'app-cpt-catalog',
  templateUrl: './catalog.component.html',
  styleUrls: ['./catalog.component.scss']
})
export class CatalogComponent {
  constructor(private dialog: MatDialog, private productService: ProductService, private toastrService: ToastrService) { }

  @ViewChild('searchComponent') private searchComponent: SearchComponent;

  public async openProduct(product?: IProduct, isDuplication?: boolean): Promise<void> {
    try {
      const dialogData: any = { width: '90%', data: <IProductDialogParam>{} };
      if (product) {
        const result = await this.productService.getProductById(product.id);
        if (result.return.code !== 0) {
          throw result.return.message;
        }
        dialogData.data.product = result.data;
      }
      dialogData.data.isDuplication = !!isDuplication;
      this.dialog.open(ProductDialogComponent, dialogData).afterClosed().subscribe(_ => {
        if (this.searchComponent) {
          this.searchComponent.refreshProductList();
        }
      });
    } catch (err) {
      this.toastrService.error(err, '', {
        toastComponent: CustomErrorToastComponent,
      });
    }
  }
}
