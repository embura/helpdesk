import { AbstractControl } from '@angular/forms';

export function hour(control: AbstractControl) {
  const value: string = control.value;
  if (value.trim() === '') {
    return null;
  }
  return requiredHour(control);
}


export function requiredHour(control: AbstractControl) {
  const value: string = control.value;
  if (value.indexOf(':') === -1) {
    return { validHour: true };
  }
  const splitted: Array<string> = value.split(':');
  if (parseInt(splitted[0], 10) > 24 || parseInt(splitted[0], 10) < 0) { // hora
    return { validHour: true };
  }
  if (parseInt(splitted[1], 10) > 59 || parseInt(splitted[1], 10) < 0) { // minuto
    return { validHour: true };
  }
  return null;
}
