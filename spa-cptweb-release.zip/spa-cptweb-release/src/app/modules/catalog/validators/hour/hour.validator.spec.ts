import { hour } from './hour.validator';
import { AbstractControl } from '@angular/forms';

describe('Hour Validator', () => {
    it('Should validate the hour', () => {
        const control = { value: '', validator: null, asyncValidator: null };
        control.value = '10:35';
        let result = hour(control as AbstractControl);
        expect(result).toEqual(null);
        control.value = '10,35';
        result = hour(control as AbstractControl);
        expect(result).toEqual({ validHour: true });
        control.value = '22:99';
        result = hour(control as AbstractControl);
        expect(result).toEqual({ validHour: true });
    });
});
