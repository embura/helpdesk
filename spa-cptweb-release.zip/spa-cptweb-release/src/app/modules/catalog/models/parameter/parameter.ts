import { ParameterOption } from './parameter-item';

export class Parameter {
    public isOpen: boolean;
    public typeName: string;
    public options: ParameterOption[];
    public validationId: number;
    public isisEditable: boolean;
    constructor(
        public name: string,
        public typeId: number,
        public statusId: number,
        public id?: number
    ) {
        this.isOpen = false;
        this.isisEditable = true;
        this.options = [];
    }
}

export interface IOption {
    id: number;
    name: string;
    nameTec: string;
    parameterId?: number;
    isEditable: boolean;
    statusId: number;
}

export interface IValidationType {
    name: string;
    id: number;
    parameterTypeId: number;
}
export interface IParameterType {
    name: string;
    id: number;
}
export interface IParameter {
    id?: number;
    name: string;
    typeId: number;
    validationId?: number;
    options?: Array<IOption>;
    statusId: number;
    isEditable: boolean;
}

export enum TypeParameter {
    Texto_simples = 1,
    Seleção_sim_ou_não = 2,
    Caixas_de_seleção = 3,
    Lista_suspensa = 4,
    Data = 5,
    Chave_única = 6,
    Frase = 7
}

export enum TypeValidation {
    Sem_validação = 1,
    Apenas_números = 2,
    Apenas_letras = 3,
    Horário = 4
}
