export class ParameterOption {
    public editing: boolean;
    public isEditable: boolean;
    public id: number;
    public statusId: number;
    constructor(
        public name: string,
        public nameTec: string
    ) { }
}
