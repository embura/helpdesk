export interface ICategoryProduct {
    categories: ICategories;
    isValid: boolean;
}

export interface ICategories {
    familyId?: number;
    groupId?: number;
    assetClassId?: number;
    modalityId?: number;
    underlyingId?: number;
}
