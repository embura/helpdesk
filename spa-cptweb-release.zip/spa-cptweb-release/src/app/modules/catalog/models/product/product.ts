import { ICategoryProduct } from './category-product.interface';
import { IForm } from '../form/form.interface';
import { IParameter } from '../parameter/parameter';

export class Product {
    categoryProduct: ICategoryProduct;
    selectedForm: ProductForm;
}

export class ProductForm {
    name: string;
    id: number;
    fields: ProductFormField[];
    statusId: number;
}

export class ProductFormField {
    id: number;
    name: string;
    value: string;
    param: IParameter;
    isLoading: boolean;
    required: boolean;
    paramId: number;
}
