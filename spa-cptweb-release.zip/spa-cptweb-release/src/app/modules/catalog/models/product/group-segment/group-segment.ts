import { Segment } from '../../segment/segment';
import { IEvents } from '../../../components/events-channels/events/events';

export class GroupSegment {
    public name: string;
    public id?: number;
    public code?: number;
    public segments: Segment[];
    public events: IEvents[];
    public isOpen: boolean;
    public isEditing: boolean;
    constructor(
        name: string,
        id?: number,
        code?: number,
        segments?: Segment[],
        events?: IEvents[],
        isOpen?: boolean,
        isEditing?: boolean
    ) {
        this.name = name;
        this.id = id;
        this.code = code;
        this.segments = segments || [];
        this.events = events || [];
        this.isOpen = isOpen || false;
        this.isEditing = isEditing || false;
    }
}
