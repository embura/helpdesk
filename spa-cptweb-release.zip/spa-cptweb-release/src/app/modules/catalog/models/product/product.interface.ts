import { GroupSegment } from './group-segment/group-segment';
import { ICategory } from '../category/category.interface';


export interface IProductParams {
  id?: number;
  productId?: number;
  parameterId: number;
  value: string;
  name?: string;
  isPrimaryKey: boolean;
}

export interface IProduct {
  id?: number;
  formId: number;
  familyId?: number;
  modalityId: number;
  underlyingId: number;
  assetClassId: number;
  groupId: number;
  statusId: number;
  name: string;
  params: Array<IProductParams>;
  groupsSegments?: Array<GroupSegment>;
  isOpen: boolean;
  categories?: Array<ICategory>;
}

export interface ITotal {
  qtdActives?: number;
  qtdInactives?: number;
  qtdTotal?: number;
}

export interface IProductCategory {
  name: string;
  familyName: string;
  groupName: string;
  assetClassName: string;
  modalityName: string;
  underlyingName: string;
}

