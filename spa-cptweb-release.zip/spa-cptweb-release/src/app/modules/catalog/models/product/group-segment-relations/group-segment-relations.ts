
export class GroupSegmentRelations {
    public id: number;
    public segmentID: number;
    public groupSegmentID: number;
    constructor(
        id: number,
        segmentID: number,
        groupSegmentID: number
    ) {
        this.id = id;
        this.segmentID = segmentID;
        this.groupSegmentID = groupSegmentID;
    }
}
