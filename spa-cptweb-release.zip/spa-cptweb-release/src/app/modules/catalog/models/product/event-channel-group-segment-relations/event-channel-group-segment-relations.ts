
export class EventChanGrSegRelations {
    public id: number;
    public channelID: number;
    public eventID: number;
    public groupSegmentID: number;
    constructor(
        id: number,
        channelID: number,
        eventID: number,
        groupSegmentID: number
    ) {
        this.id = id;
        this.channelID = channelID;
        this.eventID = eventID;
        this.groupSegmentID = groupSegmentID;
    }
}
