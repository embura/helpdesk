
export class Segment {
    public id?: number;
    public name: string;
    public code: string;
    public isEditing: boolean;
    public isHover: boolean;
    constructor(
        code: string,
        name: string,
        id?: number
    ) {
        this.id = id;
        this.code = code;
        this.name = name;
        this.isEditing = false;
        this.isHover = false;
    }
}

export interface ISegment {
    id: number;
    name: string;
    code: number;
}
