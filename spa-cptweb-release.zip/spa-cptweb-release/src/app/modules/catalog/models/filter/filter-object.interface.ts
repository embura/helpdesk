export interface IFilterOption {
  id: number;
  value: string;
  orderBy?: string;
  order?: 'asc' | 'desc';
  status?: number;
}

export interface IFilterObject {
  showInatives: boolean;
  textFilter: string;
  filter: IFilterOption;
}
