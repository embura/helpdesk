export class CategoryDTO {
  constructor(
    public id: number,
    public name: string,
    public statusId?: number,
    public technicalName?: string
  ) { }
}

export class GroupDTO extends CategoryDTO {
  public familyId: number;
}
