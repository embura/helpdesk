export interface ICategory {
    id: number;
    name: string;
    statusId: number;
    shortName: string;
    isEditable: boolean;
}

export interface IGroup extends ICategory {
    familyId: number;
    technicalName: string;
}
