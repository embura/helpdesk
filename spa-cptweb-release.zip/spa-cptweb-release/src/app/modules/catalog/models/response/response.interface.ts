import { IReturn } from '../return/return.interface';

export interface IResponse<T> {
    return: IReturn;
    data: T;
}
