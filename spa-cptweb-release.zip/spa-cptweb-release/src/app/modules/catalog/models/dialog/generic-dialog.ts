import { MatDialogRef, MatDialog } from '@angular/material';
import { GenericDialogComponent } from '../../components/dialogs/generic/generic-dialog.component';
import { DeleteDialogComponent } from '../../components/dialogs/delete/delete-dialog.component';
import { HistoricDialogComponent } from '../../components/historic/historic-dialog.component';
import { IHistoricData } from '../../components/historic/historic-dialog';

export class GenericDialog {
  constructor(private dialog: MatDialog) { }

  public deleteWarningMessage(): MatDialogRef<DeleteDialogComponent> {
    return this.dialog.open(DeleteDialogComponent);
  }

  public successMessage(message): MatDialogRef<GenericDialogComponent> {
    return this.dialog.open(GenericDialogComponent, {
      data: {
        type: 'success',
        icon: 'check_circle',
        title: message,
        btnOK: true
      }
    });
  }

  public loadingMessage(message: string): MatDialogRef<GenericDialogComponent> {
    return this.dialog.open(GenericDialogComponent, {
      data: {
        loading: true,
        content: message
      },
      disableClose: true
    });
  }

  public errorMessage(message: string): MatDialogRef<GenericDialogComponent> {
    return this.dialog.open(GenericDialogComponent, {
      data: {
        type: 'error',
        icon: 'error',
        title: message,
        btnOK: true
      }
    });
  }

  public historic(data: IHistoricData): MatDialogRef<HistoricDialogComponent> {
    return this.dialog.open(HistoricDialogComponent, {
      data: data,
      panelClass: 'historic-dialog',
      height: '95vh'
    });
  }
}
