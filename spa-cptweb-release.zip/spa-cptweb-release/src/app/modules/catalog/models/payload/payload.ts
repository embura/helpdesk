import { PayloadItem } from './payload-item';

export class Payload {
    public isEditable: boolean;
    public isOpen: boolean;
    public itens: PayloadItem[];
    public isSaved: boolean;

    constructor(
        public id: number,
        public name: string,
    ) {
        this.isOpen = false;
        this.itens = [];
        this.isSaved = false;
        this.isEditable = true;
    }
}

export interface IItemAssociation {
    payloadId: number;
    payloadItemId: number;
    formParamId: number;
}

export interface IPayloadFormItem {
    formId: number;
    paramId: number;
    nameParam: string;
    payloadId: number;
    payloadItemId: number;
    namePayloadItem: string;
    associationId: number;
}
