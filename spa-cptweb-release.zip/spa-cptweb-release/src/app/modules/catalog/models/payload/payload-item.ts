import { IParamFormAssociation } from '../form/form.interface';

export class PayloadItem {
    public id: number;
    public name: string;
    public payloadId: number;
    public isEditable: boolean;
    public editing: boolean;
    public paramFormAssociation: IParamFormAssociation;

    constructor(payloadId: number, name: string) {
        this.payloadId = payloadId;
        this.name = name;
        this.isEditable = true;
        this.editing = false;
    }
}
