export class EventsChannelsDto {
  constructor(
    public id: number,
    public name: string,
    public nameTec: string,
    public statusId?: number
) { }
}
