export interface IEventsChannels {
  id: number;
  name: string;
  statusId: number;
  nameTec: string;
}
