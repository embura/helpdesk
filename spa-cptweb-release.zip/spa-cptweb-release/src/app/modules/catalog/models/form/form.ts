import { TypeParameter, TypeValidation } from '../parameter/parameter';
import { IForm, IFormParameter } from './form.interface';

export class Form {
    constructor(
        public name: string,
        public statusId: number,
        public isEditable: boolean,
        public id?: number) {

        this.isOpen = false;
    }

    public isOpen: boolean;
    parameters: IFormItem[];

    public static convertToModel(value: IForm): Form {
        const form: Form = new Form(value.name, value.statusId, value.isEditable, value.id);

        form.parameters = Form.convertFormParameterToModel(value.formParameters);

        return form;
    }

    public static convertFormParameterToModel(formParameters: IFormParameter[]): IFormItem[] {
        const parameters: IFormItem[] = [];

        if (formParameters && formParameters.length > 0) {
            formParameters.forEach(formParam => {
                const itemFrm: IFormItem = {
                    id: formParam.id,
                    parameterId: formParam.parameterId,
                    name: '',
                    type: null,
                    typeString: '',
                    validation: null,
                    validationString: '',
                    order: formParam.paramOrder,
                    isRequired: formParam.required === 'S' ? true : false,
                    isVisible: false
                };

                if (formParam.info) {
                    itemFrm.name = formParam.info.name;
                    itemFrm.type = formParam.info.typeId;
                    itemFrm.typeString = TypeParameter[formParam.info.typeId];
                    itemFrm.validation = formParam.info.validationId;
                    itemFrm.validationString = TypeValidation[formParam.info.validationId];
                }

                parameters.push(itemFrm);
            });
        }

        parameters.unshift(this.addBusinessName());

        parameters.sort((paramA, paramB) => paramA.order - paramB.order);

        return parameters;
    }

    private static addBusinessName(): IFormItem {
        return {
            isRequired: true,
            isVisible: false,
            name: 'Nome comercial',
            order: 1,
            parameterId: -1,
            type: -1,
            typeString: TypeParameter[1],
            validation: <TypeValidation>1,
            validationString: TypeValidation[1],
        };
    }
}
export interface IFormItem {
    id?: number;
    parameterId: number;
    name: string;
    type: TypeParameter;
    typeString: string;
    validation: TypeValidation;
    validationString: string;
    order: number;
    isRequired: boolean;
    isVisible: boolean;
}
