// tslint:disable-next-line:snt-file-name-suffix
import { Form } from './form';
import { IForm, IFormParameter } from './form.interface';
import { IParameter } from '../parameter/parameter';


const parameters: IParameter[] = [
    {
        id: 200,
        name: 'name',
        typeId: 1,
        validationId: 10,
        statusId: 10,
        isEditable: true
    }
];

const formParameters: IFormParameter[] = [
    {
        id: 100,
        formId: 101,
        parameterId: 1,
        paramOrder: 2,
        required: 'TRUE',
        info: parameters[0]
    }
];

const forms: IForm[] = [
    {
        id: 1,
        name: 'name1',
        statusId: 10,
        isEditable: true,
        formParameters: formParameters
    }
];

describe('Form', () => {
    it('Should convert to a model', () => {
        const result = Form.convertToModel(forms[0]);
        expect(result).toEqual(jasmine.any(Form));
    });
});
