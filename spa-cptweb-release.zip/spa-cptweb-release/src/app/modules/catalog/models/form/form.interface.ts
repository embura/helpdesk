import { IParameter } from '../parameter/parameter';

export interface IForm  {
    id: number;
    name: string;
    statusId: number;
    isEditable: boolean;
    formParameters?: IFormParameter[];
}

export interface IFormParameter {
    id: number;
    formId: number;
    parameterId: number;
    paramOrder: number;
    required: string;
    info?: IParameter;
}
export interface IParamFormAssociation {
    id: number;
    name: string;
}
