import { IForm, IFormParameter } from './form.interface';

export class FormDTO implements IForm {
    constructor (
        public id: number,
        public name: string,
        public statusId: number,
        public isEditable: boolean,
        public formParameters?: FormParameterDTO[]
    ) { }
}

export class FormParameterDTO implements IFormParameter {
    constructor (
        public id: number,
        public formId: number,
        public parameterId: number,
        public paramOrder: number,
        public required: string,
    ) { }

    public name: string;
}
