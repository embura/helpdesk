import { OrderAccordionPipe} from './order-accordion.pipe';
import { AccordionItem } from '../components/accordion/accordion-item';

let pipe: OrderAccordionPipe;

const accordions: AccordionItem[] = [
    {
        id: 1,
        code: 1,
        name: 'string',
        subItem: 'string',
        subItemId: 1,
        canDelete: false,
        canEdit: true,
        statusId: 10,
        isEditable: true,
        popupOpen: false,
        canDisable: true,
        nameTec: 'string'
    },
    {
        id: 2,
        code: 1,
        name: 'aname',
        subItem: 'string',
        subItemId: 1,
        canDelete: false,
        canEdit: true,
        statusId: 10,
        isEditable: true,
        popupOpen: false,
        canDisable: true,
        nameTec: 'aname'
    },
    {
        id: 3,
        code: 3,
        name: 'zed',
        subItem: 'string',
        subItemId: 1,
        canDelete: false,
        canEdit: true,
        statusId: 10,
        isEditable: true,
        popupOpen: false,
        canDisable: true,
        nameTec: 'zed'
    }
];

const accordions2: AccordionItem[] = [
    {
        id: 2,
        code: 1,
        name: 'aname',
        subItem: 'string',
        subItemId: 1,
        canDelete: false,
        canEdit: true,
        statusId: 10,
        isEditable: true,
        popupOpen: false,
        canDisable: true,
        nameTec: 'aname'
    },
    {
        id: 1,
        code: 1,
        name: 'string',
        subItem: 'string',
        subItemId: 1,
        canDelete: false,
        canEdit: true,
        statusId: 10,
        isEditable: true,
        popupOpen: false,
        canDisable: true,
        nameTec: 'string'
    },
    {
        id: 3,
        code: 3,
        name: 'zed',
        subItem: 'string',
        subItemId: 1,
        canDelete: false,
        canEdit: true,
        statusId: 10,
        isEditable: true,
        popupOpen: false,
        canDisable: true,
        nameTec: 'zed'
    }
];


describe('Order-Accordion Pipe', () => {
    beforeEach(() => {
      pipe = new OrderAccordionPipe();
    });

    it('Should sort the itens', () => {
        expect(pipe.transform(accordions)).toEqual(accordions2);
    });
});
