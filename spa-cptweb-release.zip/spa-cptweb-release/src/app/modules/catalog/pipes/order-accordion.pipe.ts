import { PipeTransform, Pipe } from '@angular/core';
import { AccordionItem } from '../components/accordion/accordion-item';

@Pipe({ name: 'orderAccordion' })
export class OrderAccordionPipe implements PipeTransform {
  transform(value: AccordionItem[], ...args: any[]) {
    if (value) {
      value.sort((itemA, itemB) => {
        if (itemA.name && itemB.name && itemA.name.toLowerCase() < itemB.name.toLowerCase()) { return -1; }
        if (itemA.name && itemB.name && itemA.name.toLowerCase() > itemB.name.toLowerCase()) { return 1; }
        return 0;
      });
    }

    return value;
  }
}
