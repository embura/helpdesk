import { Pipe, PipeTransform } from '@angular/core';
import * as moment_ from 'moment';
const moment = moment_;

@Pipe({name: 'momentDate'})
export class MomentDatePipe implements PipeTransform {
    public transform(value, ...args: Array<string>): string {
        let result = '--';
        if (value && (value instanceof Date || (typeof value === 'string' && value !== ''))) {
            const formatter: string = args[0] || 'DD/MM/YYYY HH:mm';
            result = moment(value).format(formatter);
        }
        return result;
    }
}
