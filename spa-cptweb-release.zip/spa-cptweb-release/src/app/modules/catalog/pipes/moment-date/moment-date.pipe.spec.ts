import { MomentDatePipe } from './moment-date.pipe';

describe('Moment date pipe', () => {
    let pipe: MomentDatePipe;
    let date: Date;
    beforeEach(() => {
        pipe = new MomentDatePipe();
        // 24/12/2018 10:33 *mes = mes + 1
        date = new Date(2018, 11, 24, 10, 33, 30, 0);
    });

    it('should instantiate pipe', () => {
        expect(pipe).toBeTruthy();
    });

    it('should return -- for an invalid date', () => {
        const result = pipe.transform(null, '');
        expect(result).toContain('--');
    });

    it('should return default formatation', () => {
        const result = pipe.transform(date);
        expect(result).toContain('24/12/2018 10:33');
    });

    it('should return with weird formatation', () => {
        const result = pipe.transform(date, 'YYYY-DD_MM');
        expect(result).toBe('2018-24_12');
    });

    it('should receive a string date as parameter', () => {
        expect(() => {
            pipe.transform(date.toISOString());
        }).not.toThrow();
    });
});
