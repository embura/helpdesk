// tslint:disable-next-line:snt-file-name-suffix
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { GenericDialogComponent } from './generic-dialog.component';
import { MatDialogModule, MatIconModule, MatProgressSpinnerModule, MAT_DIALOG_DATA } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
@NgModule({
  imports: [
    MatDialogModule,
    MatIconModule,
    MatProgressSpinnerModule,
    BrowserAnimationsModule,
    CommonModule,
    FormsModule
  ],
  declarations: [
    GenericDialogComponent
  ],
  entryComponents: [
    GenericDialogComponent
  ]
})
class TestModule { }

describe('GenericDialogComponent', () => {
  let component: GenericDialogComponent;
  let fixture: ComponentFixture<GenericDialogComponent>;

  const data = {
    title: 'Mock',
    content: 'Mock'
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        TestModule
      ],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: data }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GenericDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
