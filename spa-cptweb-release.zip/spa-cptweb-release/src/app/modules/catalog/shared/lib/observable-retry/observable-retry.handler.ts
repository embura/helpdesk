import { Observable } from 'rxjs/Observable';

export const ObservableRetryHandler = ( errors: Observable<any>) => {
  let retrycount = 1;
  return errors.scan( (err) => {
    if (retrycount >= 3) {
      console.error(`retry failed [${retrycount}]: ${err}`);
      throw err;
    }
    console.log(`retrying... [${retrycount}]: ${err.url}`);

    retrycount++;
    return err;
  });
};
