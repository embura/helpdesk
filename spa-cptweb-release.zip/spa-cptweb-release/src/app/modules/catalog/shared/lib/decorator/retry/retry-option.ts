
export class RetryOptions {
  maxAttempts?: number;
  interval?: number;
  exponential?: number;
}

export const sleep = (ms?: number) => new Promise(resolve => setTimeout(resolve, ms));
