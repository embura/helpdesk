import { RetryOptions, sleep } from './retry-option';

export function RetryPromise(userOptions?: RetryOptions): Function {
  const defaultOption: RetryOptions = {
    maxAttempts: 3,
    interval: 150,
  };
  userOptions = Object.assign(defaultOption, userOptions);

  return (target: Object, propertyKey: string, descriptor: TypedPropertyDescriptor<any>) => {
    const originalFunction: Function = descriptor.value;

    return descriptor.value = function(...args: any[]){
      return retryPromise.apply(this, [originalFunction, args, userOptions]);
    };

  };

  function retryPromise(originalFunction: Function, args: any[], options: RetryOptions): Promise<any> {
    console.log('retry');

    return originalFunction.apply(this, args)
      .catch( err => {
        console.log('err', err);

        if (opener.maxAttempts <= 0) {
          throw err;
        }

        const newOptions = Object.assign({}, options);
        --newOptions.maxAttempts;

        const retryCount = newOptions.maxAttempts - options.maxAttempts;
        console.log(`[${originalFunction.name}] Retrying... ${retryCount}`);

        return sleep(newOptions.interval).then( () => {
          if (newOptions.exponential) {
            newOptions.interval = newOptions.interval * options.exponential;
          }
          return retryPromise(originalFunction, args, newOptions);
        });

      });
  }

}


