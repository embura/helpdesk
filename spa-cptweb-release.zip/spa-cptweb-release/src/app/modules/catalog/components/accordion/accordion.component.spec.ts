import { TestBed, async } from '@angular/core/testing';
import { AccordionComponent } from './accordion.component';
import { AccordionItem } from './accordion-item';
import { ElementRef } from '@angular/core';
import { MatMenuModule, MatIconModule } from '@angular/material';
import { OrderAccordionPipe } from '../../pipes/order-accordion.pipe';
import { Observable } from 'rxjs/Rx';

describe('AccordionComponent', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        MatMenuModule,
        MatIconModule
      ],
      declarations: [
        AccordionComponent,
        OrderAccordionPipe
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AccordionComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'app'`, () => {
    const fixture = TestBed.createComponent(AccordionComponent);
    fixture.componentInstance.title = 'Família';
    fixture.detectChanges();
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('Família');
  });

  it('mark as open the component', () => {
    const fixture = TestBed.createComponent(AccordionComponent);
    const app = fixture.debugElement.componentInstance;
    const value = !app.isOpen;
    app.open();
    expect(app.isOpen).toBe(value);
  });

  it('emit add event', async(() => {
    const fixture = TestBed.createComponent(AccordionComponent);
    const app = fixture.debugElement.componentInstance;
    app.add.subscribe((result: boolean) => {
      expect(result).toBe(true);
    });

    app.addEvent();
  }));

  it('emit edit event when editable', async(() => {
    const fixture = TestBed.createComponent(AccordionComponent);
    const app = fixture.debugElement.componentInstance;

    const item: AccordionItem = new AccordionItem();
    item.id = 1;
    item.canEdit = true;

    app.edit.subscribe((result: AccordionItem) => {
      expect(result.id).toBe(1);
    });

    app.editEvent(item);
  }));

  it('emit edit event when not editable', async(() => {
    const fixture = TestBed.createComponent(AccordionComponent);
    const app = fixture.debugElement.componentInstance;

    const item: AccordionItem = new AccordionItem();
    item.id = 1;

    app.edit.subscribe((result: AccordionItem) => {
      expect(result.id).toBe(1);
    });

    app.editEvent(item);
  }));

  it('emit delete event when deletable', async(() => {
    const fixture = TestBed.createComponent(AccordionComponent);
    const app = fixture.debugElement.componentInstance;

    const item: AccordionItem = new AccordionItem();
    item.id = 1;
    item.canDelete = true;

    app.del.subscribe((result: AccordionItem) => {
      expect(result.id).toBe(1);
    });

    app.deleteEvent(item);
  }));

  it('emit delete event when not deletable', async(() => {
    const fixture = TestBed.createComponent(AccordionComponent);
    const app = fixture.debugElement.componentInstance;

    const item: AccordionItem = new AccordionItem();
    item.id = 1;

    app.del.subscribe((result: AccordionItem) => {
      expect(result.id).toBe(1);
    });

    app.deleteEvent(item);
  }));

  it('should not to throw when historic button clicked', () => {
    const fixture = TestBed.createComponent(AccordionComponent);
    const app = fixture.debugElement.componentInstance;
    expect(() => {
      app.historicClickHandler();
      app.table = 'mock';
      app.historicClickHandler();
    }).not.toThrow();
  });

  it('should return count', () => {
    const fixture = TestBed.createComponent(AccordionComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.count).toBe(0);
    app.items = [];
    expect(app.count).toBe(0);
  });

  it('not hide selected item', () => {
    const fixture = TestBed.createComponent(AccordionComponent);
    const app = fixture.debugElement.componentInstance;

    const items: AccordionItem[] = new Array();
    const itemOne = new AccordionItem();
    itemOne.id = 1;
    itemOne.popupOpen = true;
    items.push(itemOne);

    const itemTwo: AccordionItem = new AccordionItem();
    itemTwo.id = 2;
    itemTwo.popupOpen = true;
    items.push(itemTwo);

    const itemSelected = new AccordionItem();
    itemSelected.id = 3;
    itemSelected.popupOpen = true;
    items.push(itemSelected);

    app.items = items;

    app.hideMenu(itemSelected);

    const closedItems: AccordionItem[] = app.items.filter(it => it.popupOpen);

    expect(closedItems.length).toBe(1);
  });
});
