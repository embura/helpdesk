import { ICategory } from '../../models/category/category.interface';

export class AccordionItem {
  public id: number;
  public code: number;
  public name: string;
  public nameTec: string;
  public subItem: string;
  public subItemId: number;
  public canDelete: boolean;
  public canEdit: boolean;
  public statusId: number;
  public isEditable: boolean;
  public popupOpen = false;
  public canDisable = true;

  public static transmforCatgory(category: ICategory): AccordionItem {
    const accordionItem = new AccordionItem();
    accordionItem.name = category.name;
    accordionItem.id = category.id;
    accordionItem.statusId = category.statusId;
    accordionItem.canEdit = category.isEditable;

    return accordionItem;
  }

  public static transformCategories(category: ICategory[]): AccordionItem[] {
    const accordionItems: AccordionItem[] = new Array<AccordionItem>();
    if (category) {
      category.map(cat => {
        accordionItems.push(this.transmforCatgory(cat));
      });

      return accordionItems;
    }

    return [];
  }


}
