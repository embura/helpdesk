import {Component, Output, EventEmitter, Input, ViewChild} from '@angular/core';
import { AccordionItem } from './accordion-item';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { TABLE_MAPPER } from '../../models/common/table-mapping';
import { FilterComponent } from '../filter/filter.component';
import { EventService } from '../../services/events-channels/event/event.service';
import { Events } from '../events-channels/events/events';

@Component({
  selector: 'app-cpt-accordion',
  templateUrl: './accordion.component.html',
  styleUrls: ['./accordion.component.scss'],
  animations: [
    trigger('ease', [
      transition(':enter', [
        style({ 'max-height': 0 }),
        animate('0.15s ease-out', style({ 'max-height': '*' }))
      ]),
      transition(':leave', [
        style({ 'max-height': '*' }),
        animate('0.15s ease-in', style({ 'max-height': 0 }))
      ])
    ])
  ]
})
export class AccordionComponent {
  public isOpen = false;
  public parameter: Events;


  @ViewChild('filterRef') private filterRef: FilterComponent;

  @Input() public table: string;
  @Input() public title: string;
  @Input() public addButtonTitle: string;
  @Input() public items: AccordionItem[];
  @Input() public hasVisibility: boolean;
  @Output() public add: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() public edit: EventEmitter<AccordionItem> = new EventEmitter<AccordionItem>();
  @Output() public changeStatus: EventEmitter<AccordionItem> = new EventEmitter<AccordionItem>();
  @Output() public disable: EventEmitter<AccordionItem> = new EventEmitter<AccordionItem>();
  @Output() public del: EventEmitter<AccordionItem> = new EventEmitter<AccordionItem>();
  @Output() public showHistory: EventEmitter<number> = new EventEmitter<number>();

  public historicClickHandler(): void {
    if (this.table) {
      this.showHistory.emit(TABLE_MAPPER[this.table]);
    }
  }

  public get count(): number {
    if (this.items) {
      return this.items.length;
    }

    return 0;
  }

  public open(): void {
    this.isOpen = !this.isOpen;
  }

  public addEvent(): void {
    this.add.emit(true);
  }

  public editEvent(item: AccordionItem): void {
    if (item.canEdit) {
      this.edit.emit(item);
      this.openMenu(item);
    }
  }

  public deleteEvent(item: AccordionItem): void {
    if (item.canDelete) {
      this.del.emit(item);
      this.openMenu(item);
    }
  }

  public openMenu(item: AccordionItem) {
    this.hideMenu(item);

    item.popupOpen = !item.popupOpen;
  }

  public hideMenu(item: AccordionItem = null) {
    if (this.items) {
      this.items.map((mapItem: AccordionItem) => {
        if (mapItem !== item) {
          mapItem.popupOpen = false;
        }
      });
    }
  }

  public canDisableButton(item: AccordionItem): void {
    if (item.statusId) {
      this.changeStatus.emit(item);
    }
  }
}
