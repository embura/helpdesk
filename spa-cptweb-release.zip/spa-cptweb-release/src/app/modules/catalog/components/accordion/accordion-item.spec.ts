import { TestBed } from '@angular/core/testing';
import { AccordionItem } from './accordion-item';
import { ICategory } from '../../models/category/category.interface';

describe('AccordionItem', () => {
  it('should create the class', () => {
    const app: AccordionItem = new AccordionItem();
    expect(app).toBeTruthy();
  });

  it(`property popupOpen should be false`, () => {
    const app: AccordionItem = new AccordionItem();
    expect(app.popupOpen).toBe(false);
  });

  it('should return a AccordionItem', () => {
    const category: ICategory = { name: 'Mock', id : 1, shortName: 'Mock', statusId: 5, isEditable: true };

    const app: AccordionItem = AccordionItem.transmforCatgory(category);

    expect(app.name).toBe('Mock');
    expect(app.id).toBe(1);
  });

  it('should return an array of AccordionItem', () => {
    const categories: ICategory[] = [
      { name: 'Mock', id : 1, shortName: 'Mock', statusId: 5, isEditable: true },
      { name: 'Mock 2', id : 2, shortName: 'Mock 2', statusId: 5, isEditable: true }
    ];

    const app: AccordionItem[] = AccordionItem.transformCategories(categories);

    expect(app.length).toBe(2);

    expect(app[0].name).toBe('Mock');
    expect(app[0].id).toBe(1);

    expect(app[1].name).toBe('Mock 2');
    expect(app[1].id).toBe(2);
  });

  it('should return an empty array of AccordionItem', () => {
    const app: AccordionItem[] = AccordionItem.transformCategories(null);

    expect(app.length).toBe(0);
  });
});
