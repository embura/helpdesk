import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';
import { Segment } from '../../models/segment/segment';
import { SegmentService } from '../../services/segment/segment.service';
import { GenericDialog } from '../../models/dialog/generic-dialog';
import { MatDialog } from '@angular/material';
import { IFilterOption } from '../../models/filter/filter-object.interface';
import { UtilService } from '../../services/util/util.service';
import { ToastrService } from 'ngx-toastr';
import { CustomSuccessToastComponent } from '../toast/custom-success-toast.component';
import { CustomErrorToastComponent } from '../toast/custom-error-toast.component';

@Component({
    selector: 'app-cpt-segment',
    templateUrl: './segment.component.html',
    styleUrls: ['./segment.component.scss']
})
export class SegmentComponent implements OnInit, OnDestroy {
    public form: FormGroup;
    public segmentCodeExists = false;
    public segments: Segment[] = [];
    public segmentsItensEdit = [];
    public filtred = false;
    private subscriptions: Array<Subscription> = [];
    private genericDialog: GenericDialog;
    private dialogRef;
    private counter = 1;
    public showLoadingSpinner = false;
    public filterOptions: Array<IFilterOption> = [
        { id: 1, value: 'Ordenar por Código', orderBy: 'code', order: 'asc' },
        { id: 2, value: 'Ordenar por ordem alfabética', orderBy: 'name', order: 'asc' }
    ];
    public indexSegmentEdit = null;

    constructor(
        private dialog: MatDialog,
        private segmentService: SegmentService,
        private _fb: FormBuilder,
        private utilService: UtilService,
        private toastrService: ToastrService) {
        this.genericDialog = new GenericDialog(this.dialog);
        this.dialogRef = this.genericDialog.loadingMessage('Carregando Segmentos...');
    }

    ngOnInit(): void {
        this.createForm();
        this.loadSegments();
    }

    ngOnDestroy(): void {
        for (const subs of this.subscriptions) {
            subs.unsubscribe();
        }
    }

    public createForm(): void {
        this.form = this._fb.group({
            segmentCode: [null, Validators.compose([Validators.required, Validators.minLength(3)])],
            segmentName: ['', Validators.required],
            filter: [this.filterOptions[0]],
            textFilter: [''],
        });
        this.subscriptions.push(this.form.controls.segmentCode.valueChanges.debounceTime(300).subscribe(this.validateSegmentCode));
        this.subscriptions.push(this.form.controls.textFilter.valueChanges.debounceTime(300).subscribe(this.changeFilter));
    }

    public loadSegments(): void {
        this.segmentService.getSegments({ _limit: 15, _orderBy: this.form.value.filter.orderBy }).subscribe(result => {
            result.data.forEach((segment) => {
                this.segments.push(segment);
            });
            this.dialogRef.close();
        });
    }

    public validateSegmentCode = (): void => {
        this.form.controls.segmentCode.setValue(this.form.value.segmentCode.replace(/[^0-9\.]+/g, ''));
        if (this.form.controls.segmentCode && this.form.value.segmentCode.length === 3) {
            this.segmentService.getSegment(this.form.value.segmentCode).subscribe(result => {
                if (result.data && result.data.length > 0) {
                    this.segmentCodeExists = true;
                } else {
                    this.segmentCodeExists = false;
                }
            });
        } else {
            this.segmentCodeExists = false;
        }
    }

    public addSegment(): void {
        this.segmentService.addSegment(new Segment(this.form.value.segmentCode, this.form.value.segmentName))
            .subscribe(success => {
                if (success.data) {
                    this.segments = [];
                    this.counter = 1;
                    this.segmentService.getSegments({ _limit: 15, _orderBy: this.form.value.filter.orderBy }).subscribe(result => {
                        result.data.forEach((segment) => {
                            this.segments.push(segment);
                        });
                        this.createForm();
                        this.toastrService.success('Segmento adicionado com sucesso!', '', {
                            toastComponent: CustomSuccessToastComponent,
                          });
                    });
                }
            }, error => {
                this.createForm();
                const message = this.utilService.getServiceMessage(error.json(), 'Erro ao criar o parâmetro.');
                this.toastrService.error(message, '', {
                    toastComponent: CustomErrorToastComponent,
                  });
            });
    }

    public hoverSegment(event, segment): void {
        if (event.type === 'mouseenter') {
            if (!segment.isEditing) {
                segment.isHover = !segment.isHover;
            }
        } else {
            segment.isHover = false;
        }
    }

    public enableEditSegment(segment, index, input): void {

        if (this.indexSegmentEdit !== null && this.indexSegmentEdit !== index) {
            const indexSegmentEdit = this.indexSegmentEdit;
            this.indexSegmentEdit = null;
            this.enableEditSegment(this.segments[indexSegmentEdit], indexSegmentEdit, { disabled: false, focus: () => { } });
            this.segments[indexSegmentEdit].isHover = false;
        } else {
            this.indexSegmentEdit = null;
        }

        if (segment.isEditing) {
            segment.name = this.segmentsItensEdit[index];
            delete this.segmentsItensEdit[index];
        } else {
            this.segmentsItensEdit[index] = segment.name;
            this.indexSegmentEdit = index;
            input.disabled = false;
            input.focus();
        }

        segment.isEditing = !segment.isEditing;
        segment.isHover = !segment.isHover;
    }

    public editSegment(segmentEdit, segmentCode, segmentName, editableId): void {
        this.segmentService.editSegment(segmentEdit)
            .subscribe(success => {
                if (success.data) {
                    segmentEdit.isEditing = false;
                    segmentEdit.isHover = false;
                    this.indexSegmentEdit = null;
                    this.createForm();
                }
            }, error => {
                this.enableEditSegment(segmentEdit, editableId, { disabled: false, focus: () => { } });
                this.createForm();
                const message = this.utilService.getServiceMessage(error.json(), 'Erro ao criar o parâmetro.');
                this.toastrService.error(message, '', {
                    toastComponent: CustomErrorToastComponent,
                  });
            });
    }

    public async onScroll(): Promise<void> {
        const ordenation = { _limit: 15, _offset: this.counter * 15, _orderBy: this.form.value.filter.orderBy };
        if (this.form.value.textFilter && this.form.value.textFilter.length >= 3) {
            ordenation['_or'] = [
                'code:like:' + this.form.value.textFilter.trim(),
                'name:like:' + this.form.value.textFilter.trim()
            ];
        }
        const resp = await this.segmentService.getSegments(ordenation).toPromise();

        if (resp.return.code === 0) {
            resp.data.forEach((segment) => {
                this.segments.push(segment);
            });
            this.counter++;
        }
    }

    public changeFilter = (input: string): void => {
        if (this.form.value.textFilter && this.form.value.textFilter.length >= 2) {
            this.showLoadingSpinner = true;
            this.counter = 1;
            this.segments = [];
            const ordenation = { _limit: 15, _orderBy: this.form.value.filter.orderBy };
            ordenation['_or'] = [
                'code:like:' + this.form.value.textFilter.trim(),
                'name:like:' + this.form.value.textFilter.trim()
            ];
            this.segmentService.getSegments(ordenation).subscribe(result => {
                result.data.forEach((segment) => {
                    this.segments.push(segment);
                });
                this.showLoadingSpinner = false;
                this.filtred = true;
            });
        } else if (this.filtred || input === 'combobox') {
            this.showLoadingSpinner = true;
            this.counter = 1;
            this.segments = [];
            this.segmentService.getSegments({ _limit: 15, _orderBy: this.form.value.filter.orderBy }).subscribe(result => {
                result.data.forEach((segment) => {
                    this.segments.push(segment);
                });
                this.showLoadingSpinner = false;
                this.filtred = false;
            });
        }
    }

}
