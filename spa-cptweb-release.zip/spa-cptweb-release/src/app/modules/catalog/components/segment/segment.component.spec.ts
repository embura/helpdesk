// tslint:disable-next-line:snt-file-name-suffix
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { SegmentComponent } from './segment.component';
import { Observable } from 'rxjs/Observable';
import { IResponse } from '../../models/response/response.interface';
import { SegmentService } from '../../services/segment/segment.service';
import { Segment } from '../../models/segment/segment';
import { UtilService, IQuery } from '../../services/util/util.service';
import { MatDialogModule } from '@angular/material';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { ToastrService } from 'ngx-toastr';
import { GenericDialogComponent } from '../dialogs/generic/generic-dialog.component';
import { ToastrModule } from 'ngx-toastr';
import { CustomErrorToastComponent } from '../toast/custom-error-toast.component';
import { CustomSuccessToastComponent } from '../toast/custom-success-toast.component';
@NgModule({
    imports: [
        BrowserAnimationsModule,
        CommonModule,
        MatDialogModule,
        ToastrModule.forRoot()
    ],
    declarations: [SegmentComponent, GenericDialogComponent, CustomErrorToastComponent, CustomSuccessToastComponent],
    entryComponents: [SegmentComponent, GenericDialogComponent, CustomErrorToastComponent, CustomSuccessToastComponent],
    schemas: [NO_ERRORS_SCHEMA]
})

class TestModule { }

describe('SegmentComponent', () => {
    let component: SegmentComponent;
    let fixture: ComponentFixture<SegmentComponent>;
    let timeout;

    const segments: Segment[] = [
        {
            code: '003',
            name: 'VAN GOGH POTENCIAL',
            isEditing: false,
            id: 1,
            isHover: false
        },
        {
            code: '018',
            name: 'CORPORATE',
            isEditing: false,
            id: 2,
            isHover: false
        },
        {
            code: '010',
            name: 'CLASSICO',
            isEditing: false,
            id: 3,
            isHover: false
        }
    ];

    const mockService = {
        getSegments: (obj?: IQuery): Observable<IResponse<Segment[]>> => {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': '[Segment] Segments were found successfully.'
                },
                'data': segments
            });
        },
        addSegment: (segment: Segment): Observable<IResponse<Segment>> => {
            const newSegment: Segment = { code: segment.code, name: segment.name, isEditing: false, isHover: false };
            segments.push(newSegment);

            return Observable.of({
                'return': {
                    'code': 0,
                    'message': '[Segment] Segment was created successfully.'
                },
                'data': newSegment
            });
        },
        editSegment: (segment: Segment): Observable<IResponse<Segment>> => {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': '[Segment] Segment was edited successfully.'
                },
                'data': segment
            });
        },
        getSegment: (code: string): Observable<IResponse<Segment[]>> => {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': '[Segment] Segments were found successfully.'
                },
                'data': segments.filter(segment => segment.code === code)
            });
        }
    };

    const mockUtilService = {
        getServiceMessage: (param, defaultMessage: string): string => {
            if (param.return) {
                return param.return.message;
            } else if (param.message) {
                return param.message;
            }
            return defaultMessage;
        }
    };

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                TestModule,
                ReactiveFormsModule
            ],
            providers: [
                { provide: SegmentService, useValue: mockService },
                { provide: HubConnectorComponent, useClass: mockService },
                { provide: UtilService, useValue: mockUtilService },
                ToastrService
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(SegmentComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

        component = fixture.componentInstance;
    });

    beforeAll(() => {
        timeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
    });

    afterEach(() => {
        component.ngOnDestroy();
    });

    afterAll(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = timeout;
    });

    it('Segment Component should be truthy', () => {
        expect(component).toBeTruthy();
    });

    it('Should init component', () => {
        expect(() => component.ngOnInit()).not.toThrow();
    });

    it('valited code segment, code contains lyrics', () => {
        component.form.value.segmentCode = 'A';
        component.validateSegmentCode();
        expect(component.segmentCodeExists).toBe(false);
    });

    it('valited code segment exists', () => {
        component.form.value.segmentCode = '003';
        component.validateSegmentCode();
        expect(component.segmentCodeExists).toBe(true);
    });

    it('valited code segment not exist', () => {
        component.form.value.segmentCode = '888';
        component.validateSegmentCode();
        expect(component.segmentCodeExists).toBe(false);
    });

    it('should add a segment', () => {
        component.form.value.segmentCode = '888';
        component.form.value.segmentName = 'Teste Unitario';
        component.addSegment();
        expect(component.segments.length).toBe(4);
    });

    it('show return add response with error', () => {
        component['segmentService'].addSegment = (segment: Segment): Observable<IResponse<Segment>> => {
            return Observable.throw({
                'return': {
                    'code': 1,
                    'message': '[Segment] Segment was not created because of a error.'
                },
                'data': null,
                'json': () => {
                    return { 'message': '[Segment] Segment was not created because of a error.' };
                }
            });
        };
        component.form.value.segmentCode = '777';
        component.form.value.segmentName = 'Teste Unitario';
        component.addSegment();
        expect(component.segments.length).toBe(4);
    });

    it('should add a segment, else if not in', () => {
        component['segmentService'].addSegment = (segment: Segment): Observable<IResponse<Segment>> => {
            return Observable.of({
                'return': {
                    'code': 1,
                    'message': '[Segment] Segment was not created because of a error.'
                },
                'data': null
            });
        };
        component.form.value.segmentCode = '888';
        component.form.value.segmentName = 'Teste Unitario';
        component.addSegment();
        expect(component.segments.length).toBe(4);
    });

    it('hover item segment accordion', () => {
        component.hoverSegment({type: 'mouseenter'}, segments[0]);
        expect(component.segments.length).toBe(4);
    });

    it('hover item segment accordion, else operation', () => {
        const segment = new Segment('Teste', 'Teste');
        segment.isEditing = true;
        component.hoverSegment({type: 'mouseleave'}, segment);
        expect(component.segments.length).toBe(4);
    });

    it('hover item segment accordion, if not in else if', () => {
        const segment = new Segment('Teste', 'Teste');
        segment.isEditing = true;
        component.hoverSegment({type: 'mouseenter'}, segment);
        expect(component.segments.length).toBe(4);
    });

    it('change text filter, value valid', () => {
        component.form.value.textFilter = '03';
        component.changeFilter('text');
        expect(component.segments.length).toBe(4);
    });

    it('change text filter, filter already applied', () => {
        component.form.value.textFilter = null;
        component.filtred = true;
        component.changeFilter('text');
        expect(component.segments.length).toBe(4);
    });

    it('change text filter, filter not else if', () => {
        component.form.value.textFilter = null;
        component.filtred = false;
        component.changeFilter('text');
        expect(component.segments.length).toBe(4);
    });

    it('change text filter, by combobox', () => {
        component.form.value.textFilter = null;
        component.filtred = false;
        component.changeFilter('combobox');
        expect(component.segments.length).toBe(4);
    });

    it('scroll infinity, by or query', () => {
        component.form.value.textFilter = '03';
        component.form.value.orderBy = 'id';
        component.onScroll();
        expect(component.segments.length).toBe(4);
    });

    it('scroll infinity, else if not in', () => {
        component.form.value.textFilter = '0';
        component.form.value.orderBy = 'id';
        component.onScroll();
        expect(component.segments.length).toBe(4);
    });

    it('scroll infinity, error else', () => {
        component.form.value.textFilter = 'erro exception';
        component.form.value.orderBy = 'id';
        component['segmentService'].getSegments = (obj: IQuery): Observable<IResponse<Segment[]>> => {
            return Observable.of({
                'return': {
                    'code': 1,
                    'message': '[Segment] Segment was not fill all, because of a error.'
                },
                'data': null
            });
        };
        component.onScroll();
        expect(component.segments.length).toBe(4);
    });

    it('should editabled a segment', () => {
        component.enableEditSegment(segments[0], 0, { disabled: false, focus: () => { } });
        expect(component.segments.length).toBe(4);
    });

    it('should editabled a segment, else if not in', () => {
        const segment = new Segment('000', '000');
        segment.isEditing = true;
        component.indexSegmentEdit = 1;
        component.enableEditSegment(segment, 0, { disabled: false, focus: () => { } });
        expect(component.segments.length).toBe(4);
    });

    it('should edit a segment', () => {
        component.editSegment(segments[0], '003', 'Teste', 0);
        expect(component.segments.length).toBe(4);
    });

    it('should edit a segment, else if not in', () => {
        component.enableEditSegment(segments[0], 0, { disabled: false, focus: () => { } });
        component['segmentService'].editSegment = (segment: Segment): Observable<IResponse<Segment>> => {
            return Observable.of({
                'return': {
                    'code': 1,
                    'message': '[Segment] Segment was not created because of a error.'
                },
                'data': null
            });
        };
        component.editSegment(segments[0], '003', 'Teste', 0);
        expect(component.segments.length).toBe(4);
    });

    it('show return edit response with error', () => {
        component.enableEditSegment(segments[0], 0, { disabled: false, focus: () => { } });
        component['segmentService'].editSegment = (segment: Segment): Observable<IResponse<Segment>> => {
            return Observable.throw({
                'return': {
                    'code': 1,
                    'message': '[Segment] Segment was not edited because of a error.'
                },
                'data': null,
                'json': function () {
                    return {
                        'message': '[Segment] Segment was not edited because of a error.'
                    };
                }
            });
        };

        component.form.value.segmentCode = '003';
        component.form.value.segmentName = 'Teste Unitario';
        component.editSegment(segments[0], component.form.value.segmentCode, component.form.value.segmentName, 0);

        expect(component.segments.length).toBe(component.segments.length);
    });

});
