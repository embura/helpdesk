import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DateRangePickerComponent, IDateRange } from './date-range-picker.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { CatalogSharedModule } from './../../catalog-shared.module';
import { Daterangepicker } from 'ng2-daterangepicker';
import * as moment_ from 'moment';
const moment = moment_;

describe('Date range picker:', () => {
    let component: DateRangePickerComponent;
    let fixture: ComponentFixture<DateRangePickerComponent>;
    const value: IDateRange = {
        end: moment(new Date(2018, 4, 24)),
        start: moment(new Date(2018, 4, 24))
    };
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                CatalogSharedModule,
                Daterangepicker
            ],
            declarations: [DateRangePickerComponent],
            schemas: [NO_ERRORS_SCHEMA]
        }).compileComponents();
        fixture = TestBed.createComponent(DateRangePickerComponent);
        component = fixture.componentInstance;
    });

    it('should build an HTML template', () => {
        const template = component['buildTemplate']();
        expect(template).toContain('</h3>');
    });

    it('should validate date range', () => {
        const result = component['validDateRange'](value);
        expect(result).toBe(false);
    });

    it('should get date label', () => {
        const label = component.getLabel(value);
        expect(label).toContain('24/05/2018 a 24/05/2018');
    });

    it('should just emit date (doesn\'t have limits)', () => {
        component.rangeLimitInDays = false as any;
        expect(() => {
            component.selectedDate(value);
        }).not.toThrow();
    });

    it('should get a valid date while selecting', () => {
        component.rangeLimitInDays = true as any;
        component['validDateRange'] = () => true;
        expect(() => {
            component.selectedDate(value);
        }).not.toThrow();
    });

    it('should get a invalid date while selecting', () => {
        component.rangeLimitInDays = true as any;
        component['validDateRange'] = () => false;
        expect(() => {
            component.selectedDate(value);
        }).not.toThrow();
    });
});
