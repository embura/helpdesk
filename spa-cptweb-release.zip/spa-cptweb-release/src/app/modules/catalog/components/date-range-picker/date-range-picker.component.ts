import { Component, EventEmitter, Input, Output } from '@angular/core';
import * as moment_ from 'moment';
import { Moment } from 'moment';
const moment = moment_;

import { DaterangepickerConfig } from 'ng2-daterangepicker';

export interface IDateRange {
  start: Moment;
  end: Moment;
}

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'cpt-date-range-picker',
  templateUrl: './date-range-picker.component.html',
  styleUrls: ['./date-range-picker.component.scss']
})

export class DateRangePickerComponent {

  @Input() rangeLimitInDays: number;
  @Output() onSelectedRangeInvalid = new EventEmitter();
  @Output() onDateSelected = new EventEmitter<IDateRange>();

  invalidRange = false;
  dateRange: IDateRange;
  dateRangeLabel = '';
  rangesTitle = 'Datas rápidas';
  options: any = {
    locale: {
      format: 'DD/MM/YYYY',
      cancelLabel: 'Cancelar',
      applyLabel: 'Aplicar',
      daysOfWeek: ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'],
      monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
        'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro',
        'Dezembro']
    },
    template: this.buildTemplate(),
    alwaysShowCalendars: true,
    autoApply: true,
    showCustomRangeLabel: false,
    ranges: {
      Ontem: [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
      'Últimos 7 dias': [moment().subtract(6, 'days'), moment()],
      'Últimos 30 dias': [moment().subtract(29, 'days'), moment()],
      'Mês anterior': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    },
    opens: 'left',
    start: moment().subtract(6, 'days'),
    end: moment(),
    autoUpdateInput: false
  };

  constructor(private daterangepickerOptions: DaterangepickerConfig) {
    this.daterangepickerOptions.skipCSS = true;
  }

  private buildTemplate(): string {
    return `<div class="daterangepicker dropdown-menu">
              <link rel="stylesheet" href="../../../../../assets/css/font-awesome.min.css">
              <div class="calendar left">
                  <div class="daterangepicker_input">
                    <input class="input-mini form-control" type="text" name="daterangepicker_start" value="" />
                    <i class="fa fa-calendar glyphicon glyphicon-calendar"></i>
                    <div class="calendar-time">
                      <div></div>
                      <i class="fa fa-clock-o glyphicon glyphicon-time"></i>
                    </div>
                  </div>
                  <div class="calendar-table"></div>
              </div>
              <div class="calendar right">
                  <div class="daterangepicker_input">
                    <input class="input-mini form-control" type="text" name="daterangepicker_end" value="" />
                    <i class="fa fa-calendar glyphicon glyphicon-calendar"></i>
                    <div class="calendar-time">
                      <div></div>
                      <i class="fa fa-clock-o glyphicon glyphicon-time"></i>
                    </div>
                  </div>
                  <div class="calendar-table"></div>
              </div>
              <div class="ranges">
                <h3 class="ranges-title">${this.rangesTitle}</h3>
                <div class="range_inputs">
                  <button class="applyBtn" disabled="disabled" type="button"></button>
                  <button class="cancelBtn" type="button"></button>
              </div>
            </div>
          </div>`;
  }

  public selectedDate(value: IDateRange, datepicker?: any) {
    if (this.rangeLimitInDays) {
      if (this.validDateRange(value)) {
        this.invalidRange = false;
        this.dateRange = value;
      } else {
        this.invalidRange = true;
        this.onSelectedRangeInvalid.emit(value);
      }
      this.dateRangeLabel = this.getLabel(value);
    } else {
      this.dateRange = value;
    }
    this.onDateSelected.emit(this.dateRange);
  }

  public getLabel(value: IDateRange): string {
    const init: string = value.start.format('DD/MM/YYYY');
    const end: string = value.end.format('DD/MM/YYYY');
    return `${init} a ${end}`;
  }

  private validDateRange(value: IDateRange): boolean {
    return value.end.diff(value.start, 'days') < this.rangeLimitInDays;
  }
}
