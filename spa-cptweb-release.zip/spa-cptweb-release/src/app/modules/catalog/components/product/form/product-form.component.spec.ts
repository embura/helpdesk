// // tslint:disable-next-line:snt-file-name-suffix
// import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
// import { ProductFormComponent } from './product-form.component';
// import { CommonModule } from '@angular/common';
// import { ComponentFixture, TestBed, async, tick, fakeAsync, flush, flushMicrotasks } from '@angular/core/testing';
// import { MatCheckboxModule } from '@angular/material/checkbox';

// import { FormService } from '../../../services/form/form.service';
// import { ParameterService } from '../../../services/parameter/parameter.service';
// import { ToastrService } from 'ngx-toastr';

// import { IQuery, UtilService } from '../../../services/util/util.service';
// import { IResponse } from '../../../models/response/response.interface';

// import { Product, ProductForm, ProductFormField } from '../../../models/product/product';
// import { Parameter, IParameter } from '../../../models/parameter/parameter';

// import { By } from '@angular/platform-browser';
// import { Subject } from 'rxjs/Subject';

// import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
// import { Observable } from 'rxjs/Observable';
// import { IForm, IFormParameter } from '../../../models/form/form.interface';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import 'rxjs/add/observable/of';
// import { MatIcon, MatChip, MatChipList, MatIconModule } from '@angular/material';
// import { CatalogSharedModule } from '../../../catalog-shared.module';
// import { TextMaskModule } from 'angular2-text-mask';
// import { HubConnectorModule } from 'angl-spawebbgrl/spa-http-module/hub-connector.module';
// import { Http, HttpModule } from '@angular/http';
// import { SPAHttpService } from 'angl-spawebbgrl/spa-http-module/services/hub-connector-http.service';
// import { ConfigService } from 'angl-spawebbgrl/json-config-module/services/config.service';
// import { TranslateStaticLoader, TranslateLoader, TranslateModule } from 'ng2-translate';
// import { SharedModule } from './../../../../../shared.module';
// import { IProductParams, IProduct } from '../../../models/product/product.interface';


// export class MockToastrService {
//     public success = () => 'mock';
//     public error = () => 'mock';
// }

// @NgModule({
//     imports: [
//         CommonModule,
//         SharedModule,
//         FormsModule,
//         ReactiveFormsModule,
//         CatalogSharedModule,
//         MatCheckboxModule,
//         MatIconModule,
//         TextMaskModule,
//     ],
//     declarations: [
//         ProductFormComponent
//     ],
//     providers: [
//         FormService,
//         ParameterService,
//         { provide: ToastrService, useClass: MockToastrService },
//         { provide: HubConnectorComponent, useValue: {} },
//         { provide: 'appKey', useValue: 'mockAPPKEY' },
//         { provide: 'hubHost', useValue: 'mockHUBHOST' },
//         UtilService
//     ],
//     entryComponents: [ProductFormComponent]
// })

// class TestModule { }

// describe('Product Form Component', () => {
//     let component: ProductFormComponent;
//     let fixture: ComponentFixture<ProductFormComponent>;
//     const listIForm: IForm[] = [];
//     const iFormParameter: IFormParameter = {
//         formId: 1,
//         id: 1,
//         parameterId: 1,
//         paramOrder: 1,
//         required: 'no'
//     };
//     const listFormParameter: IFormParameter[] = [];
//     const iForm: IForm = {
//         id: 1,
//         name: 'teste 1',
//         statusId: 1,
//         isEditable: true,
//         formParameters: listFormParameter
//     };

//     const iProduct: IProduct = {
//         id: 1,
//         formId: 1,
//         modalityId: 1,
//         underlyingId: 1,
//         assetClassId: 1,
//         groupId: 1,
//         statusId: 1,
//         name: 'test 1',
//         params: [],
//         isOpen: true
//     };

//     listIForm.push({
//         id: 1,
//         name: 'teste 1',
//         statusId: 1,
//         isEditable: true,
//         formParameters: listFormParameter
//     });

//     const mockFormService = {
//         getForms(obj?: IQuery): Observable<IResponse<IForm[]>> {
//             return Observable.of({
//                 return: {
//                     code: 0,
//                     message: '[ProductForm] Form was found successfully.'
//                 },
//                 data: listIForm
//             });
//         },
//         getForm(obj?: IQuery): Observable<IResponse<IForm>> {
//             return Observable.of({
//                 return: {
//                     code: 0,
//                     message: '[ProductForm] Form was found successfully.'
//                 },
//                 data: listIForm[0]
//             });
//         }
//     };

//     beforeEach(() => {
//         TestBed.configureTestingModule({
//             imports: [
//                 TestModule,
//             ],
//             providers: [
//                 { provide: FormService, useValue: mockFormService }
//             ]
//         }).compileComponents();
//     });

//     beforeEach(() => {
//         fixture = TestBed.createComponent(ProductFormComponent);
//         component = fixture.componentInstance;
//         component['subscriptions'].pop();
//         fixture.detectChanges();
//     });

//     afterEach( () => {
//         // fixture = TestBed.createComponent(ProductFormComponent);
//         // component = fixture.componentInstance;
//         // component['subscriptions'].pop();
//     });

//     it('should create instan', () => {
//         expect(component).toBeTruthy();
//     });

//     it('Should set state isDuplication for true', () => {
//         component.isDuplication = true;
//         expect(component.isDuplication).toBeTruthy();
//     });

//     it('Should set proprety product', async () => {
//         component['product'] = iProduct;
//         expect(component['product'].name).toBe(iProduct.name);
//     });

//     it('Should open Form List', async () => {
//         await component.openFormList();
//         expect(component.popOverOpen).toBe(true);
//     });

//     it('Should return list forms', async () => {
//         await component.getForms();

//         expect(component.formListLoading).toBe(false);
//         expect(component['subscriptions'].length).toBe(1);
//     });

//     it('Should return fail on load list of the forms', async () => {
//         component['formService'].getForms = (obj?: IQuery): Observable<IResponse<IForm[]>> => {
//             return Observable.of({
//                 return: {
//                     code: 1,
//                     message: '[ProductForm] Form was fail.'
//                 },
//                 data: []
//             });
//         };
//         await component.getForms();

//         expect(component.formListLoading).toBe(false);
//         expect(component['subscriptions'].length).toBe(1);
//     });

//     it('Should select form ', async () => {
//         await component.selectForm(iForm);

//         expect(component.isSelectedForm(iForm)).toBeTruthy();
//     });

//     it('Should Exception getForms', async () => {

//         component['formService'].getForms = (obj?: IQuery): Observable<IResponse<IForm[]>> => {
//             return Observable.throw({
//                 return: {
//                     code: 1,
//                     message: '[ProductForm] Form was fail.'
//                 },
//                 data: []
//             });
//         };

//         await component.getForms();

//         expect(component.formListLoading).toBe(false);
//         expect(component['subscriptions'].length).toBe(1);
//     });

//     it('Should get Form Details ', () => {

//         component.model.selectedForm = new ProductForm();
//         component.getFormDetails(iProduct.formId);

//         console.log('model.selectedForm.fields: ', component['model']);

//         expect(component['model'].selectedForm.fields.length).toBe(0);
//     });

// });
