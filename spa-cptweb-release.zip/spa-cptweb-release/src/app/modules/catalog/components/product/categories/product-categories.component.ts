import {
    Component,
    OnInit,
    OnDestroy,
    Output,
    EventEmitter,
    Input,
    AfterViewInit
} from '@angular/core';
import { ICategory, IGroup } from '../../../models/category/category.interface';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { FamilyService } from '../../../services/category/family/family.service';
import { ToastrService } from 'ngx-toastr';
import { GroupService } from '../../../services/category/group/group.service';
import { AssetClassService } from '../../../services/category/asset-class/asset-class.service';
import { ModalityService } from '../../../services/category/modality/modality.service';
import { UnderlyingService } from '../../../services/category/underlying/underlying.service';
import { Subscription } from 'rxjs/Subscription';
import { ICategoryProduct, ICategories } from '../../../models/product/category-product.interface';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';


@Component({
    selector: 'app-cpt-product-categories',
    templateUrl: './product-categories.component.html',
    styleUrls: ['./product-categories.component.scss']
})
export class ProductCategoriesComponent implements AfterViewInit, OnDestroy {
    @Input() public categories: ICategoryProduct = { categories: null, isValid: false };
    @Input() public isEditing: boolean;
    @Input() public isDuplication: boolean;
    @Output() public dataChanged: EventEmitter<ICategoryProduct> = new EventEmitter<ICategoryProduct>();

    public families: ICategory[];
    public groups: IGroup[] = [];
    public assetClasses: ICategory[] = [];
    public modalities: ICategory[] = [];
    public underlyings: ICategory[] = [];
    public form: FormGroup;
    public familyLoading = false;
    public groupLoading = false;
    public assetClassLoading = false;
    public modalityLoading = false;
    public underlyingLoading = false;
    public subscriptions: Subscription[] = [];

    private formControls = [
        { name: 'family', isRequired: true },
        { name: 'group', isRequired: true },
        { name: 'assetClass', isRequired: false },
        { name: 'modality', isRequired: false },
        { name: 'underlying', isRequired: false },
    ];

    constructor(private _fb: FormBuilder,
        private familyService: FamilyService,
        private groupService: GroupService,
        private assetClassService: AssetClassService,
        private modalityService: ModalityService,
        private underlyingService: UnderlyingService,
        private toastrService: ToastrService) {
        this.addFields();
    }

    public ngAfterViewInit(): void {
        if (this.categories && this.categories.categories) {
            this.getFamilies(this.categories.categories.familyId);
            this.getGroups(this.categories.categories.familyId, this.categories.categories.groupId);
            this.getAssetClass(this.categories.categories.assetClassId);
            this.getModality(this.categories.categories.modalityId);
            this.getUnderlying(this.categories.categories.underlyingId);
        } else {
            this.categories = { categories: null, isValid: false };

            this.getFamilies();
            this.getAssetClass();
            this.getModality();
            this.getUnderlying();
        }
    }

    public ngOnDestroy(): void {
        this.subscriptions.forEach(subs => {
            subs.unsubscribe();
        });
    }

    public getFamilies(familyId?: number): void {
        this.subscriptions.push(
            this.form.controls.family.valueChanges
                .subscribe(value => {
                    this.getGroups(value.id);
                    this.clearFields(0);
                })
        );

        this.familyLoading = true;

        this.subscriptions.push(
            this.familyService.getAllFamilies(10)
                .subscribe(res => {
                    if (res.return.code === 0) {
                        this.families = res.data;

                        if (familyId) {
                            this.form.controls.family.setValue(this.families.find(fam => fam.id === familyId), { emitEvent: false });
                        }
                    } else {
                        this.toastrService.error('Ocorreu um erro ao recuperar famílias.', '', {
                            toastComponent: CustomErrorToastComponent,
                        });
                    }
                    this.familyLoading = false;
                }, err => {
                    this.toastrService.error('Ocorreu um erro ao recuperar famílias.', '', {
                        toastComponent: CustomErrorToastComponent,
                    });
                    this.familyLoading = false;
                })
        );
    }

    public getGroups(familyId: number, groupId?: number): void {
        this.groupLoading = true;

        this.subscriptions.push(
            this.groupService.getGroupsByFamily(familyId, 10)
                .subscribe(res => {
                    if (res.return.code === 0) {
                        this.groups = res.data;

                        if (groupId) {
                            this.form.controls.group.setValue(this.groups.find(grp => grp.id === groupId), { emitEvent: false });
                        }
                    } else {
                        this.toastrService.error('Ocorreu um erro ao recuperar os grupos.', '', {
                            toastComponent: CustomErrorToastComponent,
                        });
                    }
                    this.groupLoading = false;
                }, err => {
                    this.toastrService.error('Ocorreu um erro ao recuperar os grupos.', '', {
                        toastComponent: CustomErrorToastComponent,
                    });
                    this.groupLoading = false;
                })
        );
    }

    public getAssetClass(assetClassId?: number): void {
        this.assetClassLoading = true;

        this.subscriptions.push(
            this.assetClassService.getAllAssetClasses(10)
                .subscribe(res => {
                    if (res.return.code === 0) {
                        this.assetClasses = res.data;

                        if (assetClassId) {
                            this.form.controls.assetClass.setValue(
                                this.assetClasses.find(asse => asse.id === assetClassId), { emitEvent: false }
                            );
                        }
                    } else {
                        this.toastrService.error('Ocorreu um erro ao recuperar asset class.', '', {
                            toastComponent: CustomErrorToastComponent,
                        });
                    }
                    this.assetClassLoading = false;
                }, err => {
                    this.toastrService.error('Ocorreu um erro ao recuperar asset class.', '', {
                        toastComponent: CustomErrorToastComponent,
                    });
                    this.assetClassLoading = false;
                })
        );
    }

    public getModality(modalityId?: number) {
        this.modalityLoading = true;

        this.subscriptions.push(
            this.modalityService.getAllModalities(10)
                .subscribe(res => {
                    if (res.return.code === 0) {
                        this.modalities = res.data;

                        if (modalityId) {
                            this.form.controls.modality.setValue(
                                this.modalities.find(mod => mod.id === modalityId), { emitEvent: false }
                            );
                        }
                    } else {
                        this.toastrService.error('Ocorreu um erro ao recuperar modalidades.', '', {
                            toastComponent: CustomErrorToastComponent,
                        });
                    }

                    this.modalityLoading = false;
                }, err => {
                    this.toastrService.error('Ocorreu um erro ao recuperar modalidades.', '', {
                        toastComponent: CustomErrorToastComponent,
                    });
                    this.modalityLoading = false;
                })
        );
    }

    public getUnderlying(underlyingId?: number) {
        this.underlyingLoading = true;

        this.subscriptions.push(
            this.underlyingService.getAllUnderlyings(10)
                .subscribe(res => {
                    if (res.return.code === 0) {
                        this.underlyings = res.data;

                        if (underlyingId) {
                            this.form.controls.underlying.setValue(
                                this.underlyings.find(und => und.id === underlyingId), { emitEvent: false }
                            );
                        }
                    } else {
                        this.toastrService.error('Ocorreu um erro ao recuperar underlying.', '', {
                            toastComponent: CustomErrorToastComponent,
                        });
                    }
                    this.underlyingLoading = false;

                }, err => {
                    this.toastrService.error('Ocorreu um erro ao recuperar underlying.', '', {
                        toastComponent: CustomErrorToastComponent,
                    });
                    this.underlyingLoading = false;
                })
        );
    }

    public notValid(): boolean {
        return !this.form.pristine &&
            this.categories &&
            this.categories.categories &&
            Object.keys(this.categories.categories).filter(key => this.categories.categories[key] !== null).length < 5;
    }

    private addFields(): void {
        this.form = new FormGroup({});
        this.formControls.forEach((value, index) => {
            this.form.addControl(value.name, new FormControl(null, value.isRequired ? Validators.required : null));
            this.subscriptions.push(
                this.form.controls[value.name].valueChanges
                    .subscribe(frmValue => {
                        this.clearFields(index);
                    })
            );
        });
    }

    private clearFields(index: number): void {
        for (let frmIdx = index + 1; frmIdx < this.formControls.length; frmIdx++) {
            const formControl = this.form.controls[this.formControls[frmIdx].name];

            if (!this.isNull(formControl.value)) {
                formControl.setValue(null, { emitEvent: false });
            }
        }

        this.getCategoryId();
    }

    private getCategoryId() {
        const categories: ICategories = { familyId: null, groupId: null, assetClassId: null, modalityId: null, underlyingId: null };
        this.formControls.forEach(value => {
            const category: ICategory = this.form.controls[value.name].value;

            categories[value.name + 'Id'] = category ? category.id : null;
        });

        if (categories !== this.categories.categories) {
            this.categories.categories = categories;
            this.categories.isValid = this.form.valid && !this.notValid();
            this.dataChanged.emit(this.categories);
        }
    }

    private isNull(value: any) {
        return value === '' ||
            value === null ||
            value === undefined ||
            value === 'undefined';
    }
}
