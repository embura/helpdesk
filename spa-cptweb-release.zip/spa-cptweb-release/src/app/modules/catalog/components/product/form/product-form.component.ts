import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormService } from '../../../services/form/form.service';
import { ToastrService } from 'ngx-toastr';
import { IForm } from '../../../models/form/form.interface';
import { Product, ProductForm, ProductFormField } from '../../../models/product/product';
import { Subscription } from 'rxjs/Subscription';
import { ParameterService } from '../../../services/parameter/parameter.service';
import { Parameter, IParameter } from '../../../models/parameter/parameter';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { IProductParams, IProduct } from '../../../models/product/product.interface';
import { MatCheckbox } from '@angular/material';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';

@Component({
    selector: 'app-cpt-product-form',
    templateUrl: './product-form.component.html',
    styleUrls: ['./product-form.component.scss']
})
export class ProductFormComponent {
    constructor(private formService: FormService,
        private toastrService: ToastrService,
        private parameterService: ParameterService,
        private _fb: FormBuilder) { }

    private _product: IProduct;
    private _isDuplication = false;

    @Output() public emitShowAssignGroups: EventEmitter<boolean> = new EventEmitter<boolean>();

    @Input() set isDuplication(value: boolean) {
        if (typeof value === 'boolean') {
            this._isDuplication = value;
        }
    }
    get isDuplication(): boolean {
        return this._isDuplication;
    }

    @Input() private set product(value: IProduct) {
        this._product = value;

        if (value) {
            this.model.selectedForm = new ProductForm();
            this.model.selectedForm.id = value.formId;
            this.model.selectedForm.statusId = value.statusId;

            this.getFormDetails(value.formId);
        }
    }
    private get product(): IProduct {
        return this._product;
    }

    public popOverOpen: boolean;
    public formListLoading: boolean;
    public formList: IForm[] = [];
    public model: Product = new Product();
    public form: FormGroup;
    public hourMask: Array<RegExp | string> = [/\d/, /\d/, ':', /\d/, /\d/];
    public numberMask: Array<RegExp | string> = [/^(-)?/, /(\d)?/, /(\d)?/, /(\d)?/, /(\.|\,)?/,
        /(\d)?/, /(\d)?/, /(\d)?/, /(\d)?/, /(\d)?/, /(\d)?/, /(\d)?/, /(\d)?/, /(%)?$/g];
    public textMask: Array<RegExp | string> = [/a-zA-Z/g];
    public dateMask: Array<RegExp | string> = [/\d/, /\d/, '/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/];
    public minDate = new Date();

    private subscriptions: Subscription[] = [];
    private businessNameControl = { businessName: [this.product ? this.product.name : '', Validators.required] };
    public loadingForm: boolean;

    public openFormList(): void {
        this.popOverOpen = !this.popOverOpen;

        if (this.popOverOpen) {
            this.getForms();
        }
    }

    public getForms(): void {
        this.formListLoading = true;
        this.subscriptions.push(
            this.formService.getForms({ statusId: 10 })
                .subscribe(res => {
                    if (res.return.code === 0) {
                        this.formList = res.data;
                    } else {
                        this.toastrService.error('Ocorreu um erro ao recuperar a lista de formulários.', '', {
                            toastComponent: CustomErrorToastComponent,
                        });
                    }

                    this.formListLoading = false;
                }, err => {
                    this.toastrService.error('Ocorreu um erro ao recuperar a lista de formulários.', '', {
                        toastComponent: CustomErrorToastComponent,
                    });

                    this.formListLoading = false;
                })
        );
    }

    public isSelectedForm(item: IForm): boolean {
        return this.model && this.model.selectedForm && this.model.selectedForm.id === item.id;
    }

    public selectForm(item: IForm): void {
        this.product = null;
        this.model.selectedForm = new ProductForm();
        this.model.selectedForm.id = item.id;
        this.model.selectedForm.name = item.name;
        this.model.selectedForm.statusId = 10;
        this.getFormDetails(item.id);
        this.popOverOpen = false;
        this.emitShowAssignGroups.emit(true);
    }

    public getFormDetails(formId: number) {
        this.loadingForm = true;
        this.emitShowAssignGroups.emit(true);
        this.createForm();
        this.subscriptions.push(
            this.formService.getForm(formId)
                .subscribe(res => {
                    if (res.return.code === 0) {
                        this.model.selectedForm.id = res.data.id;
                        this.model.selectedForm.name = res.data.name;

                        if (res.data.formParameters) {
                            res.data.formParameters = res.data.formParameters.sort(
                                (paramA, paramB) => paramA.paramOrder - paramB.paramOrder);

                            this.model.selectedForm.fields = new Array();

                            res.data.formParameters.forEach(value => {
                                const formField: ProductFormField = new ProductFormField();
                                if (value.info.typeId === 3 || value.info.typeId === 4) {
                                    this.getParameterOptions(value.info, formField);
                                }

                                formField.name = value.info.name;
                                formField.param = value.info;
                                formField.required = value.required === 'S';
                                formField.paramId = value.id;
                                formField.id = this.fillFormId(formField.paramId);

                                const formValue = this.fillFormValue(formField.paramId, formField.param.typeId);

                                this.form.addControl(this.getFieldName(formField.name),
                                    new FormControl(formValue, value.required === 'S' ? Validators.required : null));

                                this.model.selectedForm.fields.push(formField);
                            });
                        }
                    } else {
                        this.toastrService.error('Ocorreu um erro ao recuperar os detalhes do formulário', '', {
                            toastComponent: CustomErrorToastComponent,
                        });
                    }

                    this.loadingForm = false;
                }, err => {
                    this.toastrService.error('Ocorreu um erro ao recuperar os detalhes do formulário', '', {
                        toastComponent: CustomErrorToastComponent,
                    });
                    this.loadingForm = false;
                })
        );
    }

    public getParameterOptions(paramter: IParameter, formField: ProductFormField) {
        formField.isLoading = true;

        this.subscriptions.push(
            this.parameterService.getOptions(paramter.id, 10).subscribe(resOptions => {
                if (resOptions.return.code === 0) {
                    paramter.options = resOptions.data.filter(f => f.statusId === 10);
                    formField.param = paramter;
                } else {
                    this.toastrService.error('Ocorreu um erro ao recuperar as opções do campo ', '', {
                        toastComponent: CustomErrorToastComponent,
                    });
                }

                formField.isLoading = false;
            }, err => {
                this.toastrService.error('Ocorreu um erro ao recuperar as opções do campo ', '', {
                    toastComponent: CustomErrorToastComponent,
                });
                formField.isLoading = false;
            })
        );
    }

    public getFieldName(field: string): string {
        field = field.replace(/ /g, '');
        field = field.toLowerCase();

        return field;
    }

    public validateAllFormFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched({ onlySelf: true });
            } else if (control instanceof FormGroup) {
                this.validateAllFormFields(control);
            }
        });
    }

    public getMask(id: number): Array<RegExp | string> {
        switch (id) {
            case 2:
                return this.numberMask;
            case 3:
                return this.textMask;
            case 4:
                return this.hourMask;
            default:
                return null;
        }
    }

    public removeCharacters(event, validationId: number, formControlName: string) {
        if (validationId === 2) {
            event.target.value = event.target.value.replace(/[^!(\d\%\+\-\,\.)]/g, '');
        } else if (validationId === 3) {
            event.target.value = event.target.value.replace(/[^A-Za-z|\u00C0-\u00FF| ]+/g, '');
        }

        this.form.controls[this.getFieldName(formControlName)].setValue(event.target.value, { emitEvent: false });
    }

    public getData(): IProduct {
        const product: IProduct = {
            id: this.product ? this.product.id : null,
            groupId: 0,
            assetClassId: 0,
            modalityId: 0,
            underlyingId: 0,
            formId: this.model.selectedForm.id,
            statusId: this.model.selectedForm.statusId,
            name: '',
            params: [],
            groupsSegments: [],
            isOpen: false
        };
        Object.keys(this.form.controls).forEach(key => {
            if (key === 'businessName') {
                product.name = this.form.controls[key].value;
            } else {
                const formField: ProductFormField = this.model.selectedForm.fields.find(fld => this.getFieldName(fld.name) === key);

                if (formField && formField.param.typeId === 3) {
                    const formValue = this.form.controls[key].value as number[];

                    formValue.forEach(vlr => {
                        const param: IProductParams = {
                            id: formField.id,
                            productId: this.product ? this.product.id : null,
                            parameterId: formField.paramId,
                            value: vlr.toString(),
                            isPrimaryKey: false
                        };

                        product.params.push(param);
                    });
                } else if (formField) {
                    const param: IProductParams = {
                        id: formField.id,
                        productId: this.product ? this.product.id : null,
                        parameterId: formField.paramId,
                        value: this.form.controls[key].value,
                        isPrimaryKey: formField.param.typeId === 6
                    };

                    product.params.push(param);
                }
            }
        });

        return product;
    }

    public optionChecked(fieldName: string, optionValue: number, checkbox: MatCheckbox) {
        const fieldValue = this.form.controls[this.getFieldName(fieldName)].value as number[];
        const valueExists = fieldValue.filter(vlr => vlr === optionValue);

        // check if option already exists
        if (checkbox.checked && valueExists.length === 0) {
            fieldValue.push(optionValue);
        } else if (!checkbox.checked && valueExists) {
            valueExists.forEach(itm => {
                fieldValue.splice(fieldValue.findIndex(idx => idx === optionValue), 1);
            });
        }

        this.form.controls[this.getFieldName(fieldName)].setValue(fieldValue);
    }

    public setFormTouched(fieldName: string) {
        this.form.controls[this.getFieldName(fieldName)].markAsTouched({ onlySelf: true });
    }

    public invalidCheckbox(field: ProductFormField): boolean {
        return field.required &&
            this.form.controls[this.getFieldName(field.name)].touched &&
            this.form.controls[this.getFieldName(field.name)].value.length === 0;
    }

    public fillFormId(paramId: number): number {
        if (this.product && this.product.params) {
            const param = this.product.params.find(prm => prm.parameterId === paramId);

            return param ? param.id : null;
        }

        return null;
    }

    public fillFormValue(paramId: number, paramTypeId: number): string | number[] | number {
        let value: string | number[] | number = paramTypeId === 3 ? new Array<number>() : '';
        if (this.product && this.product.params) {
            if (paramTypeId === 3) {
                const options = this.product.params.filter(opt => opt.parameterId === paramId);

                if (options) {
                    options.forEach(opt => {
                        (value as number[]).push(+opt.value);
                    });
                }
            } else {
                const param = this.product.params.find(prm => prm.parameterId === paramId);

                if (param) {
                    value = param.value;

                    if (paramTypeId === 4) {
                        value = +param.value;
                    }
                }
            }
        }

        return value;
    }

    public createForm() {
        if (this.product) {
            this.form = this._fb.group({
                businessName: [this.product.name, Validators.required]
            });
        } else {
            this.form = this._fb.group(this.businessNameControl);
        }
    }

    public isChecked(field: ProductFormField, id: number) {
        return (this.form.controls[this.getFieldName(field.name)].value as number[]).find(str => str === id);
    }
}
