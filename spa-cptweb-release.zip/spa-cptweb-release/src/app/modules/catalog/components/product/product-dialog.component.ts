import { Component, Inject, ViewChild, Optional } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ICategoryProduct } from '../../models/product/category-product.interface';
import { ProductFormComponent } from './form/product-form.component';
import { IProduct } from '../../models/product/product.interface';
import { ProductService } from '../../services/product/product.service';
import { ToastrService } from 'ngx-toastr';
import { UtilService } from '../../services/util/util.service';
import { GroupSegment } from '../../models/product/group-segment/group-segment';
import { CustomSuccessToastComponent } from '../toast/custom-success-toast.component';
import { CustomErrorToastComponent } from '../toast/custom-error-toast.component';

export interface IProductDialogParam {
    product: IProduct;
    isDuplication: boolean;
}

@Component({
    selector: 'app-cpt-product-dialog',
    templateUrl: './product-dialog.component.html',
    styleUrls: ['./product-dialog.component.scss']
})
export class ProductDialogComponent {
    @ViewChild(ProductFormComponent) private productForm: ProductFormComponent;
    public product: IProduct;
    public productId: number;
    public isEditing = false;
    constructor(public dialogRef: MatDialogRef<ProductDialogComponent, any>,
        private productService: ProductService,
        private toastrService: ToastrService,
        private serviceUtil: UtilService,
        @Optional() @Inject(MAT_DIALOG_DATA) public data: IProductDialogParam) {
        this.fillModel();
    }

    public title = 'Inclusão';
    public categoryProduct: ICategoryProduct;
    public showAssignGroups = false;
    public groupsSegements: GroupSegment[] = [];

    public savingProduct: boolean;

    public closeDialog(): void {
        this.dialogRef.close();
    }

    public categoryChanged(categories: ICategoryProduct): void {
        this.categoryProduct = categories;
    }

    public isValid(): boolean {

        let existGroupSegmentEditing = [];

        if (this.groupsSegements) {
            existGroupSegmentEditing = this.groupsSegements.filter(currentGroupSegment => {
                return currentGroupSegment.isEditing;
            });
        }

        return this.categoryProduct &&
            this.groupsSegements &&
            existGroupSegmentEditing.length === 0 &&
            this.categoryProduct.isValid &&
            this.productForm.form &&
            this.productForm.form.valid &&
            (this.data.isDuplication ? this.productForm.form.dirty : true);
    }

    public submit() {
        this.productForm.validateAllFormFields(this.productForm.form);

        const product: IProduct = this.productForm.getData();

        product.groupId = this.categoryProduct.categories.groupId;
        product.assetClassId = this.categoryProduct.categories.assetClassId;
        product.modalityId = this.categoryProduct.categories.modalityId;
        product.underlyingId = this.categoryProduct.categories.underlyingId;
        product.groupsSegments = this.groupsSegements;

        if (this.productForm.form.valid) {
            if (this.product && this.product.id) {
                this.updateProduct(product);
            } else {
                this.createProduct(product);
            }
        }
    }

    public createProduct(product: IProduct): void {
        this.savingProduct = true;
        this.productService.createProduct(product)
            .subscribe(res => {
                if (res.return.code === 0) {
                    this.toastrService.success( 'Produto criado com sucesso!', '', {
                        toastComponent: CustomSuccessToastComponent,
                      });
                    this.dialogRef.close();
                } else {
                    this.toastrService.error( res.return.message, '', {
                        toastComponent: CustomErrorToastComponent,
                      });
                }

                this.savingProduct = false;
            }, err => {
                this.toastrService.error( this.serviceUtil.getServiceMessage(err.json(), 'Ocorreu um erro ao criar o produto'), '', {
                    toastComponent: CustomErrorToastComponent,
                  });

                this.savingProduct = false;
            });
    }

    public updateProduct(product: IProduct): void {
        this.savingProduct = true;
        this.productService.updateProduct(product)
            .subscribe(resp => {
                if (resp.return.code === 0) {
                    this.toastrService.success( 'Produto atualizado com sucesso!', '', {
                        toastComponent: CustomSuccessToastComponent,
                      });
                    this.dialogRef.close();
                } else {
                    this.toastrService.error( resp.return.message, '', {
                        toastComponent: CustomErrorToastComponent,
                      });
                }
                this.savingProduct = false;

            }, err => {
                this.toastrService.error( this.serviceUtil.getServiceMessage(err.json(), 'Ocorreu um erro ao atualizar o produto'), '', {
                    toastComponent: CustomErrorToastComponent,
                  });
                this.savingProduct = false;
            });
    }

    public fillModel(): void {
        if (this.data && this.data.product) {

            this.productId = this.data.product.id;

            if (this.data.isDuplication) {
                delete this.data.product.id;
                this.title = 'Duplicar';
            } else {
                this.title = 'Editar';
            }

            this.data.product.id ? this.isEditing = true : this.isEditing = false;

            this.product = this.data.product;


            this.categoryProduct = {
                categories: {
                    familyId: this.product.familyId,
                    groupId: this.product.groupId,
                    assetClassId: this.product.assetClassId,
                    modalityId: this.product.modalityId,
                    underlyingId: this.product.underlyingId
                },
                isValid: true
            };
        }
    }

    public setGroupsSegments(groupsSegments): void {
        this.groupsSegements = groupsSegments;
    }

}
