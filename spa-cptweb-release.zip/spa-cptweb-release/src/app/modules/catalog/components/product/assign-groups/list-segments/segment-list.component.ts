import { Component, OnInit, Output, EventEmitter, ElementRef, ViewChild, AfterViewInit, OnDestroy, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Segment } from '../../../../models/segment/segment';
import { SegmentService } from '../../../../services/segment/segment.service';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-cpt-segment-list',
  templateUrl: './segment-list.component.html',
  styleUrls: ['./segment-list.component.scss']
})
export class SegmentListComponent implements OnInit, AfterViewInit, OnDestroy {
  public segmentList = [];
  public segmentListAcc = [];
  public checkedList = [];
  public toHideList = [];
  public segmentListView = [];
  public loading = false;
  public scrollLoading = false;
  public counter = 1;
  public inputBox;
  public quantity = 9;

  constructor(
    public segmentService: SegmentService,
  ) { }

  @ViewChild('segments') list;
  @ViewChild('textInput') searchInput: ElementRef;
  @Input() public toHideListChange: Subject<Segment[]>;
  @Input() selectionEmitter: Subject<Segment[]>;
  @Output() public listChanged: EventEmitter<any[]> = new EventEmitter<any[]>();

  ngOnInit(): void {
    this.loadSegments();
  }

  ngAfterViewInit() {
    this.inputBox = Observable.fromEvent(this.searchInput.nativeElement, 'keyup')
      .debounceTime(400)
      .subscribe((ev: any) => {
        this.counter = 1;
        return this.loadSegments(ev.target.value.toLowerCase());
      });

    this.selectionEmitter.subscribe(() => {
      this.checkedList = [];
      setTimeout(this.updateSegmentListView);
    });

    this.toHideListChange.subscribe(list => {
      this.toHideList = list;
      this.listChanged.emit([]);
      this.updateSegmentListView();
    });
  }

  ngOnDestroy() {
    this.inputBox.unsubscribe();
    this.toHideListChange.unsubscribe();
    this.selectionEmitter.unsubscribe();
  }

  updateSegmentListView() {

    if (this.segmentList) {
      this.segmentListView = this.segmentList.filter(seg => {
        const hideListCodes = this.toHideList.map(segment => segment.code);
        return hideListCodes.indexOf(seg.code) < 0;
      });
    }

    if (this.segmentListView) {
      this.segmentListView = this.segmentListView.map(seg => {
        if (this.checkedList.indexOf(seg.code) >= 0) {
          seg.checked = true;
        } else {
          seg.checked = false;
        }
        return seg;
      });
    }

  }

  onSelectionChanged(segCode, checked): void {
    if (checked) {
      this.checkedList.push(segCode);
    } else {
      const position = this.checkedList.indexOf(segCode);
      this.checkedList.splice(position, 1);
    }

    // removes duplicates
    this.checkedList = this.checkedList.filter(function (item, pos, array) {
      return array.indexOf(item) === pos;
    });

    this.listChanged.emit(this.getSegmentsToExport());
    this.updateSegmentListView();
  }

  getSegmentsToExport() {
    // gets the full segment object list (without the checked property) from a code list
    const list = this.checkedList.map(code => this.segmentListAcc.filter(segmentInArray => segmentInArray.code === code)[0]);
    // returns a list without elements already on the right-hand side
    return list.filter(segment => this.toHideList.indexOf(segment) < 0);
  }

  loadSegments(value?): void {
    const ordenation = {};
    this.segmentList = [];
    this.loading = true;

    if (value) {
      ordenation['_or'] = ['code:like:' + value.trim(), 'name:like:' + value.trim()];
    }

    this.segmentService.getSegments(ordenation).subscribe(result => {
      result.data.forEach(segment => {
        this.segmentList.push(segment);
        this.segmentListAcc.push(Object.assign({}, segment));
      });
      this.updateSegmentListView();
      this.loading = false;
    });
  }
}
