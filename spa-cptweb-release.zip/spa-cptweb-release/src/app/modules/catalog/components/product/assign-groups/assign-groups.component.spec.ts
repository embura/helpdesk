// tslint:disable-next-line:snt-file-name-suffix
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { Segment } from '../../../models/segment/segment';
import { AssignGroupsComponent } from './assign-groups.component';
import { By } from '@angular/platform-browser';
@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [AssignGroupsComponent ],
    entryComponents: [AssignGroupsComponent ],
    schemas: [NO_ERRORS_SCHEMA]
})

class TestModule { }


const segments: Segment[] = [
    {
        code: '003',
        name: 'VAN GOGH POTENCIAL',
        isEditing: false,
        id: 1,
        isHover: false
    },
    {
        code: '002',
        name: 'CORPORATE',
        isEditing: false,
        id: 2,
        isHover: false
    },
    {
        code: '055',
        name: 'NRA 55',
        isEditing: false,
        id: 3,
        isHover: false
    },
    {
        code: '004',
        name: 'CLASSICO 4',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '005',
        name: 'CLASSICO 5',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '006',
        name: 'CLASSICO 6',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '007',
        name: 'EXPERT 1',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '008',
        name: 'EXPERT 2',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '009',
        name: 'NORMAL X',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '010',
        name: 'NORMAL 2',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '011',
        name: 'LOW 2',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '012',
        name: 'LOW 3',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '013',
        name: 'CLASSICO EXPERT',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '014',
        name: 'MAX 1',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '015',
        name: 'MAX 2',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '016',
        name: 'CORPORATE AD',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '017',
        name: 'CLASSICO AS',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '018',
        name: 'MEDIUM',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '019',
        name: 'LIGHT',
        isEditing: false,
        id: 4,
        isHover: false
    },
    {
        code: '030',
        name: 'HARD',
        isEditing: false,
        id: 20,
        isHover: false
    }
];


describe('assign-groups-component', () => {
    let component: AssignGroupsComponent;
    let fixture: ComponentFixture<AssignGroupsComponent>;
    let timeout;
    let nativeElement;
    let debugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                TestModule
            ],
            providers: []
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(AssignGroupsComponent);
        component = fixture.componentInstance;
        nativeElement = fixture.nativeElement;
        debugElement = fixture.debugElement;
        fixture.detectChanges();
    });

    beforeAll(() => {
        timeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
    });

    afterAll(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = timeout;
    });

    it('Assign Groups Component should be truthy', () => {
        expect(component).toBeTruthy();
    });

    it('Should receive and store a list of current selected segments on the left-side component', fakeAsync(() => {
        const segmentListComponent = debugElement.query(By.css('app-cpt-segment-list'));
        segmentListComponent.triggerEventHandler('listChanged', segments);
        tick(300);
        expect(component.selectedSegmentsList).toEqual(segments);
    }));

    it('Should emit a list of segments when the Add Button is clicked', fakeAsync(() => {
        let receivedData;
        component.selectedSegmentsList = segments;
        component.selectionEmitter.subscribe(data => {
            receivedData = data;
        });
        const addButtonDe = debugElement.query(By.css('.add-text'));
        addButtonDe.triggerEventHandler('click', null);
        tick(300);
        expect(receivedData).toEqual(segments);
    }));

    it('Should emit a list of segments when the Arrow is clicked', fakeAsync(() => {
        let receivedData;
        component.selectedSegmentsList = segments;
        component.selectionEmitter.subscribe(data => {
            receivedData = data;
        });
        const addArrowDe = debugElement.query(By.css('.add-arrow'));
        addArrowDe.triggerEventHandler('click', null);
        tick(300);
        expect(receivedData).toEqual(segments);
    }));

    it('Should receive and then emit the list of segments of the current group', fakeAsync(() => {
        let receivedData;
        const groupsComponent = debugElement.query(By.css('app-cpt-groups'));
        component.toHideListChange.subscribe(data => {
            receivedData = data;
        });
        groupsComponent.triggerEventHandler('addedList', segments);
        tick(300);
        expect(receivedData).toEqual(segments);
    }));

});
