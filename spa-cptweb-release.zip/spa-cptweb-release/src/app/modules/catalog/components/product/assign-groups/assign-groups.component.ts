import { Component, EventEmitter, Output, Input } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Product } from '../../../models/product/product';
import { IProduct } from '../../../models/product/product.interface';
import { GroupSegment } from '../../../models/product/group-segment/group-segment';

@Component({
    selector: 'app-cpt-assign-groups',
    templateUrl: './assign-groups.component.html',
    styleUrls: ['./assign-groups.component.scss']
})
export class AssignGroupsComponent {
    public selectedSegmentsList = [];
    public selectionEmitter: Subject<any> = new Subject();
    public toHideListChange: Subject<any> = new Subject();
    public allClosed = false;

    @Input() productId?: number;
    @Output() public emitGroupsSegments: EventEmitter<GroupSegment[]> = new EventEmitter<GroupSegment[]>();

    constructor() {
    }

    onSelectionChange(selection: any) {
        this.selectedSegmentsList = selection;
    }

    onAddSelected() {
        this.selectionEmitter.next(this.selectedSegmentsList);
    }

    onAddedListChange(currentList) {
        this.toHideListChange.next(currentList);
    }

    emitterGroupsSegments(groupsSegments) {
        this.emitGroupsSegments.emit(groupsSegments);
        const allClosed = groupsSegments.filter(currentGroup => {
            return currentGroup.isOpen === true;
        });
        this.allClosed = (allClosed.length === 0);
    }

}
