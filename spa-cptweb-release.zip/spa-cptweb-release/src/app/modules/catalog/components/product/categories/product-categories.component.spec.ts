// tslint:disable-next-line:snt-file-name-suffix
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { ProductCategoriesComponent } from './product-categories.component';
import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, async, tick, fakeAsync, flush, flushMicrotasks } from '@angular/core/testing';
import { Observable } from 'rxjs/Observable';
import { By } from '@angular/platform-browser';
import { Subject } from 'rxjs/Subject';
import { ToastrModule } from 'ngx-toastr';
import { FamilyService } from '../../../services/category/family/family.service';
import { GroupService } from '../../../services/category/group/group.service';
import { AssetClassService } from '../../../services/category/asset-class/asset-class.service';
import { ModalityService } from '../../../services/category/modality/modality.service';
import { UnderlyingService } from '../../../services/category/underlying/underlying.service';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { ICategory, IGroup } from '../../../models/category/category.interface';
import { IResponse } from '../../../models/response/response.interface';
import { FormBuilder } from '@angular/forms';

@NgModule({
    imports: [
        CommonModule,
        ToastrModule.forRoot({
            timeOut: 3000,
            positionClass: 'toast-bottom-center'
        }),
    ],
    declarations: [ProductCategoriesComponent, CustomErrorToastComponent],
    entryComponents: [ProductCategoriesComponent, CustomErrorToastComponent],
    schemas: [NO_ERRORS_SCHEMA]
})
class TestModule { }

const families: ICategory[] = [
    {
      'id': 1,
      'name': 'Estruturados',
      'shortName': 'Estruturados',
      'statusId': 5,
      'isEditable': true
    },
    {
      'id': 2,
      'name': 'Renda Fixa',
      'shortName': 'Renda Fixa',
      'statusId': 5,
      'isEditable': true
    }
];

const groups: IGroup[] = [
    {
        id: 1,
        name: 'grupo1',
        statusId: 10,
        shortName: 'sh-group',
        isEditable: true,
        familyId: 2,
        technicalName: ' '
    }
];

describe('Segment-List Component', () => {
    let component: ProductCategoriesComponent;
    let fixture: ComponentFixture<ProductCategoriesComponent>;
    let timeout;
    let nativeElement;
    let debugElement;

    const mockFamilyService = {
        getAllFamilies: (): Observable<IResponse<ICategory[]>> => {
            return Observable.of({
              'return': {
                'code': 0,
                'message': '[Category] Families were found successfully.'
              },
              'data': families
            });
          },
    };

    const mockGroupService = {
        getGroupsByFamily(familyId: number): Observable<IResponse<IGroup[]>> {
            return Observable.of({
                'return': {
                  'code': 0,
                  'message': 'Groups were found successfully.'
                },
                'data': groups
              });
          }
    };

    const mockAssetClassService = {
        getAllAssetClasses(): Observable<IResponse<ICategory[]>> {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': 'Assets Classes consultados com sucesso'
                },
                'data': families
            });
        }
    };

    const mockModalityService = {
        getAllModalities(): Observable<IResponse<ICategory[]>> {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': 'Modalities consultados com sucesso'
                },
                'data': families
            });
        }
    };

    const mockUnderlyingService = {
        getAllUnderlyings(): Observable<IResponse<ICategory[]>> {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': 'Modalities consultados com sucesso'
                },
                'data': families
            });
        }
    };

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                TestModule
            ],
            providers: [
                FormBuilder,
                { provide: FamilyService, useValue: mockFamilyService },
                { provide: GroupService, useValue: mockGroupService },
                { provide: AssetClassService, useValue: mockAssetClassService },
                { provide: ModalityService, useValue: mockModalityService },
                { provide: UnderlyingService, useValue: mockUnderlyingService }
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(ProductCategoriesComponent);
        component = fixture.componentInstance;
        nativeElement = fixture.nativeElement;
        debugElement = fixture.debugElement;
        // fixture.detectChanges();
    });

    afterEach(() => {
        component.ngOnDestroy();
    });

    beforeAll(() => {
        timeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
    });

    afterAll(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = timeout;
    });

    it('Segment List Component should be truthy', () => {
        expect(component).toBeTruthy();
    });

    it('Should init component', () => {
        expect(() => component.ngAfterViewInit()).not.toThrow();
    });

    // it('Should load a list of groups on initialization', fakeAsync(() => {
    //     component.ngOnInit();
    //     tick(500);
    //     fixture.detectChanges();
    //     expect(component.groups[0].id).toEqual(45);
    // }));

    // it('Should render a segment emitted by the parent component', fakeAsync(() => {
    //     component.selectionEmitter = new Subject();
    //     tick(300);
    //     component.ngOnInit();
    //     fixture.detectChanges();
    //     tick(300);
    //     expect(nativeElement.textContent).not.toContain('CLASSICO 5');
    //     component.selectionEmitter.next([segments[4]]);
    //     component.selectionEmitter.unsubscribe();
    //     fixture.detectChanges();
    //     expect(nativeElement.textContent).toContain('CLASSICO 5');
    // }));

    // it('Should add a new group', fakeAsync(() => {
    //     component.ngOnInit();
    //     fixture.detectChanges();
    //     tick(300);
    //     component.groups = [];
    //     component.addGroup();
    //     tick(500);
    //     fixture.detectChanges();
    //     expect(component.groups.length).toBe(1);
    // }));

    // it('Should remove a group', fakeAsync(() => {
    //     component.ngOnInit();
    //     fixture.detectChanges();
    //     tick(300);
    //     const initialGroups = component.groups.length;
    //     component.removeGroup(1);
    //     tick(500);
    //     fixture.detectChanges();
    //     expect(component.groups.length).toBe(initialGroups - 1);
    // }));

});
