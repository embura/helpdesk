// tslint:disable-next-line:snt-file-name-suffix
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { SegmentListComponent } from './segment-list.component';
import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, async, tick, fakeAsync, flush, flushMicrotasks } from '@angular/core/testing';
import { Observable } from 'rxjs/Observable';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { SegmentService } from '../../../../services/segment/segment.service';
import { IQuery } from '../../../../services/util/util.service';
import { IResponse } from '../../../../models/response/response.interface';
import { Segment } from '../../../../models/segment/segment';
import { By } from '@angular/platform-browser';
import { Subject } from 'rxjs/Subject';

@NgModule({
    imports: [
        CommonModule,
        MatCheckboxModule
    ],
    declarations: [SegmentListComponent],
    entryComponents: [SegmentListComponent],
    schemas: [NO_ERRORS_SCHEMA]
})
class TestModule { }

describe('Segment-List Component', () => {
    let component: SegmentListComponent;
    let fixture: ComponentFixture<SegmentListComponent>;
    let timeout;
    let nativeElement;
    let debugElement;

    const segments: Segment[] = [
        {
            code: '003',
            name: 'VAN GOGH POTENCIAL',
            isEditing: false,
            id: 1,
            isHover: false
        },
        {
            code: '002',
            name: 'CORPORATE',
            isEditing: false,
            id: 2,
            isHover: false
        },
        {
            code: '055',
            name: 'NRA 55',
            isEditing: false,
            id: 3,
            isHover: false
        },
        {
            code: '004',
            name: 'CLASSICO 4',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '005',
            name: 'CLASSICO 5',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '006',
            name: 'CLASSICO 6',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '007',
            name: 'EXPERT 1',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '008',
            name: 'EXPERT 2',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '009',
            name: 'NORMAL X',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '010',
            name: 'NORMAL 2',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '011',
            name: 'LOW 2',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '012',
            name: 'LOW 3',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '013',
            name: 'CLASSICO EXPERT',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '014',
            name: 'MAX 1',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '015',
            name: 'MAX 2',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '016',
            name: 'CORPORATE AD',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '017',
            name: 'CLASSICO AS',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '018',
            name: 'MEDIUM',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '019',
            name: 'LIGHT',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '030',
            name: 'HARD',
            isEditing: false,
            id: 20,
            isHover: false
        }
    ];

    const mockService = {
        getSegments: (obj?: IQuery): Observable<IResponse<Segment[]>> => {
            if (!obj['_or']) {
                return Observable.of({
                    'return': {
                        'code': 0,
                        'message': '[Segment] Segments were found successfully.'
                    },
                    'data': segments
                });
            } else {
                const filteredSegments = segments.filter(seg => {
                    const lowerCaseName = seg.name.toLowerCase();
                    const lowerCaseValue = obj['_or'][0].slice(10).toLowerCase();
                    return lowerCaseName.indexOf(lowerCaseValue) || seg.code.indexOf(lowerCaseValue);
                });
                return Observable.of({
                    'return': {
                        'code': 0,
                        'message': '[Segment] Segments were found successfully.'
                    },
                    'data': filteredSegments
                });
            }
        }
    };

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                TestModule
            ],
            providers: [
                { provide: SegmentService, useValue: mockService }
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(SegmentListComponent);
        component = fixture.componentInstance;
        nativeElement = fixture.nativeElement;
        debugElement = fixture.debugElement;
        component.selectionEmitter = new Subject();
        component.toHideListChange = new Subject();
        fixture.detectChanges();
    });

    beforeAll(() => {
        timeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
    });

    afterAll(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = timeout;
    });

    it('Segment List Component should be truthy', () => {
        expect(component).toBeTruthy();
    });

    it('Should init component', () => {
        expect(() => component.ngOnInit()).not.toThrow();
    });

    it('Should init the view and AfterViewInit hook', () => {
        expect(() => component.ngAfterViewInit()).not.toThrow();
    });

    it('Should load a list of segments on initialization', () => {
        component.ngOnInit();
        expect(component.segmentList).toEqual(segments);
    });

    it('Should render a segment item on initialization', () => {
        component.ngOnInit();
        expect(nativeElement.textContent).toContain('VAN GOGH POTENCIAL');
    });

    it('Should not have any checked itens on initialization', () => {
        component.ngOnInit();
        expect(component.checkedList).toEqual([]);
    });

    it('Should emit a correct list with checked properties when an item has just been checked', fakeAsync(() => {
        component.ngOnInit();
        fixture.detectChanges();
        const firstItem = nativeElement.querySelectorAll('.list-item')[0];
        expect(firstItem.textContent).toContain('VAN GOGH POTENCIAL');
        const firstItemClickArea = firstItem.querySelector('.mat-checkbox-layout');
        let data;
        component.listChanged.subscribe(segs => {
            data = segs;
        });
        firstItemClickArea.click();
        tick(500);
        fixture.detectChanges();
        expect(component.checkedList[0]).toEqual('003');
        expect(data[0].id).toEqual(segments[0].id);
    }));

    it('Should emit a correct list with checked properties when an item has just been unchecked', fakeAsync(() => {
        component.ngOnInit();
        fixture.detectChanges();
        const firstItem = nativeElement.querySelectorAll('.list-item')[0];
        expect(firstItem.textContent).toContain('VAN GOGH POTENCIAL');
        const firstItemClickArea = firstItem.querySelector('.mat-checkbox-layout');
        firstItemClickArea.click();
        tick(200);
        fixture.detectChanges();
        expect(component.checkedList[0]).toEqual('003');

        let data;
        component.listChanged.subscribe(segs => {
            data = segs;
        });

        firstItemClickArea.click();
        fixture.detectChanges();
        tick(500);
        expect(component.checkedList).toEqual([]);
        expect(data).toEqual([]);
    }));

    it('Should reset the offset counter when fitered', fakeAsync(() => {
        component.ngOnInit();
        fixture.detectChanges();
        component.ngAfterViewInit();
        const form = debugElement.query(By.css('.filter-form'));
        form.nativeElement.click();
        const inputEl = debugElement.query(By.css('input'));
        tick(500);
        const evt = new Event('keyup');
        inputEl.nativeElement.dispatchEvent(evt);

        tick(900);
        fixture.detectChanges();

        expect(component.counter).toEqual(1);
    }));

    it('Should call the backend with a filter when a word is typed', fakeAsync(() => {
        component.ngOnInit();
        fixture.detectChanges();
        component.ngAfterViewInit();
        fixture.detectChanges();
        const form = debugElement.query(By.css('.filter-form'));
        form.nativeElement.click();
        tick(500);

        const input = component.searchInput;
        input.nativeElement.value = 'corporat';
        const ordenation = { _limit: component.quantity };
        ordenation['_or'] = [
            'code:like:' + 'corporat'.trim(),
            'name:like:' + 'corporat'.trim()
        ];
        const spy = spyOn(component.segmentService, 'getSegments').and.callThrough();

        tick(500);
        fixture.detectChanges();
        input.nativeElement.dispatchEvent(new Event('keyup'));
        tick(900);
        fixture.detectChanges();

        expect(component.counter).toEqual(1);
    }));

    it('Should have no selected items when the parent component emit that segments have been added', fakeAsync(() => {
        component.ngOnInit();
        fixture.detectChanges();
        component.ngAfterViewInit();
        fixture.detectChanges();
        const firstItem = nativeElement.querySelectorAll('.list-item')[0];
        expect(firstItem.textContent).toContain('VAN GOGH POTENCIAL');
        const firstItemClickArea = firstItem.querySelector('.mat-checkbox-layout');
        firstItemClickArea.click();
        tick(200);
        fixture.detectChanges();
        expect(component.checkedList[0]).toEqual('003');
        component.selectionEmitter.next();
        tick(300);
        expect(component.checkedList).toEqual([]);
        expect(component.segmentListView[0].checked).toBe(true);
    }));

    it('Should hide segments emitted by the parent component from the view list', fakeAsync(() => {
        component.ngOnInit();
        fixture.detectChanges();
        component.ngAfterViewInit();
        fixture.detectChanges();
        const firstItem = nativeElement.querySelectorAll('.list-item')[0];
        expect(firstItem.textContent).toContain('VAN GOGH POTENCIAL');
        const firstItemClickArea = firstItem.querySelector('.mat-checkbox-layout');
        firstItemClickArea.click();
        tick(200);
        fixture.detectChanges();
        expect(component.checkedList[0]).toEqual('003');
        expect(component.segmentListView[0].code).toBe('003');
        component.toHideListChange.next([segments[0]]);
        tick(300);
        expect(component.segmentListView[0].code).not.toBe('003');
    }));

});
