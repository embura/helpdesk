// tslint:disable-next-line:snt-file-name-suffix
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { GroupsComponent } from './groups.component';
import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed, async, tick, fakeAsync, flush, flushMicrotasks } from '@angular/core/testing';
import { Observable } from 'rxjs/Observable';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { SegmentService } from '../../../../services/segment/segment.service';
import { IQuery } from '../../../../services/util/util.service';
import { IResponse } from '../../../../models/response/response.interface';
import { Segment } from '../../../../models/segment/segment';
import { By } from '@angular/platform-browser';
import { Subject } from 'rxjs/Subject';
import { GroupSegmentService } from '../../../../services/group-segment/group-segment.service';
import { EventService } from '../../../../services/events-channels/event/event.service';
import { ChannelService } from '../../../../services/events-channels/channel/channel.service';
import { GroupSegmentRelationsService } from '../../../../services/group-segment-relations/group-segment-relations.service';
import { EventChanGrSegRelationsService } from '../../../../services/event-channel-gr-seg-relat/event-channel-gr-seg-relat.service';
import { GroupSegment } from '../../../../models/product/group-segment/group-segment';
import { IEvents } from '../../../events-channels/events/events';
import { IChannels } from '../../../events-channels/channels/channels';
import { IEventsChannels } from '../../../../models/events-channels/events-channels.interface';
import { GroupSegmentRelations } from '../../../../models/product/group-segment-relations/group-segment-relations';
import {
    EventChanGrSegRelations
} from '../../../../models/product/event-channel-group-segment-relations/event-channel-group-segment-relations';
import { MatMenuModule } from '@angular/material';
import { ToastrModule } from 'ngx-toastr';
import { CustomErrorToastComponent } from '../../../toast/custom-error-toast.component';
import { CustomSuccessToastComponent } from '../../../toast/custom-success-toast.component';

@NgModule({
    imports: [
        CommonModule,
        MatCheckboxModule,
        MatMenuModule,
        ToastrModule.forRoot({
            timeOut: 3000,
            positionClass: 'toast-bottom-center'
        }),
    ],
    declarations: [GroupsComponent, CustomErrorToastComponent, CustomSuccessToastComponent],
    entryComponents: [GroupsComponent, CustomErrorToastComponent, CustomSuccessToastComponent],
    schemas: [NO_ERRORS_SCHEMA]
})
class TestModule {

}

describe('Segment-List Component', () => {
    let component: GroupsComponent;
    let fixture: ComponentFixture<GroupsComponent>;
    let timeout;
    let nativeElement;
    let debugElement;

    const channels: IChannels[] = [
        {
            id: 555,
            name: 'ch5',
            nameTec: '52',
            isSelected: false,
            statusId: 10
        }
    ];

    const events: [IEvents] = [
        {
            id: 12,
            name: 'evt1',
            statusId: 10,
            channels: [channels[0]],
            nameTec: 'evt1'
        }
    ];

    const segments: Segment[] = [
        {
            code: '003',
            name: 'VAN GOGH POTENCIAL',
            isEditing: false,
            id: 1,
            isHover: false
        },
        {
            code: '002',
            name: 'CORPORATE',
            isEditing: false,
            id: 2,
            isHover: false
        },
        {
            code: '055',
            name: 'NRA 55',
            isEditing: false,
            id: 3,
            isHover: false
        },
        {
            code: '004',
            name: 'CLASSICO 4',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '005',
            name: 'CLASSICO 5',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '006',
            name: 'CLASSICO 6',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '007',
            name: 'EXPERT 1',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '008',
            name: 'EXPERT 2',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '009',
            name: 'NORMAL X',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '010',
            name: 'NORMAL 2',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '011',
            name: 'LOW 2',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '012',
            name: 'LOW 3',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '013',
            name: 'CLASSICO EXPERT',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '014',
            name: 'MAX 1',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '015',
            name: 'MAX 2',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '016',
            name: 'CORPORATE AD',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '017',
            name: 'CLASSICO AS',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '018',
            name: 'MEDIUM',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '019',
            name: 'LIGHT',
            isEditing: false,
            id: 4,
            isHover: false
        },
        {
            code: '030',
            name: 'HARD',
            isEditing: false,
            id: 20,
            isHover: false
        }
    ];

    const groups: GroupSegment[] = [
        {
            name: 'grupo 1',
            id: 45,
            code: 123,
            segments: [segments[0], segments[1], segments[2]],
            events: [events[0]],
            isOpen: false,
            isEditing: false
        },
        {
            name: 'grupo2',
            id: 46,
            code: 124,
            segments: [segments[0]],
            events: [events[0]],
            isOpen: false,
            isEditing: false,
        }
    ];

    const evtChans: IEventsChannels[] = [
        {
            id: 5,
            name: 'evtch',
            statusId: 10,
            nameTec: 'evttch'
        }
    ];

    const groupSegRel: GroupSegmentRelations[] = [
        {
            id: 4,
            segmentID: 2,
            groupSegmentID: 45
        }
    ];

    const eventChanGrSegRelations: EventChanGrSegRelations[] = [
        {
            id: 6,
            channelID: 555,
            eventID: 12,
            groupSegmentID: 46
        }
    ];

    const mockSegmentService = {
        getSegments: (obj?: IQuery): Observable<IResponse<Segment[]>> => {
            if (!obj['_or']) {
                return Observable.of({
                    'return': {
                        'code': 0,
                        'message': '[Segment] Segments were found successfully.'
                    },
                    'data': segments
                });
            } else {
                const filteredSegments = segments.filter(seg => {
                    const lowerCaseName = seg.name.toLowerCase();
                    const lowerCaseValue = obj['_or'][0].slice(10).toLowerCase();
                    return lowerCaseName.indexOf(lowerCaseValue) || seg.code.indexOf(lowerCaseValue);
                });
                return Observable.of({
                    'return': {
                        'code': 0,
                        'message': '[Segment] Segments were found successfully.'
                    },
                    'data': filteredSegments
                });
            }
        }
    };

    const mockGroupSegmentService = {
        getGroupSegmentByCode: (productId: number): Observable<IResponse<Array<GroupSegment>>> => {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': 'Groups were found successfully.'
                },
                'data': groups
            });
        }
    };

    const mockEventService = {
        getAllEvents: (): Observable<IResponse<IEventsChannels[]>> => {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': 'EventsChannels were found successfully.'
                },
                'data': evtChans
            });
        }
    };

    const mockChannelService = {
        getAllChannels: (): Observable<IResponse<IEventsChannels[]>> => {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': 'EventsChannels were found successfully.'
                },
                'data': evtChans
            });
        }
    };

    const mockGroupSegmentRelationsService = {
        getGroupsSegmentsRelations: (obj: IQuery): Observable<IResponse<Array<GroupSegmentRelations>>> => {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': 'Group Segments were found successfully.'
                },
                'data': groupSegRel
            });
        }
    };

    const mockEventChanGrSegRelationsService = {
        getEventChanGrSegRelations: (obj: IQuery): Observable<IResponse<Array<EventChanGrSegRelations>>> => {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': 'EventChanGrSegRelations were found successfully.'
                },
                'data': eventChanGrSegRelations
            });
        }
    };

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                TestModule
            ],
            providers: [
                { provide: SegmentService, useValue: mockSegmentService },
                { provide: GroupSegmentService, useValue: mockGroupSegmentService },
                { provide: EventService, useValue: mockEventService },
                { provide: ChannelService, useValue: mockChannelService },
                { provide: GroupSegmentRelationsService, useValue: mockGroupSegmentRelationsService },
                { provide: EventChanGrSegRelationsService, useValue: mockEventChanGrSegRelationsService }
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(GroupsComponent);
        component = fixture.componentInstance;
        nativeElement = fixture.nativeElement;
        debugElement = fixture.debugElement;
        component.selectionEmitter = new Subject();
        fixture.detectChanges();
    });

    afterEach(() => {
        component.ngOnDestroy();
    });

    beforeAll(() => {
        timeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
    });

    afterAll(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = timeout;
    });

    it('Segment List Component should be truthy', () => {
        expect(component).toBeTruthy();
    });

    it('Should init component', () => {
        expect(() => component.ngOnInit()).not.toThrow();
    });

    it('Should load a list of groups on initialization, not group', fakeAsync(() => {
        mockGroupSegmentService.getGroupSegmentByCode = (productId: number): Observable<IResponse<Array<GroupSegment>>> => {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': 'Groups were found successfully.'
                },
                'data': []
            });
        };
        component.ngOnInit();
        tick(500);
        fixture.detectChanges();
        expect(component.groups).toBeTruthy();
    }));

    it('Should load a list of groups on initialization', fakeAsync(() => {
        mockGroupSegmentService.getGroupSegmentByCode = (productId: number): Observable<IResponse<Array<GroupSegment>>> => {
            return Observable.of({
                'return': {
                    'code': 0,
                    'message': 'Groups were found successfully.'
                },
                'data': groups
            });
        };
        component.ngOnInit();
        tick(500);
        fixture.detectChanges();
        expect(component.groups).toBeTruthy();
    }));

    it('Should render a segment emitted by the parent component', fakeAsync(() => {
        component.selectionEmitter = new Subject();
        tick(300);
        component.ngOnInit();
        fixture.detectChanges();
        tick(300);
        expect(nativeElement.textContent).not.toContain('CLASSICO 5');
        component.selectionEmitter.next([segments[4]]);
        component.selectionEmitter.unsubscribe();
        fixture.detectChanges();
        expect(nativeElement.textContent).toContain('CLASSICO 5');
    }));

    it('Should add a new group', fakeAsync(() => {
        component.ngOnInit();
        fixture.detectChanges();
        tick(300);
        component.groups = [];
        component.addGroup();
        tick(500);
        fixture.detectChanges();
        expect(component.groups.length).toBe(1);
    }));

    it('Should remove a group', fakeAsync(() => {
        component.ngOnInit();
        fixture.detectChanges();
        tick(300);
        const initialGroups = component.groups.length;
        component.removeGroup(1);
        tick(500);
        fixture.detectChanges();
        expect(component.groups.length).toBe(initialGroups - 1);
    }));

    it('Open Group', fakeAsync(() => {
        component.open(groups[0]);
        expect(groups[0].isOpen).toBe(true);
    }));

    it('Edit Group', fakeAsync(() => {
        component.editGroup(groups[0], 0, { disabled: false, focus: () => { } });
        expect(groups[0]).toBeTruthy();
    }));

    it('Save Group', fakeAsync(() => {
        component.saveGroup(groups[0]);
        expect(groups[0]).toBeTruthy();
    }));

    it('Calcel Editing Group', (() => {
        component.groupsEdit = groups;
        component.cancelEditGroup(groups[0], 0);
        expect(groups).toBeTruthy();
    }));

    it('removeSegment', fakeAsync(() => {
        component.removeSegment({segments: []}, segments[0]);
        expect(component.groups).toBeTruthy();
    }));

    it('changeChannel', fakeAsync(() => {
        component.changeChannel(channels[0]);
        expect(channels[0].isSelected).toBe(false);
    }));

});
