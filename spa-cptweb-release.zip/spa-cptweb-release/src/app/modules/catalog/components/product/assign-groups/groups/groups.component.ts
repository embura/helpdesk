// tslint:disable-next-line:max-line-length
import { Component, Inject, EventEmitter, OnInit, ViewChildren, ElementRef, Input, OnDestroy, Output, IterableDiffers } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { GroupSegment } from '../../../../models/product/group-segment/group-segment';
import { IChannels } from '../../../events-channels/channels/channels';
import { Segment } from '../../../../models/segment/segment';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs/Observable';
import { IResponse } from '../../../../models/response/response.interface';
import { GroupSegmentService } from '../../../../services/group-segment/group-segment.service';
import { EventService } from '../../../../services/events-channels/event/event.service';
import { IEventsChannels } from '../../../../models/events-channels/events-channels.interface';
import { ChannelService } from '../../../../services/events-channels/channel/channel.service';
import { IEvents } from '../../../events-channels/events/events';

import { Subject } from 'rxjs/Subject';
import { GroupSegmentRelationsService } from '../../../../services/group-segment-relations/group-segment-relations.service';
import { SegmentService } from '../../../../services/segment/segment.service';
import { EventChanGrSegRelationsService } from '../../../../services/event-channel-gr-seg-relat/event-channel-gr-seg-relat.service';
import { IProduct } from '../../../../models/product/product.interface';
import { FormBuilder, FormGroup } from '@angular/forms';
import { SubscriptionLog } from 'rxjs/testing/SubscriptionLog';
import { Subscription } from 'rxjs/Subscription';
import { CustomErrorToastComponent } from '../../../toast/custom-error-toast.component';
import * as _ from 'lodash';


@Component({
    selector: 'app-cpt-groups',
    templateUrl: './groups.component.html',
    styleUrls: ['./groups.component.scss']
})
export class GroupsComponent implements OnInit, OnDestroy {
    public groups: GroupSegment[] = [];
    public events: IEvents[] = [];
    public allChannels: IChannels[] = [];
    public segments: Segment[] = [];
    public groupsEdit = [];

    @Input() selectionEmitter: Subject<Segment[]>;
    @Input() productId?: number;
    @Output() public addedList: EventEmitter<Segment[]> = new EventEmitter<Segment[]>();
    @Output() public emitGroupsSegments: EventEmitter<GroupSegment[]> = new EventEmitter<GroupSegment[]>();
    @ViewChildren('groupName') private inputGroupName: Array<ElementRef>;

    constructor(
        private toastrService: ToastrService,
        private groupSegmentService: GroupSegmentService,
        private eventService: EventService,
        private channelService: ChannelService,
    ) {
    }

    ngOnInit(): void {
        Observable.forkJoin(
            this.groupSegmentService.getGroupSegmentByCode(this.productId),
            this.eventService.getAllEvents(),
            this.channelService.getAllChannels())
            .subscribe(res => {
                res[0].data.forEach(currentGroup => {
                    this.groups.push(new GroupSegment(
                        currentGroup.name,
                        currentGroup.id,
                        currentGroup.code,
                        currentGroup.segments,
                        currentGroup.events, false, false));
                });

                res[1].data.forEach(currentValue => {
                    this.events.push({
                        id: currentValue.id,
                        name: currentValue.name,
                        nameTec: currentValue.nameTec,
                        statusId: currentValue.statusId,
                        channels: []
                    });
                });

                res[2].data.forEach(currentValue => {
                    this.allChannels.push({
                        id: currentValue.id,
                        name: currentValue.name,
                        nameTec: currentValue.nameTec,
                        statusId: currentValue.statusId,
                        isSelected: false,
                    });
                });

                this.events.forEach(currentEvent => {
                    currentEvent.channels = JSON.parse(JSON.stringify(this.allChannels));
                });

                if (this.groups && this.groups.length > 0) {
                    this.groups[0].isOpen = true;
                    this.groups.forEach(currentGroup => {
                        currentGroup.events.forEach(currentEvent => {
                            const differents = _.xorBy(currentEvent.channels, this.allChannels, 'id');
                            currentEvent.channels.map(currentChannel => {
                                const a = this.allChannels;
                                currentChannel.isSelected = true;
                            });
                            currentEvent.channels.push(...differents);
                        });
                    });
                    this.emitCurrentSegments();
                    return;
                }

                const initialGroup = new GroupSegment('Grupo 1', null, null, null, null, true);
                initialGroup.events = JSON.parse(JSON.stringify(this.events));
                this.groups.push(initialGroup);
                this.emitCurrentSegments();

            });

        this.selectionEmitter.subscribe(selectedSegments => {
            const openGroupArray = this.groups.filter(group => group.isOpen === true);
            if (openGroupArray.length > 0 && openGroupArray[0].segments) {
                selectedSegments.map(segment => openGroupArray[0].segments.push(segment));
                this.emitCurrentSegments();
            }
        });

    }

    ngOnDestroy() {
        this.selectionEmitter.unsubscribe();
    }

    public emitCurrentSegments() {
        const openGroupArray = this.groups.filter(group => group.isOpen === true);
        if (openGroupArray.length > 0 && openGroupArray[0].segments) {
            this.addedList.emit(openGroupArray[0].segments);
        }
        this.emitGroupsSegments.emit(this.groups);
    }

    public open(group): void {
        group.isOpen = !group.isOpen;
        this.groups.forEach((currentGroup) => {
            if (currentGroup.name !== group.name) {
                currentGroup.isOpen = false;
            }
        });
        this.emitCurrentSegments();
    }

    public addGroup(): void {
        const newGroup = new GroupSegment(null);
        newGroup.isEditing = true;
        newGroup.events = JSON.parse(JSON.stringify(this.events));
        newGroup.events.forEach(currentEvent => {
            currentEvent.channels = JSON.parse(JSON.stringify(this.allChannels));
        });
        this.groups.forEach(currentGroup => {
            currentGroup.isOpen = false;
        });
        this.groups.push(newGroup);
        setTimeout(() => {
            this.inputGroupName['last'].nativeElement.focus();
            this.emitCurrentSegments();
            this.emitGroupsSegments.emit(this.groups);
        }, 100);
    }

    public editGroup(group, indexGroup, input): void {
        this.groupsEdit[indexGroup] = { ...group };
        group.isEditing = true;
        input.disabled = false;
        input.focus();
        this.emitCurrentSegments();
        this.emitGroupsSegments.emit(this.groups);
    }

    public saveGroup(group): void {
        if (!group.name) {
            this.toastrService.error('Nome do Grupo de Segmento obrigatório.', '', {
                toastComponent: CustomErrorToastComponent,
            });
        } else {
            let existsName = false;
            for (const currentGroup of this.groups) {
                if (group.name === currentGroup.name && currentGroup.id !== group.id) {
                    existsName = true;
                }
            }
            if (existsName) {
                this.toastrService.error('Nome do Grupo de Segmento já existe.', '', {
                    toastComponent: CustomErrorToastComponent,
                });
            } else {
                group.isEditing = false;
            }
        }
        this.emitCurrentSegments();
        this.emitGroupsSegments.emit(this.groups);
    }

    public cancelEditGroup(group, indexGroup): void {
        if (group.id || this.groups.length === 1) {
            group.name = this.groupsEdit[indexGroup].name;
            delete this.groupsEdit[indexGroup];
            group.isEditing = false;
        } else {
            this.groups.splice(indexGroup, 1);
        }
        this.emitCurrentSegments();
        this.emitGroupsSegments.emit(this.groups);
    }

    public removeGroup(indexGroup): void {
        this.groups.splice(indexGroup, 1);
        this.emitCurrentSegments();
        this.emitGroupsSegments.emit(this.groups);
    }

    public removeSegment(group, segment): void {
        const index = group.segments.indexOf(segment);
        if (index > -1) {
            group.segments.splice(index, 1);
        }
        this.emitCurrentSegments();
        this.emitGroupsSegments.emit(this.groups);
    }

    public changeChannel(channel): void {
        channel.isSelected = !channel.isSelected;
        this.emitGroupsSegments.emit(this.groups);
    }


}
