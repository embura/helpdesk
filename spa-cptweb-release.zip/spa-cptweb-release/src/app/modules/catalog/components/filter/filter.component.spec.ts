import { TestBed, ComponentFixture, async } from '@angular/core/testing';
import { CatalogSharedModule } from './../../catalog-shared.module';
import { FilterComponent } from './filter.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

describe('Testing Filter Component', () => {
  let component: FilterComponent;
  let fixture: ComponentFixture<FilterComponent>;
  let timeout: number;
  beforeAll(() => {
    timeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CatalogSharedModule,
        FormsModule,
        ReactiveFormsModule
      ],
      declarations: [
        FilterComponent
      ],
      schemas: [
        NO_ERRORS_SCHEMA
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
  });

  afterEach(() => {
    component.ngOnDestroy();
  });

  afterAll(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = timeout;
  });

  it('should create filtercomponent', () => {
    expect(component).toBeDefined();
  });

  it('should create 3 instances of Subscription', () => {
    expect(component['subscriptions'].length).toBe(3);
  });

  it('should emit form after input text change', () => {
    component['onTextFilterChange']('test');
  });

  it('shouldn´t emit form after input text change', () => {
    component['onTextFilterChange']('te');
  });

  it('should emit serch event on dropdown change', () => {
    component['onDropDownFilterChange'](component.filterOptions[0]);
    component['onDropDownFilterChange'](component.filterOptions[3]);
    expect(component.form.value.showInatives).toBe(true);
    component['onDropDownFilterChange'](component.filterOptions[2]);
    expect(component.form.value.showInatives).toBe(false);
  });

  it('should emit search event on checkbox change', () => {
    component.form.value.filter = component.filterOptions[2];
    component['onCheckBoxChange'](true);
    component.form.value.filter = component.filterOptions[3];
    component['onCheckBoxChange'](false);
    expect(component.form.value.filter.id).toBe(1);
    component['onCheckBoxChange'](true);
  });
});
