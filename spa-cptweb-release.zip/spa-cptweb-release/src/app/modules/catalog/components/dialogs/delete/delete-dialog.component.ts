import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
  templateUrl: './delete-dialog.component.html',
  styleUrls: ['./delete-dialog.component.scss']
})
export class DeleteDialogComponent {

  constructor(private readonly dialog: MatDialogRef<DeleteDialogComponent>) {}

  public closeModal(confirm?: boolean): void {
    this.dialog.close(confirm);
  }

}
