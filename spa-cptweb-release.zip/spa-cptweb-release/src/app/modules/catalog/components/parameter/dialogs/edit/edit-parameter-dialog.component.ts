import { Component, Optional, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatSelectChange } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IParameterItem } from '../../parameter.component';
import { IListOption } from '../create/parameter-dialog.component';
import { Parameter } from '../../../../models/parameter/parameter';


@Component({
  templateUrl: './edit-parameter-dialog.component.html',
  styleUrls: ['./../create/parameter-dialog.component.scss']
})

export class EditParameterDialogComponent implements OnInit {

  public form: FormGroup;
  public typeOptions: Array<IListOption> = [];
  public validationOptions: Array<IListOption> = [];
  public originalValidationOptions: Array<IListOption> = [];

  constructor(
    _fb: FormBuilder,
    private dialogRef: MatDialogRef<EditParameterDialogComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) private data
  ) {
    this.form = _fb.group({
      name: ['', Validators.required],
      type: [null, Validators.required],
      validation: [null]
    });
    if (data) {
      this.typeOptions = data.parameterTypes;
      this.originalValidationOptions = [...data.validationTypes];
      // tslint:disable-next-line:max-line-length
      this.validationOptions = data.item.typeId === 6 ? this.originalValidationOptions.filter(op => op.id !== 4) : this.originalValidationOptions;

      this.form.setValue({
        name: data.item.name,
        type: this.typeOptions.filter(to => to.id === data.item.typeId)[0],
        validation: data.item.validationId ? this.validationOptions.filter(v => v.id === data.item.validationId)[0] : null
      });

    }
  }

  public onCancelClickHandler(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.form.controls.name.setValue(this.data.item.name);
  }

  public getIcon(option: IListOption): string {
    switch (option.id) {
      case 1:
        return 'short_text';
      case 2:
        return 'radio_button_checked';
      case 3:
        return 'check_box';
      case 5:
        return 'date_range';
      default:
        return 'arrow_drop_down_circle';
    }
  }

  public applyValidation(type: MatSelectChange): void {
    if (type.value.text) {
      this.form.controls.validation.setValidators(Validators.required);
      this.form.controls.validation.markAsTouched();
      this.form.controls.validation.updateValueAndValidity();
      return;
    }
    // tslint:disable-next-line:max-line-length
    this.validationOptions = type.value.id === 6 ? this.originalValidationOptions.filter(op => op.id !== 4) : this.originalValidationOptions;
    this.form.controls.validation.reset();
  }

  public getItemModify(): any {
    return {
      name: this.form.value.name ? this.form.value.name : this.data.item.name,
      typeId: this.form.value.type ? this.form.value.type.id : this.data.item.typeId,
      validationId: this.form.value.validation ? this.form.value.validation.id : this.data.item.validationId
    };
  }

}
