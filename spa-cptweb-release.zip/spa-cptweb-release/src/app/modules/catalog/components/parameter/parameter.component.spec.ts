// tslint:disable-next-line:snt-file-name-suffix
import { ParameterComponent, IParameterItem } from './parameter.component';
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { FilterComponent, IFilterEvent } from '../filter/filter.component';
import { CatalogSharedModule } from '../../catalog-shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Parameter, IParameter } from '../../models/parameter/parameter';
import { NgModule, NO_ERRORS_SCHEMA, ModuleWithComponentFactories } from '@angular/core';
import { ParameterDialogComponent } from './dialogs/create/parameter-dialog.component';
import { DialogHeaderComponent } from '../dialog-header/dialog-header.component';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ParameterService } from '../../services/parameter/parameter.service';
import { ValidationTypeService } from '../../services/parameter/validation-type/validation-type.service';
import { OptionService } from '../../services/parameter/option/option.service';
import { UtilService } from '../../services/util/util.service';
import { ParameterTypeService } from '../../services/parameter/parameter-type/parameter-type.service';
import { GenericDialogComponent } from '../dialogs/generic/generic-dialog.component';
import { ComponentType } from '@angular/core/src/render3';
import { IResponse } from '../../models/response/response.interface';
import { GenericDialog } from '../../models/dialog/generic-dialog';
import { ParameterOption } from '../../models/parameter/parameter-item';
import { ToastrService, ToastrModule } from 'ngx-toastr';
import { CustomSuccessToastComponent } from '../toast/custom-success-toast.component';
import { CustomErrorToastComponent } from '../toast/custom-error-toast.component';
import { CustomWarningToastComponent } from '../toast/custom-warning-toast.component';

class MockMatDialog extends MatDialog {
    protected result = {
        groupName: 'unitTest',
        family: {
            name: 'test',
            id: 1
        },
    };
    open<T>(a: ComponentType<T>, options?: any): any {
        return {
            close: () => null,
            afterClosed: () => Observable.of(this.result)
        };
    }
}

const response: IResponse<any> = {
    return: {
        code: 0,
        message: 'mock'
    },
    data: []
};
class MockParameterService {
    public getParameters(param?): Observable<IResponse<any>> {
        return Observable.of(response);
    }
    public createParameter(parameter): Observable<IResponse<any>> {
        return Observable.of(response);
    }
    public getOptions(parameter): Observable<IResponse<any>> {
        return Observable.of(response);
    }
    public alterParameter(parameter): Observable<IResponse<any>> {
        return Observable.of(response);
    }
}
class MockOptionService {
    public createOptions(option, parameter): Observable<IResponse<any>> {
        return Observable.of(response);
    }
    public alterOption(option, parameter): Observable<IResponse<any>> {
        return Observable.of(response);
    }
    public deleteOption(option, parameter): Observable<IResponse<any>> {
        return Observable.of(response);
    }
}
class MockServices {
    public getParametersType(): Observable<IResponse<any>> {
        return Observable.of(response);
    }
    public getValidationTypes(): Observable<IResponse<any>> {
        return Observable.of(response);
    }
}
@NgModule({
    imports: [
        CatalogSharedModule,
        NoopAnimationsModule,
        ToastrModule.forRoot({
            timeOut: 3000,
            positionClass: 'toast-bottom-center'
        }),
    ],
    declarations: [
        ParameterComponent,
        GenericDialogComponent,
        CustomSuccessToastComponent,
        CustomErrorToastComponent,
        CustomWarningToastComponent
    ],
    providers: [
        { provide: MatDialog, useClass: MockMatDialog },
        { provide: ParameterService, useClass: MockParameterService },
        { provide: ParameterTypeService, useClass: MockServices },
        { provide: ValidationTypeService, useClass: MockServices },
        { provide: OptionService, useClass: MockOptionService },
        {
            provide: UtilService,
            useValue: {
                getServiceMessage: (str: string, def: string) => 'mock',
                getHubUrl: () => 'mock'
            }
        },
    ],
    entryComponents: [CustomSuccessToastComponent, CustomErrorToastComponent, CustomWarningToastComponent],
    schemas: [NO_ERRORS_SCHEMA],
})
export class ParameterTestModule { }

describe('ParameterComponent', () => {
    const parameter: IParameter = {
        id: 1,
        typeId: 2,
        statusId: 10,
        name: 'mock',
        options: [],
        isEditable: true,
        validationId: 1
    };

    let component: ParameterComponent;
    let fixture: ComponentFixture<ParameterComponent>;
    let initialTimeout: number;

    beforeAll(() => {
        initialTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000000;
    });

    afterAll(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = initialTimeout;
    });

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [ParameterTestModule]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ParameterComponent);
        component = fixture.componentInstance;

        component['filterRef'] = {
            form: {
                value: 4
            }
        } as any;
    });

    it('should create component', () => {
        expect(component).toBeDefined();
    });

    it('should return empty string', () => {
        const result = component['getTypeName'](2);
        expect(result).toBe('');
    });

    it('should build ParametersList', () => {
        const paramterList: Array<IParameter> = [parameter];
        component['parameterTypes'] = [{ id: 2 }] as any;
        const list = component['buildParametersList'](paramterList);
        expect(list.length).toBe(1);
    });

    it('should build ParametersList', () => {
        delete parameter.validationId;
        const paramterList: Array<IParameter> = [parameter];
        component['parameterTypes'] = [{ id: 2 }] as any;
        const list = component['buildParametersList'](paramterList);
        expect(list.length).toBe(1);
    });

    it('should build QueryParams', () => {
        const searchParam: any = {};
        searchParam.filter = { status: 5, orderBy: 'id', order: 'desc' };
        searchParam.textFilter = ' mock ';
        let result = component['buildQueryParams'](searchParam);
        expect(result._likeValue).toContain('%mock%');
        delete searchParam.filter.status;
        searchParam.showInatives = false;
        result = component['buildQueryParams'](searchParam);
        expect(result).toBeDefined();
        searchParam.showInatives = true;
        delete searchParam.textFilter;
        result = component['buildQueryParams'](searchParam);
        expect(result._likeValue).toBeUndefined();
    });

    it('should search parameters', () => {
        const filter: IFilterEvent = {
            isTextualChange: false,
            value: {
                showInatives: false,
                textFilter: 'mock',
                filter: {
                    id: 0,
                    value: 'fwa'
                }
            }
        };
        expect(async () => {
            await component.searchParameters(filter);
            filter.isTextualChange = true;
            component['parameterService'].getParameters = () => Observable.of({
                return: {
                    code: 1
                }
            } as any);
            await component.searchParameters(filter);
        }).not.toThrow();
    });

    it('should search parameters when scroll is called', () => {
        const obj: any = {
            return: {
                code: 0
            },
            data: [{ ...parameter }]
        };
        component['parameterService'].getParameters = () => Observable.of(obj);
        expect(() => {
            component.onScroll();
        }).not.toThrow();
    });

    it('should search parameters when scroll is called', () => {
        const obj: any = {
            return: {
                code: 1
            },
            data: [{ ...parameter }]
        };
        component['parameterService'].getParameters = () => Observable.of(obj);
        expect(() => {
            component.onScroll();
        }).not.toThrow();
    });

    it('open create modal', () => {
        component.searchParameters = async (): Promise<void> => { };
        expect(async () => {
            await component.openModal();

            component['parameterService'].createParameter = () => Observable.of({
                return: {
                    code: 5
                }
            } as any);
            await component.openModal();

            component['parameterService'].createParameter = () => Observable.throw({ json: () => { } });
            await component.openModal();

            component['createModalInstance'] = () => ({
                afterClosed: () => Observable.of(null)
            } as any);
            await component.openModal();

        }).not.toThrow();
    });

    it('open accordion', () => {
        const param = new Parameter('mock', 1, 10);
        param.options = [new ParameterOption('mock Option', 'mock tec')];
        const parameterItem: IParameterItem = {
            isOpen: false,
            typeName: 'mocktype',
            parameter: param
        };
        expect(async () => {
            await component.open(parameterItem); // do not have options
            param.typeId = 3;
            await component.open(parameterItem);
            param.isOpen = true;
            await component.open(parameterItem);
            component['parameterService'].getOptions = () => Observable.of({ return: { code: 1 } } as any);
            await component.open(parameterItem);
        }).not.toThrow();
    });

    it('change Visibility', () => {
        const param = new Parameter('mock', 1, 10);
        component['searchParameters'] = async () => { };
        expect(() => {
            component.changeVisibility(param);
            component['parameterService'].alterParameter = () => Observable.of({} as any);
            param.statusId = 5;
            component.changeVisibility(param);
            component['parameterService'].alterParameter = () => Observable.throw({ json: () => 'mock' });
            component.changeVisibility(param);
        }).not.toThrow();
    });

    it('Create parameter item', () => {
        const param = new Parameter('mock', 3, 10);
        expect(() => {
            component.createParameterItem('mock', 'mock tec', param, {}, {});
            param.options = [new ParameterOption('mock', 'mock tec')];
            component.createParameterItem('mock', 'mock tec', param, {}, {});
            component['optionService'].createOptions = () => Observable.throw({ json: () => 'mock' });
            component.createParameterItem('mock', 'mock tec', param, {}, {});
        }).not.toThrow();
    });

    it('should get error message', () => {
        const param = new Parameter('mock', 3, 10);
        component['optionService'].createOptions = () => Observable.of({
            'return': {
                'code': 1
            }
        } as any);
        expect(() => {
            component.createParameterItem('mock', 'mock tec', param, {}, {});
        }).not.toThrow();
    });

    it('should enable editing parameter item', () => {
        const option = new ParameterOption('mock', 'mock tec');
        component.enableEditParameterItem(option, { focus: () => { } }, {}, 2);
        expect(component['editingInfo'][2]).toBeDefined();
        option.isEditable = true;
        component.enableEditParameterItem(option, { focus: () => { } }, {}, 2);
        expect(component['editingInfo'][2]).toBeUndefined();
    });

    it('should edit parameter item', () => {
        const param = new Parameter('mock', 3, 10);
        param.options = [new ParameterOption('mock', 'mock tec')];
        expect(async () => {
            await component.editParameterItem(param.options[0], param, 1);
            component['optionService'].alterOption = () => Observable.of({ return: { code: 1 } } as any);
            await component.editParameterItem(param.options[0], param, 1);
            component['optionService'].alterOption = () => Observable.throw({ json: () => 'mock' });
            await component.editParameterItem(param.options[0], param, 1);
        }).not.toThrow();
    });

    it('should delete parameter', () => {
        const param = new Parameter('mock', 3, 10);
        const option = new ParameterOption('mock', 'mock tec');
        option.id = 5;
        param.options = [{ ...option }];
        expect(async () => {
            await component.deleteParameterItem(param.options[0], param);
            param.options.push({ ...option });
            component['optionService'].deleteOption = () => Observable.of({} as any);
            await component.deleteParameterItem(param.options[0], param);
            component['optionService'].deleteOption = () => Observable.throw({ json: () => 'mock' });
            await component.deleteParameterItem(param.options[0], param);
        }).not.toThrow();
    });

    it('should not delete parameter', () => {
        component['genericDialog'].deleteWarningMessage = () => <any>({
            afterClosed: () => Observable.of(null)
        });
        expect(() => {
            component.deleteParameterItem(null, null);
        }).not.toThrow();
    });

    it('edit modal', () => {
        const item = new Parameter('shodi', 3, 10);
        component.searchParameters = async () => { };
        expect(async () => {
            await component.editModal(item);
            component['parameterService'].alterParameter = () => Observable.of({} as any);
            await component.editModal(item);
            component['parameterService'].alterParameter = () => Observable.of({ return: { message: 'mock' } } as any);
            await component.editModal(item);
            component['parameterService'].alterParameter = () => Observable.throw({ json: () => 'mock' } as any);
            await component.editModal(item);
            component['dialog'].open = () => ({
                afterClosed: () => Observable.of(null)
            } as any);
            await component.editModal(item);

            component['dialog'].open = () => ({
                afterClosed: () => Observable.of({ typeId: 1, })
            } as any);
            item.validationId = 2;
            await component.editModal(item);


        }).not.toThrow();
    });

    it('historic button click handler', () => {
        expect(() => {
            const param = new Parameter('mock', 1, 10);
            param.id = 5;
            component.historicClickHandler(param);
        }).not.toThrow();
    });

    it('changeOptionVisibility', () => {
        const param = new Parameter('mock', 1, 10);
        param.options = [new ParameterOption('mock Option', 'mock tec')];
        expect(() => {
            component.changeOptionVisibility(param.options[0], param);
        }).not.toThrow();
    });

    it('should get error message changeOptionVisibility', () => {
        const param = new Parameter('mock', 1, 10);
        param.options = [new ParameterOption('mock Option', 'mock tec')];
        component['optionService'].alterOption = () => Observable.of({
            'return': {
                'code': 1
            }
        } as any);
        expect(() => {
            component.changeOptionVisibility(param.options[0], param);
        }).not.toThrow();
    });

    it('should get error message changeOptionVisibility execute function', () => {
        const param = new Parameter('mock', 1, 10);
        param.options = [new ParameterOption('mock Option', 'mock tec')];
        component['optionService'].alterOption = () => Observable.throw({ json: () => { } });
        expect(() => {
            component.changeOptionVisibility(param.options[0], param);
        }).not.toThrow();
    });

    it('Should init component', () => {
        expect(() => component.ngOnInit()).not.toThrow();
    });
});
