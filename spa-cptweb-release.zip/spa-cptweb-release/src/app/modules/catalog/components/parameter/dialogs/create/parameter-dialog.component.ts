
import { Component, Inject } from '@angular/core';
import { MatDialogRef, MatSelectChange, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Parameter, IParameter } from '../../../../models/parameter/parameter';

export interface IListOption {
  id: number;
  name: string;
}

@Component({
  templateUrl: './parameter-dialog.component.html',
  styleUrls: ['./parameter-dialog.component.scss']
})
export class ParameterDialogComponent {

  public form: FormGroup;
  public typeOptions: Array<IListOption> = [];
  public validationOptions: Array<IListOption> = [];
  public originalValidationOptions: Array<IListOption> = [];

  constructor(
    _fb: FormBuilder,
    private dialogRef: MatDialogRef<ParameterDialogComponent>,
    @Inject(MAT_DIALOG_DATA) private dialogData
  ) {
    this.form = _fb.group({
      name: ['', Validators.required],
      type: [null, Validators.required],
      validation: [null]
    });
    if (dialogData) {
      this.typeOptions = dialogData.parameterTypes;
      this.originalValidationOptions = [...dialogData.validationTypes];
      this.validationOptions = this.originalValidationOptions;
    }
  }

  public applyValidation(type: MatSelectChange): void {
    if (type.value.text) {
      this.form.controls.validation.setValidators(Validators.required);
      this.form.controls.validation.markAsTouched();
      this.form.controls.validation.updateValueAndValidity();
      return;
    }
    // tslint:disable-next-line:max-line-length
    this.validationOptions = type.value.id === 6 ? this.originalValidationOptions.filter(op => op.id !== 4) : this.originalValidationOptions;
    this.form.controls.validation.reset();
  }

  public getIcon(option: IListOption): string {
    switch (option.id) {
      case 1:
        return 'short_text';
      case 2:
        return 'radio_button_checked';
      case 3:
        return 'check_box';
      case 5:
        return 'date_range';
      case 6:
        return 'vpn_key';
      case 7:
        return 'code';
      default:
        return 'arrow_drop_down_circle';
    }
  }

  private getFinalValue(): IParameter {
    const formValue = this.form.value;
    const parameter: IParameter = {
      name: formValue.name,
      typeId: formValue.type.id,
      validationId: formValue.validation ? formValue.validation.id : null,
      statusId: 10,
      isEditable: true
    };
    return parameter;
  }

  public save(): void {
    const parameter: IParameter = this.getFinalValue();
    this.dialogRef.close(parameter);
  }

  public onCancelClickHandler(): void {
    this.dialogRef.close();
  }
}
