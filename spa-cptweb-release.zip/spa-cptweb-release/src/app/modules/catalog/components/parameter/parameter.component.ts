import { Component, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { trigger, transition, style, animate } from '@angular/animations';
import { MatDialogRef, MatDialog } from '@angular/material';
import { ParameterDialogComponent } from './dialogs/create/parameter-dialog.component';
import { EditParameterDialogComponent } from './dialogs/edit/edit-parameter-dialog.component';
import { Parameter, TypeValidation } from '../../models/parameter/parameter';
import { ParameterOption } from '../../models/parameter/parameter-item';
import { IParameter, IParameterType, IValidationType } from '../../models/parameter/parameter';
import { Observable } from 'rxjs/Rx';
import { ParameterService } from '../../services/parameter/parameter.service';
import { ParameterTypeService } from '../../services/parameter/parameter-type/parameter-type.service';
import { ValidationTypeService } from '../../services/parameter/validation-type/validation-type.service';
import { OptionService } from '../../services/parameter/option/option.service';
import { GenericDialog } from '../../models/dialog/generic-dialog';
import { IFilterEvent, FilterComponent } from '../filter/filter.component';
import { UtilService, IQuery } from '../../services/util/util.service';
import { IResponse } from '../../models/response/response.interface';
import { IHistoricData } from '../historic/historic-dialog';
import { TABLE_MAPPER } from '../../models/common/table-mapping';
import { ToastrService } from 'ngx-toastr';
import { CustomWarningToastComponent } from '../toast/custom-warning-toast.component';
import { CustomSuccessToastComponent } from '../toast/custom-success-toast.component';
import { CustomErrorToastComponent } from '../toast/custom-error-toast.component';

export interface IParameterItem {
  parameter: Parameter;
  typeName: string;
  validationName?: string;
  isOpen?: boolean;
}
@Component({
  selector: 'app-cpt-parameter',
  templateUrl: './parameter.component.html',
  styleUrls: ['./parameter.component.scss'],
  animations: [
    trigger('ease', [
      transition('void => *', [
        style({ 'max-height': 0 }),
        animate('0.15s ease-out', style({ 'max-height': '*' })),
      ]),
      transition('* => void', [
        style({ 'max-height': '*' }),
        animate('0.15s ease-in', style({ 'max-height': 0 }))
      ])
    ])
  ]
})
export class ParameterComponent implements OnInit, OnDestroy {
  parameters: IParameterItem[] = [];
  private parameterTypes: IParameterType[] = [];
  private validationTypes: IValidationType[] = [];
  private genericDialog: GenericDialog;
  @ViewChild('filterRef') private filterRef: FilterComponent;
  @ViewChild('newNameOption') private newNameOption;
  @ViewChild('newNameTec') private newNameTec;
  constructor(
    private dialog: MatDialog,
    private parameterService: ParameterService,
    private parameterTypeService: ParameterTypeService,
    private validationTypeService: ValidationTypeService,
    private optionService: OptionService,
    private utilService: UtilService,
    private toastrService: ToastrService,
  ) {
    this.genericDialog = new GenericDialog(this.dialog);
  }

  ngOnInit(): void {
    const dialogRef = this.genericDialog.loadingMessage('Carregando parâmetros...');
    Observable.forkJoin(
      this.parameterTypeService.getParametersType(),
      this.validationTypeService.getValidationTypes(),
    ).subscribe(res => {
      this.parameterTypes = res[0].data;
      this.validationTypes = res[1].data;
      dialogRef.close();
    });
  }

  ngOnDestroy(): void {
    this.parameterTypes = null;
    this.validationTypes = null;
    this.parameters = null;
  }

  public warningToast(option, parameter) {
    const toast = this.toastrService.warning('O parametro foi removido do formulário!',
      '', {
        toastComponent: CustomWarningToastComponent,
        tapToDismiss: false,
      });

    toast.onAction.subscribe(() => {
      this.newNameOption.value = '';
      this.createParameterItem(
        option[0].name, option[0].nameTec, parameter, this.newNameOption.nativeElement, this.newNameTec.nativeElement);
      this.toastrService.clear(toast.toastId);
    });
  }

  public errorToast(message) {
    this.toastrService.error(message, '', {
      toastComponent: CustomErrorToastComponent,
    });
  }

  public successToast(message) {
    this.toastrService.success(message, '', {
      toastComponent: CustomSuccessToastComponent,
    });
  }

  private getTypeName(id: number): string {
    const paramType = this.parameterTypes.find(type => type.id === id);
    if (!paramType) {
      return '';
    }
    return paramType.name;
  }

  private buildParametersList(params: Array<IParameter>): Array<IParameterItem> {
    const parameters = new Array<IParameterItem>();
    params.forEach(param => {
      const parameter = new Parameter(param.name, param.typeId, param.statusId);
      parameter.id = param.id;
      parameter.validationId = param.validationId;
      parameter.isisEditable = param.isEditable;
      const parameterItem: IParameterItem = {
        parameter,
        typeName: this.getTypeName(parameter.typeId),
      };

      if (param.validationId) {
        parameterItem.validationName = TypeValidation[param.validationId];
      }

      parameters.push(parameterItem);
    });
    return parameters;
  }

  private buildQueryParams(searchParams): IQuery {
    const ordenation: IQuery = {};
    if (searchParams.filter.hasOwnProperty('status')) {
      ordenation.statusId = searchParams.filter.status;
    } else if (!searchParams.showInatives) {
      ordenation.statusId = 10;
    }
    if (searchParams.textFilter && searchParams.textFilter.trim() !== '') {
      ordenation._likeColumn = 'name';
      ordenation._likeValue = `%${searchParams.textFilter.trim()}%`;
    }
    ordenation._orderBy = searchParams.filter.orderBy;
    ordenation._order = searchParams.filter.order;
    return ordenation;
  }

  // tslint:disable-next-line
  public showSpinner: boolean = false;
  public async searchParameters(event: IFilterEvent): Promise<void> {
    const queryParams: IQuery = this.buildQueryParams(event.value);
    let dialogRef;
    if (!event.isTextualChange) {
      dialogRef = this.genericDialog.loadingMessage('Buscando parâmetros...');
    } else {
      this.showSpinner = true;
    }
    const response = await this.parameterService.getParameters(queryParams).toPromise();
    if (response.return.code === 0) {
      this.parameters = this.buildParametersList(response.data);
    }
    if (dialogRef) {
      dialogRef.close();
    }
    this.showSpinner = false;
  }

  private createModalInstance(): MatDialogRef<ParameterDialogComponent> {
    return this.dialog.open(ParameterDialogComponent, {
      width: '570px',
      data: {
        parameterTypes: this.parameterTypes,
        validationTypes: this.validationTypes
      }
    });
  }

  // tslint:disable-next-line:member-ordering
  private counter = 1;
  public async onScroll(): Promise<void> {
    const resp = await this.parameterService.getParameters({ _limit: 25, _offset: this.counter * 25 + 1 }).toPromise();
    if (resp.return.code === 0) {
      this.buildParametersList(resp.data).forEach(param => {
        this.parameters.push(param);
      });
      this.counter++;
    }
  }

  public async editModal(item: Parameter): Promise<void> {
    const dialogRef = this.dialog.open(EditParameterDialogComponent, {
      width: '570px',
      data: {
        item: item,
        parameterTypes: this.parameterTypes,
        validationTypes: this.validationTypes
      }
    });
    const response: Parameter = await dialogRef.afterClosed().toPromise();
    if (response) {
      const oldName = item.name;
      const oldTypeId = item.typeId;
      const oldValidationId = item.validationId;

      item.name = response.name;
      item.typeId = response.typeId;

      if (response.typeId !== 1 && response.typeId !== 6) {
        item.validationId = null;
      } else {
        item.validationId = response.validationId ? response.validationId : oldValidationId;
      }

      const generic = this.genericDialog.loadingMessage('Editando parâmetro...');
      const resp = await this.parameterService.alterParameter(item).toPromise().catch(err => {
        const parameter: IResponse<IParameter> = { return: { code: 1, message: '' }, data: null };
        parameter.return.message = this.utilService.getServiceMessage(err.json(), 'Erro ao editar o parâmetro.');
        return parameter;
      });
      if (!resp.return || resp.return.code !== 0) {
        this.errorToast(resp.return ? resp.return.message : 'Erro ao editar o parâmetro.');
        item.name = oldName;
        item.typeId = oldTypeId;
        item.validationId = oldValidationId;

      } else {
        this.successToast(resp.return.message);
      }
      generic.close();
      this.searchParameters({ value: this.filterRef.form.value, isTextualChange: false });
    }
  }

  public async openModal(): Promise<void> {
    const dialogRef = this.createModalInstance();
    const response: IParameter = await dialogRef.afterClosed().toPromise();
    if (response) {
      const newParameter = new Parameter(response.name, response.typeId, 10);

      newParameter.validationId = response.validationId ? response.validationId :
        response.typeId === 1 || response.typeId === 6 ? this.validationTypes.filter(v => v.id === 1)[0].id : null;

      const generic = this.genericDialog.loadingMessage('Criando parâmetro...');
      this.parameterService.createParameter(newParameter).subscribe(resp => {
        if (resp.return && resp.return.code === 0) {
          newParameter.id = resp.data.id;
          const newParameterItem: IParameterItem = {
            parameter: newParameter,
            typeName: this.getTypeName(newParameter.typeId),
          };

          if (resp.data.validationId) {
            newParameterItem.validationName = TypeValidation[resp.data.validationId];
          }

          this.parameters.push(newParameterItem);
          this.successToast(resp.return.message);
          generic.close();
        } else {
          const message = this.utilService.getServiceMessage(resp, 'Erro ao criar o parâmetro.');
          this.errorToast(message);
          generic.close();
        }
      }, err => {
        const message = this.utilService.getServiceMessage(err.json(), 'Erro ao criar o parâmetro.');
        this.errorToast(message);
        generic.close();
      }, () => {
        this.searchParameters({ value: this.filterRef.form.value, isTextualChange: false });
        generic.close();
      });
    }
  }

  public async open(item: IParameterItem) {
    if (this.hasItems(item.parameter)) {

      for (const i of this.parameters) {
        if (i.parameter.id !== item.parameter.id) {
          i.isOpen = false;
        }
      }

      if (!item.isOpen) {
        const resp = await this.parameterService.getOptions(item.parameter.id).toPromise();
        if (resp.return.code === 0) {
          item.parameter.options = resp.data;
        }
      }

      item.isOpen = !item.isOpen;
    }
  }

  public changeVisibility(item: Parameter) {
    const oldStatus = item.statusId;
    item.statusId = item.statusId === 10 ? 5 : 10;
    const generic = this.genericDialog.loadingMessage('Mudando a visibilidade do parâmetro...');
    this.parameterService.alterParameter(item).subscribe(resp => {
      if (!resp.return || resp.return.code !== 0) {
        const message = this.utilService.getServiceMessage(resp, 'Erro ao mudar a visibilidade do parâmetro.');
        // this.genericDialog.errorMessage(message);
        this.errorToast(message);
        item.statusId = oldStatus;
      } else {
        // this.genericDialog.successMessage(resp.return.message);
        this.successToast(resp.return.message);
      }
      this.searchParameters({ value: this.filterRef.form.value, isTextualChange: false });
    }, err => {
      const message = this.utilService.getServiceMessage(err.json(), 'Erro ao mudar a visibilidade do parâmetro.');
      // this.genericDialog.errorMessage(message);
      this.errorToast(message);
    });
    generic.close();
  }

  public changeOptionVisibility(item: ParameterOption, parameter: Parameter) {
    const oldStatus = item.statusId;
    item.statusId = item.statusId === 10 ? 5 : 10;
    const generic = this.genericDialog.loadingMessage('Mudando a visibilidade da opção de parâmetro...');
    this.optionService.alterOption(item, parameter).subscribe(resp => {
      if (!resp.return || resp.return.code !== 0) {
        const message = this.utilService.getServiceMessage(resp, 'Erro ao mudar a visibilidade da opção de parâmetro.');
        this.errorToast(message);
        item.statusId = oldStatus;
      } else {
        this.successToast(resp.return.message);
      }
    }, err => {
      const message = this.utilService.getServiceMessage(err.json(), 'Erro ao mudar a visibilidade da opção de parâmetro.');
      this.errorToast(message);
    });
    generic.close();
  }

  public hasItems(item: Parameter): boolean {
    return item.typeId === 3 || item.typeId === 4;
  }

  public createParameterItem(name: string, nameTec: string, item: Parameter, inputName, inputNameTec): void {
    const dialog = this.genericDialog.loadingMessage('Criando opção de parâmetro...');
    const parameterOption: ParameterOption = new ParameterOption(name, nameTec);
    parameterOption.statusId = 10;

    this.optionService.createOptions(parameterOption, item).subscribe(resp => {
      if (resp.return.code === 0) {
        const newOption = new ParameterOption(resp.data.name, resp.data.nameTec);
        newOption.id = resp.data.id;
        newOption.statusId = resp.data.statusId;
        newOption.isEditable = resp.data.isEditable;
        if (item.options) {
          item.options = [newOption, ...item.options];
        } else {
          item.options = new Array<ParameterOption>();
          item.options.push(newOption);
        }
        this.successToast('Opção de parâmetro criado com sucesso.');
      } else {
        const message = this.utilService.getServiceMessage(resp, 'Erro ao criar opção de parâmetro.');
        this.errorToast(message);
      }
      dialog.close();
    }, err => {
      const message = this.utilService.getServiceMessage(err.json(), 'Erro ao criar opção de parâmetro.');
      this.errorToast(message);
      dialog.close();
    });
    inputName.value = '';
    inputNameTec.value = '';
  }

  // tslint:disable-next-line:member-ordering
  private editingInfo = []; // apenas para guardar o nome inicial das opcoes de parâmetro que estão sendo atualizadas
  public enableEditParameterItem(item: ParameterOption, inputName, inputNameTec, index: number) {
    if (item.editing) {
      item.name = this.editingInfo[index].name;
      item.nameTec = this.editingInfo[index].nameTec;
      delete this.editingInfo[index];
    } else {
      this.editingInfo[index] = { 'name': item.name, 'nameTec': item.nameTec };
    }
    item.editing = !item.editing;
    inputName.disabled = !item.editing;
    inputNameTec.disabled = !item.editing;
    inputName.focus();
  }

  public async editParameterItem(item: ParameterOption, parameter: Parameter, index: number): Promise<void> {
    const generic = this.genericDialog.loadingMessage('Editando opção de parâmetro...');

    this.optionService.alterOption(item, parameter).subscribe(resp => {
      if (resp.return && resp.return.code === 0) {
        delete this.editingInfo[index];
        item.editing = false;
        this.successToast(resp.return.message);
      } else {
        const message = this.utilService.getServiceMessage(resp, 'Erro ao editar opção de parâmetro.');
        this.errorToast(message);
      }

      generic.close();
    }, err => {
      const message = this.utilService.getServiceMessage(err.json(), 'Erro ao editar opção de parâmetro.');
      this.errorToast(message);
      generic.close();
    });
  }

  public async deleteParameterItem(item: ParameterOption, parameter: Parameter): Promise<void> {
    this.optionService.deleteOption(item, parameter).subscribe(resp => {
      if (resp.return && resp.return.code === 0) {
        const index: number = parameter.options.findIndex(option => option.id === item.id);
        const removedOption = parameter.options.splice(index, 1);
        this.warningToast(removedOption, parameter);
      } else {
        const message = this.utilService.getServiceMessage(resp, 'Erro ao remover opção de parâmetro.');
        this.errorToast(message);
      }
    }, err => {
      const message = this.utilService.getServiceMessage(err.json(), 'Erro ao remover opção de parâmetro.');
      this.errorToast(message);
    });
  }

  public historicClickHandler(parameter: Parameter): void {
    const data: IHistoricData = {
      tableId: TABLE_MAPPER.PARAMETER,
      subtitle: `Parâmetro ${parameter.name}`,
      recordId: parameter.id
    };
    this.genericDialog.historic(data);
  }
}
