// import { TestBed, ComponentFixture, async } from '@angular/core/testing';
// import { EditParameterDialogComponent } from './edit-parameter-dialog.component';
// import { MockMatDialogRef } from './../create/parameter-dialog.component.spec';
// import { CatalogSharedModule } from '../../../../catalog-shared.module';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
// import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
// import { SharedModule } from '../../../../../../shared.module';

// describe('Parameter dialog (edition)', () => {
//     let component: EditParameterDialogComponent;
//     let fixture: ComponentFixture<EditParameterDialogComponent>;

//     beforeEach(async(() => {
//         TestBed.configureTestingModule({
//             imports: [
//                 CatalogSharedModule,
//                 FormsModule,
//                 ReactiveFormsModule,
//                 SharedModule
//             ],
//             declarations: [
//                 EditParameterDialogComponent
//             ],
//             schemas: [
//                 CUSTOM_ELEMENTS_SCHEMA
//             ],
//             providers: [
//                 { provide: MatDialogRef, useClass: MockMatDialogRef },
//                 { provide: MAT_DIALOG_DATA, useValue: { name: 'mock' } }
//             ]
//         }).compileComponents();
//     }));

//     beforeEach(() => {
//         fixture = TestBed.createComponent(EditParameterDialogComponent);
//         component = fixture.componentInstance;
//     });

//     it('should create component', () => {
//         expect(component).toBeDefined();
//     });

//     it('cancel editing parameter', () => {
//         expect(() => component.onCancelClickHandler()).not.toThrow();
//     });

//     xit('on init', () => {
//         expect(() => {
//             component.ngOnInit();
//         }).not.toThrow();
//     });
// });
