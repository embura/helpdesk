import { TestBed, ComponentFixture } from '@angular/core/testing';
import { ParameterDialogComponent } from './parameter-dialog.component';
import { CatalogSharedModule } from './../../../../catalog-shared.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogRef, MatSelectChange, MatDialogModule, MAT_DIALOG_DATA } from '@angular/material';

export class MockMatDialogRef {
    close(param?): void {
        return;
    }
}

describe('Parameter dialog (creation)', () => {
    let component: ParameterDialogComponent;
    let fixture: ComponentFixture<ParameterDialogComponent>;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                CatalogSharedModule,
                FormsModule,
                ReactiveFormsModule
            ],
            declarations: [
                ParameterDialogComponent
            ],
            schemas: [
                CUSTOM_ELEMENTS_SCHEMA
            ],
            providers: [
                { provide: MatDialogRef, useClass: MockMatDialogRef },
                { provide: MAT_DIALOG_DATA, useValeu: {} },
                MatDialogModule
            ]
        }).compileComponents();
        fixture = TestBed.createComponent(ParameterDialogComponent);
        component = fixture.componentInstance;
    });

    it('should create component', () => {
        expect(component).toBeDefined();
    });

    xit('getIcon function', () => {
        const getIcon = component.getIcon;
        const typeOptions = component.typeOptions;
        expect(getIcon(typeOptions[0])).toBe('short_text');
        expect(getIcon(typeOptions[1])).toBe('radio_button_checked');
        expect(getIcon(typeOptions[2])).toBe('check_box');
        expect(getIcon(typeOptions[3])).toBe('arrow_drop_down_circle');
    });

    xit('applyValidation on formControl (type validation)', () => {
        expect(() => {
            let mockedChange: MatSelectChange;
            for (const i of [0, 1]) {
                mockedChange = new MatSelectChange(null, component.typeOptions[i]);
                component.applyValidation(mockedChange);
            }
        }).not.toThrow();
    });

    xit('cancel Creation', () => {
        expect(() => component.onCancelClickHandler()).not.toThrow();
    });

    xit('save Creation', () => {
        expect(() => {
            const self = component;
            self.form.controls.validation.setValue(self.validationOptions[0]);
            self.form.controls.type.setValue(self.typeOptions[0]);
            component.save();
            self.form.controls.type.setValue(self.typeOptions[1]);
            component.save();
        }).not.toThrow();
    });
});
