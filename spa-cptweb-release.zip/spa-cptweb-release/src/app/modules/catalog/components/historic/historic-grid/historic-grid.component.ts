import { Component, Input, EventEmitter, Output } from '@angular/core';
import * as HistoricGrid from './historic-grid';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'historic-grid',
  templateUrl: './historic-grid.component.html',
  styleUrls: ['./historic-grid.component.scss']
})
export class HistoricGridComponent {
  @Input() public gridFields: Array<HistoricGrid.IGridField> = [
    { name: 'Usuário', field: 'userId', size: 2, isBoldText: true },
    { name: 'Data', field: 'actionDate', type: 'date', format: 'DD/MM/YYYY' },
    { name: 'Hora', field: 'actionDate', type: 'date', format: 'HH:mm' },
    { name: 'Ação', field: 'actionType' },
    { name: 'Campos', field: 'name', size: 2 },
    { name: 'Valor anterior', field: 'oldValue', size: 2 },
    { name: 'Novo valor', field: 'newValue', size: 2 }
  ];
  @Input() public dateRangeLabel: string;
  @Input() public wasFiltered: boolean;
  @Output() public onScroll: EventEmitter<void> = new EventEmitter<void>();
  public fieldArr: Array<string> = [];
  private colCount: number;
  @Input() public data = [];

  constructor() {
    this.gridFields.forEach(item => this.fieldArr.push(item.field));
  }

  public getQtdLabel(): string {
    const len: number = this.data.length;
    return `${len} ${len === 1 ? 'ação encontrada' : 'ações encontradas'}`;
  }

  public getCols(): number {
    if (!this.colCount) {
      this.colCount = 0;
      this.gridFields.forEach(item => this.colCount += (item.size ? item.size : 1));
    }
    return this.colCount;
  }
}
