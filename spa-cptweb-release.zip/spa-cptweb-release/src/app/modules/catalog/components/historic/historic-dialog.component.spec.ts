import { TestBed, ComponentFixture, fakeAsync, async } from '@angular/core/testing';
import { HistoricDialogComponent } from './historic-dialog.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AuditService, IAuditInfo } from '../../services/audit/audit.service';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../models/response/response.interface';
import { UtilService } from '../../services/util/util.service';
import { ReactiveFormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { IHistoricData, IDateInfo } from './historic-dialog';
import { IDateRange } from '../date-range-picker/date-range-picker.component';
import * as moment_ from 'moment';
const moment = moment_;

const mockedAuditData: Array<IAuditInfo> = [
    {
        actionDate: '25/05/2018',
        actionType: 'C',
        id: 1,
        isEditable: true,
        name: 'mockedName',
        newValue: '--',
        oldValue: 'MockedValue',
        recordId: '4',
        tableId: 40,
        userId: 'xMock'
    }
];

const historicData: IHistoricData = {
    subtitle: 'MockedSub',
    tableId: 20
};

const defaultReturn: IResponse<any> = {
    return: {
        code: 0,
        message: 'mock'
    },
    data: []
};

class ToastrServiceMock {
    error = () => 'mock';
}

class AuditServiceMock {
    getHistoric = () => {
        const response = defaultReturn;
        response.data = mockedAuditData;
        return Observable.of(response as any).toPromise();
    }
    getCSVData = () => Promise.all('mock');
}

describe('Historic Dialog test:', () => {
    let component: HistoricDialogComponent;
    let fixture: ComponentFixture<HistoricDialogComponent>;
    const date: IDateRange = {
        end: moment(new Date(2018, 4, 23)),
        start: moment(new Date(2018, 4, 23))
    };
    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [
                HistoricDialogComponent,
            ],
            imports: [
                ReactiveFormsModule
            ],
            providers: [
                { provide: MAT_DIALOG_DATA, useValue: historicData },
                { provide: ToastrService, useClass: ToastrServiceMock },
                { provide: MatDialog, useValue: {open: () => 'mock'} },
                { provide: AuditService, useClass: AuditServiceMock },
                { provide: MatDialogRef, useValue: { close: () => 'mock' } },
                { provide: UtilService, useValue: { buildCSV: () => 'mockedCSV' } }
            ],
            schemas: [NO_ERRORS_SCHEMA]
        }).compileComponents();
            fixture = TestBed.createComponent(HistoricDialogComponent);
            component = fixture.componentInstance;
    });

    it('should create component instance', () => {
        expect(component).toBeTruthy();
    });

    it('should select date (same day)', () => {
        const resp = component.onDateSelected(date);
        expect(resp).toContain('23/05/2018 a 23/05/2018');
    });

    it('should select date (different day)', () => {
        const newDate = {...date};
        newDate.end = moment(new Date(2018, 6, 5));
        const resp = component.onDateSelected(newDate);
        expect(resp).toContain('23/05/2018 a 05/07/2018');
    });

    it('should generate CSV', () => {
        expect(async () => {
            await component.exportCSV();
        }).not.toThrow();
    });

    it('should fail to generate CSV', () => {
        component['utilService'].buildCSV = () => false;
        expect(async () => {
            await component.exportCSV();
        }).not.toThrow();
    });

    it('should get more data', () => {
        expect(async () => {
            await component.getMoreData();
        }).not.toThrow();
    });

    it('should throw getGridData', () => {
        component['auditService'].getHistoric = () => Observable.throw({return: {code: 1}}) as any;
        expect(async () => {
            await component['getGridData']();
        });
    });

    it('should detect that search was filtered with combobox', () => {
        component.filterForm.controls.actions.setValue(['mock', 'mock2']);
        expect(component['wasFiltered']()).toBe(true);
    });

    it('should detect that search was filtered with user field', () => {
        component.filterForm.controls.user.setValue('Mock');
        expect(component['wasFiltered']()).toBe(true);
    });

    it('should build query object with all fields', () => {
        component['callCount'] = 1;
        component['data'].recordId = 20;
        component.dateInfo = {
            date: {
                start: moment(),
                end: moment()
            },
            label: 'mocked'
        };
        component.filterForm.controls.actions.setValue(['mock1', 'mock2']);
        component.filterForm.controls.user.setValue('mockedUser');
        const result = component['getQueryParams']();
        component['closeDialog']();
        expect(result.userId).toContain('mockedUser');
    });

    it('should build query object with initHour and finalHour fields', () => {
        component.dateInfo = {
            date: {
                start: moment(),
                end: moment()
            },
            label: 'mocked'
        };
        component.filterForm.value.initHour = '22:10';
        component.filterForm.value.finalHour = '12:05';
        const result = component['getQueryParams']();
        expect(result._between).toBeTruthy();
    });

    it('should not get grid data', async(() => {
        component['auditService'].getHistoric = (param) => Promise.resolve({return: {code: 1, message: 'mock'}, data: []});
        expect(async () => {
            await component['getGridData']();
        }).not.toThrow();
    }));
});
