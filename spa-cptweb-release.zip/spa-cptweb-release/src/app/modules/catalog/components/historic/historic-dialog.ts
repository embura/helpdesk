import { MatDialog } from '@angular/material';
import { IDateRange } from '../date-range-picker/date-range-picker.component';

export interface IHistoricData {
  tableId: number;
  subtitle: string;
  recordId?: number;
}

export interface IHistoricForm {
  date?: string;
  initHour?: string;
  finalHour?: string;
  user?: string;
  actions?: Array<string>;
}

export interface IHistoricAction {
  name: string;
  actionType: string;
}

export interface IDateInfo {
  label: string;
  date: IDateRange;
}

export interface IHistoricGridData {
  userId: string;
  actionDate: string;
  action: string;
  name: string;
  oldValue: string;
  newValue: string;
}
