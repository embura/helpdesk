import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HistoricGridComponent } from './historic-grid.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { MomentDatePipe } from './../../../pipes/moment-date/moment-date.pipe';

describe('Historic data grid', () => {
    let component: HistoricGridComponent;
    let fixture: ComponentFixture<HistoricGridComponent>;

    const gridFieldHelper = [
        { name: 'Usuário', field: 'userId', size: 2, isBoldText: true },
        { name: 'Data', field: 'actionDate', type: 'date', format: 'DD/MM/YYYY' },
        { name: 'Hora', field: 'actionDate', type: 'date', format: 'HH:mm' },
        { name: 'Ação', field: 'actionType' },
        { name: 'Campos', field: 'name', size: 2 },
        { name: 'Valor anterior', field: 'oldValue', size: 2 },
        { name: 'Novo valor', field: 'newValue', size: 2 }
    ];

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [
                HistoricGridComponent,
                MomentDatePipe
            ],
            schemas: [NO_ERRORS_SCHEMA]
        }).compileComponents();
        fixture = TestBed.createComponent(HistoricGridComponent);
        component = fixture.componentInstance;
    });

    it('should create component instance', () => {
        expect(component).toBeTruthy();
    });

    it('should get qtdlabel (singular)', () => {
        component.data = [{}];
        expect(component.getQtdLabel()).toContain('ação encontrada');
    });

    it('should get qtdLabel (plural)', () => {
        component.data = [{}, {}];
        expect(component.getQtdLabel()).toContain('ações encontradas');
    });

    it('should get columns size', () => {
        component.gridFields = [...gridFieldHelper] as any;
        expect(component.getCols()).toBe(11);
    });

    it('should get columns size', () => {
        component['colCount'] = 5;
        expect(component.getCols()).toBe(5);
    });
});
