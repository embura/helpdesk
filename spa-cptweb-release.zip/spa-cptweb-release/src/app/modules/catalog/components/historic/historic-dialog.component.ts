import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material';
import { IDateInfo, IHistoricGridData, IHistoricData, IHistoricAction } from './historic-dialog';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { IFilterOption } from '../../models/filter/filter-object.interface';
import { DateRangePickerComponent, IDateRange } from '../date-range-picker/date-range-picker.component';
import { Subscription } from 'rxjs/Rx';
import * as Validator from './../../validators/hour/hour.validator';
import { IAuditData, AuditService, IAuditInfo } from '../../services/audit/audit.service';
import { GenericDialog } from '../../models/dialog/generic-dialog';
import { GenericDialogComponent } from '../dialogs/generic/generic-dialog.component';
import { UtilService, IQuery } from '../../services/util/util.service';
import { ToastrService } from 'ngx-toastr';
import { CustomErrorToastComponent } from '../toast/custom-error-toast.component';
import * as moment_ from 'moment';
const moment = moment_;

@Component({
  templateUrl: './historic-dialog.component.html',
  styleUrls: ['./historic-dialog.component.scss']
})
export class HistoricDialogComponent {
  public subtitle: string;
  public title = 'Histórico de ações';
  public hourMask: Array<RegExp | string> = [/\d/, /\d/, ':', /\d/, /\d/];
  public dateInfo: IDateInfo = {label: '', date: null};
  public gridData: Array<any> = [];
  public searchedWithFilter: boolean;
  public filterForm: FormGroup;
  public order: FormControl;
  private callCount = 0;
  public actions: Array<IHistoricAction> = [
    { name: 'Adicionar', actionType: 'C' },
    { name: 'Editar', actionType: 'E' },
    { name: 'Excluir', actionType: 'D' }
  ];

  public orderOptions: Array<IFilterOption> = [
    { id: 1, value: 'mais recentes', orderBy: 'id', order: 'desc' },
    { id: 2, value: 'menos recentes', orderBy: 'id', order: 'asc' }
  ];

  constructor(
    private readonly dialogRef: MatDialogRef<HistoricDialogComponent>,
    private readonly _fb: FormBuilder,
    private auditService: AuditService,
    private readonly dialog: MatDialog,
    private readonly utilService: UtilService,
    private readonly toastrService: ToastrService,
    @Inject(MAT_DIALOG_DATA) private readonly data: IHistoricData
  ) {
    this.filterForm = _fb.group({
      date: [''],
      initHour: [{value: '', disabled: true}, Validator.hour],
      finalHour: [{value: '', disabled: true}, Validator.hour],
      user: [''],
      actions: [[]]
    });
    this.order = new FormControl(this.orderOptions[0]);
    this.subtitle = data.subtitle;
    this.applyFilter();
  }

  public onDateSelected(date: IDateRange): string {
    this.dateInfo.label = date.start.format('DD/MM/YYYY') + ' a ' + date.end.format('DD/MM/YYYY');
    this.dateInfo.date = date;
    if (date.start.isSame(date.end, 'day')) {
      this.filterForm.controls.initHour.enable();
      this.filterForm.controls.finalHour.enable();
    } else {
      this.filterForm.controls.initHour.disable();
      this.filterForm.controls.finalHour.disable();
      this.filterForm.controls.initHour.reset();
      this.filterForm.controls.finalHour.reset();
    }
    return this.dateInfo.label;
  }

  public async applyFilter(): Promise<void> {
    const options = this.buildFilterOptions({});
    this.gridData = await this.getGridData();
    this.callCount = 0;
  }

  private wasFiltered(): boolean {
    const value = this.filterForm.value;
    // tslint:disable-next-line:forin
    for (const key in value) {
      if (value[key] instanceof Array) {
        if (value[key].length) {
          return true;
        }
      } else if (value[key] && value[key] !== '') {
        return true;
      }
    }
    return false;
  }

  // tslint:disable-next-line:cyclomatic-complexity
  private getQueryParams(): IQuery {
    const query: IQuery = {};
    const formData = this.filterForm.value;
    query.tableId = this.data.tableId;
    if (this.data.hasOwnProperty('recordId')) {
      query.recordId = this.data.recordId;
    }
    if (this.dateInfo.date) {
      const date = this.dateInfo.date;
      let initDate = date.start.format('YYYY-MM-DD');
      initDate += `-${formData.initHour && formData.initHour !== '' ? moment(formData.initHour, 'HH:mm').format('HHmm') : '0001'}`;
      let finalDate = date.end.format('YYYY-MM-DD');
      finalDate += `-${formData.finalHour && formData.finalHour !== '' ? moment(formData.finalHour, 'HH:mm').format('HHmm') : '2359'}`;
      query._between = `actionDate:${initDate}:${finalDate}`;
    }
    if (formData.actions.length) {
      query._or = [];
      for (let i = 0; i < formData.actions.length; i++) {
        if (!i) {
          query.actionType = formData.actions[i].actionType;
          continue;
        }
        query._or.push(`actionType:eq:${formData.actions[i].actionType}`);
      }
    }
    if (formData.user !== '') {
      query.userId = formData.user;
    }
    this.buildFilterOptions(query);
    return query;
  }

  private async getGridData(): Promise<Array<any>> {
    let result: Array<IAuditInfo> = [];
    this.searchedWithFilter = this.wasFiltered();
    const response = await this.auditService.getHistoric(this.getQueryParams());
    try {
      if (response.return.code !== 0) {
        throw response;
      }
      result = response.data;
    } catch (err) {
      this.toastrService.error( err.return.message, '', {
        toastComponent: CustomErrorToastComponent,
      });
    }
    return result;
  }

  private buildFilterOptions(a: IQuery) {
    a._limit = 80;
    if (this.callCount) {
      a._offset = 80 * this.callCount + 1;
    }
    const ordenationValue = this.order.value;
    a._orderBy = ordenationValue.orderBy;
    a._order = ordenationValue.order;
  }

  public async getMoreData(): Promise<void> {
    this.gridData = await this.getGridData();
    this.callCount++;
    return;
  }

  public async exportCSV(): Promise<void> {
    const response = await this.auditService.getCSVData(this.getQueryParams());
    try {
      if (!this.utilService.buildCSV(response._body, this.data.subtitle)) {
        throw response;
      }
    } catch (err) {
      this.toastrService.error('Erro ao exportar CSV', '', {
        toastComponent: CustomErrorToastComponent,
      });
    }
  }

  public closeDialog(): void {
    this.dialogRef.close();
  }
}
