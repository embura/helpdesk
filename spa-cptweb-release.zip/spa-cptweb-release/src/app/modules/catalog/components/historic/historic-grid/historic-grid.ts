export interface IGridField {
  field: string;
  name: string;
  size?: number;
  isBoldText?: boolean;
  type?: 'date' | 'text';
  format?: string;
}
