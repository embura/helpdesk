// tslint:disable-next-line:snt-file-name-suffix
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule, MatDialog, MatButtonModule, MatInputModule } from '@angular/material';
import { TestBed, ComponentFixture, fakeAsync, tick, async } from '@angular/core/testing';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { AccordionComponent } from '../../accordion/accordion.component';
import { FormsModule } from '@angular/forms';
import { DialogHeaderComponent } from '../../dialog-header/dialog-header.component';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AccordionItem } from '../../accordion/accordion-item';
import { AssetClassCategoryComponent } from './asset-class-category.component';
import { AssetClassCategoryDialogComponent } from './dialog/asset-class-category-dialog.component';
import { AssetClass } from './asset-class';
import { ICategory } from '../../../models/category/category.interface';
import { IResponse } from '../../../models/response/response.interface';
import { AssertionError } from 'assert';
import { AssetClassService } from '../../../services/category/asset-class/asset-class.service';
import { CatalogSharedModule } from '../../../catalog-shared.module';
import { GenericDialogComponent } from '../../dialogs/generic/generic-dialog.component';
import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
import { MockToastrService } from '../family/family-category.component.spec';
import { ToastrService } from 'ngx-toastr';
import { UtilService } from '../../../services/util/util.service';
import { SharedModule } from './../../../../../shared.module';
@NgModule({
  imports: [
    CatalogSharedModule,
    FormsModule,
    CommonModule,
    BrowserAnimationsModule,
    SharedModule
  ],
  declarations: [
    AssetClassCategoryComponent,
    AccordionComponent,
    AssetClassCategoryDialogComponent,
    DialogHeaderComponent,
    GenericDialogComponent,
    OrderAccordionPipe
  ],
  providers: [
    { provide: AssetClassService, useValue: TestModule.assetClassServiceMock },
    { provide: ToastrService, useClass: MockToastrService },
    UtilService,
    { provide: 'appKey', useValue: 'mockAPPKEY' },
    { provide: 'hubHost', useValue: 'mockHUBHOST' },
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [AssetClassCategoryDialogComponent, GenericDialogComponent]
})
class TestModule {
  static assetClasses: ICategory[] = [
    {
      'id': 1,
      'name': 'FX',
      'shortName': 'FX',
      'statusId': 5,
      'isEditable': true
    },
    {
      'id': 2,
      'name': 'IR',
      'shortName': 'IR',
      'statusId': 5,
      'isEditable': true
    }
  ];

  static assetClassServiceMock = {
    getAssetClass: (code: number): Observable<IResponse<ICategory>> => {
      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Asset Class was found successfully.'
        },
        'data': TestModule.assetClasses.find(asst => asst.id === code)
      });
    },
    getAllAssetClasses: (): Observable<IResponse<ICategory[]>> => {
      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Asset Class were found successfully.'
        },
        'data': TestModule.assetClasses
      });
    },
    editAssetClass: (assetClass: AssetClass): Observable<IResponse<ICategory>> => {
      const editedAssetClass = TestModule.assetClasses[TestModule.assetClasses.findIndex(ac => ac.id === assetClass.id)];

      editedAssetClass.name = assetClass.name;

      TestModule.assetClasses[TestModule.assetClasses.findIndex(ac => ac.id === assetClass.id)] = editedAssetClass;

      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Asset Class was changed successfully.'
        },
        'data': editedAssetClass
      });
    },
    createAssetClass: (assetClass: AssetClass): Observable<IResponse<ICategory>> => {
      const newAssetClass: ICategory = { id: TestModule.assetClasses.length + 1,
        name: assetClass.name, shortName: assetClass.name, statusId: 5, isEditable: true  };
      TestModule.assetClasses.push(newAssetClass);

      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Asset Class was created successfully.'
        },
        'data': newAssetClass
      });
    }
  };
}

describe('AssetClassCategoryComponent', () => {
  let component: AssetClassCategoryComponent;
  let fixture: ComponentFixture<AssetClassCategoryComponent>;

  const dialogRef = {
    close: (data: AssetClass): Observable<AssetClassCategoryComponent> => {
      return Observable.create(() => {
        return data;
      });
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetClassCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open dialog', () => {
    const dialogRefTest: MatDialogRef<AssetClassCategoryComponent, AssetClass> = (<any>component).openDialog();

    expect(dialogRefTest).toBeTruthy();
  });

  it('should open dialog with data', () => {
    const data: AssetClass = new AssetClass('Teste', 1);

    const dialogRefTest: MatDialogRef<AssetClassCategoryComponent, AssetClass> = (<any>component).openDialog(data);

    expect(dialogRefTest).toBeTruthy();
  });

  it('should not add a asset class', () => {
    const data: AssetClass = new AssetClass('Teste', 1);

    component.add();

    (<any>component).dialogRef.close();

    expect((<any>component).assetClasses.length).toBe(0);
  });

  // it('should add a asset class', async(() => {
  //   const testViewContainerRef = fixture.componentInstance.childViewContainer;

  //   const data: AssetClass = new AssetClass('Teste', 1);
  //   const spy = jasmine.createSpy('afterClose callback');
  //   component.add();
  //   fixture.detectChanges();
  //   (<any>component).dialogRef.afterClosed().subscribe(spy);
  //   (<any>component).dialogRef.close(data);
  //   fixture.detectChanges();
  //   fixture.whenStable().then(() => {
  //     expect(spy).toHaveBeenCalledWith(data);
  //   });
  // }));

  it('should not edit a asset class', () => {
    const data: AccordionItem = new AccordionItem();
    data.name = 'Teste';
    data.id = 1;

    (<any>component).assetClasses.push(data);

    component.edit(data);

    (<any>component).dialogRef.close();
  });

  it('should edit a assetClass', () => {
    const data: AccordionItem = new AccordionItem();
    data.name = 'Teste';
    data.id = 1;

    (<any>component).assetClasses.push(data);

    component.edit(data);

    const assetClass: AssetClass = new AssetClass('Teste 2', 2);

    (<any>component).dialogRef.close(assetClass);
  });

  it('show return create response with error', () => {
    component['assetClassService'].createAssetClass = (assetClass: AssetClass): Observable<IResponse<ICategory>> => {
      return Observable.of({
        'return': {
          'code': 1,
          'message': '[Category] Asset Class was not created because of a error.'
        },
        'data': null
      });
    };

    const countBefore: number = component['assetClasses'].length;

    component.add();

    component['dialogRef'].close(new AssetClass('Teste', 1));

    const countAfter: number = component['assetClasses'].length;

    expect(countBefore).toBe(countAfter);
  });

  it('show return an exception when invoke service to add', () => {
    component['assetClassService'].createAssetClass = () => Observable.throw({});

    const countBefore: number = component['assetClasses'].length;

    component.add();

    component['dialogRef'].close(new AssetClass('Teste', 1));

    const countAfter: number = component['assetClasses'].length;

    expect(countBefore).toBe(countAfter);
  });

  it('show return edit response with error', () => {
    component['assetClassService'].editAssetClass = (assetClass: AssetClass): Observable<IResponse<ICategory>> => {
      return Observable.of({
        'return': {
          'code': 1,
          'message': '[Category] Asset class was not altered because of a error.'
        },
        'data': null
      });
    };

    const countBefore: number = component['assetClasses'].length;
    const item = new AccordionItem();
    item.name = 'Test 1';
    item.id = 1;
    item.subItem = '';
    item.subItemId = 0;
    item.canDelete = false;
    item.canEdit = false;
    item.popupOpen = false;
    component.edit(item);

    component['dialogRef'].close(new AssetClass('Teste', 1));

    const countAfter: number = component['assetClasses'].length;

    expect(countBefore).toBe(countAfter);
  });

  it('show return an exception when invoke service to edit', () => {
    component['assetClassService'].editAssetClass = () => Observable.throw({});

    const countBefore: number = component['assetClasses'].length;
    const item = new AccordionItem();
    item.name = 'Test 1';
    item.id = 1;
    item.subItem = '';
    item.subItemId = 0;
    item.canDelete = false;
    item.canEdit = false;
    item.popupOpen = false;
    component.edit(item);

    component['dialogRef'].close(new AssetClass('Teste', 1));

    const countAfter: number = component['assetClasses'].length;

    expect(countBefore).toBe(countAfter);
  });

  it('should fill data and map to assetClasses', () => {
    const data: ICategory[] = [
      { name: 'Mock 1', shortName: 'Mock 1', id: 1, statusId: 5, isEditable: true },
      { name: 'Mock 2', shortName: 'Mock 2', id: 2, statusId: 5, isEditable: true }
    ];
    component['data'] = data;

    expect(component['assetClasses'].length).toBe(2);
  });

  it('should fill data and not map to assetClasses', () => {
    component['data'] = null;

    expect(component['assetClasses'].length).toBe(0);
  });
});
