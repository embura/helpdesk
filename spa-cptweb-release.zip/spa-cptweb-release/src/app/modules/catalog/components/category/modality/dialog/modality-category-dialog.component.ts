import { Component, Inject } from '@angular/core';
import { Modality } from '../modality';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-modality-category-dialog',
  templateUrl: './modality-category-dialog.component.html',
  styleUrls: ['./modality-category-dialog.component.scss']
})
export class ModalityCategoryDialogComponent {
  modality: Modality;
  title: string;

  constructor(@Inject(MAT_DIALOG_DATA) public data: Modality,
    public dialogRef: MatDialogRef<ModalityCategoryDialogComponent, Modality>) {
    this.fillModel(data);
  }

  public fillModel(data: Modality) {
    if (data) {
      this.modality = data;
      this.title = 'Editar';
    } else {
      this.modality = new Modality('', null);
      this.title = 'Adicionar';
    }
  }

  public saveDisabled(value: string): boolean {
    return !(value && value.length > 0);
  }

  public save(): void {
    this.dialogRef.close(this.modality);
  }

  public closeDialog(): void {
    this.dialogRef.close();
  }
}
