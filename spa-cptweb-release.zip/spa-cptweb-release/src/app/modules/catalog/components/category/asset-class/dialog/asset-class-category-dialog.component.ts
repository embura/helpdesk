import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { AssetClass } from '../asset-class';

@Component({
  selector: 'app-cpt-asset-class-category-dialog',
  templateUrl: './asset-class-category-dialog.component.html',
  styleUrls: ['./asset-class-category-dialog.component.scss']
})
export class AssetClassCategoryDialogComponent {
  assetClass: AssetClass;
  title: string;

  constructor(@Inject(MAT_DIALOG_DATA) public data: AssetClass,
    public dialogRef: MatDialogRef<AssetClassCategoryDialogComponent, AssetClass>) {
    this.fillModel(data);
  }

  public fillModel(data: AssetClass) {
    if (data) {
      this.assetClass = data;
      this.title = 'Editar';
    } else {
      this.assetClass = new AssetClass('', null);
      this.title = 'Adicionar';
    }
  }

  public saveDisabled(value: string): boolean {
    return !(value && value.length > 0);
  }

  public save(): void {
    this.dialogRef.close(this.assetClass);
  }

  public closeDialog(): void {
    this.dialogRef.close();
  }
}
