export class Family {
  constructor(
    public name: string,
    public code?: number,
    public statusId?: number
  ) { }
}
