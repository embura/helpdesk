import { Component, OnInit, ViewChild } from '@angular/core';
import { FamilyService } from '../../services/category/family/family.service';
import { Observable } from 'rxjs/Observable';
import { MatDialog } from '@angular/material';
import { AssetClassService } from '../../services/category/asset-class/asset-class.service';
import { IGroup } from '../../models/category/category.interface';
import { GroupService } from '../../services/category/group/group.service';
import { ICategory } from '../../models/category/category.interface';
import { ModalityService } from '../../services/category/modality/modality.service';
import { UnderlyingService } from '../../services/category/underlying/underlying.service';
import { GenericDialog } from '../../models/dialog/generic-dialog';
import { AccordionComponent } from '../accordion/accordion.component';

@Component({
  selector: 'app-cpt-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent implements OnInit {
  @ViewChild('familyAccordion') private familyAccordion: AccordionComponent;
  @ViewChild('groupAccordion') private groupAccordion: AccordionComponent;
  @ViewChild('assetAccordion') private assetAccordion: AccordionComponent;
  @ViewChild('modalAccordion') private modalAccordion: AccordionComponent;
  @ViewChild('underAccordion') private underAccordion: AccordionComponent;

  public groups: IGroup[];
  public families: ICategory[];
  public familiesCategory: ICategory[];
  public assetClasses: ICategory[];
  public modalities: ICategory[];
  public underlyings: ICategory[];
  private genericDialog = new GenericDialog(this.dialog);
  public accordions = [];

  constructor(
    private dialog: MatDialog,
    private familyService: FamilyService,
    private assetClassService: AssetClassService,
    private modalitySerivce: ModalityService,
    private groupService: GroupService,
    private underlyingService: UnderlyingService
  ) { }

  public ngOnInit(): void {
    const dialogRef = this.genericDialog.loadingMessage('Carregando categorias...');
    this.accordions.push({
      name: 'familyAccordion',
      accordion: this.familyAccordion
    });
    this.accordions.push({
      name: 'groupAccordion',
      accordion: this.groupAccordion
    });
    this.accordions.push({
      name: 'assetAccordion',
      accordion: this.assetAccordion
    });
    this.accordions.push({
      name: 'modalAccordion',
      accordion: this.modalAccordion
    });
    this.accordions.push({
      name: 'underAccordion',
      accordion: this.underAccordion
    });

    Observable.forkJoin(this.familyService.getAllFamilies(),
      this.groupService.getAllGroups(),
      this.modalitySerivce.getAllModalities(),
      this.underlyingService.getAllUnderlyings(),
      this.assetClassService.getAllAssetClasses())
      .subscribe(res => {
        this.families = res[0].data;
        this.familiesCategory = res[0].data;
        this.groups = res[1].data;
        this.modalities = res[2].data;
        this.underlyings = res[3].data;
        this.assetClasses = res[4].data;
        dialogRef.close();
      });
  }

  public openAccordion(nameAccordion): void {
    for (const obj of this.accordions) {
      if (obj.name !== nameAccordion) {
        obj.accordion.accordion.isOpen = false;
      }
    }
  }
}
