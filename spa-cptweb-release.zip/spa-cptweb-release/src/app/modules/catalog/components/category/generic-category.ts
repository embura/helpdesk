import { MatDialog, MatDialogRef } from '@angular/material';
import { HistoricDialogComponent } from '../historic/historic-dialog.component';
import { IHistoricData } from '../historic/historic-dialog';

export class GenericCategory {
  protected _dialog: MatDialog;
  constructor(dialog: MatDialog) {
    this._dialog = dialog;
  }
  public openHistory(tableId: number, category: string): MatDialogRef<HistoricDialogComponent, any> {
    const data: IHistoricData = {
      tableId: tableId,
      subtitle: `Categoria ${category}`
    };
    return this._dialog.open(HistoricDialogComponent, {
      data: data,
      panelClass: 'historic-dialog',
      height: '95vh'
    });
  }
}
