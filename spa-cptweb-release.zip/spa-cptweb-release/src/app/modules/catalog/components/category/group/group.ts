import { Family } from '../family/family';

export class Group {
  public name: string;
  public code: number;
  public family: Family;
  public statusId: number;
  public technicalName: string;
  constructor(groupName?: string, technicalName?: string, groupCode?: number, family?: Family, statusId?: number) {
    this.name = groupName;
    this.technicalName = technicalName;
    this.code = groupCode;
    this.family = family;
    this.statusId = statusId;
  }
}
