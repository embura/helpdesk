import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DialogHeaderComponent } from '../../../dialog-header/dialog-header.component';
import { FormsModule } from '@angular/forms';
import { MatInputModule, MatDialogModule, MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { Observable } from 'rxjs/Observable';
import { UnderlyingCategoryDialogComponent } from './underlying-category-dialog.component';
import { Underlying } from '../underlying';
import { CatalogSharedModule } from '../../../../catalog-shared.module';
import { SharedModule } from '../../../../../../shared.module';

describe('UnderlyingCategoryDialogComponent', () => {
  let component: UnderlyingCategoryDialogComponent;
  let fixture: ComponentFixture<UnderlyingCategoryDialogComponent>;
  let comp;

  const dialogRef = {
    close : (data: Underlying): Observable<Underlying> => {
      return Observable.create(() => {
        return data;
      });
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        MatInputModule,
        MatDialogModule,
        BrowserAnimationsModule,
        SharedModule,
        CatalogSharedModule
       ],
      declarations: [
        UnderlyingCategoryDialogComponent,
        DialogHeaderComponent
      ],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: undefined },
        { provide: MatDialogRef, useValue: {} }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnderlyingCategoryDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    comp = fixture.debugElement.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open dialog with new underlying and save it', () => {
    comp.dialogRef = dialogRef;

    comp.underlying.name = 'Teste';

    comp.save();
  });

  it('save button should be enabled when name is informed', () => {
    comp.dialogRef = dialogRef;

    const resultInformed: boolean = comp.saveDisabled('Teste');

    expect(resultInformed).toBe(false);

    const resultNotInformed: boolean = comp.saveDisabled();

    expect(resultNotInformed).toBe(true);
  });

  it('model was informed', () => {
    const model: Underlying = new Underlying('Teste', 1);

    comp.fillModel(model);

    expect(comp.underlying).toBe(model);
  });
});
