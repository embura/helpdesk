import { Component, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { AccordionItem } from '../../accordion/accordion-item';
import { MatDialog, MatDialogRef } from '@angular/material';
import { FamilyCategoryDialogComponent } from './dialog/family-category-dialog.component';
import { Family } from './family';
import { FamilyService } from '../../../services/category/family/family.service';
import { ICategory } from '../../../models/category/category.interface';
import { GenericDialog } from '../../../models/dialog/generic-dialog';
import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
import { GenericCategory } from '../generic-category';
import { ToastrService } from 'ngx-toastr';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { CustomSuccessToastComponent } from '../../toast/custom-success-toast.component';
import { UtilService } from '../../../services/util/util.service';
import { AccordionComponent } from '../../accordion/accordion.component';

@Component({
  selector: 'app-cpt-family-category',
  templateUrl: './family-category.component.html',
  styleUrls: ['./family-category.component.scss']
})
export class FamilyCategoryComponent extends GenericCategory {
  public families: AccordionItem[] = [];
  private dialogRef: MatDialogRef<FamilyCategoryDialogComponent, Family>;
  private genericDialog = new GenericDialog(this.dialog);
  @ViewChild('accordion') public accordion: AccordionComponent;

  @Output() private dataChanged = new EventEmitter<ICategory[]>();
  @Input() private set data(data: ICategory[]) {
    if (data) {
      this.families = [];

      data.map(fam => {
        const family = new AccordionItem();

        family.name = fam.name;
        family.id = fam.id;
        family.statusId = +fam.statusId;
        family.canEdit = fam.isEditable;

        this.families.push(family);
      });
    }
  }

  constructor(
    private dialog: MatDialog,
    private familyService: FamilyService,
    private toastrService: ToastrService,
    private utilService: UtilService
  ) {
    super(dialog);
  }

  private openDialog(data: Family = null): MatDialogRef<FamilyCategoryDialogComponent, Family> {
    return this.dialog.open(FamilyCategoryDialogComponent, {
      width: '570px',
      height: '314px',
      data: data,
      disableClose: true
    });
  }

  public add(): void {
    this.dialogRef = this.openDialog();

    this.dialogRef.afterClosed().subscribe(data => {
      if (data) {
        const dialogRefLoading = this.genericDialog.loadingMessage('Adicionando Família...');
        data.statusId = 10;
        this.familyService.addFamiliy(data)
          .subscribe(response => {
            if (response.return.code === 0) {
              const item: AccordionItem = new AccordionItem();
              item.name = response.data.name;
              item.id = response.data.id;
              item.canEdit = true;
              item.statusId = 10;
              this.families.push(item);
              this.dataHasChanged();
              this.toastrService.success('Família adicionada com sucesso.', '', {
                toastComponent: CustomSuccessToastComponent,
              });
            } else {
              this.toastrService.error(response.return.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            dialogRefLoading.close();
          }, err => {
            const error = err.json ? err.json() : {};
            if (error.message) {
              this.toastrService.error(error.message , '', {
                toastComponent: CustomErrorToastComponent,
              });
            } else {
              this.toastrService.error('Ocorreu um erro ao adicionar a família.', '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            dialogRefLoading.close();
          });
      }

      this.dialogRef = null;
    });
  }

  public edit(item: AccordionItem) {
    const dialogData: Family = new Family(item.name, item.id);

    this.dialogRef = this.openDialog(dialogData);

    this.dialogRef.afterClosed().subscribe(data => {
      if (data) {
        const dialogRefLoading = this.genericDialog.loadingMessage('Alterando Família...');

        this.familyService.editFamily(data)
          .subscribe(resp => {
            if (resp.return.code === 0) {
              this.families[this.families.indexOf(item)].name = resp.data.name;
              this.dataHasChanged();
              this.toastrService.success('Família alterada com sucesso.', '', {
                toastComponent: CustomSuccessToastComponent,
              });
            } else {
              this.toastrService.error(resp.return.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            dialogRefLoading.close();
          }, err => {
            const error = err.json ? err.json() : {};
            if (error.message) {
              this.toastrService.error(error.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            } else {
              this.toastrService.error('Ocorreu um erro ao adicionar a família.', '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            dialogRefLoading.close();
          });
      }

      this.dialogRef = null;
    });
  }

  public del(item: AccordionItem) {
    this.families.splice(this.families.indexOf(item), 1);
  }

  private dataHasChanged() {
    const pipe: OrderAccordionPipe = new OrderAccordionPipe();
    this.families = pipe.transform(this.families);
    const newData: ICategory[] = [];
    this.families.map(fam => {
      newData.push({ name: fam.name, id: fam.id, statusId: fam.statusId, shortName: '', isEditable: fam.isEditable});
    });


    this.dataChanged.emit(newData);
  }

  public changeStatus(item: AccordionItem) {
    const aux = new Family(item.name, item.id, item.statusId === 10 ? 5 : 10);
    const dialogRefLoading = this.genericDialog.loadingMessage('Mudando visibilidade ...');
    this.familyService.editFamily(aux)

      .subscribe(response => {
        if (response.return.code === 0) {
          item.name = response.data.name;
          item.id = response.data.id;
          item.statusId = +response.data.statusId;
          this.dataHasChanged();
          this.toastrService.success('Visibilidade alterada com sucesso.', '', {
            toastComponent: CustomSuccessToastComponent,
          });
        } else {
          this.toastrService.error(response.return.message, '', {
            toastComponent: CustomErrorToastComponent,
          });
        }
        dialogRefLoading.close();
      }, err => {
        const error = err.json ? err.json() : {};
        this.toastrService.error(this.utilService.getServiceMessage(error, 'Ocorreu um erro ao editar a família.'), '', {
          toastComponent: CustomErrorToastComponent,
        });

        dialogRefLoading.close();
      });

    this.dialogRef = null;
  }

}
