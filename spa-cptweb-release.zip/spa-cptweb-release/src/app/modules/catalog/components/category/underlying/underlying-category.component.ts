import { Component, Input, ViewChild } from '@angular/core';
import { AccordionItem } from '../../accordion/accordion-item';
import { MatDialogRef, MatDialog } from '@angular/material';
import { Underlying } from './underlying';
import { UnderlyingCategoryDialogComponent } from './dialog/underlying-category-dialog.component';
import { GenericDialog } from '../../../models/dialog/generic-dialog';
import { UnderlyingService } from '../../../services/category/underlying/underlying.service';
import { ICategory } from '../../../models/category/category.interface';
import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
import { GenericCategory } from '../generic-category';
import { ToastrService } from 'ngx-toastr';
import { CustomSuccessToastComponent } from '../../toast/custom-success-toast.component';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { UtilService } from '../../../services/util/util.service';
import { AccordionComponent } from '../../accordion/accordion.component';

@Component({
  selector: 'app-cpt-underlying-category',
  templateUrl: './underlying-category.component.html',
  styleUrls: ['./underlying-category.component.scss']
})
export class UnderlyingCategoryComponent extends GenericCategory {
  @Input() set data(data: ICategory[]) {
    if (data) {
      this.underlyings = AccordionItem.transformCategories(data);
    }
  }

  public underlyings: AccordionItem[] = [];
  private dialogRef: MatDialogRef<UnderlyingCategoryDialogComponent, Underlying>;
  private genericDialog = new GenericDialog(this.dialog);
  @ViewChild('accordion') public accordion: AccordionComponent;

  constructor(
    private dialog: MatDialog,
    private underlyingService: UnderlyingService,
    private toastrService: ToastrService,
    private utilService: UtilService
  ) {
    super(dialog);
  }

  private openDialog(data: Underlying = null): MatDialogRef<UnderlyingCategoryDialogComponent, Underlying> {
    return this.dialog.open(UnderlyingCategoryDialogComponent, {
      width: '570px',
      height: '314px',
      data: data,
      disableClose: true
    });
  }

  public add(): void {
    this.dialogRef = this.openDialog();

    this.dialogRef.afterClosed().subscribe(data => {
      if (data) {
        data.statusId = 10;
        const dialogRefLoading = this.genericDialog.loadingMessage('Adicionando Underlying...');

        this.underlyingService.addUnderlying(data)
          .subscribe(response => {
            if (response.return.code === 0) {
              this.underlyings.push(AccordionItem.transmforCatgory(response.data));
              this.dataHasChanged();
              this.toastrService.success('Underlying adicionado com sucesso.', '', {
                toastComponent: CustomSuccessToastComponent,
              });
            } else {
              this.toastrService.error(response.return.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            dialogRefLoading.close();
          }, err => {
            const error = err.json ? err.json() : {};
            if (error.message) {
              this.toastrService.error(error.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            } else {
              this.toastrService.error('Ocorreu um erro ao adicionar o underlying.', '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            dialogRefLoading.close();
          });
      }

      this.dialogRef = null;
    });
  }

  public edit(item: AccordionItem) {
    const data: Underlying = new Underlying(item.name, item.id);

    this.dialogRef = this.openDialog(data);

    this.dialogRef.afterClosed().subscribe(dataDialog => {
      if (dataDialog) {
        const dialogRefLoading = this.genericDialog.loadingMessage('Alterando Underlying...');

        this.underlyingService.editUnderlying(dataDialog)
          .subscribe(response => {
            if (response.return.code === 0) {
              this.underlyings[this.underlyings.indexOf(item)].name = response.data.name;
              this.dataHasChanged();
              this.toastrService.success('Underlying alterado com sucesso.', '', {
                toastComponent: CustomSuccessToastComponent,
              });
            } else {
              this.toastrService.error(response.return.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            dialogRefLoading.close();
          }, err => {
            const error = err.json ? err.json() : {};
            if (error.message) {
              this.toastrService.error(error.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            } else {
              this.toastrService.error('Ocorreu um erro ao alterar o underlying.', '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            dialogRefLoading.close();
          });
      }

      this.dialogRef = null;
    });
  }

  public del(item: AccordionItem) {
    this.underlyings.splice(this.underlyings.indexOf(item), 1);
  }

  private dataHasChanged() {
    const pipe: OrderAccordionPipe = new OrderAccordionPipe();

    this.underlyings = pipe.transform(this.underlyings);
  }

  public changeStatus(item: AccordionItem) {
    const aux = new Underlying(item.name, item.id, item.statusId === 10 ? 5 : 10);
    const dialogRefLoading = this.genericDialog.loadingMessage('Mudando visibilidade ...');
    this.underlyingService.editUnderlying(aux)

      .subscribe(response => {
        if (response.return.code === 0) {
          item.name = response.data.name;
          item.id = response.data.id;
          item.statusId = +response.data.statusId;
          this.dataHasChanged();
          this.toastrService.success('Visibilidade alterada com sucesso.', '', {
            toastComponent: CustomSuccessToastComponent,
          });
        } else {
          this.toastrService.error(response.return.message, '', {
            toastComponent: CustomErrorToastComponent,
          });
        }
        dialogRefLoading.close();
      }, err => {
        const error = err.json ? err.json() : {};
        this.toastrService.error(this.utilService.getServiceMessage(error, 'Ocorreu um erro ao editar o Underlying.'), '', {
          toastComponent: CustomErrorToastComponent,
        });

        dialogRefLoading.close();
      });
  }
}
