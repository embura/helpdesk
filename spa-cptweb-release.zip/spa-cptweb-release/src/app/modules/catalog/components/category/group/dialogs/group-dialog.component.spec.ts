import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { GroupDialogComponent } from './group-dialog.component';
import { DialogHeaderComponent } from '../../../dialog-header/dialog-header.component';
import { CatalogSharedModule } from '../../../../catalog-shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { AccordionItem } from '../../../accordion/accordion-item';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { OverlayRef, ComponentType } from '@angular/cdk/overlay';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';

class MockMatDialog extends MatDialog {
  protected result = {
    groupName: 'unitTest',
    technicalName: '',
    family: {
      name: 'test',
      id: 1
    }
  };
  open<T>(a: ComponentType<T>, options?: any): any {
    return {
      afterClosed: () => Observable.of(this.result)
    };
  }
}

describe('Group dialog Component', () => {
  let component: GroupDialogComponent;
  let fixture: ComponentFixture<GroupDialogComponent>;
  const headerSelector = 'div.header > div.title > span';
  let timeout;
  const editInfo = { data: new AccordionItem(), families: [{ name: 'mock5' }, { name: 'mock' }] };
  editInfo.data.subItem = 'mock';
  editInfo.data.name = 'unit Test';
  editInfo.data.nameTec = 'unit Test';

  // por conta das animacoes css do material
  Object.defineProperty(document.body.style, 'transform', {
    value: () => {
      return {
        enumerable: true,
        configurable: true
      };
    },
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        CatalogSharedModule,
        ReactiveFormsModule
      ],
      declarations: [
        GroupDialogComponent,
        DialogHeaderComponent
      ],
      providers: [
        { provide: MatDialogRef, useValue: { technicalName: '' } },
        { provide: MAT_DIALOG_DATA, useValue: editInfo }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupDialogComponent);
    fixture.detectChanges();
    component = fixture.debugElement.componentInstance;
  });

  beforeAll(() => {
    timeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 1000000;
  });

  afterAll(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = timeout;
  });

  it('should create group dialog component', () => {
    expect(component).toBeTruthy();
  });

  it('Should close modal', () => {
    component['dialog'].close = () => Observable.of();
    component.onCancelClickHandler();
  });

  it('Should instantiate without data for edit', () => {
    component.editInfo = {} as any;
    component.ngOnInit();
    expect(component.editInfo.data).toBeFalsy();
    expect(component.editInfo.families).toBeFalsy();
  });
});
