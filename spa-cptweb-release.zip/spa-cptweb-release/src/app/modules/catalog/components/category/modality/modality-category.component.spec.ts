// tslint:disable-next-line:snt-file-name-suffix
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule, MatDialog, MatButtonModule, MatInputModule } from '@angular/material';
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Observable } from 'rxjs/Observable';
import { AccordionComponent } from '../../accordion/accordion.component';
import { FormsModule } from '@angular/forms';
import { DialogHeaderComponent } from '../../dialog-header/dialog-header.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AccordionItem } from '../../accordion/accordion-item';
import { ModalityCategoryComponent } from './modality-category.component';
import { Modality } from './modality';
import { ModalityCategoryDialogComponent } from './dialog/modality-category-dialog.component';
import { IResponse } from '../../../models/response/response.interface';
import { ICategory } from '../../../models/category/category.interface';
import 'rxjs/add/observable/of';
import { ModalityService } from '../../../services/category/modality/modality.service';
import { GenericDialogComponent } from '../../dialogs/generic/generic-dialog.component';
import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
import { MockToastrService } from '../family/family-category.component.spec';
import { ToastrService } from 'ngx-toastr';
import { UtilService } from '../../../services/util/util.service';
import { CatalogSharedModule } from '../../../catalog-shared.module';
import { SharedModule } from '../../../../../shared.module';
@NgModule({
  imports: [
    CatalogSharedModule,
    FormsModule,
    CommonModule,
    BrowserAnimationsModule,
    SharedModule
  ],
  declarations: [
    ModalityCategoryComponent,
    AccordionComponent,
    ModalityCategoryDialogComponent,
    DialogHeaderComponent,
    GenericDialogComponent,
    OrderAccordionPipe
  ],
  providers: [
    { provide: ModalityService, useValue: TestModule.modalityServiceMock },
    { provide: ToastrService, useClass: MockToastrService },
    UtilService,
    { provide: 'appKey', useValue: 'mockAPPKEY' },
    { provide: 'hubHost', useValue: 'mockHUBHOST' },
  ],
  entryComponents: [ModalityCategoryDialogComponent, GenericDialogComponent]
})
class TestModule {
  static modalities: ICategory[] = [
    {
      'id': 1,
      'name': 'Call',
      'shortName': 'Call',
      'statusId': 5,
      'isEditable': true
    },
    {
      'id': 2,
      'name': 'Vanila',
      'shortName': 'Vanila',
      'statusId': 5,
      'isEditable': true
    }
  ];

  static modalityServiceMock = {
    getModality: (code: number): Observable<IResponse<ICategory>> => {
      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Modality was found successfully.'
        },
        'data': TestModule.modalities.find(mod => mod.id === code)
      });
    },
    getAllModalities: (): Observable<IResponse<ICategory[]>> => {
      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Modalities were found successfully.'
        },
        'data': TestModule.modalities
      });
    },
    editModality: (modality: Modality): Observable<IResponse<ICategory>> => {
      const editedModality = TestModule.modalities[TestModule.modalities.findIndex(ac => ac.id === modality.id)];

      editedModality.name = modality.name;

      TestModule.modalities[TestModule.modalities.findIndex(ac => ac.id === modality.id)] = editedModality;

      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Modality was changed successfully.'
        },
        'data': editedModality
      });
    },
    addModality: (modality: Modality): Observable<IResponse<ICategory>> => {
      const newModality: ICategory = { id: TestModule.modalities.length + 1,
        name: modality.name, shortName: modality.name, statusId: 5, isEditable: true };
      TestModule.modalities.push(newModality);

      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Modality was created successfully.'
        },
        'data': newModality
      });
    }
  };
}

describe('ModalityCategoryComponent', () => {
  let component: ModalityCategoryComponent;
  let fixture: ComponentFixture<ModalityCategoryComponent>;
  let comp;
  let timeout;
  const dialogRef = {
    close: (data: Modality): Observable<Modality> => {
      return Observable.create(() => {
        return data;
      });
    }
  };
  beforeAll(() => {
    timeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;
  });

  afterAll(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = timeout;
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestModule]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalityCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    comp = fixture.debugElement.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open dialog', () => {
    const dialogRefTest: MatDialogRef<ModalityCategoryDialogComponent, Modality> = comp.openDialog();

    expect(dialogRefTest).toBeTruthy();
  });

  it('should open dialog with data', () => {
    const data: Modality = new Modality('Teste', 1);

    const dialogRefTest: MatDialogRef<ModalityCategoryDialogComponent, Modality> = comp.openDialog(data);

    expect(dialogRefTest).toBeTruthy();
  });

  it('should not add a modality', () => {
    const data: Modality = new Modality('Teste', 1);

    comp.add();

    comp.dialogRef.close();

    expect(comp.modalities.length).toBe(0);
  });

  it('should add a modality', () => {
    const data: Modality = new Modality('Teste', 1);

    comp.add();

    comp.dialogRef.close(data);
  });

  it('should not edit a modality', () => {
    const data: AccordionItem = new AccordionItem();
    data.name = 'Teste';
    data.id = 1;

    comp.modalities.push(data);

    comp.edit(data);

    comp.dialogRef.close();
  });

  it('should edit a modality', () => {
    const data: AccordionItem = new AccordionItem();
    data.name = 'Teste';
    data.id = 1;

    comp.modalities.push(data);

    comp.edit(data);

    const modality: Modality = new Modality('Teste 2', 2);

    comp.dialogRef.close(modality);
  });

  it('should delete a modality', () => {
    const item1: AccordionItem = new AccordionItem();
    item1.name = 'Teste';
    item1.id = 1;

    const item2: AccordionItem = new AccordionItem();
    item2.name = 'Teste 2';
    item2.id = 2;

    comp.modalities.push(item1);
    comp.modalities.push(item2);

    expect(comp.modalities.length).toBe(2);

    comp.del(item2);

    expect(comp.modalities.length).toBe(1);
  });

  it('Should get error while add family', () => {
    component['openDialog'] = () => ({
      afterClosed: () => Observable.of({})
    }) as any;
    component['modalityService']['addModality'] = (data) => Observable.of({return: {code: '1', message: 'mock'}}) as any;
    component.add();
    component['modalityService'].addModality = () => Observable.throw({});
    component.add();
  });

  it('Should get error while edit family', () => {
    component['openDialog'] = () => ({
      afterClosed: () => Observable.of({})
    }) as any;
    component['modalityService'].editModality = () => Observable.of({return: {code: 1, message: 'mock'}}) as any;
    component.edit(new AccordionItem());
    component['modalityService'].editModality = () => Observable.throw({}) as any;
    component.edit(new AccordionItem());
  });

  it('Should set modalities', () => {
    component['data'] = null;
    component['data'] = [{id: 6, name: 'mock', shortName: 'mock', statusId: 5, isEditable: true}];
  });
});
