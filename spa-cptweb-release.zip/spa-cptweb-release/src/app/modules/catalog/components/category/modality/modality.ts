export class Modality {
  constructor(
    public name: string,
    public id?: number,
    public statusId?: number
  ) { }
}
