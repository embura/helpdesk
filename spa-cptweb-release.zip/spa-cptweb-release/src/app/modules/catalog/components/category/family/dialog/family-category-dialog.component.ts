import { Component, Inject } from '@angular/core';
import { Family } from '../family';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-cpt-family-category-dialog',
  templateUrl: './family-category-dialog.component.html',
  styleUrls: ['./family-category-dialog.component.scss']
})
export class FamilyCategoryDialogComponent {
  family: Family;
  title: string;

  constructor(@Inject(MAT_DIALOG_DATA) public data: Family,
    public dialogRef: MatDialogRef<FamilyCategoryDialogComponent, Family>) {
    this.fillModel(data);
  }

  public fillModel(data: Family) {
    if (data) {
      this.family = data;
      this.title = 'Editar';
    } else {
      this.family = new Family('', null);
      this.title = 'Adicionar';
    }
  }

  public saveDisabled(value: string): boolean {
    return !(value && value.length > 0);
  }

  public save(): void {
    this.dialogRef.close(this.family);
  }

  public closeDialog(): void {
    this.dialogRef.close();
  }
}
