export class Underlying {
  constructor(
    public name: string,
    public id?: number,
    public statusId?: number
  ) { }
}
