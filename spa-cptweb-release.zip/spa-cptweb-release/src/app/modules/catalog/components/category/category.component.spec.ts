import { TestBed, ComponentFixture } from '@angular/core/testing';
import { CategoryComponent } from './category.component';
import { FamilyService } from '../../services/category/family/family.service';
import { AssetClassService } from '../../services/category/asset-class/asset-class.service';
import { ModalityService } from '../../services/category/modality/modality.service';
import { GroupService } from '../../services/category/group/group.service';
import { UnderlyingService } from '../../services/category/underlying/underlying.service';
import { CatalogSharedModule } from '../../catalog-shared.module';
import { Observable } from 'rxjs/Rx';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

class ServiceMock {
  public getAllFamilies = () => Observable.of({data: []});
  public getAllGroups = () => Observable.of({data: []});
  public getAllModalities = () => Observable.of({data: []});
  public getAllUnderlyings = () => Observable.of({data: []});
  public getAllAssetClasses = () => Observable.of({data: []});
}

describe('Category Component', () => {
  let fixture: ComponentFixture<CategoryComponent>;
  let component: CategoryComponent;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        CategoryComponent
      ],
      imports: [
        CatalogSharedModule
      ],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: [
        { provide: FamilyService, useClass: ServiceMock },
        { provide: AssetClassService, useClass: ServiceMock },
        { provide: ModalityService, useClass: ServiceMock },
        { provide: GroupService, useClass: ServiceMock },
        { provide: UnderlyingService, useClass: ServiceMock },
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(CategoryComponent);
    component = fixture.componentInstance;
    component['genericDialog'].loadingMessage = (text: string) => ({
      close: () => null
    }) as any;
  });

  it('Category Component should be truthy', () => {
    expect(component).toBeTruthy();
  });

  it('Should init component', () => {
    expect(() => component.ngOnInit()).not.toThrow();
  });
});
