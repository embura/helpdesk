export class AssetClass {
  constructor(
    public name: string,
    public id?: number,
    public statusId?: number
  ) { }
}
