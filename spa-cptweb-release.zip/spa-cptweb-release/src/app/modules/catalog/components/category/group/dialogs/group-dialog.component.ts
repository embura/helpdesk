import { Component, Inject, Optional, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { AccordionItem } from '../../../accordion/accordion-item';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ICategory } from '../../../../models/category/category.interface';
import { Group } from '../group';

export interface IInfo {
    data: AccordionItem;
    families: ICategory[];
}
@Component({
    templateUrl: './group-dialog.component.html',
    styleUrls: ['./group-dialog.component.scss']
})
export class GroupDialogComponent implements OnInit {
    public families: Array<any> = [];
    public form: FormGroup;
    title: string;

    constructor(
        private dialog: MatDialogRef<GroupDialogComponent>,
        @Optional() @Inject(MAT_DIALOG_DATA) public editInfo: IInfo,
        private _fb: FormBuilder) {
        this.fillModel(editInfo.data);
    }

    public fillModel(data: AccordionItem) {
        this.title = data ? 'Editar' : 'Adicionar';
    }

    ngOnInit(): void {
        this.form = this._fb.group({
            family: [null, Validators.required],
            groupName: ['', Validators.required],
            technicalName: ['', Validators.compose([Validators.required, Validators.maxLength(10)])],
        });
        if (this.editInfo.families) {
            this.families = this.editInfo.families;
        }
        if (this.editInfo.data) {
            for (const family of this.families) {
                if (family.name === this.editInfo.data.subItem) {
                    this.form.setValue({
                        family,
                        groupName: this.editInfo.data.name,
                        technicalName: this.editInfo.data.nameTec,
                    });
                    break;
                }
            }
        }
    }

    public onCancelClickHandler(): void {
        this.dialog.close();
    }
}
