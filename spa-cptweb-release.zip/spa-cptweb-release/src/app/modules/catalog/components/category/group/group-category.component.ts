import { Component, Input, ViewChild } from '@angular/core';
import { AccordionItem } from '../../accordion/accordion-item';
import { MatDialog, MatDialogRef } from '@angular/material';
import { GroupDialogComponent } from './dialogs/group-dialog.component';
import { GroupService } from '../../../services/category/group/group.service';
import { Group } from './group';
import { Family } from '../family/family';
import { GenericDialogComponent } from '../../dialogs/generic/generic-dialog.component';
import { IGroup, ICategory } from '../../../models/category/category.interface';
import { GenericDialog } from '../../../models/dialog/generic-dialog';
import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
import { GenericCategory } from '../generic-category';
import { ToastrService } from 'ngx-toastr';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { CustomSuccessToastComponent } from '../../toast/custom-success-toast.component';
import { UtilService } from '../../../services/util/util.service';
import { AccordionComponent } from '../../accordion/accordion.component';

@Component({
  selector: 'app-cpt-group-category',
  templateUrl: './group-category.component.html'
})
export class GroupCategoryComponent extends GenericCategory {
  public groups: Array<AccordionItem> = [];
  private _families: Array<ICategory> = [];
  private auxGenericDialog: MatDialogRef<GenericDialogComponent>;
  private genericDialog: GenericDialog;
  @ViewChild('accordion') public accordion: AccordionComponent;

  constructor(
    private readonly groupService: GroupService,
    private readonly dialog: MatDialog,
    private toastrService: ToastrService,
    private utilService: UtilService
  ) {
    super(dialog);
    this.genericDialog = new GenericDialog(this.dialog);
  }


  @Input() private set families(data: Array<ICategory>) {
    if (data) {
      this._families = data;
      data.forEach(family => {
        this.groups.forEach(group => {
          if (group.subItemId === family.id) {
            group.subItem = family.name;
          }
        });
      });
    }
  }

  @Input() private set data(data: Array<IGroup>) {
    if (data) {
      this.groups = [];
      data.forEach(group => {
        const auxItem: AccordionItem = new AccordionItem();
        const currentFamily = this._families.find(family => family.id === group.familyId);
        auxItem.id = group.id;
        auxItem.name = group.name;
        auxItem.nameTec = group.technicalName || ' ';
        auxItem.statusId = group.statusId;
        auxItem.canEdit = group.isEditable;
        auxItem.subItem = currentFamily.name;
        auxItem.subItemId = currentFamily.id;
        this.groups.push(auxItem);
      });
    }
  }

  private openModal(data?: AccordionItem): MatDialogRef<GroupDialogComponent> {
    const groupDialog = this.dialog.open(GroupDialogComponent, {
      width: '570px',
      data: { data, families: this._families },
      disableClose: true
    });
    return groupDialog;
  }

  public async createGroupDialog(): Promise<void> {
    const groupDialog = this.openModal();
    const newGroup = await groupDialog.afterClosed().toPromise();
    if (newGroup) {
      const group: Group = new Group(newGroup.groupName, newGroup.technicalName);
      const family: Family = new Family(newGroup.family.name, newGroup.family.id);
      group.statusId = 10;
      this.addGroup(group, family);
    }
  }

  public async editGroupDialog(item: AccordionItem): Promise<void> {
    const groupDialog = this.openModal(item);
    const updatedGroup = await groupDialog.afterClosed().toPromise();
    if (updatedGroup) {
      const group: Group = new Group(
        updatedGroup.groupName,
        updatedGroup.technicalName,
        item.id, new Family(item.subItem, item.subItemId),
        item.statusId);
      group.family = updatedGroup.family;
      group.family = new Family(updatedGroup.family.name, updatedGroup.family.id);
      this.editGroup(group, item);
    }
  }

  private editGroup(group: Group, item: AccordionItem): void {
    this.auxGenericDialog = this.genericDialog.loadingMessage('Alterando Grupo...');
    this.groupService.alterGroup(group).subscribe(
      response => {
        if (response.return.code === 0) {
          item.name = response.data.name;
          item.subItem = group.family.name;
          this.dataHasChanged();
          this.toastrService.success('Grupo alterado com sucesso.', '', {
            toastComponent: CustomSuccessToastComponent,
          });
        } else {
          this.toastrService.error(response.return.message, '', {
            toastComponent: CustomErrorToastComponent,
          });
        }
        this.auxGenericDialog.close();
      },
      err => {
        this.auxGenericDialog.close();
        const error = err.json ? err.json() : {};
        if (error.message) {
          this.toastrService.error(error.message, '', {
            toastComponent: CustomErrorToastComponent,
          });
        } else {
          this.toastrService.error('Ocorreu um erro ao adicionar o grupo.', '', {
            toastComponent: CustomErrorToastComponent,
          });
        }
      }
    );
  }

  private addGroup(group: Group, family: Family): void {
    this.auxGenericDialog = this.genericDialog.loadingMessage('Adicionando Grupo...');
    this.groupService.addGroup(group, family).subscribe(
      response => {
        if (response.return.code === 0) {
          const newItem = new AccordionItem();
          newItem.id = response.data.id;
          newItem.name = response.data.name;
          newItem.statusId = response.data.statusId;
          newItem.subItem = family.name;
          newItem.subItemId = family.code;
          newItem.canEdit = true;
          this.groups.push(newItem);
          this.dataHasChanged();
          this.toastrService.success('Grupo adicionado com sucesso.', '', {
            toastComponent: CustomSuccessToastComponent,
          });
        } else {
          this.toastrService.error(response.return.message, '', {
            toastComponent: CustomErrorToastComponent,
          });
        }
        this.auxGenericDialog.close();
      },
      err => {
        this.auxGenericDialog.close();
        const error = err.json ? err.json() : {};
        if (error.message) {
          this.toastrService.error(error.message, '', {
            toastComponent: CustomErrorToastComponent,
          });
        } else {
          this.toastrService.error('Ocorreu um erro ao adicionar o grupo.', '', {
            toastComponent: CustomErrorToastComponent,
          });
        }
      }
    );
  }

  private dataHasChanged() {
    const pipe: OrderAccordionPipe = new OrderAccordionPipe();

    this.groups = pipe.transform(this.groups);
  }

  public changeStatus(item: AccordionItem) {
    const aux = new Group(
      item.name, item.nameTec,
      item.id, new Family(item.subItem, item.subItemId),
      item.statusId === 10 ? 5 : 10);
    const dialogRefLoading = this.genericDialog.loadingMessage('Mudando visibilidade ...');
    this.groupService.alterGroup(aux)

      .subscribe(response => {
        if (response.return.code === 0) {
          item.name = response.data.name;
          item.id = response.data.id;
          item.statusId = +response.data.statusId;
          this.dataHasChanged();
          this.toastrService.success('Visibilidade alterada com sucesso.', '', {
            toastComponent: CustomSuccessToastComponent,
          });
        } else {
          this.toastrService.error(response.return.message, '', {
            toastComponent: CustomErrorToastComponent,
          });
        }
        dialogRefLoading.close();
      }, err => {
        const error = err.json ? err.json() : {};
        this.toastrService.error(this.utilService.getServiceMessage(error, 'Ocorreu um erro ao editar o grupo.'), '', {
          toastComponent: CustomErrorToastComponent,
        });

        dialogRefLoading.close();
      });
  }
}
