// tslint:disable-next-line:snt-file-name-suffix
import { UnderlyingCategoryComponent } from './underlying-category.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Underlying } from './underlying';
import { Observable } from 'rxjs/Observable';
import { MatDialogRef, MatDialogModule, MatButtonModule, MatInputModule, MatIconModule } from '@angular/material';
import { UnderlyingCategoryDialogComponent } from './dialog/underlying-category-dialog.component';
import { AccordionItem } from '../../accordion/accordion-item';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AccordionComponent } from '../../accordion/accordion.component';
import { DialogHeaderComponent } from '../../dialog-header/dialog-header.component';
import { IResponse } from '../../../models/response/response.interface';
import { ICategory } from '../../../models/category/category.interface';
import 'rxjs/add/observable/of';
import { UnderlyingService } from '../../../services/category/underlying/underlying.service';
import { GenericDialogComponent } from '../../dialogs/generic/generic-dialog.component';
import { CatalogSharedModule } from '../../../catalog-shared.module';
import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
import { MockToastrService } from '../family/family-category.component.spec';
import { ToastrService } from 'ngx-toastr';
import { UtilService } from '../../../services/util/util.service';
import { SharedModule } from '../../../../../shared.module';

@NgModule({
  imports: [
    CatalogSharedModule,
    FormsModule,
    CommonModule,
    BrowserAnimationsModule,
    SharedModule
  ],
  declarations: [
    UnderlyingCategoryComponent,
    AccordionComponent,
    UnderlyingCategoryDialogComponent,
    DialogHeaderComponent,
    GenericDialogComponent,
    OrderAccordionPipe
  ],
  providers: [
    { provide: UnderlyingService, useValue: TestModule.underlyingServiceMock },
    { provide: ToastrService, useClass: MockToastrService },
    UtilService,
    { provide: 'appKey', useValue: 'mockAPPKEY' },
    { provide: 'hubHost', useValue: 'mockHUBHOST' },
  ],
  entryComponents: [UnderlyingCategoryDialogComponent, GenericDialogComponent]
})
class TestModule {
  static underlyings: ICategory[] = [
    {
      'id': 1,
      'name': 'USD/BRL',
      'shortName': 'USD/BRL',
      'statusId': 5,
      'isEditable': true
    },
    {
      'id': 2,
      'name': 'IDI',
      'shortName': 'IDI',
      'statusId': 5,
      'isEditable': true
    }

  ];

  static underlyingServiceMock = {
    getUnderlying: (code: number): Observable<IResponse<ICategory>> => {
      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Underlying was found successfully.'
        },
        'data': TestModule.underlyings.find(mod => mod.id === code)
      });
    },
    getAllUnderlyings: (): Observable<IResponse<ICategory[]>> => {
      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Underlyings were found successfully.'
        },
        'data': TestModule.underlyings
      });
    },
    editUnderlying: (underlying: Underlying): Observable<IResponse<ICategory>> => {
      const editedUnderlying = TestModule.underlyings[TestModule.underlyings.findIndex(ac => ac.id === underlying.id)];

      editedUnderlying.name = underlying.name;

      TestModule.underlyings[TestModule.underlyings.findIndex(ac => ac.id === underlying.id)] = editedUnderlying;

      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Underlying was changed successfully.'
        },
        'data': editedUnderlying
      });
    },
    addUnderlying: (underlying: Underlying): Observable<IResponse<ICategory>> => {
      const newUnderlying: ICategory = { id: TestModule.underlyings.length + 1,
        name: underlying.name, shortName: underlying.name, statusId: 5, isEditable: true };
      TestModule.underlyings.push(newUnderlying);

      return Observable.of({
        'return': {
          'code': 0,
          'message': '[Category] Underlying was created successfully.'
        },
        'data': newUnderlying
      });
    }
  };
}

describe('UnderlyingCategoryComponent', () => {
  let component: UnderlyingCategoryComponent;
  let fixture: ComponentFixture<UnderlyingCategoryComponent>;
  let comp;

  const dialogRef = {
    close: (data: Underlying): Observable<Underlying> => {
      return Observable.create(() => {
        return data;
      });
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TestModule]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnderlyingCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    comp = fixture.debugElement.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open dialog', () => {
    const dialogRefTest: MatDialogRef<UnderlyingCategoryDialogComponent, Underlying> = comp.openDialog();

    expect(dialogRefTest).toBeTruthy();
  });

  it('should open dialog with data', () => {
    const data: Underlying = new Underlying('Teste', 1);

    const dialogRefTest: MatDialogRef<UnderlyingCategoryDialogComponent, Underlying> = comp.openDialog(data);

    expect(dialogRefTest).toBeTruthy();
  });

  it('should not add a underlying', () => {
    const data: Underlying = new Underlying('Teste', 1);

    comp.add();

    comp.dialogRef.close();

    expect(comp.underlyings.length).toBe(0);
  });

  it('should add a underlying', () => {
    const data: Underlying = new Underlying('Teste', 1);

    comp.add();

    comp.dialogRef.close(data);
  });

  it('should not edit a underlying', () => {
    const data: AccordionItem = new AccordionItem();
    data.name = 'Teste';
    data.id = 1;

    comp.underlyings.push(data);

    comp.edit(data);

    comp.dialogRef.close();
  });

  it('should edit a underlying', () => {
    const data: AccordionItem = new AccordionItem();
    data.name = 'Teste';
    data.id = 1;

    comp.underlyings.push(data);

    comp.edit(data);

    const underlying: Underlying = new Underlying('Teste 2', 2);

    comp.dialogRef.close(underlying);
  });

  it('should delete a underlying', () => {
    const item1: AccordionItem = new AccordionItem();
    item1.name = 'Teste';
    item1.id = 1;

    const item2: AccordionItem = new AccordionItem();
    item2.name = 'Teste 2';
    item2.id = 2;

    comp.underlyings.push(item1);
    comp.underlyings.push(item2);

    expect(comp.underlyings.length).toBe(2);

    comp.del(item2);

    expect(comp.underlyings.length).toBe(1);
  });

  it('show return create response with error', () => {
    component['underlyingService'].addUnderlying = (underlying: Underlying): Observable<IResponse<ICategory>> => {
      return Observable.of({
        'return': {
          'code': 1,
          'message': '[Category] Underlying was not created because of a error.'
        },
        'data': null
      });
    };

    const countBefore: number = component['underlyings'].length;

    component.add();

    component['dialogRef'].close(new Underlying('Teste', 1));

    const countAfter: number = component['underlyings'].length;

    expect(countBefore).toBe(countAfter);
  });

  it('show return an exception when invoke service to add', () => {
    component['underlyingService'].addUnderlying = () => Observable.throw({});

    const countBefore: number = component['underlyings'].length;

    component.add();

    component['dialogRef'].close(new Underlying('Teste', 1));

    const countAfter: number = component['underlyings'].length;

    expect(countBefore).toBe(countAfter);
  });

  it('show return edit response with error', () => {
    component['underlyingService'].editUnderlying = (underlying: Underlying): Observable<IResponse<ICategory>> => {
      return Observable.of({
        'return': {
          'code': 1,
          'message': '[Category] Underlying was not altered because of a error.'
        },
        'data': null
      });
    };

    const countBefore: number = component['underlyings'].length;
    const item = new AccordionItem();
    item.name = 'Test 1';
    item.id = 1;
    item.subItem = '';
    item.subItemId = 0;
    item.canDelete = false;
    item.canEdit = false;
    item.popupOpen = false;
    component.edit(item);

    component['dialogRef'].close(new Underlying('Teste', 1));

    const countAfter: number = component['underlyings'].length;

    expect(countBefore).toBe(countAfter);
  });

  it('show return an exception when invoke service to edit', () => {
    component['underlyingService'].editUnderlying = () => Observable.throw({});

    const countBefore: number = component['underlyings'].length;
    const item = new AccordionItem();
    item.name = 'Test 1';
    item.id = 1;
    item.subItem = '';
    item.subItemId = 0;
    item.canDelete = false;
    item.canEdit = false;
    item.popupOpen = false;
    component.edit(item);

    component['dialogRef'].close(new Underlying('Teste', 1));

    const countAfter: number = component['underlyings'].length;

    expect(countBefore).toBe(countAfter);
  });

  it('should fill data and map to underlyings', () => {
    const data: ICategory[] = [
      { name: 'Mock 1', shortName: 'Mock 1', id: 1, statusId: 5, isEditable: true },
      { name: 'Mock 2', shortName: 'Mock 2', id: 2, statusId: 5, isEditable: true }
    ];
    component['data'] = data;

    expect(component['underlyings'].length).toBe(2);
  });

  it('should fill data and not map to underlyings', () => {
    component['data'] = null;

    expect(component['underlyings'].length).toBe(0);
  });
});
