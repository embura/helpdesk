import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DialogHeaderComponent } from '../../../dialog-header/dialog-header.component';
import { FormsModule } from '@angular/forms';
import { MatInputModule, MatDialogModule, MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Observable } from 'rxjs/Observable';
import { AssetClassCategoryDialogComponent } from './asset-class-category-dialog.component';
import { AssetClass } from '../asset-class';
import { SharedModule } from '../../../../../../shared.module';
import { CatalogSharedModule } from '../../../../catalog-shared.module';

describe('AssetClassCategoryDialogComponent', () => {
  let component: AssetClassCategoryDialogComponent;
  let fixture: ComponentFixture<AssetClassCategoryDialogComponent>;
  let comp;

  const dialogRef = {
    close : (data: AssetClass): Observable<AssetClass> => {
      return Observable.create(() => {
        return data;
      });
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        MatInputModule,
        MatDialogModule,
        BrowserAnimationsModule,
        SharedModule,
        CatalogSharedModule
       ],
      declarations: [
        AssetClassCategoryDialogComponent,
        DialogHeaderComponent
      ],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: undefined },
        { provide: MatDialogRef, useValue: {} }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetClassCategoryDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    comp = fixture.debugElement.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open dialog with new asset class and save it', () => {
    comp.dialogRef = dialogRef;

    comp.assetClass.name = 'Teste';

    comp.save();
  });

  it('save button should be enabled when name is informed', () => {
    comp.dialogRef = dialogRef;

    const resultInformed: boolean = comp.saveDisabled('Teste');

    expect(resultInformed).toBe(false);

    const resultNotInformed: boolean = comp.saveDisabled();

    expect(resultNotInformed).toBe(true);
  });

  it('model was informed', () => {
    const model: AssetClass = new AssetClass('Teste', 1);

    comp.fillModel(model);

    expect(comp.assetClass).toBe(model);
  });
});
