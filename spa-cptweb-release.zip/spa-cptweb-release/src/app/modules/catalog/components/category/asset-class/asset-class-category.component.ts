import { Component, Input, ViewChild } from '@angular/core';
import { AccordionItem } from '../../accordion/accordion-item';
import { MatDialog, MatDialogRef } from '@angular/material';
import { AssetClass } from './asset-class';
import { AssetClassCategoryDialogComponent } from './dialog/asset-class-category-dialog.component';
import { AssetClassService } from '../../../services/category/asset-class/asset-class.service';
import { GenericDialogComponent } from '../../dialogs/generic/generic-dialog.component';
import { ICategory } from '../../../models/category/category.interface';
import { GenericDialog } from '../../../models/dialog/generic-dialog';
import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
import { GenericCategory } from '../generic-category';
import { CustomSuccessToastComponent } from '../../toast/custom-success-toast.component';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { ToastrService } from 'ngx-toastr';
import { UtilService } from '../../../services/util/util.service';
import { AccordionComponent } from '../../accordion/accordion.component';

@Component({
  selector: 'app-cpt-asset-class-category',
  templateUrl: './asset-class-category.component.html',
  styleUrls: ['./asset-class-category.component.scss']
})
export class AssetClassCategoryComponent extends GenericCategory {
  public assetClasses: AccordionItem[] = [];
  private dialogRef: MatDialogRef<AssetClassCategoryDialogComponent, AssetClass>;
  private genericDialog: GenericDialog;
  @ViewChild('accordion') public accordion: AccordionComponent;

  @Input() private set data(data: Array<ICategory>) {
    if (data) {
      this.assetClasses = [];
      data.forEach(assetClass => {
        const assetClassItem = new AccordionItem();
        assetClassItem.name = assetClass.name;
        assetClassItem.id = assetClass.id;
        assetClassItem.statusId = assetClass.statusId;
        assetClassItem.canEdit = assetClass.isEditable;
        this.assetClasses.push(assetClassItem);
      });
    }
  }

  constructor(
    private dialog: MatDialog,
    private assetClassService: AssetClassService,
    private toastrService: ToastrService,
    private utilService: UtilService
  ) {
    super(dialog);
    this.genericDialog = new GenericDialog(dialog);
  }

  private openDialog(data: AssetClass = null): MatDialogRef<AssetClassCategoryDialogComponent, AssetClass> {
    return this.dialog.open(AssetClassCategoryDialogComponent, {
      width: '570px',
      height: '314px',
      data: data,
      disableClose: true
    });
  }

  public add(): void {
    this.dialogRef = this.openDialog();

    this.dialogRef.afterClosed().subscribe(data => {
      if (data) {
        data.statusId = 10;
        const loadingDialog: MatDialogRef<GenericDialogComponent> = this.genericDialog.loadingMessage('Adicionando Asset Class...');
        const assetClass: AssetClass = new AssetClass(data.name, data.id, data.statusId);
        this.assetClassService.createAssetClass(assetClass).subscribe(
          resp => {
            if (resp.return.code === 0) {
              const item: AccordionItem = new AccordionItem();
              item.name = resp.data.name;
              item.id = resp.data.id;
              item.statusId = resp.data.statusId;
              item.canEdit = true;
              this.assetClasses.push(item);
              this.dataHasChanged();
              // this.genericDialog.successMessage('Asset Class adicionada com sucesso.');
              this.toastrService.success('Asset Class adicionada com sucesso.', '', {
                toastComponent: CustomSuccessToastComponent,
              });
            } else {
              // this.genericDialog.errorMessage(resp.return.message);
              this.toastrService.error(resp.return.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            }
            loadingDialog.close();
          }, err => {
            const error = err.json ? err.json() : {};
            if (error.message) {
              // this.genericDialog.errorMessage(error.message);
              this.toastrService.error(error.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            } else {
              // this.genericDialog.errorMessage('Ocorreu um erro ao adicionar a Asset Class.');
              this.toastrService.error('Ocorreu um erro ao adicionar a Asset Class.', '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            loadingDialog.close();
          }
        );
      }

      this.dialogRef = null;
    });
  }

  public edit(item: AccordionItem) {
    const data: AssetClass = new AssetClass(item.name, item.id);

    this.dialogRef = this.openDialog(data);

    this.dialogRef.afterClosed().subscribe(dataResp => {
      if (dataResp) {
        const loadingDialog: MatDialogRef<GenericDialogComponent> = this.genericDialog.loadingMessage('Alterando Asset Class...');
        this.assetClassService.editAssetClass(dataResp).subscribe(
          resp => {
            if (resp.return.code === 0) {
              // this.genericDialog.successMessage('Asset Class alterada com sucesso.');
              this.toastrService.success('Asset Class alterada com sucesso.', '', {
                toastComponent: CustomSuccessToastComponent,
              });
              this.dataHasChanged();
              this.assetClasses[this.assetClasses.indexOf(item)].name = resp.data.name;
            } else {
              // this.genericDialog.errorMessage(resp.return.message);
              this.toastrService.error(resp.return.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            }
            loadingDialog.close();
          }, err => {
            const error = err.json ? err.json() : {};
            if (error.message) {
              // this.genericDialog.errorMessage(error.message);
              this.toastrService.error(error.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            } else {
              // this.genericDialog.errorMessage('Ocorreu um erro ao alterar a Asset Class.');
              this.toastrService.error('Ocorreu um erro ao alterar a Asset Class.', '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            loadingDialog.close();
          }
        );
      }

      this.dialogRef = null;
    });
  }

  private dataHasChanged() {
    const pipe: OrderAccordionPipe = new OrderAccordionPipe();

    this.assetClasses = pipe.transform(this.assetClasses);
  }

  public changeStatus(item: AccordionItem) {
    const aux = new AssetClass(item.name, item.id, item.statusId === 10 ? 5 : 10);
    const dialogRefLoading = this.genericDialog.loadingMessage('Mudando visibilidade ...');
    this.assetClassService.editAssetClass(aux)

      .subscribe(response => {
        if (response.return.code === 0) {
          item.name = response.data.name;
          item.id = response.data.id;
          item.statusId = +response.data.statusId;
          this.dataHasChanged();
          this.toastrService.success('Visibilidade alterada com sucesso.', '', {
            toastComponent: CustomSuccessToastComponent,
          });
        } else {
          this.toastrService.error(response.return.message, '', {
            toastComponent: CustomErrorToastComponent,
          });
        }
        dialogRefLoading.close();
      }, err => {
        const error = err.json ? err.json() : {};
        this.toastrService.error(this.utilService.getServiceMessage(error, 'Ocorreu um erro ao editar a Asset Class.'), '', {
          toastComponent: CustomErrorToastComponent,
        });

        dialogRefLoading.close();
      });
  }
}
