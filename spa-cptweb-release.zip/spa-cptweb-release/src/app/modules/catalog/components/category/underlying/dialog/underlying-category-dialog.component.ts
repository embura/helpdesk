import { Component, Inject } from '@angular/core';
import { Underlying } from '../underlying';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-cpt-underlying-category-dialog',
  templateUrl: './underlying-category-dialog.component.html',
  styleUrls: ['./underlying-category-dialog.component.scss']
})
export class UnderlyingCategoryDialogComponent {
  underlying: Underlying;
  title: string;

  constructor(@Inject(MAT_DIALOG_DATA) public data: Underlying,
    public dialogRef: MatDialogRef<UnderlyingCategoryDialogComponent, Underlying>) {
    this.fillModel(data);
  }

  public fillModel(data: Underlying) {
    if (data) {
      this.underlying = data;
      this.title = 'Editar';
    } else {
      this.underlying = new Underlying('', null);
      this.title = 'Adicionar';
    }
  }

  public saveDisabled(value: string): boolean {
    return !(value && value.length > 0);
  }

  public save(): void {
    this.dialogRef.close(this.underlying);
  }

  public closeDialog(): void {
    this.dialogRef.close();
  }
}
