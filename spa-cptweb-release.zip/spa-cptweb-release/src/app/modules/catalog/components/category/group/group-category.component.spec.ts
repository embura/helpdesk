// tslint:disable-next-line:snt-file-name-suffix
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { GroupCategoryComponent } from './group-category.component';
import { CatalogSharedModule } from '../../../catalog-shared.module';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AccordionComponent } from '../../accordion/accordion.component';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ComponentType } from '@angular/cdk/overlay';
import { Observable } from 'rxjs/Rx';
import { GroupService } from '../../../services/category/group/group.service';
import { Group } from './group';
import { Family } from '../family/family';
import { AccordionItem } from '../../accordion/accordion-item';
import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
import { MockToastrService } from '../family/family-category.component.spec';
import { ToastrService } from 'ngx-toastr';
import { HistoricDialogComponent } from '../../historic/historic-dialog.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { UtilService } from '../../../services/util/util.service';
class MockMatDialog extends MatDialog {
  protected result = {
    groupName: 'unitTest',
    family: {
      name: 'test',
      id: 1
    }
  };
  open<T>(a: ComponentType<T>, options?: any): any {
    return {
      afterClosed: () => Observable.of(this.result)
    };
  }
}

const response = {
  return: {
    code: 0,
    message: 'mock'
  },
  data: { id: 1 }
};

const MockGroupService = {
  addGroup: () => Observable.of(response),
  alterGroup: () => Observable.of(response)
};

describe('Group Category Component', () => {
  let component: GroupCategoryComponent;
  let fixture: ComponentFixture<GroupCategoryComponent>;
  const returnErr = { return: { code: 'not 0', message: 'mock' } };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        CatalogSharedModule,
        NoopAnimationsModule
      ],
      declarations: [
        GroupCategoryComponent,
        AccordionComponent,
        OrderAccordionPipe,
        HistoricDialogComponent
      ],
      schemas: [NO_ERRORS_SCHEMA],
      providers: [
        {
          provide: MatDialog,
          useClass: MockMatDialog
        },
        {
          provide: GroupService,
          useValue: MockGroupService
        },
        {
          provide: ToastrService,
          useClass: MockToastrService
        },
        UtilService,
        { provide: 'appKey', useValue: 'mockAPPKEY' },
        { provide: 'hubHost', useValue: 'mockHUBHOST' },
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupCategoryComponent);
    component = fixture.debugElement.componentInstance;
    component['genericDialog'].loadingMessage = (message) => ({
      close: () => 'mock'
    }) as any;
    component['genericDialog'].successMessage = component['genericDialog'].loadingMessage;
    component['genericDialog'].errorMessage = component['genericDialog'].successMessage;
  });

  it('should create Group Category Component', () => {
    expect(component).toBeTruthy();
  });

  it('should add an item to groups array', () => {
    const item = new AccordionItem();
    item.name = 'mock';
    item.id = 2;
    item.subItemId = 2;
    component.groups = [item];
    component['families'] = [{ id: 2, name: 'mockFamily', shortName: 'mockFamily', statusId: 5, isEditable: true }];
    component['data'] = [{ id: 2, name: 'mock', familyId: 2, shortName: 'mock', statusId: 5, isEditable: true, technicalName: '' }];
    expect(() => component.createGroupDialog()).not.toThrow();
  });

  it('should cancel an group insertion', () => {
    component['openModal'] = () => ({
      afterClosed: () => Observable.of(null)
    }) as any;
    expect(() => component.createGroupDialog()).not.toThrow();
  });

  it('should cancel group edition', () => {
    component['openModal'] = () => ({
      afterClosed: () => Observable.of(null)
    }) as any;
    expect(() => component.editGroupDialog(new AccordionItem())).not.toThrow();
  });

  it('addgroup error', () => {
    component['data'] = null;
    component['families'] = null;
    const item = new AccordionItem();
    item.subItemId = 2;
    component.groups = [item];
    component['families'] = [{ id: 9, name: 'mockFamily', shortName: 'mockFamily', statusId: 5, isEditable: true },
    { id: 2, name: 'mockFamily', shortName: 'mockFamily', statusId: 5, isEditable: true }];
    component['_families'] = [{ id: 2, name: 'mock', shortName: 'mock', statusId: 5, isEditable: true }];
    component['data'] = [{ id: 9, name: 'mock', familyId: 2, shortName: 'mock', statusId: 5, isEditable: true, technicalName: '' }];
    component['groupService']['addGroup'] = () => Observable.of(returnErr) as any;
    expect(() => component.createGroupDialog()).not.toThrow();
  });

  it('addgroup throw', () => {
    component['groupService']['addGroup'] = () => Observable.throw({}) as any;
    expect(() => component.createGroupDialog()).not.toThrow();
  });

  it('should edit an item', () => {
    const item = new AccordionItem();
    expect(() => component.editGroupDialog(item)).not.toThrow();
  });

  it('should not edit an item', () => {
    const item = new AccordionItem();
    component['groupService'].alterGroup = () => Observable.of(returnErr) as any;
    expect(() => component.editGroupDialog(item)).not.toThrow();
  });

  it('should observable throw at editing', () => {
    const item = new AccordionItem();
    component['groupService'].alterGroup = () => Observable.throw({});
    expect(() => component.editGroupDialog(item)).not.toThrow();
  });

  it('should open historic modal', () => {
    const result = component.openHistory(1, 'mockedCategory');
    expect(result).toBeTruthy();
  });
});
