import { Component, EventEmitter, Output, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ProductService } from '../../services/product/product.service';
import { ICategoryProduct, ICategories } from '../../models/product/category-product.interface';
import { IResponse } from '../../models/response/response.interface';
import { ToastrService } from 'ngx-toastr';
import { IProduct, ITotal } from '../../models/product/product.interface';
import * as HistoricGrid from '../historic/historic-grid/historic-grid';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { IFilterOption } from '../../models/filter/filter-object.interface';
import { GenericDialog } from '../../models/dialog/generic-dialog';
import { MatDialog, MatDialogRef } from '@angular/material';
import { IHistoricData } from '../historic/historic-dialog';
import { TABLE_MAPPER } from '../../models/common/table-mapping';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { FamilyService } from '../../services/category/family/family.service';
import { GroupService } from '../../services/category/group/group.service';
import { AssetClassService } from '../../services/category/asset-class/asset-class.service';
import { ModalityService } from '../../services/category/modality/modality.service';
import { UnderlyingService } from '../../services/category/underlying/underlying.service';
import { Subscription } from 'rxjs/Rx';
import { IFilterEvent, FilterComponent } from '../filter/filter.component';
import { UtilService, IQuery } from '../../services/util/util.service';
import { CustomErrorToastComponent } from '../toast/custom-error-toast.component';
import { CustomSuccessToastComponent } from '../toast/custom-success-toast.component';
import { GenericDialogComponent } from '../dialogs/generic/generic-dialog.component';

@Component({
  selector: 'app-cpt-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
  animations: [
    trigger('rotatedState', [
      state('default', style({ transform: 'rotate(0)' })),
      state('rotated', style({ transform: 'rotate(-180deg)' })),
      transition('rotated => default', animate('400ms ease-out')),
      transition('default => rotated', animate('400ms ease-in'))
    ])
  ]
})
export class SearchComponent implements OnInit, OnDestroy {

  @Output() openProduct: EventEmitter<IProduct> = new EventEmitter<IProduct>();
  @Output() duplicateProduct: EventEmitter<IProduct> = new EventEmitter<IProduct>();
  @ViewChild('filterComponent') private filterComponent: FilterComponent;
  private genericDialog: GenericDialog;
  private _subscriptions: Array<Subscription> = [];
  public filter: FormGroup;
  public groupLoading: boolean;
  public products: Array<IProduct> = [];
  public families: Array<any> = [];
  public groups: Array<any> = [];
  public assetClasses: Array<any> = [];
  public modalities: Array<any> = [];
  public underlyings: Array<any> = [];
  public quantites: ITotal;
  private counter = 1;
  public showSpinner: boolean;
  private paramsCache = {};
  public scrolled = false;

  constructor(
    dialog: MatDialog,
    private _fb: FormBuilder,
    private productService: ProductService,
    private toastrService: ToastrService,
    private familyService: FamilyService,
    private groupService: GroupService,
    private assetClassService: AssetClassService,
    private modalityService: ModalityService,
    private underlyingService: UnderlyingService,
    private readonly utilService: UtilService) {
    this.genericDialog = new GenericDialog(dialog);
  }

  private onSuccessDataParse(response: IResponse<any[]>): IResponse<any[]> {
    response.data = [{ name: 'Nenhum', id: 0 }, ...response.data === undefined ? [] : response.data];
    return response;
  }

  private errorHandler(): IResponse<any[]> {
    return {
      return: {
        code: 1,
        message: 'Erro ao recuperar dados.'
      },
      data: []
    } as IResponse<any[]>;
  }

  public async ngOnInit(): Promise<void> {
    this.filter = this._fb.group({
      family: [null],
      group: [null],
      assetClass: [null],
      modality: [null],
      underlying: [null]
    });
    this._subscriptions.push(this.filter.valueChanges.subscribe(_ => {
      this.filterComponent.emitSearch();
    }));
    const responses = await Promise.all([
      this.familyService.getAllFamilies().toPromise().then(this.onSuccessDataParse).catch(this.errorHandler),
      this.assetClassService.getAllAssetClasses().toPromise().then(this.onSuccessDataParse).catch(this.errorHandler),
      this.modalityService.getAllModalities().toPromise().then(this.onSuccessDataParse).catch(this.errorHandler),
      this.underlyingService.getAllUnderlyings().toPromise().then(this.onSuccessDataParse).catch(this.errorHandler)
    ]);
    this.families = responses[0].data;
    this.assetClasses = responses[1].data;
    this.modalities = responses[2].data;
    this.underlyings = responses[3].data;
    const _callBack = async (values): Promise<void> => {
      this.groupLoading = true;
      this.filter.controls.group.setValue(null);
      const resp = await this.groupService.getGroupsByFamily(values.id)
        .toPromise().then(this.onSuccessDataParse).catch(this.errorHandler);
      this.groups = resp.data;
      this.groupLoading = false;
    };
    this._subscriptions.push(this.filter.controls.family.valueChanges.subscribe(_callBack));
  }

  public editProduct(product: IProduct): void {
    this.openProduct.emit(product);
  }

  public duplicateButtonHandler(product: IProduct): void {
    this.duplicateProduct.emit(product);
  }

  public async changeProductStatus(product: IProduct): Promise<void> {
    const updatedProduct = { ...product };

    updatedProduct.statusId = updatedProduct.statusId === 10 ? 5 : 10;
    const statusDescription = updatedProduct.statusId === 10 ? 'ativado' : 'inativado';
    product.isOpen = false;

    if (updatedProduct.params) {
      delete updatedProduct.params;
    }

    if (updatedProduct.groupsSegments) {
      delete updatedProduct.groupsSegments;
    }

    this.productService.updateProduct(updatedProduct).subscribe(res => {
      this.toastrService.success('Produto ' + statusDescription + ' com sucesso.', '', {
        toastComponent: CustomSuccessToastComponent,
      });
      this.refreshProductList();
    }, err => {
      const errorParse = JSON.parse(err._body);
      this.toastrService.error(errorParse.message, '', {
        toastComponent: CustomErrorToastComponent,
      });
    });

  }

  public async collapseInfo(product: IProduct): Promise<void> {

    if (!product.isOpen) {
      const dialogRef = this.genericDialog.loadingMessage('Buscando informações do produto...');
      const infos = await this.productService.getAllInfos(product.id);
      product.categories = infos.data.categories;

      product.params = [{ parameterId: -1, name: 'Nome Comercial', value: product.name, isPrimaryKey: false }];
      infos.data['values'].forEach(currentValue => {
        // tslint:disable-next-line:max-line-length
        product.params.push({ parameterId: currentValue.id, name: currentValue.name, value: currentValue.value, isPrimaryKey: currentValue.isPrimaryKey });
      });

      product.groupsSegments = infos.data.groupsSegments;

      dialogRef.close();
    }

    product.isOpen = !product.isOpen;

    this.products.forEach(currentProduct => {
      if (currentProduct.id !== product.id) {
        currentProduct.isOpen = false;
      }
    });

  }

  public async exportCSV(): Promise<void> {
    const response = await this.productService.findCategories();
    try {
      if (!this.utilService.buildCSV(this.ConvertToCSV(response.data), 'Produtos')) {
        throw response;
      }
    } catch (err) {
      this.toastrService.error('Erro ao exportar CSV');
    }
  }

  public showHistory(product: IProduct): void {
    const data: IHistoricData = {
      tableId: TABLE_MAPPER.PRODUCT,
      recordId: product.id,
      subtitle: 'Produto'
    };
    this.genericDialog.historic(data);
  }

  public refreshProductList(): void {
    this.counter = 1;
    this.filterComponent.emitSearch();
  }

  private buildQueryParams(searchParams): IQuery {
    const ordenation: IQuery = {};
    if (searchParams.filter.hasOwnProperty('status')) {
      ordenation.statusId = searchParams.filter.status;
    } else if (!searchParams.showInatives) {
      ordenation.statusId = 10;
    }
    if (searchParams.textFilter && searchParams.textFilter.trim() !== '') {
      ordenation._likeColumn = 'name';
      ordenation._likeValue = `%${searchParams.textFilter.trim()}%`;
    }
    ordenation._orderBy = searchParams.filter.orderBy;
    ordenation._order = searchParams.filter.order;
    return ordenation;
  }

  private buildFilterFormParam(queryParam: IQuery): IQuery {
    const formValue = this.filter.value;
    Object.keys(formValue).forEach(key => {
      if (formValue[key] && formValue[key].id > 0) {
        queryParam[`${key}Id`] = formValue[key].id;
      }
    });
    return queryParam;
  }

  public async onSearchHandler(data: IFilterEvent): Promise<void> {
    let dialogRef: MatDialogRef<GenericDialogComponent, void>;
    const queryParam = this.buildQueryParams(data.value);

    this.buildFilterFormParam(queryParam);

    if (!data.isTextualChange && !this.scrolled) {
      dialogRef = this.genericDialog.loadingMessage('Buscando produtos...');
    } else {
      this.showSpinner = true;
    }

    queryParam._limit = 15;
    if (this.scrolled) {
      queryParam._offset = this.counter * 15;
    } else {
      this.counter = 1;
    }

    const response = await this.productService.getProducts(queryParam);
    const responseQuantites = await this.productService.findQuantites();

    if (response.return.code === 0) {
      if (this.scrolled) {
        this.scrolled = false;
        for (const product of response.data) {
          this.products.push(product);
        }
      } else {
        this.products = response.data;
      }
    }

    if (responseQuantites.return.code === 0) {
      this.quantites = responseQuantites.data;
    }

    if (dialogRef) {
      dialogRef.close();
    }

    this.showSpinner = false;
  }

  public ngOnDestroy(): void {
    for (const subscription of this._subscriptions) {
      if (subscription) {
        subscription.unsubscribe();
      }
    }
  }

  public collapseGroup(groupSegment, product): void {
    groupSegment.isOpen = !groupSegment.isOpen;

    product.groupsSegments.forEach(currentGroupSegment => {
      if (currentGroupSegment.id !== groupSegment.id) {
        currentGroupSegment.isOpen = false;
      }
    });
  }

  public async onScroll(): Promise<void> {
    this.scrolled = true;
    this.filterComponent.emitSearch();
    this.counter++;
  }

  public ConvertToCSV(objArray) {
    let csvContent = 'Nome Comercial;Família;Grupo;AssetClass;Modalidade;Underluing' + '\r\n';
    objArray.forEach(function (rowArray) {
      const values = [];
      for (const key of Object.keys(rowArray)) {
        values.push(rowArray[key]);
      }
      const row = values.join(';');
      csvContent += row + '\r\n';
    });
    return csvContent;
  }

}
