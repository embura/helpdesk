// import { ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
// import { CatalogSharedModule } from '../../catalog-shared.module';
// import { SearchComponent } from './search.component';
// import { ProductService } from '../../services/product/product.service';
// import { UtilService, IQuery } from '../../services/util/util.service';
// import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
// import { ToastrModule } from 'ngx-toastr';
// import { FilterComponent } from '../filter/filter.component';
// import { ReactiveFormsModule } from '@angular/forms';
// import { FamilyService } from '../../services/category/family/family.service';
// import { GroupService } from '../../services/category/group/group.service';
// import { AssetClassService } from '../../services/category/asset-class/asset-class.service';
// import { ModalityService } from '../../services/category/modality/modality.service';
// import { UnderlyingService } from '../../services/category/underlying/underlying.service';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { InfiniteScrollModule } from 'ngx-infinite-scroll';
// import { ICategory, IGroup } from '../../models/category/category.interface';
// import { IResponse } from '../../models/response/response.interface';
// import { Observable } from 'rxjs/Observable';
// import { IProduct, IProductParams, ITotal } from '../../models/product/product.interface';

// const families: ICategory[] = [
//   {
//     'id': 1,
//     'name': 'Estruturados',
//     'shortName': 'Estruturados',
//     'statusId': 5,
//     'isEditable': true
//   },
//   {
//     'id': 2,
//     'name': 'Renda Fixa',
//     'shortName': 'Renda Fixa',
//     'statusId': 5,
//     'isEditable': true
//   }
// ];

// const groups: IGroup[] = [
//   {
//       id: 1,
//       name: 'grupo1',
//       statusId: 10,
//       shortName: 'sh-group',
//       isEditable: true,
//       familyId: 2
//   }
// ];

// const prodParams: IProductParams[] = [
//   {
//     id: 12,
//     productId: 1,
//     parameterId: 1,
//     value: 'string',
//     name: 'string'
//   }
// ];

// const products: IProduct[] = [
//   {
//     id: 1,
//     formId: 1,
//     familyId: 1,
//     modalityId: 1,
//     underlyingId: 1,
//     assetClassId: 1,
//     groupId: 1,
//     statusId: 10,
//     name: 'nameprod',
//     params: prodParams,
//     isOpen: true,
//   }
// ];

// const prodTotal: ITotal = {
//   qtdActives: 1,
//   qtdInactives: 1,
//   qtdTotal: 1
// };

// const mockFamilyService = {
//   getAllFamilies: (): Observable<IResponse<ICategory[]>> => {
//       return Observable.of({
//         'return': {
//           'code': 0,
//           'message': '[Category] Families were found successfully.'
//         },
//         'data': families
//       });
//     },
// };

// const mockGroupService = {
//   getGroupsByFamily(familyId: number): Observable<IResponse<IGroup[]>> {
//       return Observable.of({
//           'return': {
//             'code': 0,
//             'message': 'Groups were found successfully.'
//           },
//           'data': groups
//         });
//     }
// };

// const mockAssetClassService = {
//   getAllAssetClasses(): Observable<IResponse<ICategory[]>> {
//       return Observable.of({
//           'return': {
//               'code': 0,
//               'message': 'Assets Classes consultados com sucesso'
//           },
//           'data': families
//       });
//   }
// };

// const mockModalityService = {
//   getAllModalities(): Observable<IResponse<ICategory[]>> {
//       return Observable.of({
//           'return': {
//               'code': 0,
//               'message': 'Modalities consultados com sucesso'
//           },
//           'data': families
//       });
//   }
// };

// const mockUnderlyingService = {
//   getAllUnderlyings(): Observable<IResponse<ICategory[]>> {
//       return Observable.of({
//           'return': {
//               'code': 0,
//               'message': 'Modalities consultados com sucesso'
//           },
//           'data': families
//       });
//   }
// };

// const mockProductService = {
//   getProducts(query: IQuery): Promise<IResponse<Array<IProduct>>> {
//     return Observable.of({
//       'return': {
//           'code': 0,
//           'message': 'Produtos consultados com sucesso'
//       },
//       'data': products
//   }).toPromise();
//   },

//   findQuantites(): Promise<IResponse<ITotal>> {
//     return Observable.of({
//       'return': {
//           'code': 0,
//           'message': ''
//       },
//       'data': prodTotal
//     }).toPromise();
//   }

// };

// const mockUtilService = {
//   buildCSV(data: string, fileName: string): boolean {
//     return true;
//   }
// };


// describe('SearchComponent', () => {
//   let component: SearchComponent;
//   let fixture: ComponentFixture<SearchComponent>;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [
//         CatalogSharedModule,
//         ToastrModule.forRoot({
//           timeOut: 3000,
//           positionClass: 'toast-bottom-center'
//         }),
//         ReactiveFormsModule,
//         BrowserAnimationsModule,
//         InfiniteScrollModule
//       ],
//       declarations: [SearchComponent, FilterComponent],
//       providers: [
//         { provide: 'hubHost', useValue: 'mock' },
//         { provide: 'appKey', useValue: 'mock' },
//         { provide: HubConnectorComponent, useValue: {} },
//         { provide: ProductService, useValue: mockProductService },
//         { provide: UtilService, useValue: mockUtilService },
//         { provide: FamilyService, useValue: mockFamilyService },
//         { provide: GroupService, useValue: mockGroupService },
//         { provide: AssetClassService, useValue: mockAssetClassService },
//         { provide: ModalityService, useValue: mockModalityService },
//         { provide: UnderlyingService, useValue: mockUnderlyingService }
//       ]
//     })
//       .compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(SearchComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   // it('should init the component', fakeAsync(() => {
//   //   component.ngOnInit();
//   //   tick(500);
//   //   component.ngOnDestroy();
//   // }));


// });
