import {Component, Inject} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import { Form } from '../../../models/form/form';

@Component({
  selector: 'app-ctp-form-dialog.component',
  templateUrl: './form-dialog.component.html',
  styleUrls: ['./form-dialog.component.scss']
})
export class FormDialogComponent {

  form: Form;
  title: string;

  constructor(@Inject(MAT_DIALOG_DATA) public data: Form,
              public dialogRef: MatDialogRef<FormDialogComponent, Form>) {
              this.fillModel(data);
  }

  public fillModel(data: Form) {
    if (data) {
      this.form = data;
      this.title = 'Editar';
    } else {
      this.form = new Form('', 10, true);
      this.title = 'Adicionar';
    }
  }
  public saveDisabled(value: string): boolean {
    return !(value && value.length > 0);
  }

  public save(): void {
    this.dialogRef.close(this.form);
  }

  public closeDialog(): void {
    this.dialogRef.close();
  }

}
