import { Component, Input, Output, EventEmitter } from '@angular/core';
import { IFormItem } from '../../../models/form/form';
import { TypeParameter } from '../../../models/parameter/parameter';
@Component({
    selector: 'app-cpt-form-item',
    templateUrl: './form-item-component.html',
    styleUrls: ['./form-item.component.scss'],
})
export class FormItemComponent {
    @Input() public formItem: IFormItem;
    @Input() public order: number;
    @Input() public isEditable: boolean;
    @Output() public isRequired: EventEmitter<boolean> = new EventEmitter<boolean>();
    @Output() public removeFormItemToList: EventEmitter<IFormItem> = new EventEmitter<IFormItem>();

    constructor(
    ) {
    }

    public hoverFormItem(formItem): void {
        if (this.isEditable || !formItem.id) {
            formItem.isVisible = !formItem.isVisible;
        }
    }

    public removeItemToList(formItem: IFormItem): void {
        this.removeFormItemToList.emit(formItem);
    }

}
