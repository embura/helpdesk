import { Component, OnInit, OnDestroy, ViewChild, AfterViewInit, AfterViewChecked } from '@angular/core';
import { DragulaService } from 'ng2-dragula';
import { Parameter, IParameter, TypeParameter, TypeValidation } from '../../models/parameter/parameter';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ParameterService } from '../../services/parameter/parameter.service';
import { Observable } from 'rxjs/Observable';
import { IResponse } from '../../models/response/response.interface';
import { IQuery, UtilService } from '../../services/util/util.service';
import { MatAutocomplete, MatOption, MatDialog, MatDialogRef } from '@angular/material';
import { FormDialogComponent } from './dialogs/form-dialog.component';
import { IFormItem, Form } from '../../models/form/form';
import { IFilterEvent } from '../filter/filter.component';
import { FormService } from '../../services/form/form.service';
import { ToastrService } from 'ngx-toastr';
import { CustomSuccessToastComponent } from '../toast/custom-success-toast.component';
import { CustomErrorToastComponent } from '../toast/custom-error-toast.component';
import { IForm } from '../../models/form/form.interface';
import { GenericDialog } from '../../models/dialog/generic-dialog';
import { TABLE_MAPPER } from '../../models/common/table-mapping';
import { IHistoricData } from '../historic/historic-dialog';

@Component({
    selector: 'app-cpt-form',
    templateUrl: './form.component.html',
    styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {
    constructor
        (
        private dragulaSerice: DragulaService,
        private _fb: FormBuilder,
        private parameterService: ParameterService,
        private dialog: MatDialog,
        private utilService: UtilService,
        private formSerice: FormService,
        private toastrService: ToastrService,
    ) {
        this.genericDialog = new GenericDialog(this.dialog);
    }

    public forms: Form[] = [];
    public parameters: Parameter[] = [];
    public showSpinner = false;
    public form: FormGroup;
    public filteredParameters: Observable<IParameter[]>;
    public selectedParameter: Parameter;
    public formItens: Array<IFormItem> = [];
    public loadingParameters: boolean;

    private dialogRef: MatDialogRef<FormDialogComponent, Form>;
    private genericDialog: GenericDialog;
    private oldSearch = '';

    private errorMessage = 'Ocorreu um erro ao recuperar parâmetros';

    private dragulaOptions = {
        moves: this.moves,
        accepts: this.accepts
    };

    @ViewChild(MatAutocomplete) public auto: MatAutocomplete;

    ngOnInit(): void {
        this.form = this._fb.group({
            autoComplete: [null]
        });

        this.form.controls['autoComplete'].valueChanges.debounceTime(300).subscribe(value => this.valueChanged(value));

        this.filterParameters();
    }

    private openDialog(data: Form = null): MatDialogRef<FormDialogComponent, Form> {
        return this.dialog.open(FormDialogComponent, {
            width: '570px',
            height: '314px',
            data: data ? { ...data } : null,
            disableClose: true
        });
    }

    public getIndex(item: Form, formItem: IFormItem): number {
        return item.parameters.indexOf(formItem) + 1;
    }

    public searchForm(event?: IFilterEvent): void {
        let ordenation: IQuery;

        if (event) {
            ordenation = this.utilService.buildQueryParams(event);

            if (event.isTextualChange) {
                this.showSpinner = true;
            }
        }

        let dialogRef;

        if (!event || !event.isTextualChange) {
            dialogRef = this.genericDialog.loadingMessage('Carregando formulários...');
        }

        this.formSerice.getForms(ordenation)
            .subscribe(data => {
                if (data.return.code === 0) {
                    this.forms = new Array<Form>();
                    data.data.forEach(value => {
                        this.forms.push(Form.convertToModel(value));
                    });
                } else {
                    this.toastrService.error(this.utilService.getServiceMessage(data, this.errorMessage),
                        '', {
                            toastComponent: CustomErrorToastComponent,
                        });
                }

                dialogRef ? dialogRef.close() : this.showSpinner = false;
            }, err => {
                dialogRef ? dialogRef.close() : this.showSpinner = false;
                this.toastrService.error(this.utilService.getServiceMessage(err.json(), this.errorMessage),
                    '', {
                        toastComponent: CustomErrorToastComponent,
                    });
            });
    }

    public openModal(): void {
        this.dialogRef = this.openDialog();

        this.dialogRef.afterClosed().subscribe(data => {
            if (data) {
                this.formSerice.createForm(data)
                    .subscribe(res => {
                        if (res.return.code === 0) {
                            this.forms.push(Form.convertToModel(res.data));
                            this.toastrService.success('Formulário criado com sucesso.',
                                '', {
                                    toastComponent: CustomSuccessToastComponent,
                                });
                        } else {
                            this.toastrService.error(this.utilService.getServiceMessage(data, this.errorMessage),
                                '', {
                                    toastComponent: CustomErrorToastComponent,
                                });
                        }
                    }, err => {
                        this.toastrService.error(
                            this.utilService.getServiceMessage(err.json(), this.errorMessage),
                            '', {
                                toastComponent: CustomErrorToastComponent,
                            });
                    });
            }

            this.dialogRef = null;
        });
    }

    public editModal(item: Form): void {
        this.dialogRef = this.openDialog(item);

        this.dialogRef.afterClosed().subscribe(dataRes => {
            if (dataRes) {
                this.saveForm(dataRes);
            }
        });
    }

    public saveForm(item: Form): void {
        const dialogRef = this.genericDialog.loadingMessage('Salvando formulário...');

        this.formSerice.editForm(item)
            .subscribe(data => {
                if (data.return.code === 0) {
                    const formIdx = this.forms.findIndex(fm => fm.id === data.data.id);
                    const frm = Form.convertToModel(data.data);
                    frm.isOpen = item.isOpen;

                    this.forms[formIdx] = frm;

                    this.toastrService.success('Formulário salvo com sucesso.',
                        '', {
                            toastComponent: CustomSuccessToastComponent,
                        });
                } else {
                    this.toastrService.error(this.utilService.getServiceMessage(data, this.errorMessage),
                        '', {
                            toastComponent: CustomErrorToastComponent,
                        });
                }

                dialogRef.close();
            }, err => {
                this.toastrService.error(
                    this.utilService.getServiceMessage(err.json(), this.errorMessage)
                    ,
                    '', {
                        toastComponent: CustomErrorToastComponent,
                    });

                dialogRef.close();
            });
    }

    public openAccordeon(item: Form): void {
        if (!item.isOpen) {
            let dialogRef;
            dialogRef = this.genericDialog.loadingMessage('Carregando informações do formulário...');
            this.formSerice.getForm(item.id)
                .subscribe(data => {
                    if (data.return.code === 0) {
                        this.form.controls.autoComplete.setValue('');

                        item.isOpen = true;
                        item.isEditable = data.data.isEditable;

                        item.parameters = Form.convertFormParameterToModel(data.data.formParameters);

                        this.forms.forEach(itemForm => {
                            if (itemForm.id !== item.id) {
                                itemForm.isOpen = false;
                            }
                        });
                    } else {
                        this.toastrService.error(this.utilService.getServiceMessage(data, this.errorMessage),
                            '', {
                                toastComponent: CustomErrorToastComponent,
                            });
                    }

                    dialogRef.close();

                }, err => {
                    dialogRef.close();
                    this.toastrService.error(this.errorMessage,
                        '', {
                            toastComponent: CustomErrorToastComponent,
                        });
                });
        } else {
            item.isOpen = false;
            this.selectedParameter = null;
        }
    }

    public addParameter(item: Form): void {
        if (!item.parameters) {
            item.parameters = new Array();
        }

        item.parameters.push({
            parameterId: this.selectedParameter.id,
            name: this.selectedParameter.name,
            type: <TypeParameter>this.selectedParameter.typeId,
            typeString: TypeParameter[this.selectedParameter.typeId],
            order: item.parameters.length + 1,
            validation: <TypeValidation>this.selectedParameter.validationId,
            validationString: TypeValidation[this.selectedParameter.validationId],
            isRequired: true,
            isVisible: false
        });

        this.selectedParameter = null;
        this.form.controls.autoComplete.setValue('');
    }

    public displayFn(param?: Parameter): string {
        return param ? param.name : '';
    }

    public filterParameters(search?: string): void {
        if (search !== this.oldSearch && !(typeof (search) === 'object')) {
            let ordenation: IQuery = {
                _orderBy: 'name',
                _order: 'asc',
                statusId: 10
            };

            if (search && typeof (search) === 'string') {
                ordenation = {
                    ...ordenation,
                    _likeColumn: 'name',
                    _likeValue: search,
                };
            }

            this.loadingParameters = true;

            this.filteredParameters = this.parameterService.getParameters(ordenation).map(res => {
                this.loadingParameters = false;

                return res.data;
            });

            this.oldSearch = search;
        }
    }

    public checkButtonEnable(item: Form, itemMat: MatOption): boolean {
        return this.selectedParameter &&
            item.parameters &&
            item.parameters.findIndex(param => param.parameterId === this.selectedParameter.id) === -1;
    }

    public changeStatus(item: Form) {
        const newValue = { ...item };
        if (item.statusId === 10) {
            newValue.statusId = 5;
        } else {
            newValue.statusId = 10;
        }

        this.saveForm(newValue);
    }

    public valueChanged(value: any) {
        if (typeof (value) === 'string') {
            this.filterParameters(value);
        } else if (typeof (value) === 'object') {
            this.selectedParameter = value;
        }
    }

    public removeFormItemToList(formItem: IFormItem, item: Form) {
        const indexParam = item.parameters.findIndex(param => param.parameterId === formItem.parameterId);
        item.parameters.splice(indexParam, 1);
    }

    public moves(el, source, handle, sibling) {
        if (el.className.indexOf('businessName') > -1) {
            return false;
        }

        return true;
    }

    public accepts(el, target, source, sibling) {
        if (sibling && sibling.className.indexOf('businessName') > -1) {
            return false;
        }

        return true;
    }

    public historicClickHandler(form: Form): void {
        const data: IHistoricData = {
            tableId: TABLE_MAPPER.FORM,
            subtitle: `Formulário ${form.name}`,
            recordId: form.id
        };
        this.genericDialog.historic(data);
    }

    public checkParamExists(param: Parameter, form: Form): boolean {
        const formItem = form.parameters.find(frmItem => frmItem.parameterId === param.id);

        return formItem === undefined || formItem === null;
    }
}
