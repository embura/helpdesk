// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ChannelsCategoryDialog.ComponentComponent } from './channels-dialog.component.component';

// describe('ChannelsCategoryDialog.ComponentComponent', () => {
//   let component: ChannelsCategoryDialog.ComponentComponent;
//   let fixture: ComponentFixture<ChannelsCategoryDialog.ComponentComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ChannelsCategoryDialog.ComponentComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ChannelsCategoryDialog.ComponentComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
