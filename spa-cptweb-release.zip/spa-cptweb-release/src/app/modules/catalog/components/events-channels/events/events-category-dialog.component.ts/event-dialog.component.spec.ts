import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EventsDialogComponent } from './events-dialog.component';
import { CatalogSharedModule } from '../../../../catalog-shared.module';
import { DialogHeaderComponent } from '../../../dialog-header/dialog-header.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { Events } from '../events';

describe('EventCategoryDialog.ComponentComponent', () => {
  let component: EventsDialogComponent;
  let fixture: ComponentFixture<EventsDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, CommonModule, BrowserAnimationsModule, CatalogSharedModule ],
      declarations: [ DialogHeaderComponent, EventsDialogComponent ],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: undefined },
        { provide: MatDialogRef, useValue: {} }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fill model', () => {
    const event: Events = {
      id: 1,
      name: 'Event',
      nameTec: 'Event',
      statusId: 10
    };

    component.fillModel(event);

    expect(component.events).toBe(event);
  });

  it('should save', () => {
    (<any>component.dialogRef) = {
      close: () => { }
    };

    component.save();
  });

  it('should close', () => {
    (<any>component.dialogRef) = {
      close: () => { }
    };

    component.closeDialog();
  });

  it('saveDisabled', () => {
    component.saveDisabled('');
  });
});
