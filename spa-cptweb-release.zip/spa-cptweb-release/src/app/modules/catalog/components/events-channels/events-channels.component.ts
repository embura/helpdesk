import { Component, OnInit, ViewChild } from '@angular/core';
import {IEventsChannels} from '../../models/events-channels/events-channels.interface';
import {GenericDialog} from '../../models/dialog/generic-dialog';
import {MatDialog} from '@angular/material';
import {Observable} from 'rxjs/Observable';
import {EventService} from '../../services/events-channels/event/event.service';
import {ChannelService} from '../../services/events-channels/channel/channel.service';
import { AccordionComponent } from '../accordion/accordion.component';

@Component({
  selector: 'app-cpt-events-channels',
  templateUrl: './events-channels.component.html',
  styleUrls: ['./events-channels.component.scss']
})
export class EventsChannelsComponent implements OnInit {
  private eventsCategory: IEventsChannels[];
  private channelsCategory: IEventsChannels[];
  public events: IEventsChannels[];
  public channels: IEventsChannels[];
  private genericDialog = new GenericDialog(this.dialog);
  public accordions = [];

  @ViewChild('eventAccordion') private eventAccordion: AccordionComponent;
  @ViewChild('channelAccordion') private channelAccordion: AccordionComponent;

  constructor(
    private dialog: MatDialog,
    private eventService: EventService,
    private channelService: ChannelService,
  ) { }

  ngOnInit() {
    const dialogRef = this.genericDialog.loadingMessage('Carregando canais e eventos...');

    this.accordions.push({
      name: 'eventAccordion',
      accordion: this.eventAccordion
    });
    this.accordions.push({
      name: 'channelAccordion',
      accordion: this.channelAccordion
    });

    Observable.forkJoin(
      this.eventService.getAllEvents(),
      this.channelService.getAllChannels(),
      )
      .subscribe( res => {
        this.events = res[0].data;
        this.eventsCategory = res [0].data;
        this.channelsCategory = res [1].data;
        this.channels = res[1].data ;
        dialogRef.close();
      });

  }

  public openAccordion(nameAccordion): void {
    for (const obj of this.accordions) {
      if (obj.name !== nameAccordion) {
        obj.accordion.accordion.isOpen = false;
      }
    }
  }

}
