// tslint:disable-next-line:snt-file-name-suffix
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventsComponent } from './events.component';
import { AccordionComponent } from '../../accordion/accordion.component';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { CustomSuccessToastComponent } from '../../toast/custom-success-toast.component';
import { ChannelsComponent } from '../channels/channels.component';
import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
import { CommonModule } from '@angular/common';
import { ToastrModule } from 'ngx-toastr';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CatalogSharedModule } from '../../../catalog-shared.module';
import { EventsDialogComponent } from './events-category-dialog.component.ts/events-dialog.component';
import { DialogHeaderComponent } from '../../dialog-header/dialog-header.component';
import { FormsModule } from '@angular/forms';
import { IEventsChannels } from '../../../models/events-channels/events-channels.interface';
import { IResponse } from '../../../models/response/response.interface';
import { Observable } from 'rxjs/Observable';
import { Events } from './events';
import { EventService } from '../../../services/events-channels/event/event.service';
import { UtilService } from '../../../services/util/util.service';
import { GenericDialogComponent } from '../../dialogs/generic/generic-dialog.component';
import { AccordionItem } from '../../accordion/accordion-item';
import { HistoricDialogComponent } from '../../historic/historic-dialog.component';

//#region Data

const eventOne: IEventsChannels = {
    id: 1,
    name: 'Evento 1',
    nameTec: 'Evento 1',
    statusId: 10
};

const eventTwo: IEventsChannels = {
    id: 2,
    name: 'Evento 2',
    nameTec: 'Evento 2',
    statusId: 10
};

//#endregion

//#region Service Mock

const mockEventService = {
    getAllEvents: (): Observable<IResponse<IEventsChannels[]>> => {
        return Observable.of({
            'return': {
                'code': 0,
                'message': 'Events returned'
            },
            'data': [eventOne, eventTwo]
        });
    },
    addEvent: (event: Events): Observable<IResponse<IEventsChannels>> => {
        return Observable.of({
            'return': {
                'code': 0,
                'message': 'Events created'
            },
            'data': eventOne
        });
    },
    editEvents: (event: Events): Observable<IResponse<IEventsChannels>> => {
        return Observable.of({
            'return': {
                'code': 0,
                'message': 'Events created'
            },
            'data': eventOne
        });
    }
};

//#endregion

//#region Test Module

@NgModule({
    imports: [
        CommonModule,
        ToastrModule.forRoot({
            timeOut: 3000,
            positionClass: 'toast-bottom-center'
        }),
        CatalogSharedModule,
        BrowserAnimationsModule,
        FormsModule
    ],
    declarations: [
        EventsComponent,
        AccordionComponent,
        CustomErrorToastComponent,
        CustomSuccessToastComponent,
        ChannelsComponent,
        AccordionComponent,
        OrderAccordionPipe,
        DialogHeaderComponent,
        EventsDialogComponent,
        GenericDialogComponent,
    ],
    entryComponents: [
        CustomErrorToastComponent,
        CustomSuccessToastComponent,
        EventsDialogComponent,
        GenericDialogComponent],
    providers: [
        { provide: EventService, useValue: mockEventService },
        {
            provide: UtilService, useValue: {
                getServiceMessage: (str: string, def: string) => 'mock',
                getHubUrl: () => 'mock'
            }
        }
    ]
})
class TestModule { }

//#endregion

describe('EventsComponent', () => {
    let component: EventsComponent;
    let fixture: ComponentFixture<EventsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [TestModule]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(EventsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('Test set data', () => {
        component['data'] = [eventOne];

        expect(component.events.length).toBe(1);
    });

    it('Test set data to null', () => {
        component['data'] = null;

        expect(component.events.length).toBe(0);
    });

    it('openDialog passing null data', () => {
        (<any>component['dialog']) = {
            open: (): void => { }
        };

        component['openDialog']();
    });

    it('openDialog passing', () => {
        (<any>component['dialog']) = {
            open: (): void => { }
        };

        component['openDialog']({ id: 1, name: '', nameTec: '', statusId: 10 });
    });

    it('add', () => {
        const event: Events = {
            id: 1,
            name: 'Event 1',
            nameTec: 'Event 2',
            statusId: 10
        };

        (<any>component['openDialog']) = () => {
            return {
                afterClosed: (): Observable<Events> => Observable.of(event)
            };
        };

        component.add();
    });

    it('edit', () => {
        const event: Events = {
            id: 1,
            name: 'Event 1',
            nameTec: 'Event 2',
            statusId: 10
        };

        (<any>component['openDialog']) = () => {
            return {
                afterClosed: (): Observable<Events> => Observable.of(event)
            };
        };

        const item: AccordionItem = new AccordionItem();
        item.name = 'Event 1';
        item.nameTec = 'Event 1';
        item.id = 1;
        item.statusId = 10;

        component.events = [item];
        component.edit(item);
    });

    it('changeStatus', () => {
        const item: AccordionItem = new AccordionItem();
        item.name = 'Event 1';
        item.nameTec = 'Event 1';
        item.id = 1;
        item.statusId = 10;

        component.changeStatus(item);
    });
});
