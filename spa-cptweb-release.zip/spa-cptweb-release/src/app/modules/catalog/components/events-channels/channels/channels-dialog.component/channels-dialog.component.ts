import {Component, Inject} from '@angular/core';
import {Channels} from '../channels';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';

@Component({
  selector: 'app-ctp-channels-category-dialog.component',
  templateUrl: './channels-dialog.component.html',
  styleUrls: ['./channels-dialog.component.scss']
})
export class ChannelsDialogComponent {

  channels: Channels;
  title: string;

  constructor(@Inject(MAT_DIALOG_DATA) public data: Channels,
              public dialogRef: MatDialogRef<ChannelsDialogComponent, Channels>) {
              this.fillModel(data);
  }

  public fillModel(data: Channels) {
    if (data) {
      this.channels = data;
      this.title = 'Editar';
    } else {
      this.channels = new Channels('', null);
      this.title = 'Adicionar';
    }
  }
  public saveDisabled(value: string): boolean {
    return !(value && value.length > 0);
  }

  public save(): void {
    this.dialogRef.close(this.channels);
  }

  public closeDialog(): void {
    this.dialogRef.close();
  }

}
