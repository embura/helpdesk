import {Component, Input, ViewChild} from '@angular/core';
import {AccordionItem} from '../../accordion/accordion-item';
import {MatDialog, MatDialogRef} from '@angular/material';
import {Channels} from './channels';
import {ChannelsDialogComponent} from './channels-dialog.component/channels-dialog.component';
import {GenericDialog} from '../../../models/dialog/generic-dialog';
import {IEventsChannels} from '../../../models/events-channels/events-channels.interface';
import {ChannelService} from '../../../services/events-channels/channel/channel.service';
import {Events} from '../events/events';
import {OrderAccordionPipe} from '../../../pipes/order-accordion.pipe';
import { ToastrService } from 'ngx-toastr';
import { CustomSuccessToastComponent } from '../../toast/custom-success-toast.component';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { IHistoricData } from '../../historic/historic-dialog';
import { TABLE_MAPPER } from '../../../models/common/table-mapping';
import { UtilService } from '../../../services/util/util.service';
import { AccordionComponent } from '../../accordion/accordion.component';

@Component({
  selector: 'app-cpt-channels',
  templateUrl: './channels.component.html',
  styleUrls: ['./channels.component.scss']
})
export class ChannelsComponent {
  public channels: AccordionItem [] = [];
  protected dialogRef: MatDialogRef<ChannelsDialogComponent, Channels>;
  private genericDialog = new GenericDialog(this.dialog);
  private statusRef: Channels;
  @ViewChild('accordion') public accordion: AccordionComponent;

  @Input() private set data(data: IEventsChannels[]) {
    if (data) {
      this.channels = [];

      data.map(eve => {
        const channels = new AccordionItem();

        channels.name = eve.name;
        channels.nameTec = eve.nameTec;
        channels.id = eve.id;
        channels.statusId = eve.statusId;
        channels.canEdit = true;

        this.channels.push(channels);
      });
    }
  }
  constructor(
    private dialog: MatDialog,
    private channelService: ChannelService,
    private toastrService: ToastrService,
    private utilService: UtilService
              ) { }


  private openDialog(data: Channels = null): MatDialogRef<ChannelsDialogComponent, Channels> {
    return this.dialog.open(ChannelsDialogComponent, {
      width: '570px',
      height: '314px',
      data: data,
      disableClose: true
    });
  }

  public add(): void {
    this.dialogRef = this.openDialog();

    this.dialogRef.afterClosed().subscribe(data => {
      if (data) {
        const dialogRefLoading = this.genericDialog.loadingMessage('Adicionando Canal...');
          data.statusId = 10;
        this.channelService.addChannel(data)
          .subscribe(response => {
            if (response.return.code === 0) {
              const item: AccordionItem = new AccordionItem();
              item.name = response.data.name;
              item.nameTec = response.data.nameTec;
              item.id = response.data.id;
              item.statusId = response.data.statusId;
              item.canEdit = true;
              this.channels.push(item);
              this.dataHasChanged();
              this.toastrService.success('Canal adicionado com sucesso.', '', {
                toastComponent: CustomSuccessToastComponent,
              });
            } else {
              this.toastrService.error(response.return.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            dialogRefLoading.close();
          }, err => {
            const error = err.json ? err.json() : {};
            this.toastrService.error(this.utilService.getServiceMessage(error, 'Ocorreu um erro ao editar o evento'), '', {
              toastComponent: CustomErrorToastComponent,
            });

            dialogRefLoading.close();
          });
      }

      this.dialogRef = null;
    });
  }

  public showHistory(tableId: number): void {
    const data: IHistoricData = {
      tableId: TABLE_MAPPER.CANAL,
      subtitle: `Canais`,
    };
    this.genericDialog.historic(data);
  }

  public edit(item: AccordionItem) {
    const dialogData: Channels = new Channels(item.name, item.nameTec, item.id);

    this.dialogRef = this.openDialog(dialogData);
    this.dialogRef.afterClosed().subscribe(data => {
      if (data) {
        const dialogRefLoading = this.genericDialog.loadingMessage('Alterando Canal ...');
        data.statusId = item.statusId;
        this.channelService.editChannel(data)
          .subscribe( resp => {
            if (resp.return.code === 0) {
              this.channels[this.channels.indexOf(item)].name = resp.data.name;
              this.channels[this.channels.indexOf(item)].nameTec = resp.data.nameTec;
              this.dataHasChanged();
              this.toastrService.success('Canal alterado com sucesso.', '', {
                toastComponent: CustomSuccessToastComponent,
              });
            } else {
              this.genericDialog.errorMessage(resp.return.message);
            }
            dialogRefLoading.close();
          }, err => {
            const error = err.json ? err.json() : {};
            this.toastrService.error(this.utilService.getServiceMessage(error, 'Ocorreu um erro ao editar o evento'), '', {
              toastComponent: CustomErrorToastComponent,
            });

            dialogRefLoading.close();
          });
      }
      this.dialogRef = null;
    });

  }

  public changeStatus(item: AccordionItem) {
    const aux = new Channels(item.name, item.nameTec, item.id, item.statusId === 10 ? 5 : 10);
    const dialogRefLoading = this.genericDialog.loadingMessage('Mudando visibilidade ...');
    this.channelService.editChannel(aux)

      .subscribe(resp => {
        if (resp.return.code === 0) {
          item.name = resp.data.name;
          item.nameTec = resp.data.nameTec;
          item.id = resp.data.id;
          item.statusId = resp.data.statusId;
          this.dataHasChanged();
          this.toastrService.success('Visibilidade alterada com sucesso.', '', {
            toastComponent: CustomSuccessToastComponent,
          });
        } else {
          this.genericDialog.errorMessage(resp.return.message);
        }
        dialogRefLoading.close();
      }, err => {
        const error = err.json ? err.json() : {};
        this.toastrService.error(this.utilService.getServiceMessage(error, 'Ocorreu um erro ao editar o evento'), '', {
          toastComponent: CustomErrorToastComponent,
        });

        dialogRefLoading.close();
      });

    this.dialogRef = null;

  }

  private dataHasChanged() {
    const pipe: OrderAccordionPipe = new OrderAccordionPipe();

    this.channels = pipe.transform(this.channels);

    const newData: IEventsChannels[] = [];

    this.channels.map(eve => {
      newData.push({name: eve.name, nameTec: eve.nameTec, id: eve.id, statusId: eve.statusId});
    });
  }

}

