import { IChannels } from '../channels/channels';

export class Events {
  constructor(
    public name: string,
    public nameTec: string,
    public id?: number,
    public statusId?: number
  ) { }
}

export interface IEvents {
  id: number;
  name: string;
  nameTec: string;
  statusId: number;
  channels: IChannels[];
}

