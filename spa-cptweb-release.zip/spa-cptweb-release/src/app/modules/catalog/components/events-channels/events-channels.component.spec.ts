// // tslint:disable-next-line:snt-file-name-suffix
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { Observable } from 'rxjs/Observable';
// import { EventsChannelsComponent } from './events-channels.component';
// import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { CommonModule } from '@angular/common';
// import { MatDialogModule } from '@angular/material';
// import { ToastrModule, ToastrService } from 'ngx-toastr';
// import { SegmentComponent } from '../segment/segment.component';
// import { GenericDialogComponent } from '../dialogs/generic/generic-dialog.component';
// import { CustomErrorToastComponent } from '../toast/custom-error-toast.component';
// import { CustomSuccessToastComponent } from '../toast/custom-success-toast.component';
// import { EventService } from '../../services/events-channels/event/event.service';
// import { ChannelService } from '../../services/events-channels/channel/channel.service';
// import { EventsComponent } from './events/events.component';
// import { ChannelsComponent } from './channels/channels.component';
// import { FormGroup } from '@angular/forms';
// @NgModule({
//     imports: [
//         BrowserAnimationsModule,
//         CommonModule,
//         MatDialogModule,
//         ToastrModule.forRoot()
//     ],
//     declarations: [
//         SegmentComponent,
//         GenericDialogComponent,
//         CustomErrorToastComponent,
//         CustomSuccessToastComponent,
//         EventsChannelsComponent,
//         EventsComponent,
//         ChannelsComponent
//     ],
//     entryComponents: [
//         EventsChannelsComponent,
//         GenericDialogComponent,
//         CustomErrorToastComponent,
//         CustomSuccessToastComponent,
//     ],
//     schemas: [CUSTOM_ELEMENTS_SCHEMA]
// })
// class TestModule { }

// const mockChannelService = {
//     getAllChannels: () => {
//         return Observable.of({
//             'return': {
//                 'code': 0,
//                 'message': ''
//             },
//             'data': ''
//         });
//     }
// };

// const mockEventService = {
//     getAllEvents: () => {
//         return Observable.of({
//             'return': {
//                 'code': 0,
//                 'message': ''
//             },
//             'data': ''
//         });
//     }
// };


// describe('EventsChannelsComponent', () => {
//     let timeout;
//     let component: EventsChannelsComponent;
//     let fixture: ComponentFixture<EventsChannelsComponent>;

//   beforeEach(() => {
//       TestBed.configureTestingModule({
//           imports: [
//               TestModule
//             ],
//             providers: [
//                 { provide: EventService, useValue: mockEventService },
//                 { provide: ChannelService, useClass: mockChannelService },
//                 ToastrService
//             ]
//         }).compileComponents();

//     fixture = TestBed.createComponent(EventsChannelsComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
