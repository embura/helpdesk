import {Component, Inject} from '@angular/core';
import {Events} from '../events';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-cpt-event-category-dialog-component',
  templateUrl: './events-dialog.component.html',
  styleUrls: ['./events-dialog.component.scss']
})
export class EventsDialogComponent {
  events: Events;
  title: string;

  constructor(@Inject(MAT_DIALOG_DATA) public data: Events,
                public dialogRef: MatDialogRef<EventsDialogComponent, Events>) {
    this.fillModel(data);
  }

  public fillModel(data: Events) {
    if (data) {
      this.events = data;
      this.title = 'Editar';
    } else {
      this.events = new Events('', '');
      this.title = 'Adicionar';
    }
  }

  public saveDisabled(value: string): boolean {
    return !(value && value.length > 0);
  }

  public save(): void {
    this.dialogRef.close(this.events);
  }

  public closeDialog(): void {
    this.dialogRef.close();
  }

}
