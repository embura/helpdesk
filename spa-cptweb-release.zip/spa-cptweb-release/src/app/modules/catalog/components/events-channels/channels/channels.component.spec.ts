// tslint:disable-next-line:snt-file-name-suffix
import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ChannelsComponent } from './channels.component';
import { AccordionComponent } from '../../accordion/accordion.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule, MatDialogModule, MatMenuModule } from '@angular/material';
import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
import { ChannelService } from '../../../services/events-channels/channel/channel.service';
import { IEventsChannels } from '../../../models/events-channels/events-channels.interface';
import { IResponse } from '../../../models/response/response.interface';
import { Observable } from 'rxjs/Observable';
import { ToastrService, ToastrModule } from 'ngx-toastr';
import { CustomSuccessToastComponent } from '../../toast/custom-success-toast.component';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { UtilService } from '../../../services/util/util.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ChannelsDialogComponent } from './channels-dialog.component/channels-dialog.component';
import { CatalogSharedModule } from '../../../catalog-shared.module';
import { FormsModule } from '@angular/forms';
import { DialogHeaderComponent } from '../../dialog-header/dialog-header.component';
import { GenericDialogComponent } from '../../dialogs/generic/generic-dialog.component';
import { Channels } from './channels';
import { AccordionItem } from '../../accordion/accordion-item';

//#region Data

const channelOne: IEventsChannels = {
    id: 1,
    name: 'Channel 1',
    nameTec: 'Channel 1',
    statusId: 10
};

const channelTwo: IEventsChannels = {
    id: 2,
    name: 'Channel 2',
    nameTec: 'Channel 2',
    statusId: 10
};

//#endregion

//#region Service Mock

const mockChannelService = {
    getAllChannels: (): Observable<IResponse<IEventsChannels[]>> => {
        return Observable.of({
            'return': {
                'code': 0,
                'message': 'Events returned'
            },
            'data': [channelOne, channelTwo]
        });
    },
    addChannel: (event: Channels): Observable<IResponse<IEventsChannels>> => {
        return Observable.of({
            'return': {
                'code': 0,
                'message': 'Events created'
            },
            'data': channelOne
        });
    },
    editChannel: (event: Channels): Observable<IResponse<IEventsChannels>> => {
        return Observable.of({
            'return': {
                'code': 0,
                'message': 'Events created'
            },
            'data': channelOne
        });
    }
};

//#endregion

@NgModule({
    imports: [
        CommonModule,
        ToastrModule.forRoot({
            timeOut: 3000,
            positionClass: 'toast-bottom-center'
        }),
        CatalogSharedModule,
        BrowserAnimationsModule,
        FormsModule
    ],
    declarations: [
        ChannelsComponent,
        ChannelsDialogComponent,
        AccordionComponent,
        CustomErrorToastComponent,
        CustomSuccessToastComponent,
        ChannelsComponent,
        AccordionComponent,
        OrderAccordionPipe,
        DialogHeaderComponent,
        GenericDialogComponent,
    ],
    entryComponents: [
        CustomErrorToastComponent,
        CustomSuccessToastComponent,
        ChannelsDialogComponent,
        GenericDialogComponent
    ],
})
// tslint:disable-next-line:one-line
class TestModule { }

const data: IEventsChannels = {
    id: 11,
    name: 'test2',
    statusId: 10,
    nameTec: 'test2'
};


describe('ChannelsComponent', () => {
    let component: ChannelsComponent;
    let fixture: ComponentFixture<ChannelsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                TestModule
            ],
            providers: [
                { provide: ChannelService, useValue: mockChannelService },
                ToastrService,
                {
                    provide: UtilService, useValue: {
                        getServiceMessage: (str: string, def: string) => 'mock',
                        getHubUrl: () => 'mock'
                    }
                }
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ChannelsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should add channels to the list', () => {
        component['data'] = [data];
        fixture.detectChanges();
        expect(JSON.stringify(component['channels'])).toContain('test2');
    });

    it('should open a dialog to add a new channel', fakeAsync(() => {
        component.add();
        tick(500);
        fixture.detectChanges();
        expect(component['dialogRef']).toBeTruthy();
    }));

    it('add', () => {
        const event: Channels = {
            id: 1,
            name: 'Event 1',
            nameTec: 'Event 2',
            statusId: 10
        };

        (<any>component['openDialog']) = () => {
            return {
                afterClosed: (): Observable<Channels> => Observable.of(event)
            };
        };

        component.add();
    });

    it('edit', () => {
        const event: Channels = {
            id: 1,
            name: 'Event 1',
            nameTec: 'Event 2',
            statusId: 10
        };

        (<any>component['openDialog']) = () => {
            return {
                afterClosed: (): Observable<Channels> => Observable.of(event)
            };
        };

        const item: AccordionItem = new AccordionItem();
        item.name = 'Event 1';
        item.nameTec = 'Event 1';
        item.id = 1;
        item.statusId = 10;

        component.channels = [item];
        component.edit(item);
    });

    it('changeStatus', () => {
        const item: AccordionItem = new AccordionItem();
        item.name = 'Event 1';
        item.nameTec = 'Event 1';
        item.id = 1;
        item.statusId = 10;

        component.changeStatus(item);
    });
});
