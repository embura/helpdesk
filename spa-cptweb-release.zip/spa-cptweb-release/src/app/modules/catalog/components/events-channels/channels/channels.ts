export class Channels {
  constructor(
    public name: string,
    public nameTec: string,
    public id?: number,
    public statusId?: number,
  ) { }
}

export interface IChannels {
  id: number;
  name: string;
  nameTec: string;
  isSelected: boolean;
  statusId: number;
}
