import { Component, Input, ViewChild } from '@angular/core';
import { AccordionItem } from '../../accordion/accordion-item';
import { MatDialog, MatDialogRef } from '@angular/material';
import { Events } from './events';
import { EventsDialogComponent } from './events-category-dialog.component.ts/events-dialog.component';
import { GenericDialog } from '../../../models/dialog/generic-dialog';
import { IEventsChannels } from '../../../models/events-channels/events-channels.interface';
import { EventService } from '../../../services/events-channels/event/event.service';
import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
import { Channels } from '../channels/channels';
import { ToastrService } from 'ngx-toastr';
import { CustomSuccessToastComponent } from '../../toast/custom-success-toast.component';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { IHistoricData } from '../../historic/historic-dialog';
import { TABLE_MAPPER } from '../../../models/common/table-mapping';
import { UtilService } from '../../../services/util/util.service';
import { AccordionComponent } from '../../accordion/accordion.component';

@Component({
  selector: 'app-cpt-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss']
})
export class EventsComponent {
  public events: AccordionItem[] = [];
  protected dialogRef: MatDialogRef<EventsDialogComponent, Events>;
  private genericDialog = new GenericDialog(this.dialog);
  @ViewChild('accordion') public accordion: AccordionComponent;

  @Input() private set data(data: IEventsChannels[]) {
    if (data) {
      this.events = [];

      data.map(eve => {
        const events = new AccordionItem();

        events.name = eve.name;
        events.nameTec = eve.nameTec;
        events.id = eve.id;
        events.statusId = eve.statusId;
        events.canEdit = true;

        this.events.push(events);
      });
    }
  }

  constructor(
    private dialog: MatDialog,
    private eventService: EventService,
    private toastrService: ToastrService,
    private utilService: UtilService
  ) { }

  private openDialog(data: Events = null): MatDialogRef<EventsDialogComponent, Events> {
    return this.dialog.open(EventsDialogComponent, {
      width: '570px',
      height: '314px',
      data: data,
      disableClose: true
    });
  }

  public add(): void {
    this.dialogRef = this.openDialog();

    this.dialogRef.afterClosed().subscribe(data => {
      if (data) {
        const dialogRefLoading = this.genericDialog.loadingMessage('Adicionando Evento...');
        data.statusId = 10;
        this.eventService.addEvent(data)
          .subscribe(response => {
            if (response.return.code === 0) {
              const item: AccordionItem = new AccordionItem();
              item.name = response.data.name;
              item.nameTec = response.data.nameTec;
              item.id = response.data.id;
              item.statusId = response.data.statusId;
              item.canEdit = true;
              this.events.push(item);
              this.dataHasChanged();
              this.toastrService.success('Evento adicionado com sucesso.', '', {
                toastComponent: CustomSuccessToastComponent,
              });
            } else {
              this.toastrService.error(response.return.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            dialogRefLoading.close();
          }, err => {
            const error = err.json ? err.json() : {};
            this.toastrService.error(this.utilService.getServiceMessage(error, 'Ocorreu um erro ao editar o evento'), '', {
              toastComponent: CustomErrorToastComponent,
            });

            dialogRefLoading.close();
          });
      }

      this.dialogRef = null;
    });
  }

  public edit(item: AccordionItem) {
    const dialogData: Events = new Events(item.name, item.nameTec, item.id, item.statusId);

    this.dialogRef = this.openDialog(dialogData);

    this.dialogRef.afterClosed().subscribe(data => {
      if (data) {
        const dialogRefLoading = this.genericDialog.loadingMessage('Alterando Evento...');
        data.statusId = item.statusId;
        this.eventService.editEvents(data)
          .subscribe(response => {
            if (response.return.code === 0) {
              this.events[this.events.indexOf(item)].name = response.data.name;
              this.events[this.events.indexOf(item)].nameTec = response.data.nameTec;
              this.dataHasChanged();
              this.toastrService.success('Evento alterado com sucesso.', '', {
                toastComponent: CustomSuccessToastComponent,
              });
            } else {
              this.toastrService.error(response.return.message, '', {
                toastComponent: CustomErrorToastComponent,
              });
            }

            dialogRefLoading.close();

          }, err => {
            const error = err.json ? err.json() : {};
            this.toastrService.error(this.utilService.getServiceMessage(error, 'Ocorreu um erro ao editar o evento'), '', {
              toastComponent: CustomErrorToastComponent,
            });

            dialogRefLoading.close();
          });
      }

      this.dialogRef = null;
    });
  }

  public showHistory(tableId: number): void {
    const data: IHistoricData = {
      tableId: TABLE_MAPPER.EVENT,
      subtitle: `Eventos`,
    };
    this.genericDialog.historic(data);
  }

  public changeStatus(item: AccordionItem) {
    const aux = new Events(item.name, item.nameTec, item.id, item.statusId === 10 ? 5 : 10);
    const dialogRefLoading = this.genericDialog.loadingMessage('Mudando visibilidade ...');
    this.eventService.editEvents(aux)

      .subscribe(response => {
        if (response.return.code === 0) {
          item.name = response.data.name;
          item.nameTec = response.data.nameTec;
          item.id = response.data.id;
          item.statusId = response.data.statusId;
          this.dataHasChanged();
          this.toastrService.success('Visibilidade alterada com sucesso.', '', {
            toastComponent: CustomSuccessToastComponent,
          });
        } else {
          this.toastrService.error(response.return.message, '', {
            toastComponent: CustomErrorToastComponent,
          });
        }
        dialogRefLoading.close();
      }, err => {
        const error = err.json ? err.json() : {};
        this.toastrService.error(this.utilService.getServiceMessage(error, 'Ocorreu um erro ao editar o evento'), '', {
          toastComponent: CustomErrorToastComponent,
        });

        dialogRefLoading.close();
      });

    this.dialogRef = null;
  }

  private dataHasChanged() {
    const pipe: OrderAccordionPipe = new OrderAccordionPipe();

    this.events = pipe.transform(this.events);

    const newData: IEventsChannels[] = [];

    this.events.map(eve => {
      newData.push({ name: eve.name, nameTec: eve.nameTec, id: eve.id, statusId: eve.statusId });
    });
  }

}
