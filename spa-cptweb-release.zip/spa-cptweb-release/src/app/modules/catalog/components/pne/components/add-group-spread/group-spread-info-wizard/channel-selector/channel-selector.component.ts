import { Subscription } from 'rxjs/Rx';
import { Component, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'pne-channel-selector',
  templateUrl: './channel-selector.component.html',
  styleUrls: ['./channel-selector.component.scss']
})
export class ChannelSelectorComponent {
  @Input() public channels;
  @Output() public submitAbstractGroup: EventEmitter<Number> = new EventEmitter();
  @Output() public submitForm: EventEmitter<any> = new EventEmitter();
  public abstractGroup: String[] = [];
  public btAbstract: Number = 0;
  public isAllSelected = false;
  public channelId: any[] = [];

  constructor() {
  }
  public channelChecked(checked, event) {
    if (event.checked === true) {
      this.channelId.push(checked.id);
      this.abstractGroup.push(checked);
    }
    if (event.checked === false) {
      for (let index = 0; index < this.abstractGroup.length; index++) {
        if (this.abstractGroup[index] === checked) {
          this.channelId.splice(index, 1);
          this.abstractGroup.splice(index, 1);
          break;
        }
      }
    }
    this.btAbstract = this.abstractGroup.length;
    this.submitForm.emit(this.channelId);
    this.submitAbstractGroup.emit(this.btAbstract);
  }
  public selectAllToggle(event) {
    this.isAllSelected = !this.isAllSelected;
    this.channels.forEach(ch => {
      this.channelChecked(ch.name, {checked: this.isAllSelected});
    });
  }

  isSelected(target: any): boolean {
    return this.abstractGroup
      .filter( ag => ag === target.name)
      .length > 0;
  }
}

