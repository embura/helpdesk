import { GroupSpreadService } from './../../services/group-spread/group-spread.service';
import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import {FormGroup, FormBuilder, FormControl, Validators} from '@angular/forms';
import { SubmitSpreadGroup } from '../../models/group-spred';
@Component({
  selector: 'pne-add-group-spread',
  templateUrl: './add-group-spread.component.html',
  styleUrls: ['./add-group-spread.component.scss']
})
export class AddGroupSpreadComponent implements OnInit, OnDestroy {

  @Input() public step: String = '1';
  @Input() public disabledSave: Boolean = false;
  @Input() submitForm: any[] = [];
  public channels: any[] = [];
  public segments: any[] = [];
  public categories: any[] = [];
  public form: SubmitSpreadGroup;
  public stepNumber;

  constructor(
    public dialogRef: MatDialogRef<AddGroupSpreadComponent, any>,
    public groupSpreadService: GroupSpreadService
  ) {
  }

  ngOnInit(): void {

  }

  ngOnDestroy(): void {

  }

  public closeDialog(): void {
    this.dialogRef.close();
}
public nextStep(step: String) {
  this.step = step;
}
public backStep() {
   this.stepNumber = Number(this.step) - 1;
   this.step = String(this.stepNumber);
}
public receiveStep(step) {
  this.step = step;
}
public receiveDisabledSave(disabledSave) {
  this.disabledSave = disabledSave;
}
public onSubmit(submitForm) {
  this.channels = submitForm.channels;
  this.segments = submitForm.segments;
  this.categories = submitForm.categories;
}
public submit(form) {
  this.form = form.value;
  this.form.channels = (this.channels);
  this.form.segments = (this.segments);
  this.form.categories = (this.categories);
  console.log('form ', this.form);
  this.groupSpreadService.saveGroupsSpread(this.form);
}

}
