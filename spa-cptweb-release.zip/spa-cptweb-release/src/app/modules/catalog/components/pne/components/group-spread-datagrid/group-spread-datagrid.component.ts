import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { GroupSpred, IGroupSpredExport } from '../../models/group-spred';
import { UtilService, IQuery } from '../../../../services/util/util.service';
import { ToastrService } from 'ngx-toastr';
import { CustomErrorToastComponent } from '../../../toast/custom-error-toast.component';
import { IFilterEvent, GroupSpreadFilterComponent } from './group-spread-filter/group-spread-filter.component';
import { GenericDialog } from '../../../../models/dialog/generic-dialog';
import { MatDialog, MatDialogRef } from '@angular/material';
import { GenericDialogComponent } from '../../../dialogs/generic/generic-dialog.component';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { GroupSpreadService } from '../../services/group-spread/group-spread.service';
import { CustomSuccessToastComponent } from '../../../toast/custom-success-toast.component';
import { ITotal } from '../../../../models/product/product.interface';
import { IHistoricData } from '../../../historic/historic-dialog';
import { TABLE_MAPPER } from '../../../../models/common/table-mapping';

@Component({
  selector: 'pne-group-spread-datagrid',
  templateUrl: './group-spread-datagrid.component.html',
  styleUrls: ['./group-spread-datagrid.component.scss'],
  animations: [
    trigger('rotatedState', [
      state('default', style({ transform: 'rotate(0)' })),
      state('rotated', style({ transform: 'rotate(-180deg)' })),
      transition('rotated => default', animate('400ms ease-out')),
      transition('default => rotated', animate('400ms ease-in'))
    ])
  ]
})
export class GroupSpreadDatagridComponent implements OnInit, OnDestroy {

  private genericDialog: GenericDialog;
  public groupsSpred: GroupSpred[] = [];
  public showSpinner = false;
  public quantites: ITotal;
  @ViewChild('filterComponent') private filterComponent: GroupSpreadFilterComponent;

  constructor(
    dialog: MatDialog,
    private readonly groupSpreadService: GroupSpreadService,
    private readonly utilService: UtilService,
    private readonly toastrService: ToastrService,
  ) {
    this.genericDialog = new GenericDialog(dialog);
  }

  ngOnInit(): void {

  }

  ngOnDestroy(): void {

  }

  public async onSearchHandler(data: IFilterEvent): Promise<void> {
    let dialogRef: MatDialogRef<GenericDialogComponent, void>;
    const queryParam = this.utilService.buildQueryParams(data);

    if (!data.isTextualChange) {
      dialogRef = this.genericDialog.loadingMessage('Buscando Grupos Spreds...');
    } else {
      this.showSpinner = true;
    }

    const response = await this.groupSpreadService.getGroupsSpread(queryParam);
    const responseQuantites = await this.groupSpreadService.findQuantites();

    if (response.return.code === 0) {
      this.groupsSpred = response.data;
    }

    if (responseQuantites.return.code === 0) {
      this.quantites = responseQuantites.data;
    }

    if (dialogRef) {
      dialogRef.close();
    }

    this.showSpinner = false;
  }

  public async exportCSV(): Promise<void> {
    try {

      const dataExport: Array<IGroupSpredExport> = [];

      this.groupsSpred.forEach(currentGroupSpread => {
        dataExport.push(
          {
            name: currentGroupSpread.name,
            spredPurchase: currentGroupSpread.spredPurchase + ' %',
            spredSale: currentGroupSpread.spredSale + ' %',
            salesPurchase: currentGroupSpread.salesPurchase + ' %',
            salesSale: currentGroupSpread.salesSale + ' %',
            qtdChannels: currentGroupSpread.qtdChannels,
            qtdCategories: currentGroupSpread.qtdCategories,
            qtdSegments: currentGroupSpread.qtdSegments
          }
        );
      });

      if (!this.utilService.buildCSV(this.ConvertToCSV(dataExport), 'Grupos Spreds')) {
        throw false;
      }
    } catch (err) {
      this.toastrService.error('Erro ao exportar CSV', '', {
        toastComponent: CustomErrorToastComponent,
      });
    }
  }

  public ConvertToCSV(objArray) {
    let csvContent = 'Nome Grupo Spred;Spred Compra;Spred Venda;Sales Compra;Sales Venda;Canais;Categorias;Segmentos' + '\r\n';
    objArray.forEach(function (rowArray) {
      const values = [];
      for (const key of Object.keys(rowArray)) {
        values.push(rowArray[key]);
      }
      const row = values.join(';');
      csvContent += row + '\r\n';
    });
    return csvContent;
  }

  public async collapseGroup(groupsSpred: GroupSpred): Promise<void> {

    if (!groupsSpred.isOpen) {

      const infos = await this.groupSpreadService.getAllInfos(groupsSpred.id);

      if (infos.return.code === 0) {
        groupsSpred.channels = infos.data.channels;
        groupsSpred.categories = infos.data.categories;
        groupsSpred.segments = infos.data.segments;
      } else {
        this.toastrService.error(infos.return.message, '', {
          toastComponent: CustomErrorToastComponent,
        });
      }

    }

    groupsSpred.isOpen = !groupsSpred.isOpen;

    this.groupsSpred.forEach(currentGroup => {
      if (currentGroup.id !== groupsSpred.id) {
        currentGroup.isOpen = false;
      }
    });
  }

  public async changeStatusGroup(groupSpred): Promise<void> {
    const statusId = groupSpred.statusId === 10 ? 5 : 10;
    const statusDescription = statusId === 10 ? 'ativado' : 'inativado';
    const response = await this.groupSpreadService.updateStatusGroupSpread(groupSpred.id, statusId);

    if (response.return.code !== 0) {
      this.toastrService.error(response.return.message, '', {
        toastComponent: CustomErrorToastComponent,
      });
    } else {
      this.toastrService.success('Grupo Spread ' + statusDescription + ' com sucesso.', '', {
        toastComponent: CustomSuccessToastComponent,
      });
    }

    this.refreshProductList();
  }

  public refreshProductList(): void {
    this.filterComponent.emitSearch();
  }

  public showHistory(groupSpred: GroupSpred): void {
    const data: IHistoricData = {
      tableId: TABLE_MAPPER.GROUP_SPREAD,
      recordId: groupSpred.id,
      subtitle: 'Grupo de Spread'
    };
    this.genericDialog.historic(data);
  }

}
