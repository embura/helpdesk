// // tslint:disable-next-line:snt-file-name-suffix
// import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule, MatDialog, MatButtonModule, MatInputModule } from '@angular/material';
// import { TestBed, ComponentFixture } from '@angular/core/testing';
// import { AddGroupSpreadComponent } from './family-category.component';
// import { Observable } from 'rxjs/Observable';
// import { Family } from './family';
// import { AccordionComponent } from '../../accordion/accordion.component';
// import { FamilyCategoryDialogComponent } from './dialog/family-category-dialog.component';
// import { FormsModule } from '@angular/forms';
// import { DialogHeaderComponent } from '../../dialog-header/dialog-header.component';
// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { AccordionItem } from '../../accordion/accordion-item';
// import { ICategory } from '../../../models/category/category.interface';
// import { IResponse } from '../../../models/response/response.interface';
// import { FamilyService } from '../../../services/category/family/family.service';
// import 'rxjs/add/observable/of';
// import { CatalogSharedModule } from '../../../catalog-shared.module';
// import { GenericDialogComponent } from '../../dialogs/generic/generic-dialog.component';
// import { OrderAccordionPipe } from '../../../pipes/order-accordion.pipe';
// import { ToastrService } from 'ngx-toastr';

// export class MockToastrService {
//   public success = () => 'mock';
//   public error = () => 'mock';
// }
// @NgModule({
//   imports: [
//     CatalogSharedModule,
//     FormsModule,
//     CommonModule,
//     BrowserAnimationsModule
//   ],
//   declarations: [
//     AddGroupSpreadComponent,
//     AccordionComponent,
//     FamilyCategoryDialogComponent,
//     DialogHeaderComponent,
//     GenericDialogComponent,
//     OrderAccordionPipe
//   ],
//   entryComponents: [FamilyCategoryDialogComponent, GenericDialogComponent]
// })
// class TestModule { }

// describe('AddGroupSpreadComponent', () => {
//   let component: AddGroupSpreadComponent;
//   let fixture: ComponentFixture<AddGroupSpreadComponent>;

//   const families: ICategory[] = [
//     {
//       'id': 1,
//       'name': 'Estruturados',
//       'shortName': 'Estruturados'
//     },
//     {
//       'id': 2,
//       'name': 'Renda Fixa',
//       'shortName': 'Renda Fixa'
//     }
//   ];

//   const mockService = {
//     getFamily: (code: number): Observable<IResponse<ICategory>> => {
//       return Observable.of({
//         'return': {
//           'code': 0,
//           'message': '[Category] Family was found successfully.'
//         },
//         'data': families.find(fam => fam.id === code)
//       });
//     },
//     getAllFamilies: (): Observable<IResponse<ICategory[]>> => {
//       return Observable.of({
//         'return': {
//           'code': 0,
//           'message': '[Category] Families were found successfully.'
//         },
//         'data': families
//       });
//     },
//     editFamily: (family: Family): Observable<IResponse<ICategory>> => {
//       const editedFamily = families[families.findIndex(ac => ac.id === family.code)];

//       editedFamily.name = family.name;

//       families[families.findIndex(ac => ac.id === family.code)] = editedFamily;

//       return Observable.of({
//         'return': {
//           'code': 0,
//           'message': '[Category] Family was changed successfully.'
//         },
//         'data': editedFamily
//       });
//     },
//     addFamiliy: (family: Family): Observable<IResponse<ICategory>> => {
//       const newFamily: ICategory = { id: families.length + 1, name: family.name, shortName: family.name };
//       families.push(newFamily);

//       return Observable.of({
//         'return': {
//           'code': 0,
//           'message': '[Category] Family was created successfully.'
//         },
//         'data': newFamily
//       });
//     }
//   };

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       imports: [TestModule],
//       providers: [
//         { provide: FamilyService, useValue: mockService  },
//         { provide: ToastrService, useClass: MockToastrService }
//       ]
//     }).compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AddGroupSpreadComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();

//     component = fixture.componentInstance;
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should open dialog', () => {
//     const dialogRefTest: MatDialogRef<FamilyCategoryDialogComponent, Family> = (<any>component).openDialog();

//     expect(dialogRefTest).toBeTruthy();
//   });

//   it('should open dialog with data', () => {
//     const data: Family = new Family('Teste', 1);

//     const dialogRefTest: MatDialogRef<FamilyCategoryDialogComponent, Family> = (<any>component).openDialog(data);

//     expect(dialogRefTest).toBeTruthy();
//   });

//   it('should not add a family', () => {
//     const data: Family = new Family('Teste', 1);

//     component.add();

//     (<any>component).dialogRef.close();

//     expect((<any>component).families.length).toBe(0);
//   });

//   it('should add a family', () => {
//     const data: Family = new Family('Teste', 1);

//     component.add();

//     (<any>component).dialogRef.close(data);
//   });

//   it('should not edit a family', () => {
//     const data: AccordionItem = new AccordionItem();
//     data.name = 'Teste';
//     data.id = 1;

//     (<any>component).families.push(data);

//     component.edit(data);

//     (<any>component).dialogRef.close();
//   });

//   it('should edit a family', () => {
//     const data: AccordionItem = new AccordionItem();
//     data.name = 'Teste';
//     data.id = 1;

//     (<any>component).families.push(data);

//     component.edit(data);

//     const family: Family = new Family('Teste 2', 2);

//     (<any>component).dialogRef.close(family);
//   });

//   it('should delete a family', () => {
//     const item1: AccordionItem = new AccordionItem();
//     item1.name = 'Teste';
//     item1.id = 1;

//     const item2: AccordionItem = new AccordionItem();
//     item2.name = 'Teste 2';
//     item2.id = 2;

//     (<any>component).families.push(item1);
//     (<any>component).families.push(item2);

//     expect((<any>component).families.length).toBe(2);

//     component.del(item2);

//     expect((<any>component).families.length).toBe(1);
//   });

//   it('should have truthy families array', () => {
//     const familiesArr = component['families'];

//     expect(familiesArr).toBeTruthy();
//   });

//   it('should fill data and map to families', () => {
//     const data: ICategory[] = [
//       { name: 'Mock 1', shortName: 'Mock 1', id: 1 },
//       { name: 'Mock 2', shortName: 'Mock 2', id: 2 }
//     ];
//     component['data'] = data;

//     expect(component['families'].length).toBe(2);
//   });

//   it('should fill data and not map to families', () => {
//     component['data'] = null;

//     expect(component['families'].length).toBe(0);
//   });

//   it('show return add response with error', () => {
//     component['familyService'].addFamiliy = (family: Family): Observable<IResponse<ICategory>> => {
//       return Observable.of({
//         'return': {
//           'code': 1,
//           'message': '[Category] Family was not created because of a error.'
//         },
//         'data': null
//       });
//     };

//     const countBefore: number = component['families'].length;

//     component.add();

//     component['dialogRef'].close(new Family('Teste', 1));

//     const countAfter: number = component['families'].length;

//     expect(countBefore).toBe(countAfter);
//   });

//   it('show return an exception when invoke service to add', () => {
//     component['familyService'].addFamiliy = () => Observable.throw({});

//     const countBefore: number = component['families'].length;

//     component.add();

//     component['dialogRef'].close(new Family('Teste', 1));

//     const countAfter: number = component['families'].length;

//     expect(countBefore).toBe(countAfter);
//   });

//   it('show return edit response with error', () => {
//     component['familyService'].editFamily = (family: Family): Observable<IResponse<ICategory>> => {
//       return Observable.of({
//         'return': {
//           'code': 1,
//           'message': '[Category] Family was not created because of a error.'
//         },
//         'data': null
//       });
//     };

//     const countBefore: number = component['families'].length;
//     const item = new AccordionItem();
//     item.name = 'Test 1';
//     item.id = 1;
//     item.subItem = '';
//     item.subItemId = 0;
//     item.canDelete = false;
//     item.canEdit = false;
//     item.popupOpen = false;
//     component.edit(item);

//     component['dialogRef'].close(new Family('Teste', 1));

//     const countAfter: number = component['families'].length;

//     expect(countBefore).toBe(countAfter);
//   });

//   it('show return an exception when invoke service to edit', () => {
//     component['familyService'].editFamily = (family: Family): Observable<IResponse<ICategory>> => {
//       return Observable.throw({});
//     };

//     const countBefore: number = component['families'].length;
//     const item = new AccordionItem();
//     item.name = 'Test 1';
//     item.id = 1;
//     item.subItem = '';
//     item.subItemId = 0;
//     item.canDelete = false;
//     item.canEdit = false;
//     item.popupOpen = false;
//     component.edit(item);

//     component['dialogRef'].close(new Family('Teste', 1));

//     const countAfter: number = component['families'].length;

//     expect(countBefore).toBe(countAfter);
//   });
// });
