
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ChannelService} from './../../../../../services/events-channels/channel/channel.service';
import {FamilyService} from './../../../../../services/category/family/family.service';
import {GroupService} from './../../../../../services/category/group/group.service';
import {SegmentService} from './../../../../../services/segment/segment.service';
import { SpredGroup } from './../../../models/group-spred';

@Component({
  selector: 'pne-group-spread-info-wizard',
  templateUrl: './group-spread-info-wizard.component.html',
  styleUrls: ['./group-spread-info-wizard.component.scss']
})
export class GroupSpreadInfoWizardComponent implements OnInit {
  @Input() public channels;
  @Input() public categoryFamily;
  @Input() public segments;
  @Input() public groupByFamily;
  @Input() public step: String = '1';
  @Input() public category: Number = 0;
  @Input() public form;
  @Output() public submitStep: EventEmitter<String> = new EventEmitter();
  @Output() public submitDisabledSave: EventEmitter<Boolean> = new EventEmitter();
  @Output() public submitFormForSpread: EventEmitter<SpredGroup> = new EventEmitter();
  public spredGroup = new SpredGroup();
  public btAbstract: Number = 0;
  public btSegment: Number = 0;
  public disabledSave: Boolean = false;
  constructor(private channelsService: ChannelService,
              private familyService: FamilyService,
              private groupService: GroupService,
              private segmentService: SegmentService) {}

  ngOnInit() {
    this.getChannel();
    this.getCategoryFamily();
    this.getSegments();
  }

  public getChannel() {
    this.channelsService.getAllChannels().subscribe(
      res => this.channels = res.data
    );
  }
  public getCategoryFamily() {
    this.familyService.getAllFamilies().subscribe(
      res => this.categoryFamily = res.data
    );
  }
  public getGroup(familyId) {
    this.groupService.getGroupsByFamily(familyId).subscribe(
      res => this.groupByFamily = res.data
    );
  }
  public getSegments() {
    this.segmentService.getSegments().subscribe(
      res => this.segments =  res.data
    );
  }
  public nextStep(step: String) {
    this.step = step;
    this.submitStep.emit(this.step);
  }
  public receiveAbstractGroup(abstract) {
    this.btAbstract = abstract;
    if (this.btAbstract > 0) {
      this.disabledSave = true;
    }else {
      this.disabledSave = false;
    }
    this.submitDisabledSave.emit(this.disabledSave);
  }
  public receiveAbstractSegment(abstract) {
    this.btSegment = abstract;
  }
  public abstractGroup(category) {
    this.category = category;
    console.log('category', this.category);
  }
  public submitForm(form, target: string) {
    this.spredGroup[target] = form;
    this.submitFormForSpread.emit(this.spredGroup);
  }
}
