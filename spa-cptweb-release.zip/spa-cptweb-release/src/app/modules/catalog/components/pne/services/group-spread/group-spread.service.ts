import { Injectable, Inject } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../../../models/response/response.interface';
import { UtilService, IQuery } from '../../../../services/util/util.service';
import { GroupSpred, SpreadInfos } from '../../models/group-spred';
import { ITotal } from '../../../../models/product/product.interface';
import { ObservableRetryHandler } from '../../../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class GroupSpreadService {
    public static serviceHost = '/treasury-product-catalog/v1/spread';
    private ordenation: IQuery = {};

    constructor(
        private hubConnector: HubConnectorComponent,
        private utilService: UtilService
    ) { }

    public saveGroupsSpread(groupSpread) {
        const url: string = this.utilService.getHubUrl(GroupSpreadService.serviceHost);
        return this.hubConnector.postJson(url, groupSpread)
        .catch(() => Observable.of(
            {
                data: []
            }
        )).toPromise();
    }

    private defaultError = (message: string): IResponse<Array<GroupSpred>> => ({
        return: {
            code: 1,
            message
        },
        data: []
    })

    public getGroupsSpread(query?: IQuery): Promise<IResponse<Array<GroupSpred>>> {
        const url: string = this.utilService.getHubUrl(GroupSpreadService.serviceHost);
        const message = 'Erro ao consultar Grupos Spread';
        return this.hubConnector.getJson(url, { params: query })
        .retryWhen(ObservableRetryHandler)
        .catch(() => Observable.of(
            {
                ...this.defaultError(message),
                data: []
            }
        )).toPromise();
    }

    public async updateStatusGroupSpread(groupSpreadId: number, statusId: number): Promise<IResponse<GroupSpred>> {
        const url: string = this.utilService.getHubUrl(GroupSpreadService.serviceHost + `/active`);
        const query = { groupSpredId: groupSpreadId,
                        statusId: statusId };
        return this.hubConnector.putJson(url, query).catch(() => Observable.of(
            {
                ...this.defaultError('Erro ao atualizar status do grupo spread.'),
                data: null
            }
        )).toPromise();
    }

    public getAllInfos(groupSpreadId: number): Promise<IResponse<SpreadInfos>> {
        const url = this.utilService.getUrlQuery(GroupSpreadService.serviceHost + `/infos/findAll`, { groupSpredId: groupSpreadId });
        return this.hubConnector.getJson(url)
        .retryWhen(ObservableRetryHandler)
        .catch(() => Observable.of(
            {
                ...this.defaultError('Erro ao informações do grupo spread.'),
                data: null
            }
        )).toPromise();
    }

    public findQuantites(): Promise<IResponse<ITotal>> {
        const url: string = this.utilService.getHubUrl(GroupSpreadService.serviceHost + `/infos/quantities`);
        return this.hubConnector.getJson(url)
        .retryWhen(ObservableRetryHandler)
        .catch(() => Observable.of(
            {
                ...this.defaultError('Erro ao consultar quantidades de grupos de spread.'),
                data: null
            }
        )).toPromise();
    }
}
