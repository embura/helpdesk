import { Component, Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'pne-segment-selector',
  templateUrl: './segment-selector.component.html',
  styleUrls: ['./segment-selector.component.scss']
})
export class SegmentSelectorComponent {

  @Input() public segments;
  @Output() public submitAbstractSegment: EventEmitter<Number> = new EventEmitter();
  @Output() public submitForm: EventEmitter<any> = new EventEmitter();
  public abstractSegment: String[] = [];
  public btSegment: Number;
  public isAllSelected = false;
  public segmentId: any[] = [];

  constructor() {
  }
  public segmentChecked(checked, event) {
    if (event.checked === true) {
      this.segmentId.push(checked.id);
      this.abstractSegment.push(checked);
    }
    if (event.checked === false) {
      for (let index = 0; index < this.abstractSegment.length; index++) {
        if (this.abstractSegment[index] === checked) {
          this.segmentId.splice(index, 1);
          this.abstractSegment.splice(index, 1);
          break;
        }
      }

    }
    this.btSegment = this.abstractSegment.length;
    this.submitForm.emit(this.segmentId);
    this.submitAbstractSegment.emit(this.btSegment);
  }
  public selectAllToggle(event) {
    this.isAllSelected = !this.isAllSelected;
    this.segments.forEach(ch => {
      this.segmentChecked(ch.name, {checked: this.isAllSelected});
    });
  }

  isSelected(target: any): boolean {
    return this.abstractSegment
      .filter( ag => ag === target.name)
      .length > 0;
  }

}
