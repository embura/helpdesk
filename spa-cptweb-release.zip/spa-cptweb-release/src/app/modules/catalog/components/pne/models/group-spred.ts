export interface GroupSpred {
    id?: number;
    name: string;
    spredPurchase: number;
    spredSale: number;
    salesPurchase: number;
    salesSale: number;
    qtdChannels: number;
    qtdCategories: number;
    qtdSegments: number;
    isActive: boolean;
    isEditing: boolean;
    channels?: any[];
    categories?: any[];
    segments?: any[];
    isOpen?: boolean;
}

export interface SpreadInfos {
    channels: Array<any>;
    categories: Array<any>;
    segments: Array<any>;
}

export interface IGroupSpredExport {
    name: string;
    spredPurchase: string;
    spredSale: string;
    salesPurchase: string;
    salesSale: string;
    qtdChannels: number;
    qtdCategories: number;
    qtdSegments: number;
}


export class SpredGroup {
    channels: any[];
    categories?: any[];
    segments?: any[];
}

export interface SubmitSpreadGroup {
    taxSpreadPurchase: number;
    taxSpreadSales: number;
    taxSalesCredPurchase: number;
    taxSalesCreditSales: number;
    qtdChannels: number;
    qtdCategories: number;
    qtdSegments: number;
    nameGroup: string;
    nrSeqSitu?: number;
    channels: number[];
    segments?: number[];
    categories?: number[];
}
