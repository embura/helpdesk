import { Component, Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'pne-monitor',
  templateUrl: './pne-monitor.component.html',
  styleUrls: ['./pne-monitor.component.scss']
})
export class PNEMonitorComponent {


  constructor() {
  }

}
