import { PNEAppComponent } from './pne-app.component';
import { Type } from '@angular/core';
import { AddGroupSpreadComponent } from './components/add-group-spread/add-group-spread.component';
import { GroupSpreadInfoWizardComponent } from './components/add-group-spread/group-spread-info-wizard/group-spread-info-wizard.component';
import { CategorySelectorComponent
} from './components/add-group-spread/group-spread-info-wizard/category-selector/category-selector.component';
import { ChannelSelectorComponent
} from './components/add-group-spread/group-spread-info-wizard/channel-selector/channel-selector.component';
import { SegmentSelectorComponent
} from './components/add-group-spread/group-spread-info-wizard/segment-selector/segment-selector.component';
import { PNEConfigurationComponent } from './components/pne-monitor/pne-configuration.component';
import { PNEMonitorComponent } from './components/pne-configuration/pne-monitor.component';
import { PNETabComponent } from './components/pne-tab/pne-tab.component';
import { GroupSpreadDatagridComponent } from './components/group-spread-datagrid/group-spread-datagrid.component';
import { GroupSpreadFilterComponent
} from './components/group-spread-datagrid/group-spread-filter/group-spread-filter.component';

export const PNEAppIndex: any[] = [
  AddGroupSpreadComponent,
  GroupSpreadInfoWizardComponent,
  CategorySelectorComponent,
  ChannelSelectorComponent,
  SegmentSelectorComponent,
  GroupSpreadDatagridComponent,
  GroupSpreadFilterComponent,
  PNEMonitorComponent,
  PNEConfigurationComponent,
  PNETabComponent,
];
