import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ProductService } from '../../services/product/product.service';
import { MatDialog } from '@angular/material';

@Component({
    templateUrl: './pne-app.component.html',
    styleUrls: ['./pne-app.component.scss']
})
export class PNEAppComponent {
    constructor(private dialog: MatDialog, private productService: ProductService, private toastrService: ToastrService) { }
}
