import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { IFilterOption } from '../../../../../models/filter/filter-object.interface';
import { Subscription } from 'rxjs/Subscription';

export interface IFilterEvent {
  value: {
    showInatives: boolean,
    textFilter: string,
    filter: IFilterOption
  };
  isTextualChange: boolean;
}

@Component({
  selector: 'pne-group-spread-filter',
  templateUrl: './group-spread-filter.component.html',
  styleUrls: ['./group-spread-filter.component.scss']
})
export class GroupSpreadFilterComponent implements OnInit, OnDestroy {
  @Input() public context: string;
  @Input() public showAddButton = true;
  @Input() public textMinLength = 3;
  private _showLoadingSpinner = false;
  @Input() public set showLoadingSpinner(value: boolean) {
    if (typeof(value) === typeof(true)) {
      this._showLoadingSpinner = value;
    }
  }
  public get showLoadingSpinner(): boolean {
    return this._showLoadingSpinner;
  }
  /**
   * @param filterOptions deverá ser alterado de acordo com
   * as necessidades do componente pai
   */
  @Input() public filterOptions: Array<IFilterOption> = [
    { id: 1, value: 'mais recentes', orderBy: 'id', order: 'desc' },
    { id: 2, value: 'menos recentes', orderBy: 'id', order: 'asc' },
    { id: 3, value: 'apenas ativos', status: 10, orderBy: 'id', order: 'desc' },
    { id: 4, value: 'apenas inativos', status: 5, orderBy: 'id', order: 'desc' },
    { id: 5, value: 'ordem Alfabética', orderBy: 'name', order: 'asc' }
  ];
  @Output() public onAddButtonClicked: EventEmitter<void>;
  @Output() public search: EventEmitter<IFilterEvent>;

  public form: FormGroup;
  private subscriptions: Array<Subscription> = [];

  constructor(_fb: FormBuilder) {
    this.form = _fb.group({
      showInatives: [false],
      textFilter: [''],
      filter: [this.filterOptions[0]]
    });
    this.onAddButtonClicked = new EventEmitter<void>();
    this.search = new EventEmitter<IFilterEvent>();
  }

  private onTextFilterChange = (val: string): void => {
    if (val.length >= this.textMinLength) {
      this.emitSearch(true);
    } else if (!val || val.length === 0) {
      this.emitSearch(true);
    }
  }

  private onDropDownFilterChange = (value: IFilterOption): void => {
    /**
     *  @todo: verificar como vai ficar essa validação de id de filtro no back
     */
    if (value.id === 4) {
      this.form.controls.showInatives.setValue(true, {emitEvent: false});
    } else if (value.id === 3) {
      this.form.controls.showInatives.setValue(false, {emitEvent: false});
    }
    this.emitSearch();
  }

  private onCheckBoxChange = (value: boolean): void => {
    const selectedFilter: number = this.form.value.filter.id;
    if (value && selectedFilter === 3) {
      this.form.controls.filter.setValue(this.filterOptions[0], {emitEvent: false});
    } else if (!value && selectedFilter === 4) {
      this.form.controls.filter.setValue(this.filterOptions[0], {emitEvent: false});
    }

    this.form.controls.showInatives.setValue(value, { emitEvent: false });

    this.emitSearch();
  }

  ngOnInit(): void {
    const formControl = this.form.controls;
    this.subscriptions.push(formControl.textFilter.valueChanges.debounceTime(200).subscribe(this.onTextFilterChange));
    this.subscriptions.push(formControl.filter.valueChanges.subscribe(this.onDropDownFilterChange));
    this.subscriptions.push(formControl.showInatives.valueChanges.subscribe(this.onCheckBoxChange));
    this.emitSearch();
  }

  public emitSearch(isText?: boolean): void {
    this.search.emit({
      value: this.form.value,
      isTextualChange: !!isText
    });
  }

  ngOnDestroy(): void {
    for (const subs of this.subscriptions) {
      subs.unsubscribe();
    }
  }

}
