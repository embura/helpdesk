import { Family } from './../../../../../category/family/family';
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Group } from '../../../../../category/group/group';

export type FamilyGroupUnion = [Family, Group];

@Component({
  selector: 'pne-category-selector',
  templateUrl: './category-selector.component.html',
  styleUrls: ['./category-selector.component.scss']
})

export class CategorySelectorComponent {

  @Input() public categoryFamily;
  @Input() public groupByFamily;
  @Output() public getGroup: EventEmitter<void> = new EventEmitter();
  @Output() public abstractGroup: EventEmitter<Number> = new EventEmitter();
  @Output() public submitForm: EventEmitter<any> = new EventEmitter();
  public getFamily;
  public group;
  public family: Family;
  public familyAndGroup: FamilyGroupUnion[] = [];
  public visible: Boolean = false;
  public abstractCategory: Number = 0;
  public groupId: any[] = [];
  constructor() {
  }

  public getFamilyId(event) {
    this.getFamily = event;
    this.getFamily =  this.getFamily.value.id;
    this.getGroup.emit(this.getFamily);
    this.family = event.value;
  }
  public getGroupName(event) {
    this.group = event.value;
  }
  mountObject() {
    this.familyAndGroup.push([this.family, this.group]);
    this.visible = true;
    this.groupId.push(this.group.id);
    this.abstractCategory =  (this.familyAndGroup).length;
    this.abstractGroup.emit(this.abstractCategory);
    this.submitForm.emit(this.groupId);
  }
  delFamilyAndGroup(obj) {
      for (let index = 0; index < this.familyAndGroup.length; index++) {
        if (this.familyAndGroup[index] === obj) {
          this.groupId.splice(index, 1);
          this.familyAndGroup.splice(index, 1);
          break;
        }
      }
      if (this.familyAndGroup.length === 0) {
        this.visible = false;
      }
      this.abstractCategory =  (this.familyAndGroup).length;
      this.abstractGroup.emit(this.abstractCategory);
      this.submitForm.emit(this.groupId);
    }
}
