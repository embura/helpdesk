import { Component, Input, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material';
import { AddGroupSpreadComponent } from '../add-group-spread/add-group-spread.component';
@Component({
  selector: 'pne-tab',
  templateUrl: './pne-tab.component.html',
  styleUrls: ['./pne-tab.component.scss']
})
export class PNETabComponent {


  constructor(
    private dialog: MatDialog,
  ) {
  }

  openAddSpreadGroupModal() {
    const dialogData: any = { width: '90%' };
    this.dialog.open(AddGroupSpreadComponent, dialogData).afterClosed().subscribe(_ => {

    });
  }

}
