import { Component, Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'pne-configuration',
  templateUrl: './pne-configuration.component.html',
  styleUrls: ['./pne-configuration.component.scss']
})
export class PNEConfigurationComponent {


  constructor() {
  }

}
