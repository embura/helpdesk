import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-cpt-app-header-dialog',
  templateUrl: './dialog-header.component.html',
  styleUrls: ['./dialog-header.component.scss']
})
export class DialogHeaderComponent {
  @Input() public title: string;
  @Input() public subtitle: string;
  @Input() public app: string;
  @Output() public close: EventEmitter<void> = new EventEmitter();

}
