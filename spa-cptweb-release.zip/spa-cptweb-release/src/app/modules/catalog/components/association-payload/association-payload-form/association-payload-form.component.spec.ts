import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastrModule } from 'ngx-toastr';
import { DragulaModule } from 'ng2-dragula';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { CustomSuccessToastComponent } from '../../toast/custom-success-toast.component';
import { AssociationFormComponent } from './association-payload-form.component';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CatalogSharedModule } from '../../../catalog-shared.module';
import { IForm, IFormParameter, IParamFormAssociation } from '../../../models/form/form.interface';
import { Observable } from 'rxjs/Observable';
import { IResponse } from '../../../models/response/response.interface';
import { FormService } from '../../../services/form/form.service';
import { Payload, IItemAssociation, IPayloadFormItem } from '../../../models/payload/payload';
import { PayloadItem } from '../../../models/payload/payload-item';
import { PayloadService } from '../../../services/payload/payload.service';
import { PayloadItemService } from '../../../services/payload-item/payload-item.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GenericDialogComponent } from '../../dialogs/generic/generic-dialog.component';

//#region Test Data

const formParameter: IFormParameter[] = [
    {
        formId: 1,
        parameterId: 1,
        paramOrder: 1,
        required: 'N',
        id: 1,
        info: {
            id: 1,
            isEditable: false,
            name: 'Param 1',
            options: null,
            statusId: 10,
            typeId: 1,
            validationId: 1
        }
    },
    {
        formId: 2,
        parameterId: 2,
        paramOrder: 2,
        required: 'N',
        id: 2,
        info: {
            id: 2,
            isEditable: false,
            name: 'Param 1',
            options: null,
            statusId: 10,
            typeId: 1,
            validationId: 1
        }
    }
];

const formData: IForm = {
    id: 1,
    isEditable: false,
    name: 'Form 1',
    statusId: 10,
    formParameters: formParameter
};

const formDataTwo: IForm = {
    id: 1,
    isEditable: false,
    name: 'Form 2',
    statusId: 10,
    formParameters: formParameter
};

const paramFormAssociation: IParamFormAssociation = {
    id: 1,
    name: 'Param Form Association'
};

const payloadItens: PayloadItem = {
    editing: false,
    id: 1,
    isEditable: false,
    name: 'Payload Item 1',
    paramFormAssociation: paramFormAssociation,
    payloadId: 1
};

const payloadOne: Payload = {
    id: 1,
    isEditable: false,
    isOpen: false,
    isSaved: false,
    name: 'Payload 1',
    itens: [payloadItens]
};

const payloadTwo: Payload = {
    id: 2,
    isEditable: false,
    isOpen: false,
    isSaved: false,
    name: 'Payload 2',
    itens: [payloadItens]
};

const itemAssociation: IItemAssociation = {
    formParamId: 1,
    payloadId: 1,
    payloadItemId: 1
};

const payloadFormItem: IPayloadFormItem = {
    associationId: 1,
    formId: 1,
    nameParam: 'Param 1',
    namePayloadItem: 'Param 1',
    paramId: 1,
    payloadId: 1,
    payloadItemId: 1
};

//#endregion

//#region Services

const mockFormService = {
    getFormsAssociations: (): Observable<IResponse<IForm[]>> => {
        return Observable.of({
            'return': {
                'code': 0,
                'message': 'Form were found successfully.'
            },
            'data': [formData, formDataTwo]
        });
    },
    getParametersById: (id: number): Promise<IResponse<IParamFormAssociation[]>> => {
        return Promise.resolve({
            'return': {
                'code': 0,
                'message': 'Param Form Association were found successfully.'
            },
            'data': [paramFormAssociation]
        });
    }
};

const mockPayloadService = {
    getAll: (): Observable<IResponse<Array<Payload>>> => {
        return Observable.of({
            'return': {
                'code': 0,
                'message': 'Payload were found successfully.'
            },
            'data': [payloadOne, payloadTwo]
        });
    },
    createAssociations: (itensAssociation: IItemAssociation[], formParamId: number): Observable<IResponse<IItemAssociation[]>> => {
        return Observable.of({
            'return': {
                'code': 0,
                'message': 'Payload were found successfully.'
            },
            'data': [itemAssociation]
        });
    },
    getPayloadFormItens: (formId: number, payloadId?: number): Promise<IResponse<IPayloadFormItem[]>> => {
        return Promise.resolve({
            'return': {
                'code': 0,
                'message': 'Payloa were found successfully.'
            },
            'data': [payloadFormItem]
        });
    }
};

const mockPayloadItemService = {
    get: (payloadId: number): Observable<IResponse<PayloadItem[]>> => {
        return Observable.of({
            'return': {
                'code': 0,
                'message': 'Payload Item were found successfully.'
            },
            'data': [payloadItens]
        });
    }
};

//#endregion

// tslint:disable-next-line:snt-file-name-suffix
@NgModule({
    imports: [
        CommonModule,
        ToastrModule.forRoot({
            timeOut: 3000,
            positionClass: 'toast-bottom-center'
        }),
        CatalogSharedModule,
        DragulaModule,
        BrowserAnimationsModule,
    ],
    declarations: [
        AssociationFormComponent,
        CustomErrorToastComponent,
        CustomSuccessToastComponent,
        GenericDialogComponent
    ],
    providers: [
        { provide: FormService, useValue: mockFormService },
        { provide: PayloadService, useValue: mockPayloadService },
        { provide: PayloadItemService, useValue: mockPayloadItemService }
    ],
    entryComponents: [
        CustomErrorToastComponent,
        CustomSuccessToastComponent,
        GenericDialogComponent
    ]
})
class TestModule { }

describe('Association Payload Form', () => {
    let component: AssociationFormComponent;
    let fixture: ComponentFixture<AssociationFormComponent>;
    let nativeElement;
    let debugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                TestModule
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(AssociationFormComponent);
        component = fixture.componentInstance;
        nativeElement = fixture.nativeElement;
        debugElement = fixture.debugElement;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(AssociationFormComponent).toBeTruthy();
    });

    it('SuccessToast', () => {
        component.successToast('Success');
    });

    it('ErrorToast', () => {
        component.errorToast('Error');
    });

    it('openFormList', () => {
        component.openFormList();
    });

    it('selectForm', () => {
        component.selectForm(formData);
    });

    it('selectForm model filled', () => {
        component.model = {
            id: 2,
            isEditable: false,
            isOpen: false,
            name: 'Model',
            parameters: null,
            statusId: 10
        };

        component.selectForm(formData);
    });

    it('isSelectedForm', () => {
        component.model = {
            id: 1,
            isEditable: false,
            isOpen: false,
            name: 'Model',
            parameters: null,
            statusId: 10
        };

        expect(component.isSelectedForm(formData)).toBe(true);
    });

    it('getParametersById', () => {
        component.getParametersById(1);
    });

    it('collapsePayload not saved', () => {
        payloadOne.isSaved = undefined;
        payloadOne.itens = undefined;
        component.collapsePayload(payloadOne);
    });

    it('collapsePayload saved', () => {
        payloadOne.isSaved = true;
        component.collapsePayload(payloadOne);
    });

    it('moves true', () => {
        const el = {
            parentElement: {
                className: 'Teste'
            }
        };

        expect(component.moves(el, null, null, null)).toBe(true);
    });

    it('moves false', () => {
        const el = {
            parentElement: {
                className: 'not-drop'
            }
        };

        expect(component.moves(el, null, null, null)).toBe(false);
    });

    it('moves false', () => {
        const el = {
            parentElement: {
                className: 'not-drop'
            }
        };

        expect(component.moves(el, null, null, null)).toBe(false);
    });

    it('accepts true', () => {
        const el = {
            className: 'Teste'
        };

        expect(component.accepts(null, null, null, el)).toBe(true);
    });

    it('accepts false drag-drop-item', () => {
        const el = {
            className: 'drag-drop-item'
        };

        expect(component.accepts(null, null, null, el)).toBe(false);
    });

    it('accepts false not-drop', () => {
        const el = {
            className: 'not-drop'
        };

        expect(component.accepts(null, null, null, el)).toBe(false);
    });

    it('removeItemAssociation', () => {
        const div = {
            classList: {
                add: (): void => { },
                remove: (): void => { }
            }
        };

        component.removeItemAssociation(payloadOne, 0, div, div);
    });

    it('overAssociationItem', () => {
        const value = {
            className: 'parameter-association not-drop',
            parentElement: {
                children: [
                    {
                        className: 'parameter-association not-drop',
                        classList: {
                            add: (): void => { }
                        }
                    }
                ]
            }
        };

        component.overAssociationItem([value]);
    });

    it('overAssociationItem not have currentValue', () => {
        component.overAssociationItem([null]);
    });

    it('overAssociationItem currentValue.className.indexOf("parameter-association not-drop") === 0', () => {
        const value = {
            className: 'Teste',
            parentElement: {
                children: [
                    {
                        className: 'parameter-association not-drop',
                        classList: {
                            add: (): void => { }
                        }
                    }
                ]
            }
        };

        component.overAssociationItem([value]);
    });

    it('overAssociationItem !currentValue.parentElement.children', () => {
        const value = {
            className: 'parameter-association not-drop',
            parentElement: {
                children: []
            }
        };

        component.overAssociationItem([value]);
    });

    it('overAssociationItem element.className.indexOf("drag-drop-item") > -1', () => {
        const value = {
            className: 'parameter-association not-drop',
            parentElement: {
                children: [
                    {
                        className: 'drag-drop-item',
                        classList: {
                            add: (): void => { },
                            remove: (): void => { }
                        }
                    }
                ]
            }
        };

        component.overAssociationItem([value]);
    });

    it('overAssociationItem element.className.indexOf("parameter-association not-drop") === -1', () => {
        const value = {
            className: 'parameter-association not-drop',
            parentElement: {
                children: [
                    {
                        className: 'Teste',
                        classList: {
                            add: (): void => { }
                        }
                    }
                ]
            }
        };

        component.overAssociationItem([value]);
    });

    it('outAssociationItem this.tempParamAssociation filled', () => {
        component.tempParamAssociation = { id: 1, name: 'Teste' };
        component.payloads = [payloadOne, payloadTwo];

        const value = {
            className: 'parameter-association not-drop',
            parentElement: {
                children: [
                    {
                        parentElement: {
                            id: '0 0'
                        },
                        className: 'parameter-association not-drop',
                        classList: {
                            add: (): void => { },
                            remove: (): void => { }
                        }
                    }
                ]
            }
        };

        component.outAssociationItem([value]);
    });

    it('outAssociationItem element.className.indexOf("drag-drop-item") > -1', () => {
        component.tempParamAssociation = { id: 1, name: 'Teste' };
        component.payloads = [payloadOne, payloadTwo];

        const value = {
            className: 'parameter-association not-drop',
            parentElement: {
                children: [
                    {
                        parentElement: {
                            id: '0 0'
                        },
                        className: 'drag-drop-item',
                        classList: {
                            add: (): void => { },
                            remove: (): void => { }
                        }
                    }
                ]
            }
        };

        component.outAssociationItem([value]);
    });

    it('outAssociationItem currentValue.className.indexOf("gu-transit") > -1', () => {
        component.payloads = [payloadOne, payloadTwo];

        const value = {
            className: 'gu-transit',
            children: [
                {

                },
                {
                    id: '1'
                },
                {
                    innerHTML: '1'
                }
            ]
        };

        component.outAssociationItem([value, value]);
    });
});
