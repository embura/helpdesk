import { Component, OnDestroy, OnInit } from '@angular/core';
import { trigger, style, transition, animate } from '@angular/animations';
import { MatDialog, MatDialogRef } from '@angular/material';
import { GenericDialog } from '../../../models/dialog/generic-dialog';
import { PayloadItem } from '../../../models/payload/payload-item';
import { Payload } from '../../../models/payload/payload';
import { PayloadEditDialogComponent } from './dialog/edit/payload-edit-dialog.component';
import { PayloadCreateDialogComponent } from './dialog/create/payload-create-dialog.component';
import { Observable } from 'rxjs/Rx';
import { PayloadService } from '../../../services/payload/payload.service';
import { ToastrService } from 'ngx-toastr';
import { CustomSuccessToastComponent } from '../../toast/custom-success-toast.component';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { IQuery } from '../../../services/util/util.service';
import { PayloadItemService } from '../../../services/payload-item/payload-item.service';

@Component({
  selector: 'app-cpt-association-payload-register',
  templateUrl: './association-payload-register.component.html',
  styleUrls: ['./association-payload-register.component.scss'],
  animations: [
    trigger('ease', [
      transition('void => *', [
        style({ 'max-height': 0 }),
        animate('0.15s ease-out', style({ 'max-height': '*' })),
      ]),
      transition('* => void', [
        style({ 'max-height': '*' }),
        animate('0.15s ease-in', style({ 'max-height': 0 }))
      ])
    ])
  ],
})

export class AssociationPayloadRegisterComponent implements OnInit, OnDestroy {

  public payloads: Map<number, Payload> = new Map();
  private editingInfo = []; // apenas para guardar o nome inicial das opcoes de parâmetro que estão sendo atualizadas

  private genericDialog: GenericDialog;
  public regSpace = new RegExp(' ', 'g');

  constructor(
    private payloadService: PayloadService,
    private payloadItemService: PayloadItemService,
    private dialog: MatDialog,
    private toastrService: ToastrService,
  ) {

  }

  public async ngOnInit(): Promise<void> {
    this.genericDialog = new GenericDialog(this.dialog);
    const dialogRef = this.genericDialog.loadingMessage('Carregando payloads...');
    const res = await this.payloadService.getAll().toPromise();
    res.data.map(payload => this.payloads.set(payload.id, payload));
    dialogRef.close();
  }

  public ngOnDestroy(): void {
  }

  public errorToast(message: string) {
    this.toastrService.error(message, '', {
      toastComponent: CustomErrorToastComponent,
    });
  }

  public successToast(message: string) {
    this.toastrService.success(message, '', {
      toastComponent: CustomSuccessToastComponent,
    });
  }

  public async editModal(payloadCurrent: Payload): Promise<void> {
    if (payloadCurrent.isEditable) {
      const dialogRef = this.dialog.open(PayloadEditDialogComponent, {
        width: '570px',
        data: payloadCurrent
      });

      const payloadEdited: Payload = await dialogRef.afterClosed().toPromise<Payload>();

      if (payloadEdited) {
        const generic = this.genericDialog.loadingMessage('Editando Payload...');
        const payloadUpdated = new Payload(payloadCurrent.id, payloadEdited.name);
        this.payloadService.editPayload(payloadUpdated).subscribe(res => {
          this.payloads.set(payloadUpdated.id, payloadUpdated);
          this.successToast(res.return.message);
        }, err => {
          let msgErr = { message: 'Error ao criar payload' };

          try {
            msgErr = JSON.parse(err._body);
          } catch (e) {
            this.errorToast(e.message);
          }
          this.errorToast(msgErr.message);
        });
        generic.close();
      }
    } else {
      this.errorToast('Payload não pode ser editado');
    }
  }

  public async open(payload: Payload): Promise<void> {
    this.payloads.forEach((pay) => {
      if (payload.id !== pay.id) {
        pay.isOpen = false;
      }
    });

    const generic = this.genericDialog.loadingMessage('Carregado atributo...');
    await this.payloadItemService.get(payload.id).subscribe(res => {
      res.data.forEach(async (v, i) => {
        const isFormAssociation = await this.payloadItemService.isFormAssociation(v);
        if (isFormAssociation) {
          v.isEditable = false;
          payload.isEditable = false;
        }
      });
      payload.itens = res.data;
      payload.isOpen = !payload.isOpen;
      generic.close();
    }, err => {
      generic.close();
    });

  }

  public createPayloadItem(name: string, payload: Payload, input): void {
    const payloadItem: PayloadItem = new PayloadItem(payload.id, name);
    const dialog = this.genericDialog.loadingMessage('Criando Atributo...');
    payloadItem.editing = false;

    this.payloadItemService.create(payloadItem).subscribe(res => {
      this.payloads.get(payload.id).itens.push({ ...res.data, 'isEditable': true });
      input.value = '';
      dialog.close();
      this.successToast(res.return.message);
    }, err => {
      let errorParse = { message: 'Error ao criar Atributo' };

      try {
        errorParse = JSON.parse(err._body);
      } catch (e) {
        this.errorToast(e.message);
      }
      this.errorToast(errorParse.message);
      dialog.close();
    });
  }

  public async deletePayloadItem(payloadItem: PayloadItem, payload: Payload): Promise<void> {

    const isFormAssociation = await this.payloadItemService.isFormAssociation(payloadItem);

    if (!isFormAssociation) {
      this.payloadItemService.delete(payloadItem).subscribe(res => {
        this.payloads.get(payload.id).itens.forEach((pay, i) => {
          if (pay.id === payloadItem.id) {
            this.payloads.get(payload.id).itens.splice(i, 1);
          }
        });
        this.successToast(res.return.message);
      }, err => {
        this.errorToast(err.return.message);
      });

    } else {
      payloadItem.isEditable = false;
      this.errorToast(`Payload Atributo(${payloadItem.name}) esta associado a um formulário`);
    }

  }

  public async enableEditPayloadItem(payloadItem: PayloadItem, input, index: number) {

    const isFormAssociation = await this.payloadItemService.isFormAssociation(payloadItem);

    if (!isFormAssociation) {
      if (payloadItem.editing) {
        payloadItem.name = this.editingInfo[index];
        delete this.editingInfo[index];
      } else {
        this.editingInfo[index] = payloadItem.name;
      }
      payloadItem.editing = !payloadItem.editing;
      input.disabled = !payloadItem.editing;
      input.focus();

    } else {
      payloadItem.isEditable = false;
      this.errorToast(`Payload Atributo(${payloadItem.name}) esta associado um formulário`);
    }

  }

  public async editPayloadItem(payloadItem: PayloadItem, payload: Payload): Promise<void> {

    const isFormAssociation = await this.payloadItemService.isFormAssociation(payloadItem);

    if (!isFormAssociation) {
      this.payloadItemService.edit(payloadItem).subscribe(res => {
        this.payloads.get(payload.id).itens.forEach((pay, i) => {
          if (pay.id === payloadItem.id) {
            this.payloads.get(payload.id).itens[i] = res.data;
          }
        });

        this.successToast(res.return.message);
      }, err => {
        this.errorToast(err.return.message);
      });
    } else {
      payloadItem.isEditable = false;
      this.errorToast(`Payload Atributo(${payloadItem.name}) esta associado a um formulário`);
    }

  }

  private createModalInstance(): MatDialogRef<PayloadCreateDialogComponent> {
    return this.dialog.open(PayloadCreateDialogComponent, {
      width: '570px',
      data: {}
    });
  }

  public async save(payload: Payload): Promise<void> {
    const generic = this.genericDialog.loadingMessage('Criando Payload...');
    this.payloadService.create(payload)
      .subscribe(resp => {
        const newPayload = resp.data;
        newPayload.isEditable = true;

        this.payloads.set(newPayload.id, newPayload);
        generic.close();
        this.successToast(resp.return.message);
      }, err => {

        generic.close();
        let msgErr = { message: 'Error ao criar Payload' };
        const regRex = new RegExp('ORA-00001');

        try {
          msgErr = JSON.parse(err._body);
        } catch (e) {
          msgErr.message = e.message;
        }

        if (regRex.test(msgErr.message)) {
          msgErr.message = 'ID do Payload já existente.';
        }
        this.errorToast(msgErr.message);

      });

  }

  public async openModal(): Promise<void> {
    const dialogRef = this.createModalInstance();
    const response: Payload = await dialogRef.afterClosed().toPromise();
    const generic = this.genericDialog.loadingMessage('Criando Atributo...');
    if (response) {
      const newPayload = new Payload(response.id, response.name);
      const res = await this.save(newPayload);
    }
    generic.close();
  }

  public getPayloadsValues(): Array<Payload> {
    return Array.from(this.payloads.values());
  }

  public async excluirPayload(payload: Payload): Promise<void> {

    if (payload.isEditable) {
      const copyPayload = Object.assign({}, payload);
      this.payloadService.delete(payload).subscribe(res => {
        if (res.return.code === 0) {
          this.successToast(res.return.message);
          this.payloads.delete(copyPayload.id);
        } else {
          this.errorToast(res.return.message);
        }
      }, err => {
        this.errorToast(err.return.message);
      });
    }

  }

}
