import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MatSelectChange, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Payload } from '../../../../../models/payload/payload';

@Component({
  selector: 'app-cpt-payload-create-dialog',
  templateUrl: './payload-create-dialog.component.html',
  styleUrls: ['./payload-create-dialog.component.scss']
})
export class PayloadCreateDialogComponent implements OnInit {

  public id: number;
  public name: string;
  public form: FormGroup;
  public idPattern = /^\d{5}$/;

  constructor(
    _fb: FormBuilder,
    private dialogRef: MatDialogRef<PayloadCreateDialogComponent>,
    @Inject(MAT_DIALOG_DATA) private dialogData
  ) {
    this.form = _fb.group({
      id: ['', Validators.required],
      name: [null, Validators.required],
      validation: [null]
    });
    if (dialogData) {
      this.name = dialogData.name;
      this.id = dialogData.id;
    }
  }

  ngOnInit() {
  }

  public save(): void {
    const formValue = this.form.value;
    const payload: Payload = new Payload(formValue.id, formValue.name);
    this.dialogRef.close(payload);
  }

  public onCancelClickHandler(): void {
    this.dialogRef.close();
  }

  public isValidIdPayload(id) {
    this.form.controls.id.valueChanges.debounceTime(500).toPromise().then(res => {
      return this.idPattern.test(res);
    }).catch(err => {
      return false;
    });
  }

}
