import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MatSelectChange, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Payload } from '../../../../../models/payload/payload';

@Component({
  selector: 'app-cpt-payload-edit-create',
  templateUrl: './payload-edit-dialog.component.html',
  styleUrls: ['./payload-edit-dialog.component.scss']
})
export class PayloadEditDialogComponent implements OnInit {

  public id: number;
  public name: string;
  public form: FormGroup;

  constructor(
    _fb: FormBuilder,
    private dialogRef: MatDialogRef<PayloadEditDialogComponent>,
    @Inject(MAT_DIALOG_DATA) private dialogData
  ) {
    this.form = _fb.group({
      name: [null, Validators.required],
      validation: [null]
    });
    if (dialogData) {
      this.name = dialogData.name;
    }
  }

  ngOnInit() {
  }

  public save(): void {
    const formValue = this.form.value;
    const payload: Payload = new Payload(formValue.id, formValue.name);
    this.dialogRef.close(payload);
  }

  public onCancelClickHandler(): void {
    this.dialogRef.close();
  }

}
