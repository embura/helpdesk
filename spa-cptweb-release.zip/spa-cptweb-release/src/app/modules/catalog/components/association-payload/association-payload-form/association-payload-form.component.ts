// tslint:disable-next-line:snt-file-name-suffix
import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { IForm, IParamFormAssociation } from '../../../models/form/form.interface';
import { FormService } from '../../../services/form/form.service';
import { Subscription } from 'rxjs/Subscription';
import { CustomErrorToastComponent } from '../../toast/custom-error-toast.component';
import { ToastrService } from 'ngx-toastr';
import { Form } from '../../../models/form/form';
import { PayloadService } from '../../../services/payload/payload.service';
import { Payload, IItemAssociation, IPayloadFormItem } from '../../../models/payload/payload';
import { GenericDialog } from '../../../models/dialog/generic-dialog';
import { MatDialog } from '@angular/material';
import { DragulaService } from 'ng2-dragula';
import { CustomSuccessToastComponent } from '../../toast/custom-success-toast.component';
import { PayloadItemService } from '../../../services/payload-item/payload-item.service';

@Component({
    selector: 'app-cpt-association-form',
    templateUrl: './association-payload-form.component.html',
    styleUrls: ['./association-payload-form.component.scss'],
    animations: [
        trigger('rotatedState', [
            state('default', style({ transform: 'rotate(0)' })),
            state('rotated', style({ transform: 'rotate(-180deg)' })),
            transition('rotated => default', animate('400ms ease-out')),
            transition('default => rotated', animate('400ms ease-in'))
        ])
    ]
})

export class AssociationFormComponent implements OnInit, OnDestroy {
    public loadingForm: boolean;
    private subscriptions: Subscription[] = [];
    private genericDialog: GenericDialog;
    private dialogRef;

    public popOverOpen: boolean;
    public formListLoading: boolean;
    public formList: IForm[] = [];
    public isAssociation = false;
    public model: Form;
    public parameters: IParamFormAssociation[];
    public payloads: Payload[];
    public tempParamAssociation: IParamFormAssociation;
    public oldPayloads: Payload[];
    private dragulaOptions;

    @ViewChild('container') public containerComponent: ElementRef;

    constructor(
        private dialog: MatDialog,
        private formService: FormService,
        public toastrService: ToastrService,
        private payloadService: PayloadService,
        private dragulaService: DragulaService,
        private payloadItemService: PayloadItemService,
    ) {
        this.genericDialog = new GenericDialog(this.dialog);
        this.dialogRef = this.genericDialog.loadingMessage('Carregando Payloads...');
    }

    public successToast(message) {
        this.toastrService.success(message, '', {
            toastComponent: CustomSuccessToastComponent,
        });
    }

    public errorToast(message) {
        this.toastrService.error(message, '', {
            toastComponent: CustomErrorToastComponent,
        });
    }

    public async ngOnInit(): Promise<void> {
        this.dragulaOptions = {
            moves: this.moves,
            accepts: this.accepts,
            copy: true,
            mirrorContainer: this.containerComponent.nativeElement
        };
        await this.loadPayloads();
        this.subscriptions.push(this.dragulaService.out.subscribe(this.outAssociationItem));
        this.subscriptions.push(this.dragulaService.over.subscribe(this.overAssociationItem));
        this.subscriptions.push(this.dragulaService.drop.subscribe(this.dropAssociation));
    }

    public async loadPayloads(): Promise<void> {
        const resp = await this.payloadService.getAll().toPromise();

        if (resp.return.code === 0) {
            this.payloads = resp.data;
        } else {
            this.errorToast(resp.return.message);
        }
        this.dialogRef.close();
    }

    public ngOnDestroy(): void {
        delete this.oldPayloads;
        for (const subs of this.subscriptions) {
            subs.unsubscribe();
        }
        this.dragulaService.destroy('dragula-bag');
    }

    public openFormList(): void {
        this.popOverOpen = !this.popOverOpen;

        if (this.popOverOpen) {
            this.getForms();
        }
    }

    public getForms(): void {
        this.formListLoading = true;
        this.subscriptions.push(
            this.formService.getFormsAssociations()
                .subscribe(resp => {
                    if (resp.return.code === 0) {
                        this.formList = resp.data;
                    } else {
                        this.errorToast(resp.return.message);
                    }
                    this.formListLoading = false;
                }, err => {
                    this.errorToast(err.return.message);
                    this.formListLoading = false;
                })
        );
    }

    public async selectForm(item: IForm): Promise<void> {
        this.dialogRef = this.genericDialog.loadingMessage('Carregando informações de formulário...');
        if (!this.model || (this.model && this.model.id !== item.id)) {
            this.oldPayloads = undefined;
            this.model = undefined;
            this.payloads = [];
            this.model = new Form(item.name, item.statusId, item.isEditable, item.id);
            this.parameters = await this.getParametersById(item.id);
            await this.loadPayloads();
            await this.getPayloadFormItens(this.model.id);
        }
        this.popOverOpen = false;
        this.dialogRef.close();
    }

    public isSelectedForm(item: IForm): boolean {
        return this.model && this.model.id === item.id;
    }

    public async getParametersById(formId: number): Promise<IParamFormAssociation[]> {
        const response = await this.formService.getParametersById(formId);
        if (response.return.code !== 0) {
            this.errorToast(response.return.message);
            return;
        }
        return response.data.sort((a, b) => {
            const x = a.name.toLowerCase();
            const y = b.name.toLowerCase();
            if (x < y) { return -1; }
            if (x > y) { return 1; }
            return 0;
        });
    }

    public async collapsePayload(payload: Payload): Promise<void> {
        if (!payload.itens && !payload.isSaved) {
            await this.getPayloadItens(payload);
            this.openPayload(payload);
        } else {
            this.openPayload(payload);
        }
    }

    public async getPayloadItens(payload: Payload): Promise<void> {
        const res = await this.payloadItemService.get(payload.id).toPromise();

        if (res.return.code === 0) {
            payload.itens = res.data;
            payload.itens.map(i => i.isEditable = true);
        } else {
            this.errorToast(res.return.message);
        }

    }

    public openPayload(payload: Payload): void {
        payload.isOpen = !payload.isOpen;

        this.payloads.forEach(currentPayload => {
            if (currentPayload.id !== payload.id) {
                currentPayload.isOpen = false;
            }
        });
    }

    public moves(el, source, handle, sibling) {
        if (el.parentElement.className.indexOf('not-drop') > -1 ||
            el.parentElement.className.indexOf('drag-drop-item') > -1) {
            return false;
        }
        return true;
    }

    public accepts(el, target, source, sibling) {
        if (sibling && sibling.className.indexOf('not-drop') > -1 || sibling && sibling.className.indexOf('drag-drop-item') > -1) {
            return false;
        }
        return true;
    }

    public removeItemAssociation(payload, indexItem, firstDiv, secondDiv): void {
        firstDiv.classList.remove('hidden');
        secondDiv.classList.add('hidden');
        payload.itens[indexItem].paramFormAssociation = undefined;
    }

    public overAssociationItem = (value): void => {
        value.forEach(currentValue => {
            if (currentValue && currentValue.className) {
                if (currentValue.className.indexOf('parameter-association not-drop') > -1) {
                    if (currentValue.parentElement.children && currentValue.parentElement.children.length > 0) {
                        for (let index = 0; index < currentValue.parentElement.children.length; index++) {
                            const element = currentValue.parentElement.children[index];
                            if (element.className.indexOf('parameter-association not-drop') > -1 &&
                                element.className.indexOf('drag-drop-item') === -1) {
                                element.classList.add('hidden');
                            } else if (element.className.indexOf('drag-drop-item') > -1) {
                                element.classList.remove('hidden');
                            }
                        }
                    }
                }
            }
        });
    }

    public outAssociationItem = (value): void => {
        value.forEach(currentValue => {
            if (currentValue && currentValue.className) {
                if (currentValue.className.indexOf('parameter-association not-drop') > -1 && this.tempParamAssociation) {
                    if (currentValue.parentElement.children && currentValue.parentElement.children.length > 0) {
                        for (let index = 0; index < currentValue.parentElement.children.length; index++) {
                            const element = currentValue.parentElement.children[index];
                            const ids = element.parentElement.id.split(' ');
                            if (this.payloads &&
                                this.payloads[ids[0]].itens &&
                                !this.payloads[ids[0]].itens[ids[1]].paramFormAssociation) {
                                if (element.className.indexOf('parameter-association not-drop') > -1 &&
                                    element.className.indexOf('drag-drop-item') === -1) {
                                    element.classList.remove('hidden');
                                } else if (element.className.indexOf('drag-drop-item') > -1) {
                                    element.classList.add('hidden');
                                }
                            }
                        }
                    }
                } else if (currentValue.className.indexOf('gu-transit') > -1) {
                    const name = currentValue.children[2].innerHTML;
                    const id = +value[1].children[2].id;
                    this.tempParamAssociation = { id: id, name: name };
                }
            }
        });
    }

    public dropAssociation = (value): void => {
        value.forEach(currentValue => {
            if (currentValue && currentValue.className) {
                if (currentValue.className.indexOf('parameter-association not-drop') > -1 && this.tempParamAssociation) {
                    const ids = currentValue.parentElement.id.split(' ');
                    this.payloads[ids[0]].itens[ids[1]].paramFormAssociation = this.tempParamAssociation;
                    delete this.tempParamAssociation;
                }
            }
        });
    }

    public isOkay(payload: Payload): boolean {
        const isOkay = true;

        if (this.oldPayloads) {
            const equalPayload = this.oldPayloads.filter(p => p.id === payload.id)[0];

            if (equalPayload) {
                return JSON.stringify(equalPayload.itens) === JSON.stringify(payload.itens);
            }
        }

        return isOkay;

    }

    public isFilled(payload: Payload): boolean {
        let isFilled = true;

        if (payload.isSaved) {
            return payload.isSaved;
        }

        if (payload.itens && payload.itens.length > 0) {

            for (let index = 0; index < payload.itens.length; index++) {
                const item = payload.itens[index];
                if (!item.paramFormAssociation || item.paramFormAssociation === null) {
                    isFilled = false;
                    break;
                }
            }

        } else {
            isFilled = false;
        }

        return isFilled;
    }

    public save(payload: Payload): void {

        this.dialogRef = this.genericDialog.loadingMessage('Salvando associação de Payload...');

        const itensAssociations: IItemAssociation[] = [];

        for (let index = 0; index < payload.itens.length; index++) {
            if (payload.itens[index].paramFormAssociation) {
                itensAssociations.push({
                    payloadId: payload.id,
                    payloadItemId: payload.itens[index].id,
                    formParamId: payload.itens[index].paramFormAssociation.id
                });
            }
        }

        this.payloadService.createAssociations(itensAssociations, this.model.id).subscribe(resp => {

            if (resp.return.code === 0) {
                payload.isSaved = false;
                this.getPayloadFormItens(this.model.id, payload.id);
                this.successToast(resp.return.message);
            } else {
                this.errorToast(resp.return.message);
            }

            this.dialogRef.close();

        }, err => {
            this.errorToast(err.message);
            this.dialogRef.close();
        });

    }

    public async getPayloadFormItens(formId: number, payloadId?: number): Promise<void> {

        const resp = await this.payloadService.getPayloadFormItens(formId, payloadId);

        if (resp.return.code !== 0) {
            this.errorToast(resp.return.message);
        } else {

            for (let index = 0; index < resp.data.length; index++) {
                const itemReturn = resp.data[index];

                const payload = this.payloads.filter(p => p.id === itemReturn.payloadId)[0];

                if (payload) {

                    if (!payload.isSaved) {
                        await this.getPayloadItens(payload);
                        payload.isSaved = true;
                    }

                    const paramFormAssociation = { id: itemReturn.paramId, name: itemReturn.nameParam };

                    const item = payload.itens.filter(i => i.id === itemReturn.payloadItemId)[0];

                    item.paramFormAssociation = paramFormAssociation;
                    item.isEditable = false;

                }

            }

            this.oldPayloads = JSON.parse(JSON.stringify(this.payloads));
        }
    }

    public isModify(): boolean {

        if (this.payloads && this.payloads.length > 0) {
            for (const payload of this.payloads) {
                if (payload.itens) {
                    const countFill = payload.itens.filter(i => i.paramFormAssociation !== undefined);
                    if (countFill && countFill.length > 0 &&
                        payload.itens.length > 0 && countFill.length !== payload.itens.length
                        && !payload.isSaved) {
                        return false;
                    } else if (countFill && countFill.length > 0 && payload.itens.length > 0 && countFill.length === payload.itens.length) {
                        if (!this.isOkay(payload)) {
                            return false;
                        }
                    }
                }
            }
        }

        return true;
    }
}
