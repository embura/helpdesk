
// import { Routes, RouterModule } from '@angular/router';
// import { NgModule } from '@angular/core';
// import { SearchComponent } from './search/search.component';
// import { RegistarComponent } from './registar/registar.component';
// import { CatalogComponent } from './catalog.component';

// const routes: Routes = [
//   {
//     path: 'catalog', component: CatalogComponent,
//     children: [
//       { path: 'search', component: SearchComponent, outlet: 'cptChild' },
//       { path: 'register', component: RegistarComponent, outlet: 'cptChild' },
//     ],
//   }
// ];

// @NgModule({
//   imports: [RouterModule.forChild(routes)],
//   exports: [RouterModule]
// })
// export class CatalogRouterModule { }
