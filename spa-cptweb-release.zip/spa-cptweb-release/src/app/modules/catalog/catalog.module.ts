import { NgModule, ModuleWithProviders } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CatalogComponent } from './catalog.component';
// import { CatalogRouterModule } from './catalog.router';
import { SearchComponent } from './components/search/search.component';
import { RegisterComponent } from './components/register/register.component';
import { FamilyCategoryComponent } from './components/category/family/family-category.component';
import { CategoryComponent } from './components/category/category.component';
import { AccordionComponent } from './components/accordion/accordion.component';
import { GroupCategoryComponent } from './components/category/group/group-category.component';
import { GroupDialogComponent } from './components/category/group/dialogs/group-dialog.component';
import { FamilyCategoryDialogComponent } from './components/category/family/dialog/family-category-dialog.component';
import { DialogHeaderComponent } from './components/dialog-header/dialog-header.component';
import { CatalogSharedModule } from './catalog-shared.module';
import { AssetClassCategoryComponent } from './components/category/asset-class/asset-class-category.component';
import { AssetClassCategoryDialogComponent } from './components/category/asset-class/dialog/asset-class-category-dialog.component';
import { ModalityCategoryComponent } from './components/category/modality/modality-category.component';
import { ModalityCategoryDialogComponent } from './components/category/modality/dialog/modality-category-dialog.component';
import { UnderlyingCategoryComponent } from './components/category/underlying/underlying-category.component';
import { UnderlyingCategoryDialogComponent } from './components/category/underlying/dialog/underlying-category-dialog.component';
import { GroupService } from './services/category/group/group.service';
import { FamilyService } from './services/category/family/family.service';
import { GenericDialogComponent } from './components/dialogs/generic/generic-dialog.component';
import { AssetClassService } from './services/category/asset-class/asset-class.service';
import { ModalityService } from './services/category/modality/modality.service';
import { UnderlyingService } from './services/category/underlying/underlying.service';
import { UtilService } from './services/util/util.service';
import { OrderAccordionPipe } from './pipes/order-accordion.pipe';
import { FilterComponent } from './components/filter/filter.component';
import { ParameterComponent } from './components/parameter/parameter.component';
import { ParameterDialogComponent } from './components/parameter/dialogs/create/parameter-dialog.component';
import { EditParameterDialogComponent } from './components/parameter/dialogs/edit/edit-parameter-dialog.component';
import { ParameterService } from './services/parameter/parameter.service';
import { ParameterTypeService } from './services/parameter/parameter-type/parameter-type.service';
import { ValidationTypeService } from './services/parameter/validation-type/validation-type.service';
import { OptionService } from './services/parameter/option/option.service';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { SegmentComponent } from './components/segment/segment.component';
import { FormComponent } from './components/form/form.component';
import { FormItemComponent } from './components/form/form-item/form-item.component';
import { SegmentService } from './services/segment/segment.service';
import { DeleteDialogComponent } from './components/dialogs/delete/delete-dialog.component';
import { MAT_DIALOG_DEFAULT_OPTIONS, MAT_DATE_LOCALE, MatDatepickerModule, MatNativeDateModule } from '@angular/material';
import { HistoricDialogComponent } from './components/historic/historic-dialog.component';
import { DateRangePickerComponent } from './components/date-range-picker/date-range-picker.component';
import { Daterangepicker } from 'ng2-daterangepicker';
import { HistoricGridComponent } from './components/historic/historic-grid/historic-grid.component';
import { MomentDatePipe } from './pipes/moment-date/moment-date.pipe';
import { TextMaskModule } from 'angular2-text-mask';
import { AuditService } from './services/audit/audit.service';
import { EventsChannelsComponent } from './components/events-channels/events-channels.component';
import { EventsComponent } from './components/events-channels/events/events.component';
import { ChannelsComponent } from './components/events-channels/channels/channels.component';
import { EventsDialogComponent } from './components/events-channels/events/events-category-dialog.component.ts/events-dialog.component';
import { ChannelsDialogComponent } from './components/events-channels/channels/channels-dialog.component/channels-dialog.component';
import { EventService } from './services/events-channels/event/event.service';
import { ChannelService } from './services/events-channels/channel/channel.service';
import { DragulaModule } from 'ng2-dragula';
import { FormDialogComponent } from './components/form/dialogs/form-dialog.component';
import { FormService } from './services/form/form.service';
import { ProductDialogComponent } from './components/product/product-dialog.component';
import { ProductCategoriesComponent } from './components/product/categories/product-categories.component';
import { ProductFormComponent } from './components/product/form/product-form.component';
import { GroupsComponent } from './components/product/assign-groups/groups/groups.component';
import { AssignGroupsComponent } from './components/product/assign-groups/assign-groups.component';
import { SegmentListComponent } from './components/product/assign-groups/list-segments/segment-list.component';
import { GroupSegmentService } from './services/group-segment/group-segment.service';
import { GroupSegmentRelationsService } from './services/group-segment-relations/group-segment-relations.service';
import { EventChanGrSegRelationsService } from './services/event-channel-gr-seg-relat/event-channel-gr-seg-relat.service';
import { ProductService } from './services/product/product.service';
import { PNEAppIndex } from './components/pne/pne-app.index';
import { PNETabComponent } from './components/pne/components/pne-tab/pne-tab.component';
import { AddGroupSpreadComponent } from './components/pne/components/add-group-spread/add-group-spread.component';
import { GroupSpreadService } from './components/pne/services/group-spread/group-spread.service';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { AssociationComponent } from './components/association-payload/association-payload.component';
import { AssociationFormComponent } from './components/association-payload/association-payload-form/association-payload-form.component';
import {
  AssociationPayloadRegisterComponent
} from './components/association-payload/association-payload-register/association-payload-register.component';
import {
  PayloadCreateDialogComponent
} from './components/association-payload/association-payload-register/dialog/create/payload-create-dialog.component';
import {
  PayloadEditDialogComponent
} from './components/association-payload/association-payload-register/dialog/edit/payload-edit-dialog.component';
import { PayloadService } from './services/payload/payload.service';
import { PayloadItemService } from './services/payload-item/payload-item.service';
import { CustomWarningToastComponent } from './components/toast/custom-warning-toast.component';
import { CustomErrorToastComponent } from './components/toast/custom-error-toast.component';
import { CustomSuccessToastComponent } from './components/toast/custom-success-toast.component';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';

@NgModule({
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CatalogSharedModule,
    InfiniteScrollModule,
    DragulaModule,
    Daterangepicker,
    TextMaskModule,
    MatCardModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatNativeDateModule,
  ],
  declarations: [
    ...PNEAppIndex,
    CatalogComponent,
    SearchComponent,
    RegisterComponent,
    FamilyCategoryComponent,
    GroupCategoryComponent,
    CategoryComponent,
    EventsChannelsComponent,
    EventsComponent,
    ChannelsComponent,
    AccordionComponent,
    GroupDialogComponent,
    FamilyCategoryDialogComponent,
    EventsDialogComponent,
    ChannelsDialogComponent,
    DialogHeaderComponent,
    AssetClassCategoryComponent,
    AssetClassCategoryDialogComponent,
    ModalityCategoryComponent,
    ModalityCategoryDialogComponent,
    UnderlyingCategoryComponent,
    UnderlyingCategoryDialogComponent,
    GenericDialogComponent,
    OrderAccordionPipe,
    HistoricDialogComponent,
    FilterComponent,
    ParameterComponent,
    ParameterDialogComponent,
    EditParameterDialogComponent,
    DeleteDialogComponent,
    DateRangePickerComponent,
    HistoricGridComponent,
    MomentDatePipe,
    SegmentComponent,
    DeleteDialogComponent,
    FormComponent,
    FormItemComponent,
    FormDialogComponent,
    ProductDialogComponent,
    ProductCategoriesComponent,
    ProductFormComponent,
    GroupsComponent,
    AssignGroupsComponent,
    SegmentListComponent,
    AssociationComponent,
    AssociationFormComponent,
    AssociationPayloadRegisterComponent,
    PayloadCreateDialogComponent,
    PayloadEditDialogComponent,
    CustomWarningToastComponent,
    CustomErrorToastComponent,
    CustomSuccessToastComponent,
  ],
  exports: [
    CatalogComponent,
    PNETabComponent,
  ],
  entryComponents: [
    AddGroupSpreadComponent,
    FamilyCategoryDialogComponent,
    GroupDialogComponent,
    AssetClassCategoryDialogComponent,
    ModalityCategoryDialogComponent,
    UnderlyingCategoryDialogComponent,
    EventsDialogComponent,
    ChannelsDialogComponent,
    GenericDialogComponent,
    HistoricDialogComponent,
    ParameterDialogComponent,
    EditParameterDialogComponent,
    DeleteDialogComponent,
    FormDialogComponent,
    ProductDialogComponent,
    PayloadCreateDialogComponent,
    PayloadEditDialogComponent,
    CustomWarningToastComponent,
    CustomErrorToastComponent,
    CustomSuccessToastComponent,
  ],
  providers: [
    AssetClassService,
    GroupService,
    FamilyService,
    EventService,
    ChannelService,
    ModalityService,
    UnderlyingService,
    UtilService,
    ParameterService,
    ParameterTypeService,
    ValidationTypeService,
    OptionService,
    AuditService,
    SegmentService,
    FormService,
    GroupSegmentService,
    GroupSegmentRelationsService,
    EventChanGrSegRelationsService,
    ProductService,
    GroupSpreadService,
    PayloadService,
    PayloadItemService,
    { provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { disableClose: true, hasBackdrop: true } },
    { provide: MAT_DATE_LOCALE, useValue: 'pt-BR' },
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } },
  ],
})

export class CatalogModule {
  static forRoot(hubHost: string, appKey: string): ModuleWithProviders {
    return {
      ngModule: CatalogModule,
      providers: [
        { provide: 'hubHost', useValue: hubHost },
        { provide: 'appKey', useValue: appKey }
      ]
    };
  }
}
