import { ChannelService } from './channel.service';
import { Observable } from 'rxjs/Observable';
import { IQuery, UtilService } from '../../util/util.service';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { TestBed } from '@angular/core/testing';
import { Channels } from '../../../components/events-channels/channels/channels';

//#region Data
const channelOne: Channels = {
    id: 1,
    name: 'Channel 1',
    nameTec: 'Channel 1',
    statusId: 10
};

const channelTwo: Channels = {
    id: 2,
    name: 'Channel 2',
    nameTec: 'Channel 2',
    statusId: 10
};
//#endregion

const MockHubConnector = {
    getJson: (url: string): Observable<any> => {
        return Observable.of({
            data: [channelOne, channelTwo]
        });
    },
    postJson: (url: string, item?: any): Observable<any> => {
        return Observable.of({
            data: channelOne
        });
    },
    putJson: (url: string, item?: any): Observable<any> => {
        return Observable.of({
            data: channelOne
        });
    }
};

const MockUtilService = {
    getUrlQuery: (url: string, obj: IQuery): string => {
        return '';
    },
    getHubUrl: () => 'mock'
};

describe('ChannelService', () => {
    let service: ChannelService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                ChannelService,
                { provide: HubConnectorComponent, useValue: MockHubConnector },
                { provide: UtilService, useValue: MockUtilService },
                { provide: 'appKey', useValue: 'mockAPPKEY' },
                { provide: 'hubHost', useValue: 'mockHUBHOST' }
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        service = TestBed.get(ChannelService);
    });

    it('Should create', () => {
        expect(service).toBeTruthy();
    });

    it('should get all channels', async () => {
        const channels = await service.getAllChannels().toPromise();

        expect(channels.data.length).toBe(2);
    });

    it('should create channel', async () => {
        const channel = await service.addChannel(channelOne).toPromise();

        expect(channel.data).toBeTruthy();
    });

    it('should edit channel', async () => {
        const channel = await service.editChannel(channelOne).toPromise();

        expect(channel.data).toBeTruthy();
    });
});
