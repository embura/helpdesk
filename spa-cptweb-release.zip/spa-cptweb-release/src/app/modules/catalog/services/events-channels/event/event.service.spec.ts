import { Observable } from 'rxjs/Observable';
import { IQuery, UtilService } from '../../util/util.service';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { TestBed } from '@angular/core/testing';
import { Events } from '../../../components/events-channels/events/events';
import { EventService } from './event.service';

//#region Data
const eventOne: Events = {
    id: 1,
    name: 'Event 1',
    nameTec: 'Event 1',
    statusId: 10
};

const eventTwo: Events = {
    id: 2,
    name: 'Event 2',
    nameTec: 'Event 2',
    statusId: 10
};
//#endregion

const MockHubConnector = {
    getJson: (url: string): Observable<any> => {
        return Observable.of({
            data: [eventOne, eventTwo]
        });
    },
    postJson: (url: string, item?: any): Observable<any> => {
        return Observable.of({
            data: eventOne
        });
    },
    putJson: (url: string, item?: any): Observable<any> => {
        return Observable.of({
            data: eventOne
        });
    }
};

const MockUtilService = {
    getUrlQuery: (url: string, obj: IQuery): string => {
        return '';
    },
    getHubUrl: () => 'mock'
};

describe('EventService', () => {
    let service: EventService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                EventService,
                { provide: HubConnectorComponent, useValue: MockHubConnector },
                { provide: UtilService, useValue: MockUtilService },
                { provide: 'appKey', useValue: 'mockAPPKEY' },
                { provide: 'hubHost', useValue: 'mockHUBHOST' }
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        service = TestBed.get(EventService);
    });

    it('Should create', () => {
        expect(service).toBeTruthy();
    });

    it('should get all channels', async () => {
        const channels = await service.getAllEvents().toPromise();

        expect(channels.data.length).toBe(2);
    });

    it('should create channel', async () => {
        const channel = await service.addEvent(eventOne).toPromise();

        expect(channel.data).toBeTruthy();
    });

    it('should edit channel', async () => {
        const channel = await service.editEvents(eventOne).toPromise();

        expect(channel.data).toBeTruthy();
    });
});
