import { Injectable } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Observable';
import { IResponse } from '../../../models/response/response.interface';
import { UtilService } from '../../util/util.service';
import {IEventsChannels} from '../../../models/events-channels/events-channels.interface';
import {Events} from '../../../components/events-channels/events/events';
import {EventsChannelsDto} from '../../../models/events-channels/events-channels.dto';
import { ObservableRetryHandler } from '../../../shared/lib/observable-retry/observable-retry.handler';



@Injectable()
export class EventService {
  public static readonly serviceHost = '/treasury-product-catalog/v1/event';

  constructor(private hubConnector: HubConnectorComponent, private utilService: UtilService) { }

  public getAllEvents(): Observable<IResponse<IEventsChannels[]>> {
    const url: string = this.utilService.getHubUrl(EventService.serviceHost);
    return this.hubConnector.getJson(url)
      .retryWhen(ObservableRetryHandler)
      .catch((err) => {
        return Observable.of({
          return: {
            code: '0',
            message: err.message,
          },
          data: []
        });
      });
  }

  public addEvent(event: Events): Observable<IResponse<IEventsChannels>> {
    const url: string = this.utilService.getHubUrl(EventService.serviceHost);
    return this.hubConnector.postJson(url, event);
  }

  public editEvents(event: Events): Observable<IResponse<IEventsChannels>> {
    const url: string = this.utilService.getHubUrl(EventService.serviceHost);
    return this.hubConnector.putJson(url, event);
  }

}
