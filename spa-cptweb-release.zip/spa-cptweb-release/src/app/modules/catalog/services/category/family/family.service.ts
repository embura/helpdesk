import { Injectable } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Family } from '../../../components/category/family/family';
import { Observable } from 'rxjs/Observable';
import { IResponse } from '../../../models/response/response.interface';
import { ICategory } from '../../../models/category/category.interface';
import { CategoryDTO } from '../../../models/category/category.dto';
import { UtilService, IQuery } from '../../util/util.service';
import { ObservableRetryHandler } from '../../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class FamilyService {
  public static readonly serviceHost = '/treasury-product-catalog/v1/category/family';

  constructor(private hubConnector: HubConnectorComponent, private utilService: UtilService) { }

  public getFamily(code: number): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(FamilyService.serviceHost, code);
    return this.hubConnector.getJson(url)
      .retryWhen(ObservableRetryHandler);
  }

  public getAllFamilies(statusId?: number): Observable<IResponse<ICategory[]>> {
    const query: IQuery = {
      statusId: statusId
    };

    const url: string = statusId ? this.utilService.getUrlQuery(FamilyService.serviceHost, query) :
      this.utilService.getHubUrl(FamilyService.serviceHost);

    return this.hubConnector.getJson(url)
      .retryWhen(ObservableRetryHandler)
      .catch((err) => {
        return Observable.of({
          return: {
            code: '1',
            message: err.message,
          },
          data: []
        });
      });
  }

  public addFamiliy(family: Family): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(FamilyService.serviceHost);
    return this.hubConnector.postJson(url, new CategoryDTO(family.code, family.name, family.statusId));
  }

  public editFamily(family: Family): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(FamilyService.serviceHost);
    return this.hubConnector.putJson(url, new CategoryDTO(family.code, family.name, family.statusId));
  }
}
