import { TestBed, async } from '@angular/core/testing';
import { ModalityService } from './modality.service';
import { Observable } from 'rxjs/Rx';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Modality } from '../../../components/category/modality/modality';
import { UtilService } from '../../util/util.service';

const MockHubConnector = {
  getJson: (url: string): Observable<any> => {
    return Observable.of({
      data: []
    });
  },
  postJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: 'mock'
    });
  },
  putJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: 'mock'
    });
  }
};

describe('Modality service', () => {
  let service: ModalityService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ModalityService,
        { provide: UtilService, useValue: {getHubUrl: () => 'mock'} },
        { provide: HubConnectorComponent, useValue: MockHubConnector }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    service = TestBed.get(ModalityService);
  });

  it('should be a instance of modalityService', () => {
    expect(service).toBeTruthy();
  });

  it('Should call all services of ModalityService', () => {
    expect(() => {
      const modality = new Modality('mock');
      service.getModality(5);
      service.addModality(modality);
      service.editModality(modality);
    }).not.toThrow();
  });

  it('Should get All modalities', async(() => {
    service['hubConnector'].getJson = () => Observable.throw({ message: 'Mock error' });

    service.getAllModalities().subscribe(response => {
      expect(response.data.length).toBe(0);
      expect(response.return.message).toContain('Mock error');
    });

  }));
});
