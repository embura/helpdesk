import { Observable } from 'rxjs/Observable';
import { UnderlyingService } from './underlying.service';
import { async, TestBed } from '@angular/core/testing';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Underlying } from '../../../components/category/underlying/underlying';
import { UtilService } from '../../util/util.service';

// tslint:disable-next-line:snt-file-name-suffix
const mockedResponse = {
  return: {
    code: 0,
    message: 'Mock'
  },
  data: {
    id: '5',
    name: 'mockedUnderlying',
    shortName: 'mockedUnderlying'
  }
};

const MockHubConnector = {
  getJson: (url: string): Observable<any> => {
    return Observable.of({
      data: [mockedResponse]
    });
  },
  postJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: mockedResponse
    });
  },
  putJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: mockedResponse
    });
  }
};

describe('UnderlyingService', () => {

  let service: UnderlyingService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        UnderlyingService,
        { provide: UtilService, useValue: {getHubUrl: () => 'mock'} },
        { provide: HubConnectorComponent, useValue: MockHubConnector }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    service = TestBed.get(UnderlyingService);
  });

  it('Should create UnderlyingService', () => {
    expect(service).toBeTruthy();
  });

  it('Should get all underlyings', () => {
    let underlyings;
    service.getAllUnderlyings().subscribe(response => {
      underlyings = response.data;
    });
    expect(underlyings.length).toBe(1);
  });

  it('Should have error when get all Underlyings', () => {
    let underlying;

    service['hubConnector'].getJson = () => Observable.throw({ data: [] });

    service.getAllUnderlyings().subscribe(response => {
      underlying = response.data;

      expect(underlying.length).toBe(0);
    });
  });

  it('Should get a Underlying', async(() => {
    let underlying;

    service.getUnderlying(5).subscribe(response => {
      underlying = response.data[0];

      expect(underlying.return.code).toBe(0);
      expect(underlying.data.name).toBe('mockedUnderlying');
    });
  }));

  it('should add an Underlying', () => {
    const underlying = new Underlying('underlying');

    service.addUnderlying(underlying).subscribe(resp => {
      expect(resp).toBeTruthy();
    });
  });

  it('should alter an underlying', () => {
    const underlying = new Underlying('underlying');

    service.editUnderlying(underlying).subscribe(resp => {
      expect(resp).toBeTruthy();
    });
  });

});
