import { Injectable } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Observable';
import { AssetClass } from '../../../components/category/asset-class/asset-class';
import { ICategory } from '../../../models/category/category.interface';
import { IResponse } from '../../../models/response/response.interface';
import { CategoryDTO } from '../../../models/category/category.dto';
import { UtilService, IQuery } from '../../util/util.service';
import { RetryPromise } from '../../../shared/lib/decorator/retry/retry.decorator';
import { ErrorStateMatcher } from '@angular/material';
import { ObservableRetryHandler } from '../../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class AssetClassService {
  public static readonly path = '/treasury-product-catalog/v1/category/asset-class';

  constructor(private hubConn: HubConnectorComponent, private utilService: UtilService) { }

  // @RetryPromise()
  public getAssetClass(code: number): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(AssetClassService.path, code);
    return this.hubConn.getJson(url)
      .retryWhen(ObservableRetryHandler);
  }

  public getAllAssetClasses(statusId?: number): Observable<IResponse<Array<ICategory>>> {
    const query: IQuery = {
      statusId: statusId
    };

    const url: string = statusId ? this.utilService.getUrlQuery(AssetClassService.path, query) :
      this.utilService.getHubUrl(AssetClassService.path);

    return this.hubConn.getJson(url)
    .retryWhen(ObservableRetryHandler)
    .catch(err => {
      return Observable.of({
        return: {
          code: 0,
          message: 'Assets Classes consultados com sucesso'
        },
        data: []
      });
    });
  }

  public editAssetClass(assetClass: AssetClass): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(AssetClassService.path);
    const editedAssetClass = new CategoryDTO(assetClass.id, assetClass.name, assetClass.statusId);
    return this.hubConn.putJson(url, editedAssetClass);
  }

  public createAssetClass(assetClass: AssetClass): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(AssetClassService.path);
    const newAssetClass = new CategoryDTO(assetClass.id, assetClass.name, assetClass.statusId);
    return this.hubConn.postJson(url, newAssetClass);
  }
}
