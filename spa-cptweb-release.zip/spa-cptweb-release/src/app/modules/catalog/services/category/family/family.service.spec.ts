// tslint:disable-next-line:snt-file-name-suffix
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { FamilyService } from './family.service';
import { Observable } from 'rxjs/Rx';
import { Group } from '../../../components/category/group/group';
import { Family } from '../../../components/category/family/family';
import { UtilService } from '../../util/util.service';

const mockedResponse = {
  return: {
    code: 0,
    message: 'Mock'
  },
  data: {
    id: '5',
    name: 'mockedFamily',
    shortName: 'mockedFamily'
  }
};

const MockHubConnector = {
  getJson: (url: string): Observable<any> =>  {
    return Observable.of({
      data: [mockedResponse]
    });
  },
  postJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: mockedResponse
    });
  },
  putJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: mockedResponse
    });
  }
};

describe('Family service', () => {

  let service: FamilyService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        FamilyService,
        { provide: UtilService, useValue: {getHubUrl: () => 'mock'} },
        { provide: HubConnectorComponent, useValue: MockHubConnector }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    service = TestBed.get(FamilyService);
  });

  it('Should create Family Service', () => {
    expect(service).toBeTruthy();
  });

  it('Should get all FAmilies', () => {
    let families;
    // service['hubConn'].getJson = () => Observable.throw({data: []});
    service.getAllFamilies().subscribe(response => {
      families = response.data;
    });
    expect(families.length).toBe(1);
  });

  it('Should have error when get all Families', () => {
    let families;
    const oldGetJson = MockHubConnector.getJson;
    service['hubConnector'].getJson = () => Observable.throw({data: []});
    service.getAllFamilies().subscribe(response => {
      families = response.data;

      expect(families.length).toBe(0);
    });
  });

  it('Should get a Family', () => {
    let family;
    service.getFamily(5).subscribe(response => {
      family = response.data[0];
    });
    expect(family.return.code).toBe(0);
    expect(family.data.name).toBe('mockedFamily');
  });

  it('should add an family', () => {
    const family = new Family('family');
    service.addFamiliy(family).subscribe(resp => {
      expect(resp).toBeTruthy();
    });
  });

  it('should alter an family', () => {
    const family = new Family('family');
    service.editFamily(family).subscribe(resp => {
      expect(resp).toBeTruthy();
    });
  });

});
