// tslint:disable-next-line:snt-file-name-suffix
import { TestBed, ComponentFixture, async } from '@angular/core/testing';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Rx';
import { AssetClassService } from './asset-class.service';
import { AssetClass } from '../../../components/category/asset-class/asset-class';
import { UtilService } from '../../util/util.service';

const mockedResponse = {
  return: {
    code: 0,
    message: 'Mock'
  },
  data: {
    id: '5',
    name: 'mockedAssetClass',
    shortName: 'mockedAssetClass'
  }
};

const MockHubConnector = {
  getJson: (url: string): Observable<any> => {
    return Observable.of({
      data: [mockedResponse]
    });
  },
  postJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: mockedResponse
    });
  },
  putJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: mockedResponse
    });
  }
};

describe('Asset Class service', () => {

  let service: AssetClassService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AssetClassService,
        { provide: UtilService, useValue: {getHubUrl: () => 'mock'} },
        { provide: HubConnectorComponent, useValue: MockHubConnector }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    service = TestBed.get(AssetClassService);
  });

  it('Should create Asset Class Service', () => {
    expect(service).toBeTruthy();
  });

  it('Should get all asset classes', async(() => {
    let assetClasses;
    service.getAllAssetClasses().subscribe(response => {
      assetClasses = response.data;
      expect(assetClasses.length).toBe(1);
    });
  }));

  it('Should have error when get all Asset Classes', async(() => {
    let assetClasses;
    const oldGetJson = MockHubConnector.getJson;
    service['hubConn'].getJson = () => Observable.throw({ data: [] });
    service.getAllAssetClasses().subscribe(response => {
      assetClasses = response.data;

      expect(assetClasses.length).toBe(0);
    });
  }));

  it('Should get a Asset Class', async(() => {
    let family;
    service.getAssetClass(5).subscribe(response => {
      family = response.data[0];

      expect(family.return.code).toBe(0);
      expect(family.data.name).toBe('mockedAssetClass');
    });
  }));

  it('should add an asset class', async(() => {
    const assetClass = new AssetClass('assetClass');
    service.createAssetClass(assetClass).subscribe(resp => {
      expect(resp).toBeTruthy();
    });
  }));

  it('should alter an asset Class', async(() => {
    const assetClass = new AssetClass('assetClass');
    service.editAssetClass(assetClass).subscribe(resp => {
      expect(resp).toBeTruthy();
    });
  }));

});
