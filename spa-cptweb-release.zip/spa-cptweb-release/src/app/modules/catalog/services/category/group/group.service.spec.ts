// tslint:disable-next-line:snt-file-name-suffix
import { TestBed,  ComponentFixture } from '@angular/core/testing';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { GroupService } from './group.service';
import { Observable } from 'rxjs/Rx';
import { Group } from '../../../components/category/group/group';
import { Family } from '../../../components/category/family/family';
import { UtilService } from '../../util/util.service';

const mockedGroup = {
  code: '5',
  name: 'mockedGroup'
};

const MockHubConnector = {
  getJson: (url: string): Observable<any> =>  {
    return Observable.of({
      data: [mockedGroup]
    });
  },
  postJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: 'mock'
    });
  },
  putJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: 'mock'
    });
  }
};

describe('GroupService', () => {

  let service: GroupService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        GroupService,
        { provide: UtilService, useValue: {getHubUrl: () => 'mock', getUrlQuery: () => 'mock' } },
        { provide: HubConnectorComponent, useValue: MockHubConnector },
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    service = TestBed.get(GroupService);
  });

  it('Should create Group Service', () => {
    expect(service).toBeTruthy();
  });

  it('Should get all Groups', () => {
    let allGroups;
    service['hubConn'].getJson = () => Observable.throw({data: []});
    service.getAllGroups().subscribe(response => {
      allGroups = response.data;
    });
    expect(allGroups.length).toBe(0);
  });

  it('Should get a Group', () => {
    let group;
    service.getGroup('5').subscribe(response => {
      group = response.data[0];
    });
    expect(group.code).toBe('5');
    expect(group.name).toBe('mockedGroup');
  });

  it('should get Group By Family', () => {
    let groups;
    service.getGroupsByFamily(2).subscribe(resp => {
      groups = resp;
    });
    expect(groups).toBeTruthy();
  });

  it('should add an group', () => {
    const group = new Group();
    const family = new Family('family');
    service.addGroup(group, family).subscribe(resp => {
      expect(resp).toBeTruthy();
    });
  });

  it('should alter an group', () => {
    const group = new Group();
    group.family = new Family('', 0);
    service.alterGroup(group).subscribe(resp => {
      expect(resp).toBeTruthy();
    });
  });

});
