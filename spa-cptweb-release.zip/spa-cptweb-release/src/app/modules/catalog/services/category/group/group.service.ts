import { Injectable } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Rx';
import { Family } from '../../../components/category/family/family';
import { Group } from '../../../components/category/group/group';
import { IResponse } from '../../../models/response/response.interface';
import { IGroup } from '../../../models/category/category.interface';
import { GroupDTO } from '../../../models/category/category.dto';
import { UtilService, IQuery } from '../../util/util.service';
import { ObservableRetryHandler } from '../../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class GroupService {

  public static readonly path = '/treasury-product-catalog/v1/category/group';

  constructor(private hubConn: HubConnectorComponent, private utilService: UtilService) { }

  public getGroup(groupId: string): Observable<IResponse<IGroup>> {
    const url: string = this.utilService.getHubUrl(GroupService.path, groupId);
    return this.hubConn.getJson(url)
    .retryWhen(ObservableRetryHandler);
  }

  public getGroupsByFamily(familyId: number, statusId?: number): Observable<IResponse<IGroup[]>> {
    const query: IQuery = {
      familyId: familyId,
      statusId: statusId
    };

    if (statusId === undefined) {
      delete query['statusId'];
    }

    const url: string = this.utilService.getUrlQuery(GroupService.path, query);
    return this.hubConn.getJson(url)
    .retryWhen(ObservableRetryHandler);
  }

  public getAllGroups(): Observable<IResponse<Array<IGroup>>> {
    const url: string = this.utilService.getHubUrl(GroupService.path);
    return this.hubConn.getJson(url)
    .retryWhen(ObservableRetryHandler)
    .catch(err => Observable.of({
      return: {
        code: 1,
        message: err.message
      },
      data: []
    }));
  }

  public addGroup(group: Group, family: Family): Observable<IResponse<IGroup>> {
    const url: string = this.utilService.getHubUrl(GroupService.path);
    const newGroup = new GroupDTO(group.code, group.name, group.statusId, group.technicalName);
    newGroup.familyId = family.code;
    return this.hubConn.postJson(url, newGroup);
  }

  public alterGroup(updatedGroup: Group): Observable<IResponse<IGroup>> {
    const url: string = this.utilService.getHubUrl(GroupService.path);
    const groupObj = new GroupDTO(updatedGroup.code, updatedGroup.name, updatedGroup.statusId);
    groupObj.familyId = updatedGroup.family.code;
    return this.hubConn.putJson(url, groupObj);
  }

}
