import { Injectable } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../../models/response/response.interface';
import { ICategory } from '../../../models/category/category.interface';
import { Modality } from '../../../components/category/modality/modality';
import { CategoryDTO } from '../../../models/category/category.dto';
import { UtilService, IQuery } from '../../util/util.service';
import { ObservableRetryHandler } from '../../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class ModalityService {
  public static serviceHost = '/treasury-product-catalog/v1/category/modality';

  constructor(private hubConnector: HubConnectorComponent, private utilService: UtilService) { }

  public getModality(code: number): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(ModalityService.serviceHost, code);
    return this.hubConnector.getJson(url)
      .retryWhen(ObservableRetryHandler);
  }

  public getAllModalities(statusId?: number): Observable<IResponse<ICategory[]>> {
    const query: IQuery = {
      statusId: statusId
    };

    const url: string = statusId ? this.utilService.getUrlQuery(ModalityService.serviceHost, query) :
      this.utilService.getHubUrl(ModalityService.serviceHost);

    return this.hubConnector.getJson(url)
      .retryWhen(ObservableRetryHandler)
      .catch((err) => {
        return Observable.of({
          return: {
            code: 1,
            message: err.message,
          },
          data: []
        });
      });
  }

  public addModality(modality: Modality): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(ModalityService.serviceHost);
    return this.hubConnector.postJson(url, new CategoryDTO(modality.id, modality.name, modality.statusId));
  }

  public editModality(modality: Modality): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(ModalityService.serviceHost);
    return this.hubConnector.putJson(url, new CategoryDTO(modality.id, modality.name, modality.statusId));
  }
}
