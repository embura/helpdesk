import { Injectable } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Observable';
import { IResponse } from '../../../models/response/response.interface';
import { ICategory } from '../../../models/category/category.interface';
import { Underlying } from '../../../components/category/underlying/underlying';
import { CategoryDTO } from '../../../models/category/category.dto';
import { UtilService, IQuery } from '../../util/util.service';
import { ObservableRetryHandler } from '../../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class UnderlyingService {
  public static serviceHost = '/treasury-product-catalog/v1/category/underlying';

  constructor(private hubConnector: HubConnectorComponent, private utilService: UtilService) { }

  public getUnderlying(code: number): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(UnderlyingService.serviceHost, code);
    return this.hubConnector.getJson(url)
      .retryWhen(ObservableRetryHandler);
  }

  public getAllUnderlyings(statusId?: number): Observable<IResponse<ICategory[]>> {
    const query: IQuery = {
      statusId: statusId
    };

    const url: string = statusId ? this.utilService.getUrlQuery(UnderlyingService.serviceHost, query) :
      this.utilService.getHubUrl(UnderlyingService.serviceHost);

    return this.hubConnector.getJson(url)
      .retryWhen(ObservableRetryHandler)
      .catch((err) => {
        return Observable.of({
          return: {
            code: '1',
            message: err.message,
          },
          data: []
        });
      });
  }

  public addUnderlying(underlying: Underlying): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(UnderlyingService.serviceHost);
    return this.hubConnector.postJson(url, new CategoryDTO(underlying.id, underlying.name, underlying.statusId));
  }

  public editUnderlying(underlying: Underlying): Observable<IResponse<ICategory>> {
    const url: string = this.utilService.getHubUrl(UnderlyingService.serviceHost);
    return this.hubConnector.putJson(url, new CategoryDTO(underlying.id, underlying.name, underlying.statusId));
  }
}
