import { Injectable, Inject } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { UtilService, IQuery } from '../util/util.service';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../models/response/response.interface';
import { GroupSegmentRelations } from '../../models/product/group-segment-relations/group-segment-relations';
import { ObservableRetryHandler } from '../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class GroupSegmentRelationsService {
    public static serviceHost = '/treasury-product-catalog/v1/group-segment/relations';
    private ordenation: IQuery = {};

    constructor(
        private hubConnector: HubConnectorComponent,
        private utilService: UtilService
    ) { }

    public getGroupsSegmentsRelations(obj?: IQuery): Observable<IResponse<Array<GroupSegmentRelations>>> {
        this.ordenation = { ...obj };
        return this.hubConnector.getJson(this.utilService.getUrlQuery(GroupSegmentRelationsService.serviceHost, this.ordenation))
            .retryWhen(ObservableRetryHandler)
            .catch(err => Observable.of({ return: { code: 1, message: err.message }, data: [] }));
    }

    public getGroupSegmentRelationsByID(code: number): Observable<IResponse<GroupSegmentRelations>> {
        const url: string = this.utilService.getHubUrl(GroupSegmentRelationsService.serviceHost, code);
        return this.hubConnector.getJson(url)
            .retryWhen(ObservableRetryHandler);
    }

    public addGroupSegmentRelations(groupSegmentRelations: GroupSegmentRelations): Observable<IResponse<GroupSegmentRelations>> {
        const url: string = this.utilService.getHubUrl(GroupSegmentRelationsService.serviceHost);
        return this.hubConnector.postJson(url, groupSegmentRelations);
    }

    public editGroupSegmentRelations(groupSegmentRelations: GroupSegmentRelations): Observable<IResponse<GroupSegmentRelations>> {
        const url: string = this.utilService.getHubUrl(GroupSegmentRelationsService.serviceHost);
        return this.hubConnector.putJson(url, groupSegmentRelations);
    }

}
