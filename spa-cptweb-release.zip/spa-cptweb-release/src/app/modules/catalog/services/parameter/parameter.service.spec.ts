import { TestBed, async } from '@angular/core/testing';
import { ParameterService } from './parameter.service';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Rx';
import { UtilService } from '../util/util.service';
import { Parameter } from '../../models/parameter/parameter';

class MockHubConn {
    getJson = () => Observable.of({});
    putJson = () => Observable.of({});
    postJson = () => Observable.of({});
}
class UtilServiceMock {
    getHubUrl = () => 'mock';
    getUrlQuery = () => 'mock';
}

describe('Parameter service', () => {
    let service: ParameterService;
    let mockedParameter: Parameter;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                ParameterService,
                { provide: 'hubHost', useValue: 'mock' },
                { provide: 'appKey', useValue: 'mock' },
                { provide: HubConnectorComponent, useClass: MockHubConn },
                { provide: UtilService, useClass: UtilServiceMock },
            ]
        }).compileComponents();
        service = TestBed.get(ParameterService);
        mockedParameter = new Parameter('mock', 1, 10);
    });

    it('should instantiate service', () => {
        expect(service).toBeTruthy();
    });

    it('should get parameters', () => {
        expect(() => {
            service.getParameters();
            service.getParameters({});
        }).not.toThrow();
    });

    it('should create parameter', () => {
        const result = service.createParameter(mockedParameter);
        expect(result instanceof Observable).toBe(true);
    });

    it('should get options', () => {
        const result = service.getOptions(mockedParameter.id);
        expect(result instanceof Observable).toBe(true);
    });

    it('should alter parameter', () => {
        const result = service.alterParameter(mockedParameter);
        expect(result instanceof Observable).toBe(true);
    });

    it('should throw getOption', () => {
        service['hubConnector'].getJson = () => {
            return Observable.throw({return: {code: 0}});
        };
        const resp = service.getOptions(mockedParameter.id);
        expect(resp instanceof Observable).toBe(true);
    });

    it('should throw get parameters', () => {
        service['hubConnector'].getJson = () => {
            return Observable.throw({message: 'mock'});
        };
        const response = service.getParameters();
        expect(response instanceof Observable).toBe(true);
    });

});
