import { TestBed } from '@angular/core/testing';
import { ValidationTypeService } from './validation-type.service';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Rx';
import { UtilService } from '../../util/util.service';

class MockHubConn {
    public getJson() {
        return Observable.of();
    }
}

describe('Validation type service', () => {
    let validationTypeService: ValidationTypeService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                ValidationTypeService,
                { provide: HubConnectorComponent, useClass: MockHubConn },
                { provide: UtilService, useValue: {getHubUrl: () => 'mock'} }
            ]
        }).compileComponents();
        validationTypeService = TestBed.get(ValidationTypeService);
    });

    it('should instantiate service', () => {
        expect(validationTypeService).toBeTruthy();
    });

    it('should observable throw', () => {
        validationTypeService['hubConnector'].getJson = () => Observable.throw({message: 'mock'});
        let message: string;
        validationTypeService.getValidationTypes().subscribe(resp => {
            message = resp.return.message;
        });
        expect(message).toContain('mock');
    });

    it('should get cache', () => {
        validationTypeService['parametersTypeCache'] = Observable.of();
        expect(() => {
            validationTypeService.getValidationTypes();
        }).not.toThrow();
    });
});
