import { Injectable } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { UtilService } from '../../util/util.service';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../../models/response/response.interface';
import { IValidationType } from '../../../models/parameter/parameter';
import { ObservableRetryHandler } from '../../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class ValidationTypeService {
  public static path = '/treasury-product-catalog/v1/parameter-validation';

  constructor(private hubConnector: HubConnectorComponent, private utilService: UtilService) { }

  private validationTypesCache: Observable<IResponse<Array<IValidationType>>>;
  public getValidationTypes(): Observable<IResponse<Array<IValidationType>>> {
    if (!this.validationTypesCache) {
      const url: string = this.utilService.getHubUrl(ValidationTypeService.path);
      this.validationTypesCache = this.hubConnector.getJson(url)
          .retryWhen(ObservableRetryHandler).publishReplay(1).refCount()
          .catch(err => Observable.of({ return: {code: 1, message: err.message}, data: []}));
    }
    return this.validationTypesCache;
  }
}
