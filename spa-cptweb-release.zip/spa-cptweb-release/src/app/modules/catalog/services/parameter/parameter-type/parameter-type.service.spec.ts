import { TestBed } from '@angular/core/testing';
import { ParameterTypeService } from './parameter-type.service';
import { Observable } from 'rxjs/Rx';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { UtilService } from '../../util/util.service';

class MockHubConnector {
    getJson(url: string): Observable<any> {
      return Observable.of({
        data: []
      });
    }
}

describe('Parameter-type service', () => {
    let parameterTypeService: ParameterTypeService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                ParameterTypeService,
                { provide: UtilService, useValue: { getHubUrl: () => 'mock' } },
                { provide: HubConnectorComponent, useClass: MockHubConnector }
            ]
        }).compileComponents();
        parameterTypeService = TestBed.get(ParameterTypeService);
    });

    it('should create service', () => {
        expect(parameterTypeService).toBeTruthy();
    });

    it('get parameters type', () => {
        expect(() => {
            parameterTypeService.getParametersType();
        }).not.toThrow();
    });

    it('should throw observable', () => {
        parameterTypeService['parametersTypeCache'] = null;
        parameterTypeService['hubConnector'] = {
            getJson: () => {
                return Observable.throw({message: 'mock'});
            }
        } as any;
        let message: string;
        parameterTypeService.getParametersType().subscribe(res => {
            message = res.return.message;
        });
        expect(message).toContain('mock');
    });

    it('should get cache', () => {
        parameterTypeService['parametersTypeCache'] = Observable.of();
        expect(() => {
            parameterTypeService.getParametersType();
        }).not.toThrow();
    });
});
