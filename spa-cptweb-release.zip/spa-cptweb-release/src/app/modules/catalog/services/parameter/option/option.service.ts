import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../../models/response/response.interface';
import { IOption, Parameter } from '../../../models/parameter/parameter';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { UtilService } from '../../util/util.service';
import { ParameterOption } from '../../../models/parameter/parameter-item';
import { ObservableRetryHandler } from '../../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class OptionService {
  public static path = '/treasury-product-catalog/v1/parameter/';

  constructor(private hubConnector: HubConnectorComponent, private utilService: UtilService) { }

  public createOptions(option: ParameterOption, parameter: Parameter): Observable<IResponse<IOption>> {
    const cloned = {...option};
    delete cloned.isEditable;
    delete cloned.editing;
    const url = this.utilService.getHubUrl(`${OptionService.path}${parameter.id}/option`);
    return this.hubConnector.postJson(url, cloned);
  }

  public alterOption(option: ParameterOption, parameter: Parameter): Observable<IResponse<IOption>> {
    const cloned = {...option};
    delete cloned.isEditable;
    delete cloned.editing;
    const url = this.utilService.getHubUrl(OptionService.path + `${parameter.id}/option`);
    return this.hubConnector.putJson(url, cloned);
  }

  public deleteOption(option: ParameterOption, parameter: Parameter): Observable<IResponse<IOption>> {
    const cloned = {...option};
    delete cloned.isEditable;
    delete cloned.editing;
    const url = this.utilService.getHubUrl(`${OptionService.path}${parameter.id}/option/${option.id}`);
    return this.hubConnector.deleteJson(url);
  }
}
