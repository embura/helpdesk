import { Injectable } from '@angular/core';
import { UtilService } from '../../util/util.service';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../../models/response/response.interface';
import { IParameterType } from '../../../models/parameter/parameter';
import { ObservableRetryHandler } from '../../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class ParameterTypeService {
  public static path = '/treasury-product-catalog/v1/parameter-type';

  constructor(private hubConnector: HubConnectorComponent, private utilService: UtilService) { }

  private parametersTypeCache: Observable<IResponse<Array<IParameterType>>>;
  public getParametersType(): Observable<IResponse<Array<IParameterType>>> {
    if (!this.parametersTypeCache) {
      const url: string = this.utilService.getHubUrl(ParameterTypeService.path);
      this.parametersTypeCache = this.hubConnector.getJson(url)
        .retryWhen(ObservableRetryHandler).publishReplay(1).refCount()
        .catch(err => Observable.of({ return: {code: 1, message: err.message}, data: []}));
    }
    return this.parametersTypeCache;
  }
}
