import { Injectable, Inject } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { UtilService, IQuery } from '../util/util.service';
import { IParameter, IParameterType, Parameter, IOption } from '../../models/parameter/parameter';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../models/response/response.interface';
import { ParameterOption } from '../../models/parameter/parameter-item';
import { ObservableRetryHandler } from '../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class ParameterService {
  public static path = '/treasury-product-catalog/v1/parameter';

  constructor(
    private hubConnector: HubConnectorComponent,
    private utilService: UtilService,
    @Inject('hubHost') private hubHost: string,
    @Inject('appKey') private appKey: string
  ) { }

  public getParameters(obj?: IQuery): Observable<IResponse<Array<IParameter>>> {
    const url = `${this.hubHost}${ParameterService.path}`;
    if (!obj) {
      obj = {};
    }
    obj['gw-app-key'] = this.appKey;
    return this.hubConnector.getJson(url, { params: obj })
      .retryWhen(ObservableRetryHandler)
      .catch(err => Observable.of({ return: { code: 1, message: err.message }, data: [] }));
  }

  public createParameter(parameter: Parameter): Observable<IResponse<IParameter>> {
    const clonedObj: Parameter = { ...parameter };
    delete clonedObj.isOpen;
    const url: string = this.utilService.getHubUrl(ParameterService.path);
    return this.hubConnector.postJson(url, clonedObj);
  }

  public getOptions(parameterId: number, statusId?: number): Observable<IResponse<Array<ParameterOption>>> {
    statusId = statusId ? statusId : 0;
    const url = this.utilService.getUrlQuery(ParameterService.path + '/' + parameterId + '/option', { 'statusId': statusId });
    return this.hubConnector.getJson(url)
    .retryWhen(ObservableRetryHandler)
    .catch(res => ({
      return: {
        code: 0
      },
      data: []
    }) as any);
  }

  public alterParameter(parameter: Parameter): Observable<IResponse<IParameter>> {
    const clonedObj: Parameter = { ...parameter };
    delete clonedObj.options;
    delete clonedObj.isOpen;
    const url: string = this.utilService.getHubUrl(ParameterService.path);
    return this.hubConnector.putJson(url, clonedObj);
  }
}
