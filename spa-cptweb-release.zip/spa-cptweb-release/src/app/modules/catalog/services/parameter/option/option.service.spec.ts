import { ComponentFixture, TestBed } from '@angular/core/testing';
import { OptionService } from './option.service';
import { Observable } from 'rxjs/Rx';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { ParameterOption } from '../../../models/parameter/parameter-item';
import { Parameter } from '../../../models/parameter/parameter';
import { UtilService } from '../../util/util.service';

class MockHubConnector {
    public deleteJson(url: string): Observable<any> {
      return Observable.of({
        data: []
      });
    }

    public postJson(url: string, item?: any): Observable<any> {
      return Observable.of({
        data: 'mock'
      });
    }

    public putJson(url: string, item?: any): Observable<any> {
      return Observable.of({
        data: 'mock'
      });
    }
}

describe('Option service', () => {

    let optionService: OptionService;
    let paramOption: ParameterOption;
    let param: Parameter;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                OptionService,
                { provide: UtilService, useValue: { getHubUrl: () => 'mock' } },
                { provide: HubConnectorComponent, useClass: MockHubConnector }
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        optionService = TestBed.get(OptionService);
        paramOption = new ParameterOption('mock', 'mock tec');
        param = new Parameter('mock', 1, 10);
    });

    it('should instantiate service', () => {
        expect(optionService).toBeTruthy();
    });

    it('should Create Option', () => {
        expect(() => {
            optionService.createOptions(paramOption, param);
        }).not.toThrow();
    });

    it('should edit option', () => {
        expect(() => {
            optionService.alterOption(paramOption, param);
        }).not.toThrow();
    });

    it('should delete option', () => {
        expect(() => {
            optionService.deleteOption(paramOption, param);
        }).not.toThrow();
    });
});
