// tslint:disable-next-line:snt-file-name-suffix
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Rx';
import { SegmentService } from './segment.service';
import { UtilService, IQuery } from '../util/util.service';
import { Segment } from '../../models/segment/segment';
import { IResponse } from '../../models/response/response.interface';

const mockedResponse = {
    return: {
        code: 0,
        message: 'Mock'
    },
    data: [{
        code: '003',
        name: 'mockedSegment'
    }]
};

const MockHubConnector = {
    getJson: (url: string): Observable<any> => {
        return Observable.of({
            data: [mockedResponse]
        });
    },
    postJson: (url: string, item?: any): Observable<any> => {
        return Observable.of({
            data: mockedResponse
        });
    },
    putJson: (url: string, item?: any): Observable<any> => {
        return Observable.of({
            data: mockedResponse
        });
    }
};

const MockUtilService = {
    getUrlQuery: (url: string, obj: IQuery): string => {
        return '';
    },
    getHubUrl: () => 'mock'
};

describe('Segment service', () => {

    let service: SegmentService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                SegmentService,
                { provide: HubConnectorComponent, useValue: MockHubConnector },
                { provide: UtilService, useValue: MockUtilService },
                { provide: 'appKey', useValue: 'mockAPPKEY' },
                { provide: 'hubHost', useValue: 'mockHUBHOST' }
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        service = TestBed.get(SegmentService);
    });

    it('Should create Segment Service', () => {
        expect(service).toBeTruthy();
    });

    it('Should get all Segments', () => {
        let segments;
        service.getSegments().subscribe(response => {
            segments = response.data;
        });
        expect(segments.length).toBe(1);
    });

    it('Should have error when get all Segments', () => {
        const oldGetJson = MockHubConnector.getJson;
        service['hubConnector'].getJson = () => Observable.throw({ data: [] });
        service.getSegments().subscribe(response => {
            this.segments = response.data;
            expect(this.segments.length).toBe(0);
        });
    });

    it('Should get a Segment', () => {
        let segment;
        service.getSegment('003').subscribe(response => {
            segment = response.data[0];
        });
        expect(segment.return.code).toBe(0);
        expect(segment.data[0].name).toBe('mockedSegment');
    });

    it('Should have error when get segment', () => {
        const oldGetJson = MockHubConnector.getJson;
        service['hubConnector'].getJson = () => Observable.throw({ data: [] });
        service.getSegment('003').subscribe(response => {
            this.segments = response.data;
            expect(this.segments.length).toBe(0);
        });
    });

    it('should add an Segment', () => {
        const segment = new Segment('0043', 'Teste');
        service.addSegment(segment).subscribe(resp => {
            expect(resp).toBeTruthy();
        });
    });

    it('should alter an Segment', () => {
        const segment = new Segment('003', 'Teste');
        service.editSegment(segment).subscribe(resp => {
            expect(resp).toBeTruthy();
        });
    });

});
