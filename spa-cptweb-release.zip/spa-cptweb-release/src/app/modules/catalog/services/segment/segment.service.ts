import { Injectable, Inject } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { UtilService, IQuery } from '../util/util.service';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../models/response/response.interface';
import { Segment } from '../../models/segment/segment';
import { ObservableRetryHandler } from '../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class SegmentService {
    public static serviceHost = '/treasury-product-catalog/v1/segment';
    private ordenation: IQuery = {};

    constructor(
        private hubConnector: HubConnectorComponent,
        private utilService: UtilService
    ) { }

    public getSegments(obj?: IQuery): Observable<IResponse<Array<Segment>>> {
        this.ordenation = { ...obj } ;
        return this.hubConnector.getJson(this.utilService.getUrlQuery(SegmentService.serviceHost, this.ordenation))
            .retryWhen(ObservableRetryHandler)
            .catch(err => Observable.of({ return: { code: 1, message: err.message }, data: [] }));
    }

    public getSegment(code: string): Observable<IResponse<Array<Segment>>> {
        this.ordenation._likeColumn = 'code';
        this.ordenation._likeValue = code;
        return this.hubConnector.getJson(this.utilService.getUrlQuery(SegmentService.serviceHost, this.ordenation))
            .retryWhen(ObservableRetryHandler)
            .catch(err => Observable.of({ return: { code: 1, message: err.message }, data: [] }));
    }

    public addSegment(segment: Segment): Observable<IResponse<Segment>> {
        const url: string = this.utilService.getHubUrl(SegmentService.serviceHost);
        return this.hubConnector.postJson(url, new Segment(segment.code, segment.name));
    }

    public editSegment(segment: Segment): Observable<IResponse<Segment>> {
        const url: string = this.utilService.getHubUrl(SegmentService.serviceHost);
        return this.hubConnector.putJson(url, segment);
    }

}
