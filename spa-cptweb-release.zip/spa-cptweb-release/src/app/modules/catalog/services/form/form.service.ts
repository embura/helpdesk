import { Injectable, Inject } from '@angular/core';
import { IQuery, UtilService } from '../util/util.service';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { IResponse } from '../../models/response/response.interface';
import { Observable } from 'rxjs/Observable';
import { IForm, IParamFormAssociation } from '../../models/form/form.interface';
import { Form } from '../../models/form/form';
import { FormDTO, FormParameterDTO } from '../../models/form/form.dto';
import { ObservableRetryHandler } from '../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class FormService {
    public static serviceHost = '/treasury-product-catalog/v1/form';
    private ordenation: IQuery = {};

    constructor(
        private hubConnector: HubConnectorComponent,
        private utilService: UtilService
    ) { }

    private defaultError = (message: string): IResponse<Array<any>> => ({
        return: {
            code: 1,
            message
        },
        data: []
    })

    public getForms(obj?: IQuery): Observable<IResponse<IForm[]>> {
        this.ordenation = { ...obj };
        return this.hubConnector.getJson(this.utilService.getUrlQuery(FormService.serviceHost, this.ordenation))
            .retryWhen(ObservableRetryHandler)
            .catch(err => Observable.of({ return: { code: 1, message: err.message }, data: [] }));
    }

    public getForm(id: number): Observable<IResponse<IForm>> {
        const url = `${FormService.serviceHost}/${id}/`;

        return this.hubConnector.getJson(this.utilService.getHubUrl(url))
        .retryWhen(ObservableRetryHandler);
    }

    public createForm(data: Form): Observable<IResponse<IForm>> {
        const form: FormDTO = new FormDTO(null, data.name, data.statusId, true);

        return this.hubConnector.postJson(this.utilService.getHubUrl(FormService.serviceHost), form);
    }

    public editForm(data: Form): Observable<IResponse<IForm>> {
        const form: FormDTO = new FormDTO(data.id, data.name, data.statusId, data.isEditable);

        if (data.parameters && data.parameters.length > 0) {
            form.formParameters = new Array<FormParameterDTO>();

            data.parameters.forEach((param, index) => {
                const isRequired = param.isRequired ? 'S' : 'N';
                form.formParameters.push(new FormParameterDTO(param.id, data.id, param.parameterId, index + 1, isRequired));
            });

            form.formParameters.shift();
        }

        return this.hubConnector.putJson(this.utilService.getHubUrl(FormService.serviceHost), form);
    }

    public removeParameter(id: number, item: Form) {
        const index = item.parameters.findIndex(param => param.parameterId === id);

        item.parameters.slice(index, 1);
    }

    public getFormsAssociations(): Observable<IResponse<IForm[]>> {
        const url: string = this.utilService.getHubUrl(FormService.serviceHost + `/associations`);
        return this.hubConnector.getJson(url)
            .retryWhen(ObservableRetryHandler)
            .catch(err => Observable.of({ return: { code: 1, message: err.message }, data: [] }));
    }

    public getParametersById(id: number): Promise<IResponse<IParamFormAssociation[]>> {
        const url = `${FormService.serviceHost}/${id}/associatedParameters`;

        return this.hubConnector.getJson(this.utilService.getHubUrl(url))
        .retryWhen(ObservableRetryHandler)
        .catch(() => Observable.of(
            {
                ...this.defaultError('Ocorreu um erro ao recuperar a lista de parâmetros do formulário selecionado.'),
                data: []
            }
        )).toPromise();
    }
}

