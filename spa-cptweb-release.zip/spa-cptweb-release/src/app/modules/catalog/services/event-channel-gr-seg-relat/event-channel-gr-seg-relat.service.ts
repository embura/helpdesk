// tslint:disable-next-line:snt-file-name-suffix
import { Injectable, Inject } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { UtilService, IQuery } from '../util/util.service';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../models/response/response.interface';
import { EventChanGrSegRelations } from '../../models/product/event-channel-group-segment-relations/event-channel-group-segment-relations';
import { ObservableRetryHandler } from '../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class EventChanGrSegRelationsService {

    public static serviceHost = '/treasury-product-catalog/v1/group-segment/events';
    private ordenation: IQuery = {};

    constructor(
        private hubConnector: HubConnectorComponent,
        private utilService: UtilService
    ) { }

    public getEventChanGrSegRelations(obj?: IQuery): Observable<IResponse<Array<EventChanGrSegRelations>>> {
        this.ordenation = { ...obj };
        return this.hubConnector.getJson(this.utilService.getUrlQuery(EventChanGrSegRelationsService.serviceHost, this.ordenation))
            .retryWhen(ObservableRetryHandler)
            .catch(err => Observable.of({ return: { code: 1, message: err.message }, data: [] }));
    }

    public getEventChanGrSegRelationsByID(code: number): Observable<IResponse<EventChanGrSegRelations>> {
        const url: string = this.utilService.getHubUrl(EventChanGrSegRelationsService.serviceHost, code);
        return this.hubConnector.getJson(url)
          .retryWhen(ObservableRetryHandler);
    }

    public addEventChanGrSegRelations(eventChanGrSegRelations: EventChanGrSegRelations): Observable<IResponse<EventChanGrSegRelations>> {
        const url: string = this.utilService.getHubUrl(EventChanGrSegRelationsService.serviceHost);
        return this.hubConnector.postJson(url, eventChanGrSegRelations);
    }

    public editEventChanGrSegRelations(eventChanGrSegRelations: EventChanGrSegRelations): Observable<IResponse<EventChanGrSegRelations>> {
        const url: string = this.utilService.getHubUrl(EventChanGrSegRelationsService.serviceHost);
        return this.hubConnector.putJson(url, eventChanGrSegRelations);
    }

}
