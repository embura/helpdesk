import { Injectable } from '@angular/core';
import { UtilService, IQuery } from '../util/util.service';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { PayloadItem } from '../../models/payload/payload-item';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../models/response/response.interface';
import { RequestOptionsArgs } from '@angular/http';
import { ObservableRetryHandler } from '../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class PayloadItemService {

    public static readonly path = '/treasury-product-catalog/v1/payload-item';
    public static readonly pathAssociation = '/treasury-product-catalog/v1/payload-association';
    constructor(
        private readonly hubConn: HubConnectorComponent,
        private utilService: UtilService) {
    }

    public get(payloadId: number): Observable<IResponse<PayloadItem[]>> {
        const url: string = this.utilService.getHubUrl(PayloadItemService.path);

        return this.hubConn
            .getJson(url, { params: { 'payloadId': payloadId } })
            .retryWhen(ObservableRetryHandler)
            .catch(err => Observable.of({
                return: {
                    code: 1,
                    message: err.message
                },
                data: []
            }));
    }

    public create(payloadItem: PayloadItem): Observable<IResponse<PayloadItem>> {
        const cloned = { ...payloadItem };
        delete cloned.isEditable;
        delete cloned.editing;
        const url: string = this.utilService.getHubUrl(PayloadItemService.path);
        return this.hubConn.postJson(url, payloadItem);
    }

    public delete(payloadItem: PayloadItem): Observable<IResponse<PayloadItem>> {
        const cloned = { ...payloadItem };
        delete cloned.isEditable;
        delete cloned.editing;
        const url = this.utilService.getHubUrl(`${PayloadItemService.path}/${payloadItem.id}`);
        return this.hubConn.deleteJson(url);
    }

    public edit(payloadItem: PayloadItem): Observable<IResponse<PayloadItem>> {
        const url: string = this.utilService.getHubUrl(PayloadItemService.path);
        return this.hubConn.putJson(url, payloadItem);
    }

    public async isFormAssociation(payloadItem: PayloadItem): Promise<Boolean> {
        const url: string = this.utilService.getHubUrl(PayloadItemService.pathAssociation);

        return this.hubConn
            .getJson(url, { params: { 'payloadItemId': payloadItem.id } })
            .retryWhen(ObservableRetryHandler)
            .toPromise().then(res => {
                if (res.data && res.data.length > 0) {
                    return true;
                } else {
                    return false;
                }
            }).catch(e => {
                return false;
            });
    }
}
