import { Injectable } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { UtilService, IQuery } from '../util/util.service';
import { IResponse } from '../../models/response/response.interface';
import { ObservableRetryHandler } from '../../shared/lib/observable-retry/observable-retry.handler';

export interface IAuditData {
  tableId: number;
  filter: IQuery;
}

export interface IAuditInfo {
  actionDate: string;
  actionType: string;
  id: number;
  isEditable: true;
  name: string;
  newValue: string;
  oldValue: string;
  recordId: string;
  tableId: number;
  userId: string;
}

@Injectable()
export class AuditService {
  public static readonly path = '/treasury-product-catalog/v1/audit';
  public defaultErrorMessage = 'Ocorreu um erro';
  constructor(private readonly hubConn: HubConnectorComponent, private utilService: UtilService) {
  }

  public getHistoric(params: IQuery): Promise<IResponse<Array<IAuditInfo>>> {
    const url: string = this.utilService.getUrlQuery(AuditService.path, params);
    return this.hubConn.getJson(url)
    .retryWhen(ObservableRetryHandler)
    .toPromise().catch(this.defaultError);
  }

  public getCSVData(params: IQuery): Promise<any> {
    delete params._limit;
    delete params._offset;
    params._limit = 1000;
    const url: string = this.utilService.getUrlQuery(AuditService.path + '/details', params);
    return this.hubConn.get(url).toPromise();
  }

  public defaultError = (): IResponse<any> => {
    return {
      return: {
        code: 1,
        message: this.defaultErrorMessage
      },
      data: []
    };
  }
}
