import { TestBed, ComponentFixture } from '@angular/core/testing';
import { AuditService } from './audit.service';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { UtilService } from '../util/util.service';
import { Observable } from 'rxjs/Rx';

export class MockHubConn {
    getJson = (): Observable<any> => Observable.of({});
    get = (): Observable<any> => Observable.of('mock');
}

const MockUtilService = {
    getUrlQuery: () => ''
};

describe('Audit Service', () => {
    let service: AuditService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                AuditService,
                { provide: HubConnectorComponent, useClass: MockHubConn },
                { provide: UtilService, useValue: MockUtilService }
            ]
        }).compileComponents();
        service = TestBed.get(AuditService);
    });

    it('should instantiate service', () => {
        expect(service).toBeTruthy();
    });

    it('should get historical data', () => {
        const result = service.getHistoric({});
        expect(result instanceof Promise).toBe(true);
    });

    it('should get csvData', () => {
        const result = service.getCSVData({});
        expect(result instanceof Promise).toBe(true);
    });
});
