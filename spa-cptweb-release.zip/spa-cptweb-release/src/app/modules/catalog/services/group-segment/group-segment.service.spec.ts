// tslint:disable-next-line:snt-file-name-suffix
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Rx';
import { GroupSegmentService } from './group-segment.service';
import { UtilService, IQuery } from '../util/util.service';
import { Segment } from '../../models/segment/segment';
import { IResponse } from '../../models/response/response.interface';
import { GroupSegment } from '../../models/product/group-segment/group-segment';

const mockedResponse = {
    return: {
        code: 0,
        message: 'Mock'
    },
    data: [{
        code: '003',
        name: 'mockedSegment'
    }]
};

const groupSegment: GroupSegment = {
    name: 'string',
    id: 120,
    code: 120,
    segments: [],
    events: [],
    isOpen: false,
    isEditing: false
};

const MockHubConnector = {
    getJson: (url: string): Observable<any> => {
        return Observable.of({
            data: [mockedResponse]
        });
    },
    postJson: (url: string, item?: any): Observable<any> => {
        return Observable.of({
            data: mockedResponse
        });
    },
    putJson: (url: string, item?: any): Observable<any> => {
        return Observable.of({
            data: mockedResponse
        });
    }
};

const MockUtilService = {
    getUrlQuery: (url: string, obj: IQuery): string => {
        return '';
    },
    getHubUrl: () => 'mock'
};

describe('Group Segment service', () => {

    let service: GroupSegmentService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                GroupSegmentService,
                { provide: HubConnectorComponent, useValue: MockHubConnector },
                { provide: UtilService, useValue: MockUtilService },
                { provide: 'appKey', useValue: 'mockAPPKEY' },
                { provide: 'hubHost', useValue: 'mockHUBHOST' }
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        service = TestBed.get(GroupSegmentService);
    });

    it('Should create Group Segment Service', () => {
        expect(service).toBeTruthy();
    });

    it('Should get all Group Segments', () => {
        let segments;
        service.getGroupsSegments().subscribe(response => {
            segments = response.data;
        });
        expect(segments.length).toBe(1);
    });

    it('Should have error when get all Group Segments', () => {
        const oldGetJson = MockHubConnector.getJson;
        service['hubConnector'].getJson = () => Observable.throw({ data: [] });
        service.getGroupsSegments().subscribe(response => {
            this.segments = response.data;
            expect(this.segments.length).toBe(0);
        });
    });

    it('Should get a Group Segment by ID', () => {
        let segment;
        service.getGroupSegmentByID(+'003').subscribe(response => {
            segment = response.data[0];
        });
        expect(segment.return.code).toBe(0);
        expect(segment.data[0].name).toBe('mockedSegment');
    });

    it('Should get a Group Segment by code', () => {
        let segment;
        service.getGroupSegmentByCode(+'003').subscribe(response => {
            segment = response.data[0];
        });
        expect(segment.return.code).toBe(0);
        expect(segment.data[0].name).toBe('mockedSegment');
    });

    it('should add a Group Segment', () => {
        service.addGroupSegment(groupSegment).subscribe(resp => {
            expect(resp).toBeTruthy();
        });
    });

    it('should alter a Group Segment', () => {
        const segment = new Segment('003', 'Teste');
        service.editGroupSegment(groupSegment).subscribe(resp => {
            expect(resp).toBeTruthy();
        });
    });

});
