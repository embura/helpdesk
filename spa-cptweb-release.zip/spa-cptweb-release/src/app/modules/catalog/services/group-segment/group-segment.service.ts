import { Injectable, Inject } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { UtilService, IQuery } from '../util/util.service';
import { Observable } from 'rxjs/Rx';
import { IResponse } from '../../models/response/response.interface';
import { GroupSegment } from '../../models/product/group-segment/group-segment';
import { ObservableRetryHandler } from '../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class GroupSegmentService {
    public static serviceHost = '/treasury-product-catalog/v1/group-segment';
    private ordenation: IQuery = {};

    constructor(
        private hubConnector: HubConnectorComponent,
        private utilService: UtilService
    ) { }

    public getGroupsSegments(obj?: IQuery): Observable<IResponse<Array<GroupSegment>>> {
        this.ordenation = { ...obj };
        return this.hubConnector.getJson(this.utilService.getUrlQuery(GroupSegmentService.serviceHost, this.ordenation))
            .retryWhen(ObservableRetryHandler)
            .catch(err => Observable.of({ return: { code: 1, message: err.message }, data: [] }));
    }

    public getGroupSegmentByID(code: number): Observable<IResponse<GroupSegment>> {
        const url: string = this.utilService.getHubUrl(GroupSegmentService.serviceHost, code);
        return this.hubConnector.getJson(url)
            .retryWhen(ObservableRetryHandler);
    }

    public getGroupSegmentByCode(productId: number): Observable<IResponse<Array<GroupSegment>>> {
        this.ordenation['productId'] = productId ? productId : '-1';
        // tslint:disable-next-line:max-line-length
        return this.hubConnector.getJson(this.utilService.getUrlQuery(GroupSegmentService.serviceHost + '/withObjectLists', this.ordenation))
            .retryWhen(ObservableRetryHandler)
            .catch(err => Observable.of({ return: { code: 1, message: err.message }, data: [] }));
    }

    public addGroupSegment(Groupsegment: GroupSegment): Observable<IResponse<GroupSegment>> {
        const url: string = this.utilService.getHubUrl(GroupSegmentService.serviceHost);
        return this.hubConnector.postJson(url, Groupsegment);
    }

    public editGroupSegment(groupSegment: GroupSegment): Observable<IResponse<GroupSegment>> {
        const url: string = this.utilService.getHubUrl(GroupSegmentService.serviceHost);
        return this.hubConnector.putJson(url, groupSegment);
    }

}
