import { Injectable, Inject } from '@angular/core';
import { IResponse } from '../../models/response/response.interface';
import { ICategories } from '../../models/product/category-product.interface';
import { UtilService, IQuery } from '../util/util.service';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { Observable } from 'rxjs/Rx';
import { IProduct, ITotal, IProductCategory } from '../../models/product/product.interface';
import { ObservableRetryHandler } from '../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class ProductService {
    public static path = '/treasury-product-catalog/v1/product';
    public hubHost: string;

    private defaultError = (message: string): IResponse<Array<ICategories>> => ({
        return: {
            code: 1,
            message
        },
        data: []
    })

    constructor(private utilService: UtilService, private hubConnector: HubConnectorComponent, @Inject('hubHost') hubHost: string) {
        this.hubHost = hubHost;
    }

    public getProductById(id: number): Promise<IResponse<IProduct>> {
        const url: string = this.utilService.getHubUrl(ProductService.path + `/${id}`);
        return this.hubConnector.getJson(url)
        .retryWhen(ObservableRetryHandler)
        .catch(() => Observable.of(
            {
                ...this.defaultError('Erro ao consultar produto.'),
                data: null
            }
        )).toPromise();
    }

    public getProducts(query?: IQuery): Promise<IResponse<Array<IProduct>>> {
        const url: string = this.utilService.getHubUrl(ProductService.path);
        const message = 'Erro ao consultar produtos';
        return this.hubConnector.getJson(url, { params: query })
        .retryWhen(ObservableRetryHandler)
        .catch(() => Observable.of(
            {
                ...this.defaultError(message),
                data: []
            }
        )).toPromise();
    }

    public createProduct(product: IProduct): Observable<IResponse<IProduct>> {
        const url: string = this.utilService.getHubUrl(ProductService.path);
        return this.hubConnector.postJson(url, product);
    }

    public updateProduct(product: IProduct): Observable<IResponse<IProduct>> {
        const url: string = this.utilService.getHubUrl(ProductService.path);
        return this.hubConnector.putJson(url, product);
    }

    public getAllInfos(id: number): Promise<IResponse<IProduct>> {
        const url = this.utilService.getUrlQuery(ProductService.path + `/infos/findAll`, { productId: id });
        return this.hubConnector.getJson(url)
        .retryWhen(ObservableRetryHandler)
        .catch(() => Observable.of(
            {
                ...this.defaultError('Erro ao consultar produto.'),
                data: null
            }
        )).toPromise();
    }

    public findQuantites(): Promise<IResponse<ITotal>> {
        const url: string = this.utilService.getHubUrl(ProductService.path + `/infos/quantities`);
        return this.hubConnector.getJson(url)
        .retryWhen(ObservableRetryHandler)
        .catch(() => Observable.of(
            {
                ...this.defaultError('Erro ao consultar quantidades de produtos.'),
                data: null
            }
        )).toPromise();
    }

    public findCategories(): Promise<IResponse<IProductCategory>> {
        const url: string = this.utilService.getHubUrl(ProductService.path + `/infos/categories`);
        const query = { _limit: 1000 };
        return this.hubConnector.getJson(url, { params: query })
        .retryWhen(ObservableRetryHandler)
        .catch(() => Observable.of(
            {
                ...this.defaultError('Erro ao consultar produtos.'),
                data: null
            }
        )).toPromise();
    }
}
