// tslint:disable-next-line:snt-file-name-suffix
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { ProductService } from './product.service';
import { Observable } from 'rxjs/Rx';
import { UtilService } from '../util/util.service';
import { IProduct } from '../../models/product/product.interface';

const mockedResponse = {
  return: {
    code: 0,
    message: 'Mock'
  },
  data: {
    id: '5',
    name: 'mockedProduct',
    shortName: 'mockedProduct'
  }
};

const iProduct: IProduct = {
    id: 1,
    formId: 1,
    modalityId: 1,
    underlyingId: 1,
    assetClassId: 1,
    groupId: 1,
    statusId: 1,
    name: 'test 1',
    params: [],
    isOpen: true
};

const MockHubConnector = {
  getJson: (url: string): Observable<any> =>  {
    return Observable.of({
      data: [mockedResponse]
    });
  },
  postJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: mockedResponse
    });
  },
  putJson: (url: string, item?: any): Observable<any> => {
    return Observable.of({
      data: mockedResponse
    });
  }
};

describe('Product service', () => {

  let service: ProductService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ProductService,
        { provide: UtilService, useValue: {
          getHubUrl: () => 'mock',
          getUrlQuery: () => 'mock'}
        },
        { provide: HubConnectorComponent, useValue: MockHubConnector },
        { provide: 'hubHost', useValue: 'mockHUBHOST' }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    service = TestBed.get(ProductService);
  });

  it('Should create Product Service', () => {
    expect(service).toBeTruthy();
  });

  it('Should get all Products', () => {
    let products;
    // service['hubConn'].getJson = () => Observable.throw({data: []});
    service.getProducts().then(response => {
      products = response.data;
      expect(products.length).toBe(1);
    });
  });

  it('Should get a Product', () => {
    let product;
    service.getProductById(5).then(response => {
        product = response.data[0];
      expect(product.return.code).toBe(0);
      expect(product.data.name).toBe('mockedProduct');
    });
  });

  it('should add a product', () => {
    service.createProduct(iProduct).subscribe(resp => {
      expect(resp).toBeTruthy();
    });
  });

  it('should alter a product', () => {
    service.updateProduct(iProduct).subscribe(resp => {
      expect(resp).toBeTruthy();
    });
  });

  it('should get all infos', () => {
    service.getAllInfos(5).then(resp => {
      expect(resp).toBeTruthy();
    });
  });

  it('should find all quantitites', () => {
    service.findQuantites().then(resp => {
      expect(resp).toBeTruthy();
    });
  });

  it('should find categories', () => {
    service.findCategories().then(resp => {
      expect(resp).toBeTruthy();
    });
  });

});
