import { Injectable } from '@angular/core';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { UtilService } from '../util/util.service';
import { Payload, IItemAssociation, IPayloadFormItem } from '../../models/payload/payload';
import { IResponse } from '../../models/response/response.interface';
import { Observable } from 'rxjs/Rx';
import { ObservableRetryHandler } from '../../shared/lib/observable-retry/observable-retry.handler';

@Injectable()
export class PayloadService {

    public static readonly path = '/treasury-product-catalog/v1/payload';

    constructor(
        private readonly hubConnector: HubConnectorComponent,
        private utilService: UtilService,
    ) {
    }

    private defaultError = (message: string): IResponse<Array<Payload>> => ({
        return: {
            code: 1,
            message
        },
        data: []
    })

    public create(payload: Payload): Observable<IResponse<Payload>> {
        const clonedObj: Payload = { ...payload };
        delete clonedObj.isOpen;
        const url: string = this.utilService.getHubUrl(PayloadService.path);
        return this.hubConnector.postJson(url, clonedObj);
    }

    public getAll(): Observable<IResponse<Array<Payload>>> {
        const url: string = this.utilService.getHubUrl(PayloadService.path);
        return this.hubConnector.getJson(url)
            .retryWhen(ObservableRetryHandler)
            .catch(err => Observable.of({
                return: {
                    code: 1,
                    message: err.message
                },
                data: []
            }));
    }

    public editPayload(payload: Payload): Observable<IResponse<Payload>> {
        const url: string = this.utilService.getHubUrl(PayloadService.path);
        return this.hubConnector.putJson(url, payload);
    }

    public createAssociations(itensAssociation: IItemAssociation[], formParamId: number): Observable<IResponse<IItemAssociation[]>> {
        const url: string = this.utilService.getHubUrl('/treasury-product-catalog/v1/' + '/payload-association');
        const obj = {itens: itensAssociation , formParamId};
        return this.hubConnector.postJson(url, obj).catch(() => Observable.of(
            {
                ...this.defaultError('Erro ao cadastrar associações de formulário de payload.'),
                data: null
            }
        ));
    }

    public getPayloadFormItens(formId: number, payloadId?: number): Promise<IResponse<IPayloadFormItem[]>> {
        const query = { formId: formId };

        if (payloadId) {
            query['payloadId'] = payloadId;
        }

        const url = this.utilService.getUrlQuery(PayloadService.path + `/form-payload/associations`, query);

        return this.hubConnector.getJson(url)
        .retryWhen(ObservableRetryHandler)
        .catch(() => Observable.of(
            {
                ...this.defaultError('Erro ao consultar associações de formulário de payload.'),
                data: null
            }
        )).toPromise();
    }

    public delete(payload: Payload): Observable<IResponse<Payload>> {
        const cloned = { ...payload };
        delete cloned.isEditable;
        const url = this.utilService.getHubUrl(`${PayloadService.path}/${payload.id}`);
        return this.hubConnector.deleteJson(url).catch(() => Observable.of(
            {
                ...this.defaultError('Erro ao deletar payload.'),
                data: null
            }
        ));
    }

}
