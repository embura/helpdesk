import { Injectable, Inject } from '@angular/core';
import { IFilterEvent } from '../../components/filter/filter.component';
import * as moment_ from 'moment';
const moment = moment_;

export interface IQuery {
  _orderBy?: string;
  _order?: 'asc' | 'desc';
  _likeColumn?: string;
  _likeValue?: string;
  _limit?: number;
  _offset?: number;
  _between?: string;
  _or?: Array<string>;
  [x: string]: string | number | Array<string>;
}

@Injectable()
export class UtilService {
  public appKey: string;
  public hubHost: string;
  constructor(
    @Inject('appKey') appKey: string,
    @Inject('hubHost') hubHost: string
  ) {
    this.appKey = appKey;
    this.hubHost = hubHost;
  }

  public buildCSV(data: string, fileName: string): boolean {
    try {
      const encodedUri = data;
      const universalBOM = '\uFEFF';
      const link = document.createElement('a');
      if (!link) {
        throw link;
      }
      // link.setAttribute('href', 'data:text/csv;charset=utf-8,%EF%BB%BF' + encodedUri);
      link.setAttribute('href', 'data:text/csv;charset=utf-16,%EF%BB%BF' + encodeURIComponent(data));
      link.setAttribute('download', `${fileName}_${moment().format('DD_MM_YYYY')}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return true;
    } catch (err) {
      return false;
    }
  }

  public getServiceMessage(param, defaultMessage: string): string {
    if (param.return && param.return.message) {
      return param.return.message;
    } else if (param.message && typeof (param.message) === 'string') {
      return param.message;
    } else if (param.message && param.message.message) {
      return param.message.message;
    }
    return defaultMessage;
  }

  public getHubUrl(servicePath: string, ...params: Array<string | number>): string {
    let stringParams = '';
    params.forEach(param => {
      stringParams += `/${param.toString()}`;
    });
    return `${this.hubHost}${servicePath}${stringParams}?gw-app-key=${this.appKey}`;
  }

  public getUrlQuery(path: string, obj: IQuery): string {
    let stringParams = `gw-app-key=${this.appKey}`;

    Object.keys(obj).forEach(function (key) {
      if (Array.isArray(obj[key]) && '_or' in obj) {
        const stringOr = [];
        for (const entry of obj['_or']) {
          stringOr.push(`${key}=${entry}`);
        }
        stringParams += `&${stringOr.join('&')}`;
      } else {
        stringParams += `&${key}=${obj[key]}`;
      }
    });

    return `${this.hubHost}${path}?${stringParams}`;
  }

  public buildQueryParams(searchParams: IFilterEvent): IQuery {
    const ordenation: IQuery = {};
    if (searchParams.value.filter.hasOwnProperty('status')) {
      ordenation.statusId = searchParams.value.filter.status;
    } else if (!searchParams.value.showInatives) {
      ordenation.statusId = 10;
    }
    if (searchParams.value.textFilter && searchParams.value.textFilter.trim() !== '') {
      ordenation._likeColumn = 'name';
      ordenation._likeValue = `%${searchParams.value.textFilter.trim()}%`;
    }
    ordenation._orderBy = searchParams.value.filter.orderBy;
    ordenation._order = searchParams.value.filter.order;
    return ordenation;
  }
}
