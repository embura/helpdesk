import { TestBed } from '@angular/core/testing';
import { UtilService } from './util.service';

describe('Util Service', () => {
  let utilService: UtilService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        UtilService,
        { provide: 'appKey', useValue: 'mockAPPKEY' },
        { provide: 'hubHost', useValue: 'mockHUBHOST' }
      ]
    }).compileComponents();
    utilService = TestBed.get(UtilService);
  });

  it('Should return a url without parameters', () => {
    const mockUrl = utilService.getHubUrl('mock');
    expect(mockUrl).toBe('mockHUBHOSTmock?gw-app-key=mockAPPKEY');
  });

  it('Should return a url with parameters', () => {
    const mockUrl = utilService.getHubUrl('/mock', 5);
    expect(mockUrl).toBe('mockHUBHOST/mock/5?gw-app-key=mockAPPKEY');
  });

  it('should get a message', () => {
    expect(utilService.getServiceMessage({}, 'oie')).toContain('oie');
    const param = {
      return: {
        message: 'message'
      }
    };
    expect(utilService.getServiceMessage(param, '')).toContain('message');
    delete param.return;
    param['message'] = 'mock';
    expect(utilService.getServiceMessage(param, '')).toContain('mock');
  });

  it('should build a link', () => {
    const result = utilService.buildCSV('data', 'file');
    expect(result).toBe(true);
  });

  it('should get a URL', () => {
    const result = utilService.getUrlQuery('/test', {});
    const expected = `${utilService.hubHost}/test?gw-app-key=${utilService.appKey}`;
    expect(result).toBe(expected);
  });

  it('should build query params', () => {
    const result = utilService.buildQueryParams({
      value: {
        showInatives: true,
        textFilter: 'string',
        filter: {
          id: 1,
          value: 'string',
          orderBy: 'string',
          order: 'asc',
          status: 10
        }
      },
      isTextualChange: true
    });
  });

});
