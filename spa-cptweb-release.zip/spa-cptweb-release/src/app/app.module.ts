import { AppService } from './app.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { Http } from '@angular/http';
import { TranslateStaticLoader, TranslateLoader, TranslateModule } from 'ng2-translate';
import { JsonConfigModule } from 'angl-spawebbgrl/json-config-module/config.module';
import { HubConnectorModule } from 'angl-spawebbgrl/spa-http-module/hub-connector.module';
import { ErrorHandlingModule } from 'angl-spawebbgrl/error-handling-module';
import { LogModule } from 'angl-spawebbgrl/log';
import { AppComponent } from './app.component';
import { SharedModule } from './shared.module';
import { CatalogModule } from './modules/public_api';
import { UserGuard } from './guards/user.guard';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { environment } from './../environments/environment';
import { GenericDialogComponent } from './modules/catalog/shared/access-dialog/generic-dialog.component';
import { MatDialogModule, MatIconModule } from '@angular/material';
import { ToastrModule } from 'ngx-toastr';
import { CustomWarningToastComponent } from './modules/catalog/components/toast/custom-warning-toast.component';
import { CustomErrorToastComponent } from './modules/catalog/components/toast/custom-error-toast.component';
import { CustomSuccessToastComponent } from './modules/catalog/components/toast/custom-success-toast.component';
import { MainAppModule } from './main-app/main-app.module';

@NgModule({
  declarations: [
    AppComponent,
    GenericDialogComponent,
  ],
  imports: [
    MatDialogModule,
    MatIconModule,
    ToastrModule.forRoot({
      // toastComponent: CustomWarningToastComponent,
      timeOut: 3000,
      positionClass: 'toast-bottom-center'
    }),
    CatalogModule.forRoot(environment.hubHost, '096bd5f01e670136a9bf0050569009ca'),
    RouterModule.forRoot([
      { path: '', canLoad: [UserGuard], loadChildren: () => MainAppModule, }
    ]),
    SharedModule,
    BrowserModule,
    BrowserAnimationsModule,
    ErrorHandlingModule,
    JsonConfigModule.forRoot(['assets/url.config.json']),
    TranslateModule.forRoot({
      provide: TranslateLoader,
      useFactory: (http: Http) => new TranslateStaticLoader(http, 'assets/translate', '.json'),
      deps: [Http]
    }),
    HubConnectorModule.forRoot(environment.jsonSsoKey, true),
    LogModule.forRoot('url_log')
  ],
  providers: [
    AppService,
    // {
    //   provide: APP_BASE_HREF,
    //   useValue: '/'
    // },
    UserGuard
  ],
  bootstrap: [AppComponent],
  entryComponents: [GenericDialogComponent]
})
export class AppModule { }
