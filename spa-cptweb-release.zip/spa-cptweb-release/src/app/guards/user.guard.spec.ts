import { UserGuard } from './user.guard';
import { TestBed, async } from '@angular/core/testing';
import { Observable } from 'rxjs/Observable';
import { AppService } from '../app.service';
import 'rxjs/add/observable/of';

class AppServiceMock {
  authentication() {
    return Observable.of({'user': 'X194252', 'id': '194252'});
  }

  getProfile(login: string) {
    return Observable.of([
      {
        'codigoGrupo': '8656',
        'nomeGrupo': 'PVD-GESTOR-PORTAL'
      }
    ]);
  }
}

describe('UserGuard', () => {
  let guard: UserGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        UserGuard,
        { provide: AppService, useClass: AppServiceMock }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    guard = TestBed.get(UserGuard);
  });

  it('Create UserGuard instance', () => {
    expect(guard).toBeTruthy();
  });

  xit('should be authenticated when local storage is set and permission has PVD', async(() => {
    localStorage.setItem('user', '[{"codigoGrupo": "8656", "nomeGrupo": "PVD-GESTOR-PORTAL" }]');

    guard.canLoad().then((data: boolean) => {
      expect(data).toBe(true);
    });
  }));

  xit('should not be authenticated when local storage is set and permission has not PVD', async(() => {
    localStorage.setItem('user', '[{"codigoGrupo": "8656", "nomeGrupo": "GESTOR-PORTAL" }]');

    guard.canLoad().then((data: boolean) => {
      expect(data).toBe(false);
    });
  }));

  xit('should authenticate and authorize in all services', async(() => {
    localStorage.removeItem('user');

    guard.canLoad().then((data: boolean) => {
      expect(data).toBe(true);
    });
  }));

  xit('should have error on authentication service', async(() => {
    localStorage.removeItem('user');

    guard['service'].authentication = () => Observable.throw({});

    guard.canLoad().then((data: boolean) => {
      expect(data).toBe(false);
    });
  }));

  xit('should have error on permissons service', async(() => {
    localStorage.removeItem('user');

    guard['service'].getProfile = () => Observable.throw({});

    guard.canLoad().then((data: boolean) => {
      expect(data).toBe(false);
    });
  }));
});
