import {  CanLoad } from '@angular/router';
import { Injectable } from '@angular/core';
import { AppService } from '../app.service';
import { Observable } from 'rxjs/Observable';

@Injectable()
// tslint:disable-next-line:snt-service-class-suffix
export class UserGuard implements CanLoad {

    constructor(
      private service: AppService
    ) { }

    async canLoad(): Promise<boolean> {
      const permissions: Array<any> = JSON.parse(localStorage.getItem('user'));
      if (!permissions) {
        const userInfo: {user: string} = await this.service.authentication().toPromise().catch(() => undefined);

        if (!userInfo) {
          return false;
        }
        // const perm = await this.service.getProfile(userInfo.user).toPromise().catch(() => undefined);
        // localStorage.setItem('user', JSON.stringify(perm));
        // if (!perm) {
        //   return false;
        // }
        // permissions = perm;
        return true;
      }
      // for (const i of permissions) {
      //   if (i.nomeGrupo.toLowerCase().startsWith('pvd')) {
      //     return true;
      //   }
      // }
      return false;
    }
}
