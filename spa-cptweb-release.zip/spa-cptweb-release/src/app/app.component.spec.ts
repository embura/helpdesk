// tslint:disable-next-line:snt-file-name-suffix
import { TestBed } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { AppService } from './app.service';
import { HubConnectorComponent } from 'angl-spawebbgrl/hub-connector-component/hub-connector';
import { HubConnectorModule } from 'angl-spawebbgrl/spa-http-module/hub-connector.module';
import { LogModule } from 'angl-spawebbgrl/log';
import { GuardsCheckEnd, Router, NavigationCancel } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { MatDialogModule, MatDialogRef, MatDialog } from '@angular/material';
import { GenericDialogComponent } from './modules/catalog/shared/access-dialog/generic-dialog.component';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

class MockRouter {
  public ch = new GuardsCheckEnd(0, '', '', null, true);
  public events = new Observable(observer => {
    observer.next(this.ch);
    observer.complete();
  });
}

@NgModule({
  imports: [
    MatDialogModule,
    BrowserAnimationsModule,
    CommonModule
  ],
  declarations: [
    AppComponent,
    GenericDialogComponent
  ],
  providers: [
    { provide: Router, useClass: MockRouter }
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [GenericDialogComponent]
})
class TestModule { }
describe('AppComponent', () => {
  let app: AppComponent;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        TestModule
      ]
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should execute onInit when navigation is GuardsCheckEnd', () => {
    app.ngOnInit();
  });

  it('should execute navigation when event is NavigationCancel', () => {
    const event: NavigationCancel = new NavigationCancel(1, '', '');

    app['navigationInterceptor'](event);
  });

  it('should execute navigation when event is null', () => {
    app['navigationInterceptor'](null);
  });
});
