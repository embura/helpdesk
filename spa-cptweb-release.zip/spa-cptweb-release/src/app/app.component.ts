import { Router, RouterEvent, GuardsCheckEnd, NavigationCancel } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { GenericDialogComponent } from './modules/catalog/shared/access-dialog/generic-dialog.component';

@Component({
  selector: 'app-cpt-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  private dialogRef: MatDialogRef<GenericDialogComponent>;
  constructor(private router: Router, private matDialog: MatDialog) { }

  private navigationInterceptor(event: RouterEvent): void {
    if (event instanceof GuardsCheckEnd) {
      this.dialogRef.close();
    }
    if (event instanceof NavigationCancel) {
      this.dialogRef.close();
      this.matDialog.open(GenericDialogComponent, {
        data: {
          type: 'error',
          icon: 'error',
          title: 'Não Autorizado',
          content: `Você não possui permissão para acessar o
          Catálogo de Produtos da Tesouraria. Contate o Administrador`
        },
        disableClose: true
      });
    }
  }

  public ngOnInit() {
    this.dialogRef = this.matDialog.open(GenericDialogComponent, {
      data: {
        type: 'auth',
        loading: true,
        title: 'Autenticando'
      },
      disableClose: true
    });

    this.router.events.subscribe((event: RouterEvent) => {
      this.navigationInterceptor(event);
    });

    localStorage.clear();
  }
}
