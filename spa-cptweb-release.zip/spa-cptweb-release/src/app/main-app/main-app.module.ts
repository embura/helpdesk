import { NgModule } from '@angular/core';
import { MainAppComponent } from './main-app.component';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CatalogModule } from '../modules/public_api';
import { PNEAppComponent } from '../modules/catalog/components/pne/pne-app.component';

@NgModule({
    declarations: [
        MainAppComponent,
        PNEAppComponent,
    ],
    imports: [
        SharedModule,
        CatalogModule,
        RouterModule.forChild([
            { path: '', component: MainAppComponent },
            { path: 'pne', component: PNEAppComponent },
        ])
    ]
})
export class MainAppModule {}
