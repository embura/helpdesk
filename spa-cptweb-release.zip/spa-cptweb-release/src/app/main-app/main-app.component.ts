import { Component } from '@angular/core';

@Component({
    templateUrl: './main-app.component.html',
    styleUrls: ['./main-app.component.scss']
})
export class MainAppComponent {

}
