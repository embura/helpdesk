import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
    MatToolbarModule,
    MatProgressSpinnerModule
} from '@angular/material';

@NgModule({
    imports: [
        MatToolbarModule,
        MatProgressSpinnerModule,
        CommonModule
    ],
    exports: [
        MatToolbarModule,
        MatProgressSpinnerModule,
        CommonModule
    ]
})
export class SharedModule { }
