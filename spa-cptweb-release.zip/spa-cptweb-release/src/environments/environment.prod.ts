export const env = 'prod';
export const hubHost = 'https://esbapi.santanderbr.pre.corp';
export const hubSSO = 'https://ssohub-prd.bs.br.bsch';
export const jsonSsoKey = 'url_hub_sso_homolog';
