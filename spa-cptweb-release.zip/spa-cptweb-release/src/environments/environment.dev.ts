export const env = 'develop';
export const hubHost = 'https://esbapi.isbanbr.dev.corp';
export const hubSSO = 'https://wastfcdvlbr01.bs.br.bsch';
export const jsonSsoKey = 'url_hub_sso';
