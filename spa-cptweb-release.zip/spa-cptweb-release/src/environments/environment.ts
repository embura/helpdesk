// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
import { hubHost, hubSSO, env, jsonSsoKey } from './environment.dev';

const defaultHost = 'localhub.santanderbr.corp:8443';
const appKey = '096bd5f01e670136a9bf0050569009ca';

export const getUrl = (url: string) => `${hubHost}${url}?gw-app-key=${appKey}`;

export const environment = {
  env,
  jsonSsoKey,
  hubHost,
  BACKEND_DOMAIN_NAME: `https://${defaultHost}`,
  SSO_SERVER_URL: `https://${defaultHost}/sso/authenticate/internal-basic`,
  urls: {
    security: {
      MBS_SERVER_URL: (login: string) => getUrl(`/seguranca/v1/permissoes/grupo/${login.toLowerCase()}`)
    }
  }
};
