export const env = 'homolog';
export const hubHost = 'https://esbapi.santanderbr.pre.corp';
export const hubSSO = 'https://ssohub-hml.bs.br.bsch';
export const jsonSsoKey = 'url_hub_sso_homolog';
