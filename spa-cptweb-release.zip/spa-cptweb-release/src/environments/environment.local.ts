export const env = 'mock';
export const hubHost = 'http://local.santanderbr.pre.corp:8080/cat-produtos';
export const hubSSO = 'http://local.santanderbr.pre.corp:8002';
export const jsonSsoKey = 'url_hub_sso_mock';
