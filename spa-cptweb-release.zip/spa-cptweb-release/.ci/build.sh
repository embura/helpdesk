npm install && npm run build:lib
