<img src="https://gitlab.produbanbr.corp/BR-SNT-PVD/spa-cptweb/raw/develop/src/assets/santander_vermelho.svg" width="200" style="margin-left:100px">


[![build status](https://gitlab.produbanbr.corp/BR-SNT-PVD/spa-cptweb/badges/develop/build.svg)](https://gitlab.produbanbr.corp/BR-SNT-PVD/spa-cptweb/commits/develop)
[![coverage report](https://gitlab.produbanbr.corp/BR-SNT-PVD/spa-cptweb/badges/develop/coverage.svg)](https://gitlab.produbanbr.corp/BR-SNT-PVD/spa-cptweb/commits/develop)

# CPT - Catálogo Produtos Tesouraria

> Aplicação SPA responsável pelo gerenciamento dos produtos da tesouraria.


## Instalação do ambiente para desenvolvomento

```terminal
npm install 
```


### Para fazer o git pull precisa instalar o SSH-Key

1. Entrar no "Profile Setings" no menu do gitlab e selecionar a aba "SSH Keys".
2. Segue a [instrução oficial do gitlab](https://gitlab.produbanbr.corp/help/ssh/README) para gerar e cadastrar a chave.

### Dependencias
```terminal
npm install --save @angular/material @angular/cdk @angular/platform-browser
```

add to CSS
```
@import "~@angular/material/prebuilt-themes/indigo-pink.css";
```


### Alterar o hosts file do windows

abrir o arquivo `C:\Windows\System32\drivers\etc\hosts` e adicionar a linha abaixo.

```code
127.0.0.1 local.isbanbr.dev.corp
```

## 1) Iniciar o Development server
Run `npm start` for a dev server. Navigate to `http://local.isbanbr.dev.corp/`. The app will automatically reload if you change any of the source files.

## 2) npm install
Before running `npm install`, npm registry have to be set to Nexus with command below:
```terminal
npm -g config set registry http://nexus.produbanbr.corp/repository/npm-all
```

## 3) Build
Run `npm run build` to build the project with Ahead of Time. The build artifacts will be stored in the `html/` directory.

--

## 4) Versioning Control (Git)

### 4.1 Working on a feature:
1.  Create a branch:     `git checkout -b branch_name`
2.  Commit changes:      `git add .`  /  `git commit -m "feat(scope): description"`
3.  When you are done, go to branch 'develop':   `git checkout develop`
4.  Update 'develop':    `git pull --rebase`
5.  Merge branch feature into 'develop':     `git merge branch_name`
6.  Resolve conflicts (if any) then commit:     `git add .` / `git commit -m "Conflicts resolved(branch_name>develop)"`

### 4.2 Commit Message Format:
`<type>(<scope>): <subject>`

The type and scope should always be lowercase as shown below.

`<type>` values:

- __feat__ (new feature for the user, not a new feature for build script)
- __fix__ (bug fix for the user, not a fix to a build script)
- __docs__ (changes to the documentation)
- __style__ (formatting, missing semi colons, etc; no production code change)
- __refactor__ (refactoring production code, eg. renaming a variable)
- __test__ (adding missing tests, refactoring tests; no production code change)
- __chore__ (updating grunt tasks etc; no production code change)

*__EXAMPLE__* : `git commit -m "feat(search): CNPJ Mask created"`

### 4.3 Commit Helper
You can use the command `npm run commit` to follow this format more easily.


## 5) Styles

### 5.1 Folder Sctructure
There are basically 3 types of places to insert our styles:
-   __Base__: the defaults. `(ex: html, body, form, a...)`
-   __Layout__: divide pages into sections. `(ex: #header, #footer, ...)`
-   __Modules__: reusable, modular parts. `(ex: .name-initials, .card, .side-menu, ...)`

```js
src/
|-- search/
|   |-- search.component.scss       // Module type
|   ...
|
...
|
|-- styles/
|   |--layout/                      //Layout type
|   |   |-- _navbar.scss
|   |   |-- _sidemenu.scss
|   |   |-- _context-buttons.scss
|   |   ...
|   |
|   |-- base.scss                   // Base type
|
|-- styles.scss                     // Import vendors, base.css and layout files    
|
|...
```

### 5.2 Naming Conventions (BEM - Blocks, Elements and Modifiers)
We use BEM(http://www.getbem.com) style to write css code.
-   __BLOCK__: Entity that is meaningful on its own;
-   __ELEMENT__: A part of a block that is semantically tied to its block;
-   __MODIFIER__: A flagon a block OR element.

```scss
/* block */
.card {
}
/* element */
.card__title {
}
/* modifier */
.card__title--big {
}
```

SASS way:

```scss
.card {
    &__title {
        &--big {
        }
    }
}
```


### 5.3 Good Practices
-   1 whitespace between element and brace
-   Line-break between styles and new element
-   Line-break after closed brace
-   Using HEX instead RGB for colors
-   Convert HEX to RGB with Sass

```css
color: rgba(255,255,255,.3);    (Bad)
color: rgba(#000,.3);           (Good) :)
```

-   DRY (Don't Repeat Yourself)
-   Readability over small size 

```css
.sb        (Bad)
.sidebar   (Good) :)
```

### 5.4 Avoid
-   Avoid ID's
-   Avoid `!important`
-   Avoid child-selector. Use classes instead!

```css
 .m-tabs > li {}        (Bad)
 .m-tabs .tab-item {}   (Good) :)
 .m-tabs__item {}         (Better!) :D
```
