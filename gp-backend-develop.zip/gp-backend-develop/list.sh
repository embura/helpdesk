#/bin/bash

pwd
echo '------'
ls
echo 'lib: ------'
ls ./lib