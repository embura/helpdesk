module.exports = {
  "collectCoverage": true,
  "collectCoverageFrom": ["src/**/*.ts"],
  "roots": [ "<rootDir>/e2e" ],
  "coverageReporters": [ "json", "lcov", "text" ],
  "reporters": ["jest-tap-reporter"],
  "transform": { "^.+\\.tsx?$": "ts-jest" },
  "testRegex": "(/__tests__/.*|(\\.|/)(e2e))\\.(jsx?|tsx?)$",
  "moduleFileExtensions": [ "ts", "tsx", "js", "jsx", "json", "node" ],
  "coverageDirectory": "./coverage"
}
