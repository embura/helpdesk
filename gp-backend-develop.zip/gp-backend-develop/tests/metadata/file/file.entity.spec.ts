import 'reflect-metadata';
import { FileRowMapper } from '../../../src/metadata/file/file.entity';

describe('File Entity', async () => {
  const row = {};
  it('RowMapper', () => {
    const file = new FileRowMapper();
    const mapper = file.map(row);
    expect(mapper).toBeTruthy();
  });
});