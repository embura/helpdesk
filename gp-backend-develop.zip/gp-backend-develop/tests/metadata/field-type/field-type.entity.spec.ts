import 'reflect-metadata';
import { FieldTypeRowMapper } from '../../../src/metadata/fieldType/fieldType.entity';

describe('FieldType Entity', async () => {
  const row = {};
  it('RowMapper', () => {
    const fieldType = new FieldTypeRowMapper();
    const mapper = fieldType.map(row);
    expect(mapper).toBeTruthy();
  });
});