import 'reflect-metadata';
import { FieldRowMapper } from '../../../src/metadata/field/field.entity';

describe('Field Entity', () => {
  const row = {};
  it('RowMapper', () => {
    const field = new FieldRowMapper();
    const mapper = field.map(row);
    expect(mapper).toBeTruthy();
  });
});