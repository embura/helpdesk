import 'reflect-metadata';
import sinon = require('sinon');
import { MovimentRepository } from '../../src/moviment/moviment.repository';

jest.mock('../../src/shared/utils/parse-date');
import { dateToYYYMMMDD } from '../../src/shared/utils/parse-date';
import { SqlHandler } from '../../src/shared/lib/database/query-handler';
import { Moviment } from '../../src/moviment/moviment.entity';
import moment = require('moment');
(dateToYYYMMMDD as any).mockImplementation(() => '20180101');

describe('ImportFileService', () => {

  let movimentRepository: MovimentRepository;

  beforeEach(() => {
    movimentRepository = new MovimentRepository();
    (movimentRepository as any).queryHandler = sinon.createStubInstance(SqlHandler);
    (movimentRepository as any).commandHandler = sinon.createStubInstance(SqlHandler);
    (movimentRepository as any).sequenceQueryHandler = sinon.createStubInstance(SqlHandler);
  });

  describe('MovimentRepository', () => {
    it('should create', () => {
      expect(movimentRepository).toBeTruthy();
    });

    it('findByEvent', async () => {
      const mockResult = Symbol('result');
      (movimentRepository as any).queryHandler.execute.resolves(mockResult);
      const mockInput = new Moviment();

      const result = await movimentRepository.findByEvent(mockInput, 'x');
      expect(result).toBe(mockResult);
    });

    it('findByGlobalIdAndDate', async () => {
      const mockResult = Symbol('result');
      (movimentRepository as any).queryHandler.execute.resolves(mockResult);
      const mockInput = new Moviment();

      const result = await movimentRepository.findByGlobalIdAndDate(mockInput);
      expect(result).toBe(mockResult);
    });

    it('getDataToExport', async () => {
      const mockResult = Symbol('result');
      (movimentRepository as any).queryHandler.execute.resolves(mockResult);
      const mockInput = { product: 'filename', fileDate: new Date() };

      const result = await movimentRepository.getDataToExport(mockInput);
      expect(result).toBe(mockResult);
    });

    it('update', async () => {
      const mockResult = Symbol('result');
      (movimentRepository as any).commandHandler.execute.resolves();
      const mockInput = new Moviment();

      await movimentRepository.update(mockInput, '1');
      expect(mockResult).toBe(mockResult);
    });

    it('create', async () => {
      const mockInput = new Moviment();
      mockInput.id = '1';
      (movimentRepository as any).commandHandler.execute.resolves(mockInput.id);

      const result = await movimentRepository.create(mockInput);
      expect(result).toEqual(mockInput.id);
    });

    it('parseUpdate', () => {
      const newMov = new Moviment();
      newMov.id = '1';
      newMov.globalId = '1';
      newMov.dateBase = new Date();

      let query = `GPOS.TB_MOVI_TESO \
        SET CD_GLOB_ID_OPER_REFE = :globalId, \
        DT_BASE_SIST = TO_DATE('20180101', 'YYYYMMDD') \
        WHERE CD_GLOB_ID_EVEN = :id`;

      query = query.replace(/[ ]{1,50}/g, ' ');

      const result = movimentRepository['parseUpdate'](newMov);
      expect(query).toEqual(result);
    });

    it('parseCreate', () => {
      const newMov = new Moviment();
      newMov.id = '1';
      newMov.globalId = '1';
      newMov.dateBase = new Date();

      let query = `INTO GPOS.TB_MOVI_TESO (CD_GLOB_ID_EVEN, CD_GLOB_ID_OPER_REFE, DT_BASE_SIST)\
        VALUES ('1', '1', TO_DATE('20180101', 'YYYYMMDD'))`;

      query = query.replace(/[ ]{1,50}/g, ' ');

      const result = movimentRepository['parseCreate'](newMov);
      expect(query).toEqual(result);
    });
  });
});
