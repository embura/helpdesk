import 'reflect-metadata';
import { MovimentService } from '../../src/moviment/moviment.service';
import { MovimentRepository } from '../../src/moviment/moviment.repository';
import { ProductRepository } from '../../src/product/product.repository';
import * as sinon from 'sinon';

import { PositionService } from '../../src/position/position.service';
import { BaseDateService } from '../../src/base-date/base-date.service';
import { SystemStatusService } from '../../src/system-status/system_status.service';
import { Moviment } from '../../src/moviment/moviment.entity';
import { Position } from '../../src/position/position.entity';
import moment = require('moment');
import { SystemStatus } from '../../src/system-status/system_status.enum';
import { PositionRepository } from '../../src/position/position.repository';
import { oracleErrorHandler, ServiceErrorHandler } from '../../src/shared/common/common.error';
import { CategoryMessage } from '../../src/shared/common/message.model';
import { MovimentMessage } from '../../src/moviment/moviment.msg';
import { doesNotThrow } from 'assert';
import { HttpException } from '@nestjs/common/exceptions';

describe('Moviment Service', () => {

  // const movimentRepository = jest.fn(() => {
  //   return { findByGlobalIdAndDate: jest.fn() };
  // });
  // const productRepository = jest.fn(() => {
  //   return { findAll: jest.fn()};
  // });
  let movementService: MovimentService;

  let movimentRepository: sinon.SinonStubbedInstance<MovimentRepository>;
  let productRepository: sinon.SinonStubbedInstance<ProductRepository>;
  let positionService: sinon.SinonStubbedInstance<PositionService>;
  let systemStatusService: sinon.SinonStubbedInstance<SystemStatusService>;
  let baseDateService: sinon.SinonStubbedInstance<BaseDateService>;
  let positionRepository: sinon.SinonStubbedInstance<PositionRepository>;

  beforeEach(() => {

    movimentRepository = sinon.createStubInstance(MovimentRepository);
    productRepository = sinon.createStubInstance(ProductRepository);
    positionService = sinon.createStubInstance(PositionService);
    baseDateService = sinon.createStubInstance(BaseDateService);
    systemStatusService = sinon.createStubInstance(SystemStatusService);
    positionRepository = sinon.createStubInstance(PositionRepository);

    movementService = new MovimentService(
      movimentRepository as any,
      productRepository as any,
      positionService as any,
      systemStatusService as any,
      baseDateService as any
      );
  });

  it('should create', () => {
    expect(movementService).toBeTruthy();
  });

  it('findByGlobalIdAndDate', async () => {
    (movementService as any).movimentRepository.findByGlobalIdAndDate = jest.fn();
    await movementService.findByGlobalIdAndDate('x' as any);
    expect(await (movementService as any).movimentRepository.findByGlobalIdAndDate).toBeCalled();
  });

  it('findByEvent', async () => {
    (movementService as any).movimentRepository.findByEvent = jest.fn();
    await movementService.findByEvent('x' as any, 'y' as any);
    expect(await (movementService as any).movimentRepository.findByEvent).toBeCalled();
  });

  it('getDataToExport', async () => {
    (movementService as any).movimentRepository.getDataToExport = jest.fn(() => {
      return [
        {},
      ];
    });
    (productRepository as any).findAll = jest.fn( () => {
      return [
        {},
      ];
    });

    await movementService.getDataToExport('x' as any);
    expect(await (movementService as any).movimentRepository.getDataToExport).toBeCalled();
  });

  it('update', async () => {
    (movementService as any).movimentRepository.update = jest.fn();
    (movementService as any).movimentRepository.findByEvent = jest.fn(() => {
      return [{
        updateParams: jest.fn(() => {}),
      }];
    });
    await movementService.update('x' as any);
    expect(await (movementService as any).movimentRepository.update).toBeCalled();
  });

  it('findMoviment', async () => {
    const moviments = await movimentRepository.findMoviment.resolves( new Array<Moviment>());
    const movis = await movementService.findMoviment('PVD_201904290001', new Date(), 'NO', 'E');
    expect(movis).toEqual([]);
  });

  it('createPositionByMovement', async  () => {
    const positionLastDate = await positionService.getLastDatePosition.resolves(moment().format('YYYYMMDD'));
    const movement: Moviment =  new Moviment();
    movement.globalId = 'PVD_201904290001';
    movement.dateBase = moment().toDate();

    const position = await movementService.createPositionByMovement(movement);

    expect(position.id).toBe(movement.globalId);
    expect(moment(position.positionDate).format('YYYYMMDD')).toBe(moment(movement.dateBase).format('YYYYMMDD'));
  });

  it('transaction contract', async  () => {
    const date: Date = moment().toDate();
    const baseDate = await baseDateService.getDefaultDate.resolves(moment().format('YYYYMMDD'));
    const statusDefault = await systemStatusService.getStatus.resolves(SystemStatus);

    const movement: Moviment =  new Moviment();
    movement.id = 'PVD_201904290001';
    movement.globalId = 'PVD_201904290001';
    movement.dateBase = date;
    movement.moviGFCode = 'NO';

    (movementService as any).contract = jest.fn( () => movement);
    const mov = await movementService.transaction(movement);

    expect(mov.id).toBe(movement.globalId);
    expect(moment(mov.positionDate).format('YYYYMMDD')).toBe(moment(movement.dateBase).format('YYYYMMDD'));
  });

  describe('create', () => {

    it('sucesso ', async () => {
      const date: Date = moment().toDate();
      const movement: Moviment =  new Moviment();
      movement.id = 'PVD_201904290001';
      movement.globalId = 'PVD_201904290001';
      movement.dateBase = date;
      movement.moviGFCode = 'NO';
      movement.moviType  = 'E';
      await movimentRepository.create.resolves(movement);
      const mov = await movementService.create(movement);

      expect(mov.id).toBe(movement.id);
    });

    it('error ', async () => {
      const date: Date = moment().toDate();
      const movement: Moviment =  new Moviment();
      movement.id = 'PVD_201904290002';
      movement.globalId = 'PVD_201904290002';
      movement.dateBase = date;
      movement.moviGFCode = 'NO';
      movement.moviType  = 'E';

      await movimentRepository.create.rejects( () => {
        throw new Error('[ERROR]Create unique constraint');
      });

      const mov = await movementService.create(movement).catch( (error) => {
        return error;
      });

      expect(mov).toThrow('[ERROR]Create unique constraint');
    });

  });

  describe('Cancel' , async () => {

    it('repurchase', async () => {
      const date: Date = moment().toDate();
      const movement: Moviment =  new Moviment();
      movement.id = 'PVD_201904290001';
      movement.globalId = 'PVD_201904290002';
      movement.dateBase = date;
      movement.moviGFCode = 'ES';
      movement.moviType  = 'S';

      let position: Position = new Position();
      position.id = movement.globalId;
      position.positionDate = movement.dateBase;

      position.dateConv = date;
      position.dateEfet = date;
      position.dateSolic = date;
      position.dueDate = moment(date).add({year: 2}).toDate();

      position =  movementService.cancelPosition(position, movement);

      const positions: Position[] = [];
      positions.push(position);
      const movements: Moviment[] = [];
      movements.push(movement);

      await movimentRepository.findMoviment.resolves(movements);
      await positionRepository.update.resolves(position);

      movimentRepository.update.resolves(async () => movement);
      await movimentRepository.findByEvent.resolves(movements);

      await positionService.findByGlobalIdAndDate.resolves(positions);
      positionService.update.resolves(async () => movement);

      const mov = await movementService.cancel(movement);
      expect(mov).toEqual(undefined);
    });
  });

  describe('contract', () => {
    it('sucess ', async () => {
      const date: Date = moment().toDate();
      const movement: Moviment =  new Moviment();
      await positionService.getLastDatePosition.resolves(moment().format('YYYYMMDD'));

      let  movi: Moviment;
      movement.id = 'PVD_201904290002';
      movement.globalId = 'PVD_201904290002';
      movement.dateBase = date;
      movement.moviGFCode = 'NO';
      movement.moviType  = 'E';

      (movementService as any).findById = jest.fn();
      (movementService as any).create = jest.fn( () => Promise.resolve(movement));

      const position: Position = new Position();
      position.id = movement.globalId;
      position.positionDate = movement.dateBase;

      position.dateConv = date;
      position.dateEfet = date;
      position.dateSolic = date;
      position.dueDate = moment(date).add({year: 2}).toDate();

      await positionService.create.resolves(position);

      movi =  await movementService.contract(movement);

      expect(movi.id).toEqual(movement.id);
      expect(moment(movi.positionDate).format('YYYYMMDD')).toBe(moment(movement.dateBase).format('YYYYMMDD'));
    });

    it.skip('error ', async (done) => {
      const date: Date = moment().toDate();
      const movement: Moviment =  new Moviment();
      await positionService.getLastDatePosition.resolves(moment().format('YYYYMMDD'));

      // let  movi: Moviment;
      movement.id = 'PVD_201904290002';
      movement.globalId = 'PVD_201904290002';
      movement.dateBase = date;
      movement.moviGFCode = 'NO';
      movement.moviType  = 'E';

      (movementService as any).findById = jest.fn();
      (movementService as any).create = jest.fn( () => Promise.reject('unique constraint'));

      await movimentRepository.findOne.resolves(movement);
      // await movimentRepository.create.rejects('unique constraint');

      await movimentRepository.create.rejects( () => {
        throw new Error('[ERROR]Create unique constraint');
      });

      const position: Position = new Position();
      position.id = movement.globalId;
      position.positionDate = movement.dateBase;

      position.dateConv = date;
      position.dateEfet = date;
      position.dateSolic = date;
      position.dueDate = moment(date).add({year: 2}).toDate();

      await positionService.create.rejects('unique constraint 2');

      const mov: Moviment =  await movementService.contract(movement);

      // expect(mov).toThrowError();
    });

  });

  it('repurchase', async () => {
    const date: Date = moment().toDate();
    const movement: Moviment =  new Moviment();
    await positionService.getLastDatePosition.resolves(moment().format('YYYYMMDD') );

    let  movi: Moviment;
    movement.id = 'PVD_201904290001';
    movement.globalId = 'PVD_201904290002';
    movement.dateBase = date;
    movement.moviGFCode = 'NO';
    movement.moviType  = 'S';
    const movements: Moviment[] = [];
    movements.push(movement);

    (movementService as any).findById = jest.fn();
    (movementService as any).create = jest.fn( () => {
      return Promise.resolve(movement);
    });

    (movementService as any).findByGlobalIdAndDate = jest.fn( () => {
      return Promise.resolve(movements);
    });
    positionService.findByGlobalIdAndDate.resolves(new Array<Position>());

    const position: Position = new Position();
    position.id = movement.globalId;
    position.positionDate = movement.dateBase;

    position.dateConv = date;
    position.dateEfet = date;
    position.dateSolic = date;
    position.dueDate = moment(date).add({year: 2}).toDate();

    await positionService.create.resolves(position);

    movi =  await movementService.repurchase(movement);

    expect(movi.id).toEqual(movement.id);
    expect(moment(movi.positionDate).format('YYYYMMDD')).toBe(moment(movement.dateBase).format('YYYYMMDD'));
  });

});
