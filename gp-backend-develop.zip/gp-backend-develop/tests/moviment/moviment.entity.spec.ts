import 'reflect-metadata';
import { MovimentRowMapper } from '../../src/moviment/moviment.entity';

describe('Moviment Entity', () => {
  const row = {};
  it('RowMapper', () => {
    const moviment = new MovimentRowMapper();
    const mapper = moviment.map(row);
    expect(mapper).toBeTruthy();
  });
});