import { MovimentController } from '../../src/moviment/moviment.controller';
import { ResTester } from '../res-req.mock';
import * as sinon from 'sinon';
import { MovimentService } from '../../src/moviment/moviment.service';
import { Moviment } from '../../src/moviment/moviment.entity';
import { BaseDate } from '../../src/base-date/base-date.entity';
import { BadRequestException, HttpException } from '@nestjs/common';
import { HttpResponse } from '../../src/shared/http.response';
import { Status } from '../../src/shared/status.entity';

let movimentService: sinon.SinonStubbedInstance<MovimentService>;
let movimentController: MovimentController;
let movement: sinon.SinonStubbedInstance<Moviment>;

const dataBase = new BaseDate();
dataBase.id = new  Date();
dataBase.statusInt = 4;

describe('Find Client', () => {
  let responseMock: ResTester;

  beforeEach(() => {
    responseMock = new ResTester();
    movement = sinon.createStubInstance<Moviment>(Moviment);
    movimentService = sinon.createStubInstance(MovimentService);
    movimentController = new MovimentController(
      movimentService as any
    );
  });

  it('should create transaction sucess', async () => {
    await movimentService.transaction.resolves( () => {
      return responseMock.stub.status(200).json(
        new HttpResponse(new Status(200, ''), {})
      );
    });

    movimentController.contract(responseMock.stub, movement as any)
    .then( res => {
      expect(res.statusCode).toBe(undefined);
    });
  });

  it('should create transaction error', async () => {
    await movimentService.transaction.rejects(() => {
      return new BadRequestException('[MovimentService] movement error');
    });

    movimentController.contract(responseMock.stub, movement as any)
    .catch( (err) => {
      console.error('[MovementControllerTest] err: ', err);
      expect(err.statusCode).toBe(undefined);
    });
  });

});
