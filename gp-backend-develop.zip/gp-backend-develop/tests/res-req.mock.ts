import {stub} from 'sinon';
import { Response, Request } from 'express';

export class ResTester {
  stub = new FakeResImpl();
  get json(): any {
    return this.stub.json.firstCall.args[0];
  }
  get statusCode(): number {
    if (!this.stub.status.lastCall) {
      return 200;
    }
    return this.stub.status.lastCall.args[0];
  }

}

class FakeResImpl implements Response {

  // Stubs
  statusCode: number;
  statusMessage: string;
  headersSent: boolean;
  writable: boolean;
  status = stub().returns(this);
  // Response Implemention
  app: any;
  connection: any;
  setTimeout: any;
  chunkedEncoding: boolean;
  shouldKeepAlive: boolean;
  useChunkedEncodingByDefault: boolean;
  sendDate: boolean;
  finished: boolean;
  upgrading: boolean;

  eventNames = stub().returns(this);
  setDefaultEncoding = stub().returns(this);
  setMaxListeners = stub().returns(this);
  cork = stub().returns(this);
  uncork = stub().returns(this);
  emit = stub().returns(this);
  on = stub().returns(this);
  once = stub().returns(this);
  prependListener = stub().returns(this);
  prependOnceListener = stub().returns(this);
  pipe = stub().returns(this);
  listenerCount = stub().returns(this);
  listeners = stub().returns(this);
  eve = stub().returns(this);
  _destroy = stub().returns(this);
  _final = stub().returns(this);
  _write = stub().returns(this);
  write = stub().returns(this);
  destroy = stub().returns(this);
  removeAllListeners = stub().returns(this);
  removeListener = stub().returns(this);
  addTrailers = stub().returns(this);
  addListener = stub().returns(this);
  flushHeaders = stub().returns(this);
  removeHeader = stub().returns(this);
  setHeader = stub().returns(this);
  hasHeader = stub().returns(this);
  getHeader = stub().returns(this);
  getHeaders = stub().returns(this);
  getHeaderNames = stub().returns(this);
  getMaxListeners = stub().returns(this);
  json = stub().returns(this);
  assignSocket = stub().returns(this);
  detachSocket = stub().returns(this);
  writeContinue = stub().returns(this);
  writeHead = stub().returns(this);
  append = stub().returns(this);
  attachement = stub().returns(this);
  clearCookie = stub().returns(this);
  cookie = stub().returns(this);
  download = stub().returns(this);
  sendfile = stub().returns(this);
  contentType = stub().returns(this);
  end = stub().returns(this);
  attachment = stub().returns(this);
  header = stub().returns(this);
  charset = '';
  format = stub().returns(this);
  get = stub().returns(this);
  jsonp = stub().returns(this);
  links = stub().returns(this);
  locals = {};
  location = stub().returns(this);
  redirect = stub().returns(this);
  render = stub().returns(this);
  send = stub().returns(this);
  sendFile = stub().returns(this);
  sendStatus = stub().returns(this);
  set = stub().returns(this);
  type = stub().returns(this);
  vary = stub().returns(this);

}
