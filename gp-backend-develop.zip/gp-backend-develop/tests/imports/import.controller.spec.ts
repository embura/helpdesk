import 'reflect-metadata';
import * as sinon from 'sinon';
import { HttpStatus } from '@nestjs/common';
import { ResTester } from '../res-req.mock';
import { ImportFileService } from '../../src/imports/import.service';
import { ImportFileController } from '../../src/imports/import.controller';

describe('Import controller', () => {
  // mocks and stubs
  let stubImportFileService: sinon.SinonStubbedInstance<ImportFileService>;
  let responseMock: ResTester;
  let requestMock;
  // class to test
  let importFileController: ImportFileController;
  const file  = {
    originalname: 'fileName',
    buffer: '',
  };

  // initializing
  beforeEach(() => {
    responseMock = new ResTester();
    requestMock = {
      body: {
        headerIdentifier: '',
        trailerIdenfier: '',
        filename: '',
      },
    };

    stubImportFileService = sinon.createStubInstance(ImportFileService);

    importFileController = new ImportFileController(
      stubImportFileService as any
    );
  });

  it('import', async () => {
    stubImportFileService.processRequest.resolves(['result']);

    await stubImportFileService.processRequest.resolves(['result']);

    await importFileController.import(responseMock.stub, file, requestMock as any);
    expect(responseMock.statusCode).toBe(HttpStatus.OK);
  });

  it('importSegment', async () => {
    stubImportFileService.processRequest.resolves(['result']);

    await stubImportFileService.processRequest.resolves(['result']);

    await stubImportFileService.startImportSegment.resolves(['result']);

    await importFileController.importSegment(responseMock.stub, file, requestMock as any);
    expect(responseMock.statusCode).toBe(HttpStatus.OK);
  });

});