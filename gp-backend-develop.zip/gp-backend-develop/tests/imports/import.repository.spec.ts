import 'reflect-metadata';

import { ImportRepository } from '../../src/imports/import.repository';

jest.mock('../../src/shared/utils/parse-date');
import { dateToYYYMMMDD } from '../../src/shared/utils/parse-date';
import { ProductRepository } from '../../src/product/product.repository';
import * as sinon from 'sinon';
import { ProductService } from '../../src/product/product.service';
import { Product } from '../../src/product/product.entity';
import * as moment from 'moment';
import { PositionPenumperRepository } from '../../src/position-penumper/position-penumper.repository';
import { BaseDateProductRepository } from '../../src/base-date-product/base-date-product.repository';
import { SqlHandler } from '../../src/shared/lib/database/query-handler';

(dateToYYYMMMDD as any).mockImplementation(() => '20180101');

const fileInfo = {
  product: 'CPT',
  type: 'parametros',
  fileDate: new Date(),
  id: 5,
  separator: ',',
};

const data1 = [[{
  id: 96,
  fileId: 5,
  name: 'CD-CAT',
  table: 'GPOS.TB_PROD_TESO',
  column: 'CD_CATG_SUBP',
  size: 2,
  filler: ' ',
  type: { id: 1, name: 'A', mask: null, decimals: null, digits: null },
  start_pos: null,
  seq_pos: 11,
  obrig: 1,
  value: '2',
},
{
  id: 97,
  fileId: 5,
  name: 'CD-GRAU-RISC',
  table: 'GPOS.TB_PROD_TESO',
  column: 'CD_GRAU_RISC_SUBP',
  size: 1,
  filler: '0',
  type: { id: 2, name: 'N', mask: null, decimals: null, digits: null },
  start_pos: null,
  seq_pos: 12,
  obrig: 1,
  value: 2,
},
{
  id: 99,
  fileId: 5,
  name: 'CD-OBRI-API',
  table: 'GPOS.TB_PROD_TESO',
  column: 'CD_OBRI_API',
  size: 1,
  filler: ' ',
  type: { id: 1, name: 'A', mask: null, decimals: null, digits: null },
  start_pos: null,
  seq_pos: 14,
  obrig: 1,
  value: 'O',
},
{
  id: 98,
  fileId: 5,
  name: 'CD-PRAZ',
  table: 'GPOS.TB_PROD_TESO',
  column: 'CD_PRAZ_SUBP',
  size: 1,
  filler: ' ',
  type: { id: 1, name: 'A', mask: null, decimals: null, digits: null },
  start_pos: null,
  seq_pos: 13,
  obrig: 1,
  value: 'L',
},
{
  id: 92,
  fileId: 5,
  name: 'CD-PROD',
  table: 'GPOS.TB_PROD_TESO',
  column: 'CD_GRUP_PROD',
  size: 12,
  filler: ' ',
  type: { id: 1, name: 'DT', mask: null, decimals: null, digits: null },
  start_pos: null,
  seq_pos: 7,
  obrig: 1,
  value: 0,
},
{
  id: 93,
  fileId: 5,
  name: 'CD-PROD-SBK',
  table: 'GPOS.TB_PROD_TESO',
  column: 'CD_PROD_SBK',
  size: 12,
  filler: ' ',
  type: { id: 1, name: 'DT', mask: null, decimals: null, digits: null },
  start_pos: null,
  seq_pos: 8,
  obrig: 1,
  value: 'CRI11L00186',
}],
[
  {
    id: 96,
    fileId: 5,
    name: 'CD-CAT',
    table: 'GPOS.TB_PROD_TESO',
    column: 'CD_CATG_SUBP',
    size: 2,
    filler: ' ',
    type: { id: 1, name: 'A', mask: null, decimals: null, digits: null },
    start_pos: null,
    seq_pos: 11,
    obrig: 1,
    value: '2',
  },
  {
    id: 97,
    fileId: 5,
    name: 'CD-GRAU-RISC',
    table: 'GPOS.TB_PROD_TESO',
    column: 'CD_GRAU_RISC_SUBP',
    size: 1,
    filler: '0',
    type: { id: 2, name: 'N', mask: null, decimals: null, digits: null },
    start_pos: null,
    seq_pos: 12,
    obrig: 1,
    value: 2,
  },
  {
    id: 99,
    fileId: 5,
    name: 'CD-OBRI-API',
    table: 'GPOS.TB_PROD_TESO',
    column: 'CD_OBRI_API',
    size: 1,
    filler: ' ',
    type: { id: 1, name: 'A', mask: null, decimals: null, digits: null },
    start_pos: null,
    seq_pos: 14,
    obrig: 1,
    value: 'O',
  },
  {
    id: 98,
    fileId: 5,
    name: 'CD-PRAZ',
    table: 'GPOS.TB_PROD_TESO',
    column: 'CD_PRAZ_SUBP',
    size: 1,
    filler: ' ',
    type: { id: 1, name: 'A', mask: null, decimals: null, digits: null },
    start_pos: null,
    seq_pos: 13,
    obrig: 1,
    value: 'L',
  },
  {
    id: 92,
    fileId: 5,
    name: 'CD-PROD',
    table: 'GPOS.TB_PROD_TESO',
    column: 'CD_GRUP_PROD',
    size: 12,
    filler: ' ',
    type: { id: 1, name: 'A', mask: null, decimals: null, digits: null },
    start_pos: null,
    seq_pos: 7,
    obrig: 1,
    value: 'CPT02',
  },
  {
    id: 93,
    fileId: 5,
    name: 'CD-PROD-SBK',
    table: 'GPOS.TB_PROD_TESO',
    column: 'CD_PROD_SBK',
    size: 12,
    filler: ' ',
    type: { id: 1, name: 'A', mask: null, decimals: null, digits: null },
    start_pos: null,
    seq_pos: 8,
    obrig: 1,
    value: 'BRPR21',
  }]];

// const fileInfo = {
//   product: 'sbk',
//   type: 'movi',
//   fileDate: '2018 - 08 - 30T03: 00: 00.000Z',
//   id: 1,
//   separator: null ,
// };

describe('Import Repository', () => {
  // Connection
  let importRepository: ImportRepository;
  let productService: sinon.SinonStubbedInstance<ProductService>;
  let importPositionRepository: sinon.SinonStubbedInstance<PositionPenumperRepository>;
  let baseDateProductRepository: sinon.SinonStubbedInstance<BaseDateProductRepository>;

  beforeEach(() => {
    // Connection
    importPositionRepository = sinon.createStubInstance(PositionPenumperRepository);
    baseDateProductRepository = sinon.createStubInstance(BaseDateProductRepository);

    productService = sinon.createStubInstance(ProductService);
    importRepository = new ImportRepository(
      productService as any,
      baseDateProductRepository as any,
      importPositionRepository as any
    );

    (importRepository as any).queryHandler = sinon.createStubInstance(SqlHandler);
    (importRepository as any).commandHandler = sinon.createStubInstance(SqlHandler);
    (importRepository as any).sequenceQueryHandler = sinon.createStubInstance(SqlHandler);
  });

  it('should create', () => {
    expect(importRepository).toBeTruthy();
  });

  it('insertData', async () => {
    (importRepository as any).commandHandler.execute.resolves('OK');
    baseDateProductRepository.findOne.resolves({baseDate: new Date()});
    productService.findAll.resolves([new Product()]);

    const result = await importRepository.insertData(data1, fileInfo);
    expect(result).toEqual('OK');
  });

  it('updateSegment', async () => {
    (importRepository as any).commandHandler.execute.resolves({ rowsAffected: 1 });
    importPositionRepository.getPenumpers.resolves([{penumper: '000000'}]);
    baseDateProductRepository.findOne.resolves({baseDate: new Date()});

    await importRepository.updateSegment([
      '0;00;20181119;',
      '1;01;0;0;000000;0;',
      '2;01;',
    ], {
        fileDate: moment('20181119', 'YYYYMMDD').toDate(),
      });
  });

});
