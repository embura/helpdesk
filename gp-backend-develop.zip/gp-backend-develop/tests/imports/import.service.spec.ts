import { ImportFileService } from '../../src/imports/import.service';

import * as sinon from 'sinon';
import { ImportRepository } from '../../src/imports/import.repository';
import { BaseDateService } from '../../src/base-date/base-date.service';
import { BaseDateProductService } from '../../src/base-date-product/base-date-product.service';
import { FileService } from '../../src/metadata/file/file.service';
import { FieldService } from '../../src/metadata/field/field.service';
import { FieldTypeService } from '../../src/metadata/fieldType/fieldType.service';
import { PositionService } from '../../src/position/position.service';
import { ImportParams } from '../../src/imports/import.interface';
import { File } from '../../src/metadata/file/file.entity';
import { Field } from '../../src/metadata/field/field.entity';
import { FieldType } from '../../src/metadata/fieldType/fieldType.entity';
import { BaseDateProduct } from '../../src/base-date-product/base-date-product.entity';
import { SystemStatusService } from '../../src/system-status/system_status.service';

describe('ImportFileService', () => {
  // Connection
  // Services
  let importService: ImportFileService;
  let importRepository: sinon.SinonStubbedInstance<ImportRepository>;
  let baseDateService: sinon.SinonStubbedInstance<BaseDateService>;
  let baseDateProductService: sinon.SinonStubbedInstance<BaseDateProductService>;
  let fileService: sinon.SinonStubbedInstance<FileService>;
  let fieldService: sinon.SinonStubbedInstance<FieldService>;
  let fieldTypeService: sinon.SinonStubbedInstance<FieldTypeService>;
  let positionService: sinon.SinonStubbedInstance<PositionService>;
  let systemStatusService: sinon.SinonStubbedInstance<SystemStatusService>;

  beforeEach(() => {
    // Connection
    // Services
    importRepository = sinon.createStubInstance<ImportRepository>(ImportRepository);
    baseDateService = sinon.createStubInstance<BaseDateService>(BaseDateService);
    baseDateProductService = sinon.createStubInstance<BaseDateProductService>(BaseDateProductService);
    fileService = sinon.createStubInstance<FileService>(FileService);
    fieldService = sinon.createStubInstance<FieldService>(FieldService);
    fieldTypeService = sinon.createStubInstance<FieldTypeService>(FieldTypeService);
    positionService = sinon.createStubInstance<PositionService>(PositionService);
    systemStatusService = sinon.createStubInstance<SystemStatusService>(SystemStatusService);

    importService = new ImportFileService(
      importRepository as any,
      baseDateService as any,
      baseDateProductService as any,
      fileService as any,
      fieldService as any,
      fieldTypeService as any,
      positionService as any,
      systemStatusService as any);
  });

  it('should create', () => {
    expect(importService).toBeTruthy();
  });

  describe('processRequest', () => {
    it('first time', async () => {
      const importParams: ImportParams = new ImportParams();
      importParams.filename = 'Teste.txt';

      fileService.parseFilename.resolves(createFileMock());
      baseDateService.findByDate.resolves([]);
      baseDateService.create.resolves(1);
      baseDateProductService.findByPKs.resolves([]);
      baseDateProductService.create.resolves(1);
      baseDateService.update.resolves(1);
      baseDateProductService.update.resolves(1);

      // Teste função importFileTemp
      importService.importFileTemp = mockImportFileTemp;

      fileService.findAll.resolves(createFilesMock());

      await importService.processRequest(importParams);
    });

    xit('throw error when try to import', async () => {
      const importParams: ImportParams = new ImportParams();
      importParams.filename = 'Teste.txt';

      const baseDateProduct: BaseDateProduct = new BaseDateProduct();
      baseDateProduct.baseDate = new Date();
      baseDateProduct.fileNumber = 1;
      baseDateProduct.product = 'Teste 1';
      baseDateProduct.statusInt = 1;

      fileService.parseFilename.resolves(createFileMock());
      baseDateService.findByDate.resolves([]);
      baseDateService.create.resolves(1);
      baseDateProductService.findByPKs.resolves([baseDateProduct]);
      baseDateProductService.create.resolves(1);
      baseDateService.update.resolves(1);
      baseDateProductService.update.resolves(1);

      // Teste função importFileTemp
      importService.importFileTemp = () => { throw Error('Test Error'); };

      fileService.findAll.resolves(createFilesMock());

      await expect(importService.processRequest(importParams)).rejects.toBeTruthy();
    });

    xit('throw when try to call file Service', async () => {
      const importParams: ImportParams = new ImportParams();
      importParams.filename = 'Teste.txt';

      fileService.parseFilename.resolves(createFileMock());
      baseDateService.findByDate.resolves([]);
      baseDateService.create.resolves(1);
      baseDateProductService.findByPKs.resolves(getBaseDateProduct());
      baseDateProductService.create.resolves(1);
      baseDateService.update.resolves(1);
      baseDateProductService.update.resolves(1);

      // Teste função importFileTemp
      importService.importFileTemp = mockImportFileTemp;

      (fileService.findAll as any) = () => { throw Error('Test Error'); };

      await expect(importService.processRequest(importParams)).rejects.toBeTruthy();
    });

    it('return more than one status code of base date product', async () => {
      const importParams: ImportParams = new ImportParams();
      importParams.filename = 'Teste.txt';

      fileService.parseFilename.resolves(createFileMock());
      baseDateService.findByDate.resolves([]);
      baseDateService.create.resolves(1);
      baseDateProductService.findByPKs.resolves(getBaseDateProduct());
      baseDateProductService.create.resolves(1);
      baseDateService.update.resolves(1);
      baseDateProductService.update.resolves(1);

      // Teste função importFileTemp
      importService.importFileTemp = mockImportFileTemp;

      fileService.findAll.resolves(createFilesMock());

      await importService.processRequest(importParams);
    });
  });

  describe('importFileTemp', () => {
    it.skip('success path', async () => {
      fieldService.getFieldsWithTypes.resolves(mockFieldsWithTypes());

      importService.readFile = () => Promise.resolve(['CPT 20181016', '00;teste 1;teste 2', '01;1;2', '01;1;2', 'T2']);

      const fileInfo = {
        separator: ';',
      };

      const request: ImportParams = new ImportParams();
      request.headerIdentifier = '00';
      request.contentIdentifier = '01';

      importService.insertData = () => Promise.resolve(true);

      // await importService.importFileTemp(fileInfo, 'Teste 1', request);
    });

    it.skip('wrong number of trailer', async () => {
      fieldService.getFieldsWithTypes.resolves(mockFieldsWithTypes());

      importService.readFile = () => Promise.resolve(['teste 1; teste 2', '1;1', '2;2']);

      const fileInfo = {
        separator: ';',
      };

      const request: ImportParams = new ImportParams();
      request.contentIdentifier = '';

      importService.insertData = () => Promise.resolve(true);

      await expect(importService.importFileTemp(fileInfo, request))
        .rejects
        .toBe('Quantidade de registros (3) incompatível com o trailer (2).');
    });
  });

  describe('startImportSegment', () => {
    it('success path', async () => {

      importService.readFile = () => Promise.resolve(['teste 1; teste 2', '1;1', '2;2']);

      importService.getCsvFile = () => Promise.resolve(['']);
      fileService.parseFilename.resolves(createFileMock());
      baseDateService.findByDate.resolves([]);
      baseDateService.create.resolves();
      baseDateProductService.findByPKs.resolves([]);
      baseDateProductService.create.resolves();
      baseDateProductService.update.resolves();
      baseDateService.update.resolves();
      importRepository.updateSegment.resolves();

      await expect(importService.startImportSegment('Test 1', '')).resolves.toBeTruthy();
    });
  });

  describe('readFile', () => {
    it.skip('reads the file', () => {
      jest.mock('fs');
      const fs = require('fs');
      (fs as any).readFile.mockImplementation(() => 'aaaaaaa \n bbbbbbb \n');
      // importService.readFile('test');
    });

    it.skip('empty file', () => {
      jest.mock('fs');
      const fs = require('fs');
      (fs as any).readFile.mockImplementation(() => '');
      // importService.readFile('test');
    });
  });

  describe('importService', () => {
    it('reads the file', () => {

      const fields = mockFieldsWithTypes();
      const data = importService.getDataRow(fields, '', null);
      expect(data).toHaveLength(fields.length);
    });

  });

  describe('importFileTemp file positional', () => {
    it('Should return Promise<any> ', async () => {

      const fileInfo: any = {};
      const importParams: ImportParams = new ImportParams();
      importParams.filename = 'Teste.txt';

      fieldService.getFieldsWithTypes.resolves(mockFieldsWithTypes());
      importService.readFile = () => Promise.resolve(['teste 1; teste 2', '1;1', '2;2']);
      importService.getDataRow = () => mockFieldsWithTypes();
      importService.insertData = () => Promise.resolve('OK');

      const data = await importService.importFileTemp(fileInfo, importParams);


      expect(data).toEqual('OK');
    });

  });

});

function createFileMock(): any {
  return {
    product: 'gpc',
    type: 'teste 1',
    fileDate: '01/01/2018',
    id: 1,
    separator: ';',
  };
}

function createFilesMock(): File[] {
  const fileOne: File = new File();
  fileOne.id = 1;
  fileOne.name = 'teste 1';
  fileOne.run = 1;
  fileOne.separator = ';';
  fileOne.dateFormat = 'dd/MM/yyyy';

  const fileTwo: File = new File();
  fileTwo.id = 2;
  fileTwo.name = 'teste 2';
  fileTwo.run = 0;
  fileTwo.separator = ';';
  fileTwo.dateFormat = 'dd/MM/yyyy';

  return [fileOne, fileTwo];
}

function mockFieldsWithTypes(): any[] {
  const fieldOne: Field = new Field();
  fieldOne.id = 1;
  fieldOne.name = 'teste 1';
  fieldOne.value = 'teste 1';
  fieldOne.obrig = 0;
  fieldOne.seq_pos = 1;
  fieldOne.size = 1;
  fieldOne.start_pos = 1;
  fieldOne.column = 'teste 1';
  fieldOne.fileId = createFileMock().id;
  fieldOne.filler = '0';

  const fieldTwo: Field = new Field();
  fieldTwo.id = 2;
  fieldTwo.name = 'teste 2';
  fieldTwo.value = 'teste 2';
  fieldTwo.obrig = 0;
  fieldTwo.seq_pos = 2;
  fieldTwo.size = 1;
  fieldTwo.start_pos = 2;
  fieldTwo.column = 'teste 2';
  fieldTwo.fileId = createFileMock().id;
  fieldTwo.filler = '0';

  const fieldTree: Field = new Field();
  fieldTree.id = 3;
  fieldTree.name = 'CD-PROD';
  fieldTree.obrig = 0;
  fieldTree.seq_pos = 3;
  fieldTree.size = 3;
  fieldTree.column = 'CD-PROD';
  fieldTree.fileId = createFileMock().id;
  fieldTree.filler = '0';

  const fieldFour: Field = new Field();
  fieldFour.id = 3;
  fieldFour.name = 'IND-IQ';
  fieldFour.obrig = 0;
  fieldFour.seq_pos = 3;
  fieldFour.size = 3;
  fieldFour.column = 'IND-IQ';
  fieldFour.fileId = createFileMock().id;
  fieldFour.filler = '0';

  const fieldType: FieldType = new FieldType();
  fieldType.id = 1;
  fieldType.mask = '';
  fieldType.name = 'teste';
  fieldType.decimals = 0;
  fieldType.digits = 0;

  return [
    { ...fieldOne, type: fieldType },
    { ...fieldTwo, type: fieldType },
    { ...fieldFour, type: fieldType },
  ];
}

function mockImportFileTemp(): Promise<boolean> {
  return Promise.resolve(true);
}

function getBaseDateProduct(): BaseDateProduct[] {
  const baseDateProductZero: BaseDateProduct = new BaseDateProduct();
  baseDateProductZero.baseDate = new Date();
  baseDateProductZero.fileNumber = 1;
  baseDateProductZero.product = 'Teste 1';
  baseDateProductZero.statusInt = 0;

  const baseDateProductOne: BaseDateProduct = new BaseDateProduct();
  baseDateProductOne.baseDate = new Date();
  baseDateProductOne.fileNumber = 1;
  baseDateProductOne.product = 'Teste 1';
  baseDateProductOne.statusInt = 1;

  const baseDateProductTwo: BaseDateProduct = new BaseDateProduct();
  baseDateProductOne.baseDate = new Date();
  baseDateProductOne.fileNumber = 1;
  baseDateProductOne.product = 'Teste 1';
  baseDateProductOne.statusInt = 2;

  const baseDateProductTree: BaseDateProduct = new BaseDateProduct();
  baseDateProductOne.baseDate = new Date();
  baseDateProductOne.fileNumber = 1;
  baseDateProductOne.product = 'Teste 1';
  baseDateProductOne.statusInt = 3;

  const baseDateProductFour: BaseDateProduct = new BaseDateProduct();
  baseDateProductOne.baseDate = new Date();
  baseDateProductOne.fileNumber = 1;
  baseDateProductOne.product = 'Teste 1';
  baseDateProductOne.statusInt = 4;

  return [
    baseDateProductZero,
    baseDateProductOne,
    baseDateProductTwo,
    baseDateProductTree,
    baseDateProductFour,
  ];
}