import 'reflect-metadata';
import { ProductRowMapper } from '../../src/product/product.entity';
import { row } from './product.mock';

describe('ProductRowMapper', () => {
  const entityMapper = new ProductRowMapper();

  it('map', () => {
    const mappedEntity = entityMapper.map(row);
    expect( mappedEntity.id ).toBe(1);
  });

});