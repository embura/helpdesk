import 'reflect-metadata';

import { ProductRepository } from '../../src/product/product.repository';

describe('ImportFileService', () => {
  // Connection
  
  let productRepository: ProductRepository;

  beforeEach(() => {
    // Connection
    
    productRepository = new ProductRepository();
  });

  describe('getDataToExport', () => {
    it('should create', () => {
      expect(productRepository).toBeTruthy();
    });

    it('gets data', async () => {
      (productRepository as any).queryHandler.execute = jest.fn((x) => {
        return new Promise((resolve, reject): any => {
          setTimeout(resolve, 100, x);
        });
      });
      // productRepository.getDataToExport = jest.fn();
      await productRepository.getDataToExport({product: 'movi', fileDate: new Date()});
      // expect((productRepository as any).getDataToExport).toBeCalled();
      expect((productRepository as any).queryHandler.execute).toBeCalled();
    });
  });
});
