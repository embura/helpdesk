import 'reflect-metadata';

import { ProductService } from '../../src/product/product.service';
import { ProductRepository } from '../../src/product/product.repository';
import { createStubInstance } from 'sinon';
import { SqlHandler } from '../../src/shared/lib/database/query-handler';

describe('ImportFileService', () => {
  // Connection
  let productRepository: sinon.SinonStubbedInstance<ProductRepository>;
  let productService: ProductService;
  let mockResult;

  beforeEach(() => {
    mockResult = Symbol('teste');
    productRepository = createStubInstance<ProductRepository>(ProductRepository);
    (productRepository as any).queryHandler = createStubInstance(SqlHandler);
    (productRepository as any).commandHandler = createStubInstance(SqlHandler);
    productService = new ProductService( productRepository as any);
  });

  describe('getDataToExport', () => {
    it('should create', () => {
      expect(productService).toBeTruthy();
    });

    it('gets data', async () => {
    await productRepository.getDataToExport.resolves(mockResult);
    const fileinfo = {};
    const result = await productService.getDataToExport(fileinfo);

    expect(result).toEqual(mockResult);
    });
  });
});
