import 'reflect-metadata';
import * as sinon from 'sinon';
import { ResTester } from '../res-req.mock';
import { HttpStatus } from '@nestjs/common';

import { SegmentController } from '../../src/segment/segment.controller';
import { segments } from '../../src/segment/mock/segment.mock';
import { SegmentRepository } from '../../src/segment/segment.repository';

describe('SegmentController', () => {
  let segmentController: SegmentController;
  let stubSegmentRepository: sinon.SinonStubbedInstance<SegmentRepository>;
  let responseMock: ResTester;

  beforeEach(() => {
    responseMock = new ResTester();
    stubSegmentRepository = sinon.createStubInstance(SegmentRepository);
    segmentController = new SegmentController(stubSegmentRepository as any);
  });

  it('getAll', async () => {
    await stubSegmentRepository.findAll.resolves(segments);
    await segmentController.findAll(responseMock.stub, {});

    expect(responseMock.statusCode).toBe(HttpStatus.OK);
    expect(responseMock.json).toEqual({
      return: {
          code: 0,
          message: 'Todos segmentos privados encontrado.',
      },
      data: segments,
    });
  });

  it('findById', async () => {
    const needle = 66;
    const res = segments.filter( seg => seg.id === needle)[0];
    await stubSegmentRepository.findOne.resolves(res);
    await segmentController.findByid(responseMock.stub, needle.toString());

    expect(responseMock.statusCode).toBe(HttpStatus.OK);
    expect(responseMock.json).toEqual({
      return: {
          code: 0,
          message: 'Segment encontrado.',
      },
      data: res,
    });
  });
});