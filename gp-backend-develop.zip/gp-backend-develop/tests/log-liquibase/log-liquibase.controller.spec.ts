// Common Imports
import 'reflect-metadata';
import { LogLiquiBase } from '../../src/log-liquibase/log-liquibase.entitty';
import { LogLiquiBaseController } from '../../src/log-liquibase/log-liquibase.controller';
import { LogLiquiBaseService } from '../../src/log-liquibase/log-liquibase.service';
import { LogLiquiBaseMessage } from '../../src/log-liquibase/log-liquibase.msg';
import { commonCreateControllerSuccessTest, commonCreateControllerRejactOracleTest } from '../common/controller/common-create.case';
import { commonFindByIdControllerSuccessTest, commonFindByIdControllerRejactOracleTest } from '../common/controller/common-find-by-id.case';
import { commonUpdateControllerSuccessTest, commonUpdateControllerRejactOracleTest } from '../common/controller/common-update.case';
import { commoFindAllControllerSuccessTest, commonFindAllControllerRejactOracleTest } from '../common/controller/common-find-all.case';

// Test Data
const testDerivativo = new LogLiquiBase();

describe('LogLiquiBase Controller', () => {

  describe('findAll', () => {

    commoFindAllControllerSuccessTest(
      LogLiquiBaseController,
      LogLiquiBaseService,
      LogLiquiBaseMessage,
      [testDerivativo]
    );

    commonFindAllControllerRejactOracleTest(
      LogLiquiBaseController,
      LogLiquiBaseService,
      LogLiquiBaseMessage,
      [testDerivativo]
    );
  });

  describe('create', () => {

    commonCreateControllerSuccessTest(
      LogLiquiBaseController,
      LogLiquiBaseService,
      LogLiquiBaseMessage,
      testDerivativo
    );

    commonCreateControllerRejactOracleTest(
      LogLiquiBaseController,
      LogLiquiBaseService,
      LogLiquiBaseMessage,
      testDerivativo
    );

  });

  describe('findOne', () => {

    commonFindByIdControllerSuccessTest(
      LogLiquiBaseController,
      LogLiquiBaseService,
      LogLiquiBaseMessage,
      testDerivativo
    );

    commonFindByIdControllerRejactOracleTest(
      LogLiquiBaseController,
      LogLiquiBaseService,
      LogLiquiBaseMessage,
      testDerivativo
    );

  });

  describe('update', () => {

    commonUpdateControllerSuccessTest(
      LogLiquiBaseController,
      LogLiquiBaseService,
      LogLiquiBaseMessage,
      testDerivativo
    );

    commonUpdateControllerRejactOracleTest(
      LogLiquiBaseController,
      LogLiquiBaseService,
      LogLiquiBaseMessage,
      testDerivativo
    );

  });

});
