import { LogAsyncBench } from '../../src/shared/utils/logger.decorator';

describe.skip('LogAsync', () => {

  it('function', async () => {
    const stream = LogAsyncBench();
    expect(stream).toBeTruthy();
  });

});