import { systemLog } from '../../src/shared/utils/system-log.service';

describe.skip('SystemLog', () => {

  it.skip('findClientDetail', async () => {
    expect(systemLog).toBeTruthy();
  });

});