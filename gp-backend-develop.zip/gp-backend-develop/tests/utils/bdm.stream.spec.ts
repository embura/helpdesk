import { BDMstream, logTemplate } from '../../src/shared/utils/bdm.stream';

describe.skip('BdmStream', () => {

  it('findClientDetail', async () => {
    const stream = new BDMstream();
    expect(stream).toBeTruthy();
  });

  it('findClientDetail', async () => {
    const stream = new BDMstream();
    expect(logTemplate.data.api).toBeTruthy();
  });

});