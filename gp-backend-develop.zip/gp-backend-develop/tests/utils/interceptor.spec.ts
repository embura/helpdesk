import 'reflect-metadata';
import { LoggingInterceptor } from '../../src/server/interceptor/logging.interceptor';
import { of } from 'rxjs/observable/of';

describe('Interceptor', () => {
  const logginInterceptor = new LoggingInterceptor();

  it('map', () => {
    const dataOrRequest = {
      method: 'GET',
      originalUrl: 'http://localhost/',
    };
    const res = logginInterceptor.intercept(dataOrRequest, undefined, of({}));
    expect(res).toBeTruthy();
  });

});