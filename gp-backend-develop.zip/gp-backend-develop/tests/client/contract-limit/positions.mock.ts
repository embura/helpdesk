export const positionsMock = {
  products: {
    product: {
      code: 'CPT01',
      subProducts: {
        subProduct: [{
          code: 'BRSTNCLTN7I2',
          description: 'TESOURO LTN PRE 7/2021',
          riskDegree: {
            code: '5',
            description: 'ALTO',
            color: '000000',
          },
          category: {
            code: '07',
            description: 'RENDA FIXA',
            color: '4682B4',
          },
          netValue: '000000010389112',
          grossValue: '000000010488359',
          participationPercentage: '00569',
          totalNetValue: '000000182328873',
          totalGrossValue: '000000184379646',
          totalParticipationValue: '10000',
        }, {
          code: 'BRSTNCNTB4U6',
          description: 'TESOURO IPCA 8/2026',
          riskDegree: {
            code: '5',
            description: 'ALTO',
            color: '000000',
          },
          category: {
            code: '07',
            description: 'RENDA FIXA',
            color: '4682B4',
          },
          netValue: '000000171939761',
          grossValue: '000000173891287',
          participationPercentage: '09430',
          totalNetValue: '000000182328873',
          totalGrossValue: '000000184379646',
          totalParticipationValue: '10000',
        }],
      },
    },
  },
};