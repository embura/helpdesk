export const productPayloadMock = [{
  'productId': 1,
  'TP-CONC-MAX-VAR': 90,
  'TP-CONC-MAX-PRI': 90,
}];