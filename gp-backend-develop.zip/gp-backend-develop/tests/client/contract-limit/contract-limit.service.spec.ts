import 'reflect-metadata';
import * as sinon from 'sinon';

import { ContactLimitService } from '../../../src/client/contract-limit/contract-limit.service';
import { SegmentRepository } from '../../../src/segment/segment.repository';
import { PdiPositionRepository } from '../../../src/shared/repository/pdi-position/pdi-position.repository';
import { CatalogRepository } from '../../../src/shared/repository/catalog/catalog.repository';
import { queryParamsMock } from './query-param.mock';
import { productPayloadMock } from './product.mock';
import { positionsMock } from './positions.mock';
import { PositionService } from '../../../src/position/position.service';
import { ContractLimitRepository } from '../../../src/client/contract-limit/contract-limit.repository';
import { Pagination } from '../../../src/shared/utils/pagination.model';
import { Position } from '../../../src/position/position.entity';

describe('SegmentController', () => {
  let contractLimitService: ContactLimitService;
  let stubContractLimitRepository: sinon.SinonStubbedInstance<ContractLimitRepository>;
  let stubSegmentRepository: sinon.SinonStubbedInstance<SegmentRepository>;
  let stubPdiPositionRepository: sinon.SinonStubbedInstance<PdiPositionRepository>;
  let stubCatalogRepository: sinon.SinonStubbedInstance<CatalogRepository>;
  let stubPositionService: sinon.SinonStubbedInstance<PositionService>;

  beforeEach(() => {
    stubContractLimitRepository = sinon.createStubInstance(ContractLimitRepository);
    stubSegmentRepository = sinon.createStubInstance(SegmentRepository);
    stubPdiPositionRepository = sinon.createStubInstance(PdiPositionRepository);
    stubCatalogRepository = sinon.createStubInstance(CatalogRepository);
    stubPositionService = sinon.createStubInstance(PositionService);

    contractLimitService = new ContactLimitService(
      stubContractLimitRepository as any,
      stubSegmentRepository as any,
      stubCatalogRepository as any,
      stubPositionService as any
    );
  });

  it('getAll', async () => {
    stubSegmentRepository.findAll.resolves([]);
    const p1 = new Position();
    const p2 = new Position();
    p1.situation = '1';
    p2.situation = '2';
    const positions: Position[] = [ p1, p2 ];
    const pagination: Pagination = new Pagination();
    const posiPage: {positions: Position[], pagination: Pagination} = {positions, pagination};

    stubPositionService.findPositionMovement.resolves(posiPage);

    stubPdiPositionRepository.findPositionByPenumper.resolves(positionsMock);
    stubCatalogRepository.getPayloadByProductIdsAndChannel.resolves(productPayloadMock);

    const limit = await contractLimitService.getLimit(queryParamsMock as any, '11');

    expect(limit).toEqual([{id: 1, limit: '0.00' }]);
  });

});