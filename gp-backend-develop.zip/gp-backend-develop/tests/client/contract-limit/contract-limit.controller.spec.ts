import 'reflect-metadata';
import * as sinon from 'sinon';
import { HttpStatus } from '@nestjs/common';
import { ResTester } from '../../res-req.mock';

import { ContractLimitController } from '../../../src/client/contract-limit/contract-limit.controller';
import { ContactLimitService } from '../../../src/client/contract-limit/contract-limit.service';

describe('BaseDate Entity', () => {
  // mocks and stubs
  let stubContactLimitService: sinon.SinonStubbedInstance<ContactLimitService>;
  // class to test
  let contractLimitController: ContractLimitController;

  // initializing
  beforeEach(() => {
    stubContactLimitService = sinon.createStubInstance(ContactLimitService);

    contractLimitController = new ContractLimitController(
      stubContactLimitService as any
    );

  });

  it('validate', async () => {
    const result = Symbol('result');
    stubContactLimitService.getLimit.resolves(result);

    const res = await contractLimitController.validate(undefined);
    expect( res.data ).toBe(result);
  });

});