const products = [
  {productId: 1},
  {productId: 100},
  {productId: 83},
];

export const productsParameter  = {
  product: {
    code : 1,
    subProducts: {
      subProduct: {
        totalGrossValue: 0,
      },
    },
  },
};

export const position = {
  products: [
    {
      product: {
        code: productsParameter,
        subProducts: {
          subProduct: {
            totalGrossValue: productsParameter.product.subProducts.subProduct.totalGrossValue,
          },
        },
      },
    },
  ],
};

export const queryParamsMock = {
  products,
  segmentCode: '',
  penumper: '00123589',
  contractValue: 1000,
  groupName: 'CPT01',
  channel: {
      code: '53',
      corporateCode: '01',
  },
  position,

};
