import 'reflect-metadata';
import * as sinon from 'sinon';
import { HttpStatus } from '@nestjs/common';
import { ResTester } from '../res-req.mock';

import { ExportFileController } from '../../src/exports/export.controller';
import { ExportFileService } from '../../src/exports/export.service';

describe('BaseDate Entity', () => {
  // mocks and stubs
  let stubExportFileService: sinon.SinonStubbedInstance<ExportFileService>;
  let responseMock: ResTester;
  // class to test
  let exportFileController: ExportFileController;

  // initializing
  beforeEach(() => {
    responseMock = new ResTester();
    stubExportFileService = sinon.createStubInstance(ExportFileService);

    exportFileController = new ExportFileController(
      stubExportFileService as any
    );

  });

  it('export', async () => {
    stubExportFileService.processRequest.resolves(['result']);

    await exportFileController.export(responseMock.stub, 'filenameString' as any);
    expect(responseMock.statusCode).toBe(HttpStatus.OK);
  });

  it('exportPenumper', async () => {
    stubExportFileService.savePenumper.resolves(['result']);

    await exportFileController.exportPenumper(responseMock.stub, 'filenameString' as any);
    expect(responseMock.statusCode).toBe(HttpStatus.OK);
  });

});