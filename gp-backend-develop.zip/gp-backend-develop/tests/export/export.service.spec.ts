import { ExportFileService } from '../../src/exports/export.service';
import * as sinon from 'sinon';

import { BaseDateService } from '../../src/base-date/base-date.service';
import { ImportFileService } from '../../src/imports/import.service';
import { BaseDateProductService } from '../../src/base-date-product/base-date-product.service';
import { FileService } from '../../src/metadata/file/file.service';
import { FieldService } from '../../src/metadata/field/field.service';
import { FieldTypeService } from '../../src/metadata/fieldType/fieldType.service';
import { MovimentService } from '../../src/moviment/moviment.service';
import { ProductService } from '../../src/product/product.service';
import { PositionService } from '../../src/position/position.service';
import { BaseDate } from '../../src/base-date/base-date.entity';
import { Field } from '../../src/metadata/field/field.entity';
import { FieldType } from '../../src/metadata/fieldType/fieldType.entity';
import { Moviment } from '../../src/moviment/moviment.entity';

jest.mock('../../src/shared/utils/parse-date');
import { dateToYYYMMMDD } from '../../src/shared/utils/parse-date';
(dateToYYYMMMDD as any).mockImplementation(() => '20180101');

describe('ExportFileService', () => {
  
  let exportFileService: ExportFileService;
  let importService: sinon.SinonStubbedInstance<ImportFileService>;
  let baseDateService: sinon.SinonStubbedInstance<BaseDateService>;
  let baseDateProductService: sinon.SinonStubbedInstance<BaseDateProductService>;
  let fileService: sinon.SinonStubbedInstance<FileService>;
  let fieldService: sinon.SinonStubbedInstance<FieldService>;
  let fieldTypeService: sinon.SinonStubbedInstance<FieldTypeService>;
  let movimentService: sinon.SinonStubbedInstance<MovimentService>;
  let productService: sinon.SinonStubbedInstance<ProductService>;
  let positionService: sinon.SinonStubbedInstance<PositionService>;

  beforeAll(() => {
    

    baseDateService = sinon.createStubInstance<BaseDateService>(BaseDateService);
    importService = sinon.createStubInstance<ImportFileService>(ImportFileService);
    baseDateProductService = sinon.createStubInstance<BaseDateProductService>(BaseDateProductService);
    fileService = sinon.createStubInstance<FileService>(FileService);
    fieldService = sinon.createStubInstance<FieldService>(FieldService);
    fieldTypeService = sinon.createStubInstance<FieldTypeService>(FieldTypeService);
    movimentService = sinon.createStubInstance<MovimentService>(MovimentService);
    productService = sinon.createStubInstance<ProductService>(ProductService);
    positionService = sinon.createStubInstance<PositionService>(PositionService);

    exportFileService = new ExportFileService(
      baseDateService as any,
      importService as any,
      baseDateProductService as any,
      fileService as any,
      fieldService as any,
      fieldTypeService as any,
      movimentService as any,
      productService as any,
      positionService as any);
  });

  it('should create', () => {
    expect(exportFileService).toBeTruthy();
  });

  it('should create', async () => {
    const fileinfo = {
      type: 'posi',
    };

    fieldService.getFieldsWithTypes.resolves([]);
    const res = await exportFileService.getData(fileinfo);
    expect(res).toBeTruthy();
  });

  describe('processRequest/moviment', () => {
    const filename = 'Test_1.txt';

    it.skip('success path', async () => {
      fileService.parseFilename.resolves(createFileMock());

      const baseDate: BaseDate = new BaseDate();
      baseDate.id = new Date();
      baseDate.statusInt = 4;

      baseDateService.findByDate.resolves([baseDate]);
      fieldService.getFieldsWithTypes.resolves(mockFieldsWithTypesMovi());
      movimentService.getDataToExport.resolves([getMovimentMock()]);

      await expect(exportFileService.processRequest(filename)).resolves.toBeTruthy();
    });
  });
});

function createFileMock(): any {
  return {
    product: 'gpc',
    type: 'movi',
    fileDate: '01/01/2018',
    id: 1,
    separator: ';',
  };
}

function mockFieldsWithTypesMovi(): any[] {
  const fieldOne: Field = new Field();
  fieldOne.id = 1;
  fieldOne.name = 'teste 1';
  fieldOne.obrig = 1;
  fieldOne.seq_pos = 1;
  fieldOne.size = 8;
  fieldOne.start_pos = 1;
  fieldOne.column = 'DT_BASE_SIST';
  fieldOne.fileId = createFileMock().id;
  fieldOne.filler = '0';

  const fieldTwo: Field = new Field();
  fieldTwo.id = 1;
  fieldTwo.name = 'teste 2';
  fieldTwo.obrig = 1;
  fieldTwo.seq_pos = 2;
  fieldTwo.size = 8;
  fieldTwo.start_pos = 3;
  fieldTwo.column = 'VL_LIQU_MOVI';
  fieldTwo.fileId = createFileMock().id;
  fieldTwo.filler = '0';

  const fieldTree: Field = new Field();
  fieldTwo.id = 1;
  fieldTwo.name = 'teste 3';
  fieldTwo.obrig = 1;
  fieldTwo.seq_pos = 3;
  fieldTwo.size = 8;
  fieldTwo.start_pos = 5;
  fieldTwo.column = 'VL_BRUT_MOVI';
  fieldTwo.fileId = createFileMock().id;
  fieldTwo.filler = '0';


  const fieldFour: Field = new Field();
  fieldTwo.id = 1;
  fieldTwo.name = 'teste 4';
  fieldTwo.obrig = 1;
  fieldTwo.seq_pos = 3;
  fieldTwo.size = 1;
  fieldTwo.start_pos = 5;
  fieldTwo.column = 'TB_INVEST_QUALI';
  fieldTwo.fileId = createFileMock().id;
  fieldTwo.filler = ' ';

  const fieldTypeDate: FieldType = new FieldType();
  fieldTypeDate.id = 1;
  fieldTypeDate.mask = 'dd/MM/yyyy';
  fieldTypeDate.name = 'DT';
  fieldTypeDate.decimals = 0;
  fieldTypeDate.digits = 0;

  const fieldTypeNumber: FieldType = new FieldType();
  fieldTypeNumber.id = 2;
  fieldTypeNumber.mask = '';
  fieldTypeNumber.name = 'N';
  fieldTypeNumber.decimals = 1;
  fieldTypeNumber.digits = 1;

  const fieldTypeDigit: FieldType = new FieldType();
  fieldTypeDigit.id = 2;
  fieldTypeDigit.mask = '';
  fieldTypeDigit.name = 'D';
  fieldTypeDigit.decimals = 1;
  fieldTypeDigit.digits = 2;

  const fieldTypePenumper: FieldType = new FieldType();
  fieldTypePenumper.id = 2;
  fieldTypePenumper.mask = '';
  fieldTypePenumper.name = 'TEXTZEROLEFT';
  fieldTypePenumper.decimals = 1;
  fieldTypePenumper.digits = 2;

  return [
    { ...fieldOne, type: fieldTypeDate },
    { ...fieldTwo, type: fieldTypeNumber },
    { ...fieldTree, type: fieldTypeDigit },
    { ...fieldFour, type: fieldTypePenumper },
  ];
}

function getMovimentMock(): Moviment {
  const moviment: Moviment = new Moviment();
  moviment.accountCode = '000000000000';
  moviment.bankCode = 0;
  moviment.branchCode = 0;
  moviment.campaignIDCode = '0';
  moviment.dateBase = new Date();
  moviment.dateConv = new Date();
  moviment.dateEfet = new Date();
  moviment.dateSolic = new Date();
  moviment.documentNumber = '00000000000';
  moviment.globalId = '0000000000000';
  moviment.grossValue = 1.1;
  moviment.id = '0';
  moviment.iofValue = 0;
  moviment.irValue = 0;
  moviment.moviGFCode = '0';
  moviment.moviType = '0';
  moviment.netValue = 1.1;
  moviment.opChanCode = '0';
  moviment.opStatusCode = '0';
  moviment.opUserCode = '0';
  moviment.penumper = '000000000';
  moviment.productSdkCode = '0';
  moviment.sdkCodeId = '0';
  moviment.sourceSys = '0';
  moviment.taxValue = 0;
  moviment.tradedQuantity = 0;
  moviment.typePerson = 'F';

  return moviment;
}