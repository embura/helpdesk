import 'reflect-metadata';
import { BDMstream } from '../../../src/shared/utils/bdm.stream';

describe.skip('BDM Stream', () => {

  it.skip('Construction', () => {
    const bdmStream = new BDMstream();
    expect(bdmStream).toBeTruthy();
  });

});