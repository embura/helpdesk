// Common Imports
import 'reflect-metadata';
import { TypeFormalization } from '../../src/type-formalization/type-formalization.entitty';
import { TypeFormalizationController } from '../../src/type-formalization/type-formalization.controller';
import { TypeFormalizationService } from '../../src/type-formalization/type-formalization.service';
import { TypeFormalizationMessage } from '../../src/type-formalization/type-formalization.msg';
import { commonCreateControllerSuccessTest, commonCreateControllerRejactOracleTest } from '../common/controller/common-create.case';
import { commonFindByIdControllerSuccessTest, commonFindByIdControllerRejactOracleTest } from '../common/controller/common-find-by-id.case';
import { commonUpdateControllerSuccessTest, commonUpdateControllerRejactOracleTest } from '../common/controller/common-update.case';
import { commoFindAllControllerSuccessTest, commonFindAllControllerRejactOracleTest } from '../common/controller/common-find-all.case';

// Test Data
const testDerivativo = new TypeFormalization();

describe('TypeFormalization Controller', () => {

  describe('findAll', () => {

    commoFindAllControllerSuccessTest(
      TypeFormalizationController,
      TypeFormalizationService,
      TypeFormalizationMessage,
      [testDerivativo]
    );

    commonFindAllControllerRejactOracleTest(
      TypeFormalizationController,
      TypeFormalizationService,
      TypeFormalizationMessage,
      [testDerivativo]
    );
  });

  describe('create', () => {

    commonCreateControllerSuccessTest(
      TypeFormalizationController,
      TypeFormalizationService,
      TypeFormalizationMessage,
      testDerivativo
    );

    commonCreateControllerRejactOracleTest(
      TypeFormalizationController,
      TypeFormalizationService,
      TypeFormalizationMessage,
      testDerivativo
    );

  });

  describe('findOne', () => {

    commonFindByIdControllerSuccessTest(
      TypeFormalizationController,
      TypeFormalizationService,
      TypeFormalizationMessage,
      testDerivativo
    );

    commonFindByIdControllerRejactOracleTest(
      TypeFormalizationController,
      TypeFormalizationService,
      TypeFormalizationMessage,
      testDerivativo
    );

  });

  describe('update', () => {

    commonUpdateControllerSuccessTest(
      TypeFormalizationController,
      TypeFormalizationService,
      TypeFormalizationMessage,
      testDerivativo
    );

    commonUpdateControllerRejactOracleTest(
      TypeFormalizationController,
      TypeFormalizationService,
      TypeFormalizationMessage,
      testDerivativo
    );

  });

});
