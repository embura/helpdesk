import {IQuery, queryStringToWhere} from '../../../src/shared/common/query.interface';
import { IFindOptions, Order } from '../../../src/shared/repository/repository.interface';

describe('queryStringToWhere', () => {

  describe('returns undefined when does not exist.', () => {

    it('returns undefined when does not exist.', async () => {
      const query: IQuery = undefined;
      expect(queryStringToWhere(query)).toBe(undefined);
    });

    it('use default order value', async () => {
      const query: IQuery = {_orderBy: 'name'};
      const result: IFindOptions<any> = {order: [['name', Order.ASC]]};

      expect(queryStringToWhere(query)).toEqual(result);
    });

    it('use default order value', async () => {
      const query: IQuery = {_orderBy: 'name', _order: 'desc'};
      const result: IFindOptions<any> = {order: [['name', Order.DESC]]};

      expect(queryStringToWhere(query)).toEqual(result);
    });

    it('Use limit, offset and where', async () => {
      const query: IQuery = {_offset: '3', _limit: '5', id: '3'};
      const result: IFindOptions<any> = {limit: 5, offset: 3, where: {id: '3'}};

      expect(queryStringToWhere(query)).toEqual(result);
    });

  });

});
