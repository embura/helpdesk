import { createStubInstance } from 'sinon';
import { CommnRepository } from '../../../src/shared/repository/common.repository';
import {
  BaseDateProduct,
  BaseDateProductRow,
  BaseDateProductTable,
  BaseDateProductRowMapper } from '../../../src/base-date-product/base-date-product.entity';
import { BaseDateProductMessage } from '../../../src/base-date-product/base-date-product.msg';
import * as odb from 'oracledb';
import { dbConfig } from '../../../src/shared/lib/database/oracle.config';
import { Op, Order } from '../../../src/shared/repository/repository.interface';
import { SqlHandler } from '../../../src/shared/lib/database/query-handler';

const BaseDateProductSequence = 'SQ_BDP';
describe.skip('Common Repository - Commands', () => {
  let repoToTest: CommnRepository<BaseDateProduct>;

  beforeEach(async () => {
    // await odb.createPool(dbConfig);
    // stubConn = createStubInstance(odb.getPool());
    repoToTest = new CommnRepository<BaseDateProduct>(
      BaseDateProductRow,
      BaseDateProductTable,
      BaseDateProductSequence,
      BaseDateProductMessage,
      new BaseDateProductRowMapper()
    );
    (repoToTest as any).queryHandler = createStubInstance(SqlHandler);
    (repoToTest as any).commandHandler = createStubInstance(SqlHandler);
    (repoToTest as any).sequenceQueryHandler = createStubInstance(SqlHandler);
  });

  describe('Common repository SQL generation tests', () => {

    // it.skip('Generates INSERT sql statement correctly.', async () => {
    //   const keys = Object.keys(BaseDateProductRow).filter(key => key !== 'product');

    //   const queryResult
    //     // tslint:disable-next-line:max-line-length
    //     = `INSERT INTO ${BaseDateProductTable} (${
      // BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber
    // }) VALUES (${BaseDateProductSequence}, :${keys[0]}, :${keys[1]})`;
    //   const connReturn: odb.IExecuteReturn = {
    //     rowsAffected: 1,
    //   };
    //   stubConn.execute.resolves(connReturn);

    //   const baseDateProduct = new BaseDateProduct();
    //   baseDateProduct.baseDate = new Date();
    //   baseDateProduct.fileNumber = 1;

    //   await repoToTest.create(baseDateProduct);

    //   const calls = stubConn.execute.getCalls();
    //   const args = calls.map(call => call.args);
    //   const query = args[0][1];
    //   const bindings = args[0][2];
    //   // tslint:disable-next-line:no-console
    //   // console.log('query =>', query);
    //   // tslint:disable-next-line:no-console
    //   // console.log('bindings => ', bindings);

    //   expect(query).toBe(queryResult);
    //   expect(bindings).toEqual(baseDateProduct);
    // });

    // it.skip('Generates UPDATE sql statement correctly.', async () => {
    //   const keys = Object.keys(BaseDateProductRow);

    //   const queryResult
    //     = `UPDATE ${BaseDateProductTable} SET ${BaseDateProductRow.baseDate
    //     } = :${keys[1]}, ${BaseDateProductRow.fileNumber} = :${keys[2]} WHERE ${BaseDateProductRow.product} = :${keys[0]}`;
    //   const connReturn: odb.IExecuteReturn = { rowsAffected: 1 };
    //   stubConn.execute.resolves(connReturn);

    //   const baseDateProduct = new BaseDateProduct();
    //   baseDateProduct.baseDate = new Date();
    //   baseDateProduct.fileNumber = 1;

    //   await repoToTest.update(baseDateProduct);

    //   const calls = stubConn.execute.getCalls();
    //   const args = calls.map(call => call.args);
    //   const query = args[0][1];
    //   const binds = args[0][2];
    //   // tslint:disable-next-line:no-console
    //   // console.log('query =>', query);
    //   // tslint:disable-next-line:no-console
    //   // console.log('bindings => ', bindings);

    //   expect(query).toBe(queryResult);
    //   expect(binds).toEqual(baseDateProduct);
    // });

    it.only('Generates simple SELECT sql statement correctly.', async () => {
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable}`;
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 1,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll();

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause using one single column as criteria in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} = ${product}`;
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 1,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({ where : { product } });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    it('Generates SELECT with WHERE clause using two columns as criteria in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} = ${product} AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}')`;
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 1,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({ where : { product, baseDate } });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    it('Generates SELECT with WHERE clause using IN operator over a number array in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = [1, 2, 3];
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${product[0]}', '${product[1]}', '${product[2]}')`;
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({  where : {
                                    product : {
                                      [Op.in] : product,
                                    },
                                  },
                              });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    // TODO: The query builder does not create the IN clause correctly when its arguments' data types are strings
    // it.skip('Generates SELECT with WHERE clause using IN operator over a character array in sql statement correctly.', async () => {
    //   const keys = Object.keys(BaseDateProductRow);
    //   const baseDates = ['a', 'b', 'c'];
    //   const queryResult
    //     // tslint:disable-next-line:max-line-length
    //     = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.baseDate} IN ('${baseDates[0]}', '${baseDates[1]}', '${baseDates[2]}')`;
    //   const connReturn: odb.IExecuteReturn = {
    //     rowsAffected: 3,
    //   };
    //   stubConn.execute.resolves(connReturn);

    //   await repoToTest.findAll({  where : {
    //                                 baseDate : {
    //                                   [Op.in] : baseDates,
    //                                 },
    //                               },
    //                           });

    //   const calls = stubConn.execute.getCalls();
    //   const args = calls.map(call => call.args);
    //   const query = args[0][1];
    //   const bindings = args[0][2];
    //   // tslint:disable-next-line:no-console
    //   // console.log('query =>', query);

    //   expect(query).toBe(queryResult);
    // });

    // tslint:disable-next-line:max-line-length
    it('Throws error when trying to generate SELECT statement with WHERE and IN clauses when passing an array containing data with different types.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);
      const invalproductArguments = [true, false, 1];

      await repoToTest.findAll({ where : {
                                   product : {
                                     [Op.in] : invalproductArguments,
                                   },
                                 },
                                }).catch(err => {
                                  try {
                                    expect(err).toThrow();
                                  } catch (e) {}
                                });
    });

    it('Generates SELECT with WHERE clause using IN and AND operators in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = [1, 2, 3];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${product[0]}', '${product[1]}', '${product[2]}') AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}')`;
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 1,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({  where : {
                                    product : {
                                      [Op.in] : product,
                                    },
                                    baseDate,
                                  },
                              });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE and BETWEEN clauses in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product1 = 1;
      const product2 = 3;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE (${BaseDateProductRow.product} BETWEEN ${product1} AND ${product2})`;
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({ where : {
                                   product : {
                                     [Op.between] : [product1, product2],
                                   },
                                 },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    //
    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE containing two BETWEEN clauses in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product1 = 1;
      const product2 = 3;
      const baseDate1 = 'Estruturado 1';
      const baseDate2 = 'Estruturado 2';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE (${BaseDateProductRow.product} BETWEEN ${product1} AND ${product2}) AND (${BaseDateProductRow.baseDate} BETWEEN ${baseDate1} AND ${baseDate2})`;
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({ where : {
                                   product : {
                                     [Op.between] : [product1, product2],
                                   },
                                   baseDate : {
                                     [Op.between] : [baseDate1, baseDate2],
                                   },
                                 },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });
    //

    // tslint:disable-next-line:max-line-length
    it('Throws error when trying to generate SELECT statement with WHERE and BETWEEN clauses when passing an array which length is different than two.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);
      const invalproductArguments = [[], [1], [1, 2, 3]];

      for (const invItem of invalproductArguments) {
        await repoToTest.findAll({ where : {
            product : {
              [Op.between] : invItem,
            },
          },
        }).catch(err => {
          try {
            expect(err).toThrow();
          } catch (e) {}
        });
      }
    });

    // tslint:disable-next-line:max-line-length
    it('Throws error when trying to generate SELECT statement with WHERE and BETWEEN clauses when passing a non-array as argument.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);
      const invalproductArguments = [1, true, 'test', new Date()];

      for (const invItem of invalproductArguments) {
        await repoToTest.findAll({ where : {
                                    product : {
                                      [Op.between] : invItem,
                                    },
                                  },
                                }).catch(err => {
                                  try {
                                    expect(err).toThrow();
                                  } catch (e) {}
                                });
      }
    });

    // tslint:disable-next-line:max-line-length
    it('Throws error when trying to generate SELECT statement with WHERE and BETWEEN clauses when passing arguments of different types.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);
      const differentData = [1, true];

      await repoToTest.findAll({ where : {
                                   product : {
                                     [Op.between] : [differentData],
                                   },
                                 },
                               }).catch(err => {
                                  try {
                                    expect(err).toThrow();
                                  } catch (e) {}
                               });
    });

    // tslint:disable-next-line:max-line-length
    it('Generates simple SELECT with ORDER BY sorting operator over one single column in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} ORDER BY ${BaseDateProductRow.baseDate} ASC`;
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  order : [
                                    ['baseDate', Order.ASC],
                                  ],
                              });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    it('Generates simple SELECT with ORDER BY sorting operator over two columns in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} ORDER BY ${BaseDateProductRow.baseDate} ASC, ${BaseDateProductRow.fileNumber} ASC`;
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  order : [
                                    ['baseDate', Order.ASC],
                                    ['fileNumber', Order.ASC],
                                  ],
                              });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates simple SELECT with ORDER BY sorting operator over three columns (baseDate DESC, fileNumber ASC, product DESC) in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} ORDER BY ${BaseDateProductRow.baseDate} DESC, ${BaseDateProductRow.fileNumber} ASC, ${BaseDateProductRow.product} DESC`;
      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  order : [
                                    ['baseDate', Order.DESC],
                                    ['fileNumber', Order.ASC],
                                    ['product', Order.DESC],
                                  ],
                              });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    it('Generates simple SELECT with LIMIT clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable}) WHERE RN < ${limit + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({ limit: 10 });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    it('Generates SELECT with WHERE and LIMIT clauses in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}')) WHERE RN < ${limit + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({ limit: 10, where : { baseDate } });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    //
    it('Generates SELECT with WHERE with BETWEEN and LIMIT clauses in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const baseDate = 'Estruturado';
      const productsBT = [1, 4];
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') AND (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]})) WHERE RN < ${limit + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                limit: 10,
                                where : {
                                  baseDate,
                                  product : {
                                    [Op.between] : productsBT,
                                  },
                                },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });
    //

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause - now containing AND operator between two columns - and LIMIT clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const baseDate = 'Estruturado';
      const fileNumber = 'Est.';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') AND LOWER(${BaseDateProductRow.fileNumber}) = LOWER('${fileNumber}')) WHERE RN < ${limit + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({ limit: 10, where : { baseDate, fileNumber } });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing AND operator between two columns and a BETWEEN operator - and LIMIT clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const baseDate = 'Estruturado';
      const fileNumber = 'Est.';
      const productsBT = [1, 4];
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') AND LOWER(${BaseDateProductRow.fileNumber}) = LOWER('${fileNumber}') AND (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]})) WHERE RN < ${limit + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({ limit: 10,
                                 where : {
                                   baseDate,
                                   fileNumber,
                                   product : {
                                     [Op.between] : productsBT,
                                   },
                                 },
                              });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with one column along with ORDER BY over one single column and LIMIT clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') ORDER BY ${BaseDateProductRow.baseDate} ASC) WHERE RN < ${limit + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 3,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({ limit: 10, where : { baseDate }, order : [['baseDate', Order.ASC]] });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates simple SELECT with LIMIT and OFFSET clauses in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const offset = 10;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable}) WHERE RN > ${offset} AND RN < ${limit + offset + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({ limit, offset });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    //
    // tslint:disable-next-line:max-line-length
    it('Generates simple SELECT with BETWEEN, LIMIT and OFFSET clauses in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const offset = 10;
      const productsBT = [1, 4];
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]})) WHERE RN > ${offset} AND RN < ${limit + offset + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where : {
                                    product : {
                                      [Op.between] : productsBT,
                                    },
                                  },
                                  limit,
                                  offset,
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });
    //

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE containing AND operator, LIMIT and OFFSET clauses in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const offset = 10;
      const baseDate = 'Estruturado';
      const fileNumber = 'Est.';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') AND LOWER(${BaseDateProductRow.fileNumber}) = LOWER('${fileNumber}')) WHERE RN > ${offset} AND RN < ${limit + offset + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  limit,
                                  offset,
                                  where: {
                                    baseDate,
                                    fileNumber,
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE containing AND and BETWEEN operators, LIMIT and OFFSET clauses in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const offset = 10;
      const baseDate = 'Estruturado';
      const fileNumber = 'Est.';
      const productsBT = [1, 4];
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') AND LOWER(${BaseDateProductRow.fileNumber}) = LOWER('${fileNumber}')) WHERE RN > ${offset} AND RN < ${limit + offset + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  limit,
                                  offset,
                                  where: {
                                    product : {
                                      [Op.between] : productsBT,
                                    },
                                    baseDate,
                                    fileNumber,
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', query);

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE containing AND operator, LIMIT, OFFSET and ORDER BY (baseDate ASC, fileNumber DESC) clauses in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const offset = 10;
      const baseDate = 'Estruturado';
      const fileNumber = 'Est.';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') AND LOWER(${BaseDateProductRow.fileNumber}) = LOWER('${fileNumber}') ORDER BY ${BaseDateProductRow.baseDate} DESC, ${BaseDateProductRow.fileNumber} ASC) WHERE RN > ${offset} AND RN < ${limit + offset + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  limit,
                                  offset,
                                  where: {
                                    baseDate,
                                    fileNumber,
                                  },
                                  order: [
                                    ['baseDate', Order.DESC],
                                    ['fileNumber', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE containing AND operator, LIMIT, OFFSET, BETWEEN and ORDER BY (baseDate ASC, fileNumber DESC) clauses in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const limit = 10;
      const offset = 10;
      const productsBT = [1, 4];
      const baseDate = 'Estruturado';
      const fileNumber = 'Est.';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM (SELECT ROWNUM as RN, ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') AND (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) AND LOWER(${BaseDateProductRow.fileNumber}) = LOWER('${fileNumber}') ORDER BY ${BaseDateProductRow.baseDate} DESC, ${BaseDateProductRow.fileNumber} ASC) WHERE RN > ${offset} AND RN < ${limit + offset + 1}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  limit,
                                  offset,
                                  where: {
                                    baseDate,
                                    product : {
                                      [Op.between] : productsBT,
                                    },
                                    fileNumber,
                                  },
                                  order: [
                                    ['baseDate', Order.DESC],
                                    ['fileNumber', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with BETWEEN operator in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const productsBT = [1, 4];
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]})`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.between] : productsBT,
                                      },
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with GREATER THAN operator in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} > ${product}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.gt] : product,
                                      },
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with GREATER THAN operator and ORDER BY with one single column clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} > ${product} ORDER BY ${BaseDateProductRow.baseDate} ASC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.gt] : product,
                                      },
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with GREATER THAN and BETWEEN operator along with ORDER BY with one single column clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const productsBT = [1, 4];
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) AND ${BaseDateProductRow.product} > ${product} ORDER BY ${BaseDateProductRow.baseDate} ASC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.between] : productsBT,
                                        [Op.gt] : product,
                                      },
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with GREATER THAN, AND, IN and EQUAL operators in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND ${BaseDateProductRow.product} > ${product} AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}')`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.gt] : product,
                                      },
                                      baseDate,
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with GREATER THAN, AND, IN, EQUAL AND BETWEEN operators in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const productsBT = [1, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND ${BaseDateProductRow.product} > ${product} AND (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}')`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.gt] : product,
                                          [Op.between] : productsBT,
                                      },
                                      baseDate,
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with GREATER THAN, AND, IN and EQUAL operators along with ORDER BY with one single column clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND ${BaseDateProductRow.product} > ${product} AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') ORDER BY ${BaseDateProductRow.baseDate} ASC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.gt] : product,
                                      },
                                      baseDate,
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with GREATER THAN, AND, IN, EQUAL and BETWEEN operators along with ORDER BY with two columns clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const productsBT = [1, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) AND ${BaseDateProductRow.product} > ${product} AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') ORDER BY ${BaseDateProductRow.baseDate} ASC, ${BaseDateProductRow.fileNumber} DESC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.between] : productsBT,
                                          [Op.gt] : product,
                                      },
                                      baseDate,
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                    ['fileNumber', Order.DESC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with GREATER THAN EQUAL operator in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} >= ${product}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.gte] : product,
                                      },
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with GREATER THAN EQUAL operator and ORDER BY with one single column clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} >= ${product} ORDER BY ${BaseDateProductRow.baseDate} ASC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.gte] : product,
                                      },
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing GREATER THAN EQUAL and BETWEEN operators along with ORDER BY with two columns clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const productsBT = [1, 4];
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} >= ${product} AND (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) ORDER BY ${BaseDateProductRow.baseDate} ASC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.gte] : product,
                                        [Op.between] : productsBT,
                                      },
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with GREATER THAN EQUAL, AND, IN and EQUAL operators in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND ${BaseDateProductRow.product} >= ${product} AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}')`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.gte] : product,
                                      },
                                      baseDate,
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with GREATER THAN EQUAL, AND, IN, BETWEEN and EQUAL operators in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const productsBT = [1, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND ${BaseDateProductRow.product} >= ${product} AND (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}')`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.gte] : product,
                                          [Op.between] : productsBT,
                                      },
                                      baseDate,
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with LESS THAN operator in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} < ${product}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.lt] : product,
                                      },
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    //
    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with BETWEEN and LESS THAN operators in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const productsBT = [1, 4];
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) AND ${BaseDateProductRow.product} < ${product}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.between] : productsBT,
                                        [Op.lt] : product,
                                      },
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });
    //

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with LESS THAN operator and ORDER BY with one single column clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} < ${product} ORDER BY ${BaseDateProductRow.baseDate} ASC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.lt] : product,
                                      },
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with LESS THAN AND BETWEEN operators along with ORDER BY containing one single column clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const productsBT = [1, 4];
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} < ${product} AND (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) ORDER BY ${BaseDateProductRow.baseDate} ASC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.lt] : product,
                                        [Op.between] : productsBT,
                                      },
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with LESS THAN, AND, IN and EQUAL operators along with ORDER BY with one single column clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND ${BaseDateProductRow.product} < ${product} AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') ORDER BY ${BaseDateProductRow.baseDate} ASC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.lt] : product,
                                      },
                                      baseDate,
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with LESS THAN, AND, IN, EQUAL and BETWEEN operators along with ORDER BY with two columns clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const productsBT = [1, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND ${BaseDateProductRow.product} < ${product} AND (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') ORDER BY ${BaseDateProductRow.baseDate} ASC, ${BaseDateProductRow.fileNumber} DESC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.lt] : product,
                                          [Op.between] : productsBT,
                                      },
                                      baseDate,
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                    ['fileNumber', Order.DESC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with LESS THAN EQUAL operator in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} <= ${product}`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.lte] : product,
                                      },
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause with LESS THAN EQUAL operator and ORDER BY with one single column clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} <= ${product} ORDER BY ${BaseDateProductRow.baseDate} ASC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                        [Op.lte] : product,
                                      },
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with LESS THAN EQUAL, AND, IN and EQUAL operators in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND ${BaseDateProductRow.product} <= ${product} AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}')`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.lte] : product,
                                      },
                                      baseDate,
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with LESS THAN EQUAL, AND, IN, EQUAL and BETWEEN operators in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const productsBT = [1, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND ${BaseDateProductRow.product} <= ${product} AND (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}')`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.lte] : product,
                                          [Op.between] : productsBT,
                                      },
                                      baseDate,
                                  },
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with LESS THAN EQUAL, AND, IN and EQUAL operators along with ORDER BY with one single column clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND ${BaseDateProductRow.product} <= ${product} AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') ORDER BY ${BaseDateProductRow.baseDate} ASC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.lte] : product,
                                      },
                                      baseDate,
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });

    // tslint:disable-next-line:max-line-length
    it('Generates SELECT with WHERE clause containing an expression with LESS THAN EQUAL, AND, IN, EQUAL and BETWEEN operators along with ORDER BY with two columns clause in sql statement correctly.', async () => {
      const keys = Object.keys(BaseDateProductRow);
      const product = 1;
      const products = [2, 3, 4];
      const productsBT = [1, 4];
      const baseDate = 'Estruturado';
      const queryResult
        // tslint:disable-next-line:max-line-length
        = `SELECT ${BaseDateProductRow.product}, ${BaseDateProductRow.baseDate}, ${BaseDateProductRow.fileNumber}, ${BaseDateProductRow.statusInt} FROM ${BaseDateProductTable} WHERE ${BaseDateProductRow.product} IN ('${products[0]}', '${products[1]}', '${products[2]}') AND ${BaseDateProductRow.product} <= ${product} AND (${BaseDateProductRow.product} BETWEEN ${productsBT[0]} AND ${productsBT[1]}) AND LOWER(${BaseDateProductRow.baseDate}) = LOWER('${baseDate}') ORDER BY ${BaseDateProductRow.baseDate} ASC, ${BaseDateProductRow.fileNumber} DESC`;

      const connReturn: odb.IExecuteReturn = {
        rowsAffected: 10,
      };
      stubConn.execute.resolves(connReturn);

      await repoToTest.findAll({
                                  where: {
                                      product : {
                                          [Op.in] : products,
                                          [Op.lte] : product,
                                          [Op.between] : productsBT,
                                      },
                                      baseDate,
                                  },
                                  order: [
                                    ['baseDate', Order.ASC],
                                    ['fileNumber', Order.DESC],
                                  ],
                               });

      const calls = stubConn.execute.getCalls();
      const args = calls.map(call => call.args);
      const query = args[0][1];
      const bindings = args[0][2];
      // tslint:disable-next-line:no-console
      // console.log('query =>', '\'' + query + '\'');

      expect(query).toBe(queryResult);
    });
  });

});
