import { CommnRepository } from '../../../src/shared/repository/common.repository';
import { Position, PositionRow, PositionTable, PositionRowMapper } from '../../../src/position/position.entity';
import { PositionMessage } from '../../../src/position/position.msg';

import { WhereOptions, Op } from '../../../src/shared/repository/repository.interface';

describe('Common Repository', () => {
  let commonRepository: CommnRepository<Position>;
  const position = new Position();
  const testEstruturadoRow =
    { [PositionRow.id]: 2, [PositionRow.name]: 'Estrururado', [PositionRow.shortName]: 'Est.' };
  position.id = '1';
  position.name = 'Estruturados';
  describe('destroy', () => {
    beforeEach(() => {
      commonRepository = new CommnRepository(PositionRow,
        PositionTable,
        null,
        PositionMessage,
        new PositionRowMapper(),
        null);
    });

    it('Sucess', () => {
      commonRepository.destroy(position);
    });

    it('destroyBy', () => {
      commonRepository.destroyBy({});
    });
  });

  describe('parseWhere', () => {
    it('parseWhere  with or', () => {
      const where: WhereOptions<any> = {
        [Op.or]: [
          { tableId: 61 },
        ],
      };

      // tslint:disable-next-line:no-string-literal
      commonRepository['parseWhere'](where);
    });

    it('parseWhere with eq', () => {
      const where: WhereOptions<any> = {
        [Op.eq]: [
          { tableId: 61 },
        ],
      };

      // tslint:disable-next-line:no-string-literal
      commonRepository['parseWhere'](where);
    });

    it('parseWhere with like', () => {
      const where: WhereOptions<any> = {
        [Op.or]: [
          { tableId: 61, recordId: { [Op.like]: '10' } },
        ],
      };

      // tslint:disable-next-line:no-string-literal
      commonRepository['parseWhere'](where);
    });

    it('with in throws error', () => {
      const where: WhereOptions<any> = {
        [Op.or]: [
          { tableId: 61, recordId: { [Op.in]: 10 } },
        ],
      };

      try {
        // tslint:disable-next-line:no-string-literal
        commonRepository['parseWhere'](where);
      } catch {
        expect(where).toBeTruthy();
      }
    });

    it('between with wrong data types', () => {
      const where: WhereOptions<any> = {
        [Op.between]: [
          { tableId: 61, recordId: { [Op.between]: [10, '10'] } },
        ],
      };

      try {
        // tslint:disable-next-line:no-string-literal
        commonRepository['parseWhere'](where);
      } catch {
        expect(where).toBeTruthy();
      }
    });
  });

  // describe('update', () => {
  //   it('update with id', () => {
  //     stubConnection.execute.resolves({ rows: [testEstruturadoRow] });
  //     commonRepository.update(position, 10);
  //   });
  // });
});