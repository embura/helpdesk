import { CommonEntity } from '../../../src/shared/common/entity';
import { oracleErrorMocker } from '../../connection.mock';
import { HttpStatus } from '@nestjs/common';
import { classRefBuilder } from '../../mocks/mock.builder';
import { CategoryMessage } from '../../../src/shared/common/message.model';

const connErrMsg = '[ORA-1234] - erro no banco.';

export async function commonFindByNameSuccessTest(classRef: any, testRow: any, resultData: CommonEntity): Promise<void> {

  it('Fluxo de busca.', async () => {
    const [serviceForTest, stubConnection] = classRefBuilder(classRef);

    stubConnection.execute.resolves({rows: [testRow]});

    await expect(serviceForTest.findByName(resultData.name))
      .resolves.toEqual(resultData);
  });

}

export async function commonFindByNameRejectOracleTest(classRef: any, message: CategoryMessage, resultData: CommonEntity): Promise<void> {

  it('Tratamento de erro: Caso de erro no banco.', async () => {
    const [serviceForTest, stubConnection] = classRefBuilder(classRef);

    stubConnection.execute.rejects( new Error(connErrMsg) );

    await expect(serviceForTest.findByName(resultData.name))
      .rejects.toEqual({
        code: HttpStatus.INTERNAL_SERVER_ERROR,
        message: oracleErrorMocker(message, connErrMsg, 'SqlHandler'),
      });
  });

}
