import { CommonEntity } from '../../../src/shared/common/entity';
import { oracleErrorMocker } from '../../connection.mock';
import { HttpStatus } from '@nestjs/common';
import { classRefBuilder } from '../../mocks/mock.builder';
import { CategoryMessage } from '../../../src/shared/common/message.model';

const connErrMsg = '[ORA-1234] - erro no banco.';

export async function commonUpdateSuccessTest(classRef: any, testRow: any, resultData: CommonEntity ): Promise<void> {

  it('Atualiza entidade existente', async () => {
    const [serviceForTest, stubConnection] = classRefBuilder(classRef);

    const testData = Object.assign({}, resultData);
    testData.name = '  Derivativo  ';
    stubConnection.execute.onCall(0).resolves({rows: []});
    stubConnection.execute.resolves({rows: [testRow]});

    await expect(serviceForTest.update(resultData))
    .resolves.toEqual(resultData);
  });

}

export async function commonUpdateRejectDuplicateTest(
  classRef: any, message: CategoryMessage, testRow: any, resultData: CommonEntity ): Promise<void> {

  it('Trata erro quando tenta cadastrar família existente', async () => {
    const [serviceForTest, stubConnection] = classRefBuilder(classRef);

    stubConnection.execute.resolves({rows: [testRow]});

    await expect(serviceForTest.update(resultData, 'x123546'))
    .rejects.toEqual({
      code: HttpStatus.BAD_REQUEST,
      message: message.error.duplicatedName,
    });
  });

}

export async function commonUpdateRejactOracleTest(classRef: any, message: CategoryMessage, resultData: CommonEntity): Promise<void> {

  it('Tratamento de erro: Caso de erro no banco.', async () => {
    const [serviceForTest, stubConnection] = classRefBuilder(classRef);

    stubConnection.execute.rejects( new Error(connErrMsg) );

    await expect(serviceForTest.update(resultData, 'x123456'))
      .rejects.toEqual({
        code: HttpStatus.INTERNAL_SERVER_ERROR,
        message: oracleErrorMocker(message, connErrMsg, 'SqlHandler'),
      });
  });

}