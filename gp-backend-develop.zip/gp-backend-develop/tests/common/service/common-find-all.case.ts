import { CommonEntity } from '../../../src/shared/common/entity';
import { oracleErrorMocker } from '../../connection.mock';
import { HttpStatus } from '@nestjs/common';
import { classRefBuilder } from '../../mocks/mock.builder';
import { IQuery } from '../../../src/shared/common/query.interface';
import { CategoryMessage } from '../../../src/shared/common/message.model';

const connErrMsg = '[ORA-1234] - erro no banco.';

export async function commonFindAllSuccessTest(classRef: any, testRows: any[], resultDatas: CommonEntity[]): Promise<void> {

  it('Recebe todas as famílias e mapea as colunas corretamente.', async () => {
    const [serviceForTest, stubConnection] = classRefBuilder(classRef);
    const query: IQuery = {};

    stubConnection.execute.resolves({rows: testRows});

    await expect(serviceForTest.findAll(query))
      .resolves.toEqual(resultDatas);
  });

}

export async function commonFindAllRejectOracleTest(classRef: any, message: CategoryMessage): Promise<void> {

  it('Tratamento de erro: Caso de erro no banco.', async () => {
    const [serviceForTest, stubConnection] = classRefBuilder(classRef);
    const query: IQuery = {};

    stubConnection.execute.rejects( new Error(connErrMsg) );

    await expect(serviceForTest.findAll(query))
      .rejects.toEqual({
        code: HttpStatus.INTERNAL_SERVER_ERROR,
        message: oracleErrorMocker(message, connErrMsg, 'SqlHandler'),
      });
  });

}
