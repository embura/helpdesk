import 'reflect-metadata';
import { controllerRefBuilder } from '../../mocks/mock.builder';
import { HttpStatus } from '@nestjs/common';
import { IQuery } from '../../../src/shared/common/query.interface';
import { CategoryMessage } from '../../../src/shared/common/message.model';

const connErrMsg = '[ORA-1234] - erro no banco.';

export async function commonUpdateControllerSuccessTest(classRef: any, serviceRef: any, message: CategoryMessage, testData: any): Promise<void> {

  it('Atualiza corretamente.', async () => {
    const [controllerForTest, stubService, responseMock] = controllerRefBuilder(classRef, serviceRef, message);

    stubService.update.resolves(testData);

    await controllerForTest.update(responseMock.stub, testData);

    expect(responseMock.statusCode).toBe(HttpStatus.OK);
    expect(responseMock.json).toEqual({
      return: {
          code: 0,
          message: message.success.update,
      },
      data: testData,
    });
  });

}

export async function commonUpdateControllerRejactOracleTest(
  classRef: any, serviceRef: any, message: CategoryMessage, testData: any): Promise<void> {

    it('Tratamento de erro.', async () => {
      const [controllerForTest, stubService, responseMock] = controllerRefBuilder(classRef, serviceRef, message);
      const query: IQuery = {};
      stubService.update.rejects( new Error(connErrMsg) );

      await controllerForTest.update(responseMock.stub, testData)
        .then(expect(null).toBe) // para falhar quando dar sucesso
        .catch( (err) => {
          expect(err.response.message)
            .toEqual(connErrMsg);
          expect(err.status).toBe(HttpStatus.INTERNAL_SERVER_ERROR);
      });

    });

}
