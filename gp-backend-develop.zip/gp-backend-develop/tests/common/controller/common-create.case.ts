import 'reflect-metadata';
import { controllerRefBuilder } from '../../mocks/mock.builder';
import { HttpStatus } from '@nestjs/common';
import { IQuery } from '../../../src/shared/common/query.interface';
import { CategoryMessage } from '../../../src/shared/common/message.model';

const connErrMsg = '[ORA-1234] - erro no banco.';

export async function commonCreateControllerSuccessTest(classRef: any, serviceRef: any, message: CategoryMessage, testData: any): Promise<void> {

  it('Cria corretamente.', async () => {
    const [controllerForTest, stubService, responseMock] = controllerRefBuilder(classRef, serviceRef, message);
    const query: IQuery = {};
    stubService.create.resolves(testData);

    await controllerForTest.create(responseMock.stub, testData);

    expect(responseMock.statusCode).toBe(HttpStatus.CREATED);
    expect(responseMock.json).toEqual({
      return: {
          code: 0,
          message: message.success.create,
      },
      data: testData,
    });
  });

}

export async function commonCreateControllerRejactOracleTest(
  classRef: any, serviceRef: any, message: CategoryMessage, testData: any): Promise<void> {

    it('Tratamento de erro.', async () => {
      const [controllerForTest, stubService, responseMock] = controllerRefBuilder(classRef, serviceRef, message);
      const query: IQuery = {};
      stubService.create.rejects( new Error(connErrMsg) );

      await controllerForTest.create(responseMock.stub, testData)
        .then(expect(null).toBe) // para falhar quando dar sucesso
        .catch( (err) => {
          expect(err.response.message)
            .toEqual(connErrMsg);
          expect(err.status).toBe(HttpStatus.INTERNAL_SERVER_ERROR);
      });

    });

}
