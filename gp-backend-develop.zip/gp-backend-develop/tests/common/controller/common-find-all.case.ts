import { controllerRefBuilder } from '../../mocks/mock.builder';
import { HttpStatus } from '@nestjs/common';
import { IQuery } from '../../../src/shared/common/query.interface';
import { CategoryMessage } from '../../../src/shared/common/message.model';

const connErrMsg = '[ORA-1234] - erro no banco.';

export async function commoFindAllControllerSuccessTest(classRef: any, serviceRef: any, message: CategoryMessage, testDatas: any[]): Promise<void> {

  it('Retorna todas as famílias do banco corretamente.', async () => {
    const [controllerForTest, stubService, responseMock] = controllerRefBuilder(classRef, serviceRef, message);
    const query: IQuery = {};
    stubService.findAll.resolves(testDatas);

    await controllerForTest.findAll(responseMock.stub, query);

    expect(responseMock.statusCode).toBe(HttpStatus.OK);
    expect(responseMock.json).toEqual({
      return: {
          code: 0,
          message: message.success.found,
      },
      data: testDatas,
    });
  });

}

export async function commonFindAllControllerRejactOracleTest(
  classRef: any, serviceRef: any, message: CategoryMessage, testDatas: any[]): Promise<void> {

    it('Tratamento de erro.', async () => {
      const [controllerForTest, stubService, responseMock] = controllerRefBuilder(classRef, serviceRef, message);
      const query: IQuery = {};
      stubService.findAll.resolves(testDatas);

      stubService.findAll.rejects( new Error(connErrMsg) );

      await controllerForTest.findAll(responseMock.stub, query)
        .then(expect(null).toBe) // para falhar quando dar sucesso
        .catch( (err) => {
          expect(err.response.message)
            .toEqual(connErrMsg);
          expect(err.status).toBe(HttpStatus.INTERNAL_SERVER_ERROR);
      });

    });

}
