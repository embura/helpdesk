import { controllerRefBuilder } from '../../mocks/mock.builder';
import { HttpStatus } from '@nestjs/common';
import { CategoryMessage } from '../../../src/shared/common/message.model';

const connErrMsg = '[ORA-1234] - erro no banco.';

export async function commonFindByIdControllerSuccessTest(
  classRef: any, serviceRef: any, message: CategoryMessage, testData: any): Promise<void> {

  it('Retorna todas o dado do banco corretamente.', async () => {
    const [controllerForTest, stubService, responseMock] = controllerRefBuilder(classRef, serviceRef, message);
    stubService.findById.resolves(testData);

    await controllerForTest.findById(responseMock.stub, 1);

    expect(responseMock.statusCode).toBe(HttpStatus.OK);

    expect(responseMock.json).toEqual({
        return: {
            code: 0,
            message: message.success.found,
        },
        data: testData,
      });
  });

}

export async function commonFindByIdControllerRejactOracleTest(
  classRef: any, serviceRef: any, message: CategoryMessage, testData: any): Promise<void> {

    it('Tratar Erro: Caso erro no banco.', async () => {
      const [controllerForTest, stubService, responseMock] = controllerRefBuilder(classRef, serviceRef, message);
      stubService.findById.resolves(testData);

      stubService.findById.rejects( new Error(connErrMsg) );

      await controllerForTest.findById(responseMock.stub, 1)
        .then(expect(null).toBe) // para falhar quando dar sucesso
        .catch( (err) => {
          expect(err.response.message)
            .toEqual(connErrMsg);
          expect(err.status).toBe(HttpStatus.INTERNAL_SERVER_ERROR);
      });

    });

}
