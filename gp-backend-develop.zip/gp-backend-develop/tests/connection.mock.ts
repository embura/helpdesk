import { stub } from 'sinon';
import { ISimpleConnection } from 'haan-oracle';
import {IExecuteOptions, IExecuteReturn} from 'oracledb';
import { CategoryMessage } from '../src/shared/common/message.model';

export class StubConnection implements ISimpleConnection {
  result: IExecuteReturn = {
    rows: [],
  };

  execute(queryName: string, sql: string, bindParams?: {} | any[], options?: IExecuteOptions): Promise<IExecuteReturn> {
    return Promise.resolve(this.result);
  }

  close(): Promise<void> {
    return Promise.resolve();
  }

  commit(queryName: string): Promise<void> {
    return Promise.resolve();
  }
  rollback(queryName: string): Promise<void> {
    return Promise.resolve();
  }
}

export class StubConnection2 implements ISimpleConnection {

  private count = 0;
  results = [];
  execute = stub();
  close = stub();
  commit = stub();
  rollback = stub();

}

export function oracleErrorMocker(msg: CategoryMessage, connErr: string, at: string): string{
  return `${msg.error.oracle}Error: Oracle error "${connErr}" at ${at}.`;
}