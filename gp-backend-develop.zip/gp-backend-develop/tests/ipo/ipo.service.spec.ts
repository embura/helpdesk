import { IQuery } from './../../src/shared/common/query.interface';

// Common Imports
import 'reflect-metadata';
import * as sinon from 'sinon';

const DATE_TO_USE = new Date('2018-12-01T03:24:00');
global.Date = jest.fn(() => DATE_TO_USE) as any;
global.Date.now = jest.fn(() => DATE_TO_USE) as any;

// Individual Imports
import { IPOService } from '../../src/ipo/ipo.service';
import { IPORepository } from '../../src/ipo/ipo.repository';
import { reserveModelMock, reserveEntityMock } from './mock/reserve-model.mock';
import { SystemStatus, SystemStatusCode } from '../../src/shared/constants/status.enum';

describe('IPOService', () => {
  const connErrMsg = '[ORA-1234] - erro no banco.';
  // Service to test
  let ipoService: IPOService;
  // Dependencies
  let stubIpoReposiroty: sinon.SinonStubbedInstance<IPORepository>;

  beforeEach(() => {
    // Initialize Stub
    stubIpoReposiroty = sinon.createStubInstance(IPORepository);

    // Create intance for test
    ipoService
      = new IPOService(
        stubIpoReposiroty as any
      );

  });

  it('reserve', async () => {
    // test config
    stubIpoReposiroty.findAll.resolves([]);
    stubIpoReposiroty.create.resolves();
    stubIpoReposiroty.findOne.resolves(reserveEntityMock);
    const expected = Object.assign({}, reserveModelMock);
    delete expected.updateAt;
    delete expected.createAt;
    // executing test
    const result = await ipoService.reserve(reserveModelMock);
    delete result.updateAt;
    delete result.createAt;
    expect(result).toEqual(expected);
  });

  it('confirmContract', async () => {
    // test config
    const entityResponse = Object.assign({}, reserveEntityMock);
    stubIpoReposiroty.findOne.resolves(entityResponse);
    stubIpoReposiroty.customUpdate.resolves();
    const expected = Object.assign({}, reserveModelMock);
    expected.status.id = SystemStatus.Completed;
    expected.status.desc = SystemStatusCode[SystemStatus.Completed];
    delete expected.updateAt;
    delete expected.createAt;
    // executing test
    const result = await ipoService.confirmContract(reserveEntityMock.contractCode);
    delete result.updateAt;
    delete result.createAt;
    expect(result).toEqual(expected);
  });

  it('cancelReservation', async () => {
    // test config
    const mockReturn = Object.assign({}, reserveEntityMock);

    stubIpoReposiroty.findOne.resolves(mockReturn);
    stubIpoReposiroty.customUpdate.resolves();
    // executing test
    const result = await ipoService.cancelReservation(reserveEntityMock.contractCode);
    expect(result).toEqual('success');
  });

  it('findAllWithContacts', async () => {
    // test config
    const expected = Object.assign({}, reserveModelMock);
    delete expected.updateAt;
    delete expected.createAt;
    expected.status.id = SystemStatus.Pending;
    expected.status.desc = SystemStatusCode[SystemStatus.Pending];
    stubIpoReposiroty.findAll.resolves([reserveEntityMock]);
    // executing test
    const result = await ipoService.findAllWithContacts({});
    delete result[0].updateAt;
    delete result[0].createAt;
    expect(result).toEqual([expected]);
  });

  it('typeRate market', async () => {
    // executing test
    const result = await ipoService.typeRate('11', 'M');
    expect(result).toEqual('A mercado');
  });
  it('typeRate select', async () => {
    // executing test
    const result = await ipoService.typeRate('11', 'S');
    expect(result).toEqual('11');
  });
  it('typeRate select', async () => {
    // mock
    const mockChannel = [{
      sequence: 42,
      code: 6,
      name: 'IBF',
      acronym: 'IBF',
    }];
    const promise = Promise.resolve(mockChannel);
    // executing test
    const result = await ipoService.getChannel('6', promise);
    expect(result).toEqual('IBF');
  });

});
