import { IPOReserveModel } from '../../../src/ipo/domain/ipo-reserve.model';
import { ConfirmType } from '../../../src/ipo/domain/confirm.type';
import { ClientType } from '../../../src/ipo/domain/client.type';
import * as json2csv from 'json2csv';
import { ReturnRateType } from '../../../src/ipo/domain/return-rate.type';

const DATE_TO_USE = new Date('2018-12-01T03:24:00');
global.Date = jest.fn(() => DATE_TO_USE) as any;
global.Date.now = jest.fn(() => DATE_TO_USE) as any;

const _reserveModelMock: IPOReserveModel = {
	productId: 1,
	contractCode: 'TEST_00017',
	unitValue: 500,
	quantity: 30,
	confirmType: ConfirmType.mobile,
  channelCode: '58',

  seller: {
    code: 'x123456',
    name: 'Luke',
  },
  trader: {
    code: 'x987654',
    name: 'Obi-Wan',
  },
  returnRate: {
    type: ReturnRateType.market,
    request: 300.1234,
  },

	client: {
		name: 'Koji',
		isInsider: false,
		penumper: '7777777',
		segmentCode: '007',
		type: ClientType.fisic,
		documentNumber: '123',
		account: {
			agency: '0012',
      code: '456789',
      isDebitConditional: true,
    },
    contact: {
      email: 'example@text.com',
      telephone: 123456789,
    },
  },
};
export const reserveEntityMock = IPOReserveModel.toEntity(_reserveModelMock);
export const reserveModelMock = IPOReserveModel.fromEntity( reserveEntityMock );
export const reserveCSVMock = new json2csv.Parser().parse(reserveEntityMock);
