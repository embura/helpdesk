import 'reflect-metadata';
import * as sinon from 'sinon';

import { IPOController } from '../../src/ipo/ipo.controller';
import { IPOService } from '../../src/ipo/ipo.service';
import { reserveModelMock, reserveEntityMock, reserveCSVMock } from './mock/reserve-model.mock';

describe('IPOController', () => {
  // mocks and stubs
  let stubIPOService: sinon.SinonStubbedInstance<IPOService>;
  // class to test
  let ipoController: IPOController;

  // initializing
  beforeEach(() => {
    stubIPOService = sinon.createStubInstance(IPOService);

    ipoController = new IPOController(
      stubIPOService as any
    );

  });

  it('findAll', async () => {
    stubIPOService.findAllWithContacts.resolves([reserveModelMock]);

    const res = await ipoController.findAll(undefined);
    expect( res.data ).toEqual([reserveModelMock]);
  });

  xit('findAllCSV', async () => {
    stubIPOService.findAll.resolves([reserveEntityMock]);

    const res = await ipoController.findAllCSV(undefined);
    expect( res ).toEqual(reserveCSVMock);
  });

  it('reserve', async () => {
    stubIPOService.reserve.resolves(reserveModelMock);

    const res = await ipoController.reserve(reserveModelMock);
    expect( res.data ).toEqual(reserveModelMock);
  });

  it('cancel', async () => {
    const result = 'success';
    stubIPOService.cancelReservation.resolves(result);

    const res = await ipoController.cancel('1');
    expect( res.data ).toEqual(result);
  });

});