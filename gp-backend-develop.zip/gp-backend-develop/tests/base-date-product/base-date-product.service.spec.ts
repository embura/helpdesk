import { BaseDateProductService } from './../../src/base-date-product/base-date-product.service';
import { BaseDateProductRepository } from './../../src/base-date-product/base-date-product.repository';
import { BaseDateProduct } from './../../src/base-date-product/base-date-product.entity';
import * as sinon from 'sinon';

import { Observable } from 'rxjs/Rx';

const fileServiceMock = {
    findById: () => Observable.of({name: 'mock'}).toPromise(),
};

describe('Base Date Product Repository', () => {
    let repository: sinon.SinonStubbedInstance<BaseDateProductRepository>;
    let service: BaseDateProductService;

    beforeEach(() => {
        repository = sinon.createStubInstance(BaseDateProductRepository);
        service = new BaseDateProductService( repository as any, fileServiceMock as any);
    });

    it('should update', async () => {
        const mock = new BaseDateProduct();
        repository.update.resolves('mock');
        const resp = await service.update(mock);
        expect(resp).toEqual('mock');
    });

    it('should create', async () => {
        const mock = new BaseDateProduct();
        repository.create.resolves('mock');
        const resp = await service.create(mock);
        expect(resp).toEqual('mock');
    });

    it('should find by primary keys', async () => {
        const fileRow = {
            product: 1,
            baseDate: 1,
            fileNumber: 1,
        };
        repository.findByPKs.resolves([]);
        const resp = await service.findByPKs(fileRow as any);
        expect(resp.length).toBe(0);
    });

    it('should find by date', async () => {
        const mock = {
            fileNumber: 1,
            baseDate: 'mock',
            product: 'mock',
        };
        repository.findByDate.resolves([mock]);
        const resp = await service.findByDate(new Date());
        expect(resp[0].fileName).toEqual('mock');
    });
});