import 'reflect-metadata';
import { BaseDateProductRepository } from '../../src/base-date-product/base-date-product.repository';
<<<<<<< HEAD

import { BaseDateProductRow, BaseDateProduct, BaseDateProductRowMapper } from '../../src/base-date-product/base-date-product.entity';
import { SqlHandler } from '../../src/shared/lib/database/query-handler';
import { RowMapper } from '../../src/shared/repository/repository.interface';
import { SequenceRowMapper } from '../../src/shared/common/sequence.entity';
import { createStubInstance } from 'sinon';
import sinon from 'sinon';
=======
import { BaseDateProductRow, BaseDateProduct } from '../../src/base-date-product/base-date-product.entity';
>>>>>>> ef52ded942efe5755b72b45280e206b165067736

const DATE_TO_USE = new Date('2018-12-01T03:24:00');
global.Date = jest.fn(() => DATE_TO_USE) as any;

const mock = new BaseDateProduct();
mock.product = 'CRI_ABC';
mock.baseDate = new Date();
mock.fileNumber =  10;
mock.statusInt = 5;

const mockRow = {
  [BaseDateProductRow.product]: mock.product,
  [BaseDateProductRow.baseDate]: mock.baseDate,
  [BaseDateProductRow.fileNumber]: mock.fileNumber,
  [BaseDateProductRow.statusInt]: mock.statusInt,
};

describe('BaseDateProductRepository', () => {
  let baseDateProductRepository: BaseDateProductRepository;
  let mockResult;

  beforeEach(() => {
    mockResult = Symbol('teste');
    baseDateProductRepository = new BaseDateProductRepository();
    (baseDateProductRepository as any).queryHandler = createStubInstance(SqlHandler);
    (baseDateProductRepository as any).commandHandler = createStubInstance(SqlHandler);
    (baseDateProductRepository as any).queryHandler.execute.resolves(mockResult);
    (baseDateProductRepository as any).commandHandler.execute.resolves(mockResult);
  });

  describe('findByPKs', () => {
    it('success case', async () => {
      const where = {
        product: '',
        baseDate: new Date(),
        fileNumber: '',
      };

      const results =  await baseDateProductRepository.findByPKs(where);
      expect(results).toEqual(mockResult);
    });

  });

  describe('findByDate', async () => {

    it('success case', async () => {
      const fileNumber = 2;
      const results =  await baseDateProductRepository.findByDate(new Date(), fileNumber);
      expect(results).toEqual(mockResult);
    });

  });

  describe('update', async () => {

    it('success case', async () => {
      const results =  await baseDateProductRepository.update(mock);
      expect(results).toEqual(mockResult);
    });

  });

  describe('create', async () => {

    it('success case', async () => {
      const results =  await baseDateProductRepository.create(mock);
      expect(results).toEqual(mockResult);
    });

  });

});
