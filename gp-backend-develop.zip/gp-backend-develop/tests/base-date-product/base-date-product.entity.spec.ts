import 'reflect-metadata';
import { BaseDateProductRowMapper } from '../../src/base-date-product/base-date-product.entity';

describe('BaseDateProduct Entity', () => {
  const row = {};
  it('RowMapper', () => {
    const baseDateProduct = new BaseDateProductRowMapper();
    const mapper = baseDateProduct.map(row);
    expect(mapper).toBeTruthy();
  });
});