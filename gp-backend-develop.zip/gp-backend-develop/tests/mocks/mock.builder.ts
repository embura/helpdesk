import * as sinon from 'sinon';
import { LogService } from '../../src/shared/repository/log/log.service';

import { CommonRepositoryService } from '../../src/shared/common/repository.service';
import { CommonController } from '../../src/shared/common/common.controller';
import { ResTester } from '../res-req.mock';
import { CategoryMessage } from '../../src/shared/common/message.model';

export function logServiceMockBuilder(): LogService {
  return sinon.createStubInstance(LogService);
}

export function classRefBuilder(classRef: any): [CommonRepositoryService<any>, undefined, LogService] {
  const logServiceMock = logServiceMockBuilder();
  const serviceForTest = new classRef(logServiceMock);
  return [serviceForTest, undefined, logServiceMock];
}
export function controllerRefBuilder(
  classRef: any, serviceRef: any, message: CategoryMessage
): [CommonController<any>, any, ResTester] {
  const stubService = sinon.createStubInstance(serviceRef);
  const controllerForTest = new classRef(stubService, message);
  return [controllerForTest, stubService, new ResTester() ];
}