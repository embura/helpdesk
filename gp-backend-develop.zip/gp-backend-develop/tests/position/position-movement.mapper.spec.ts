import 'reflect-metadata';
import { PositionMovementMapper } from '../../src/position/position-movement.mapper';
import { PositionRow } from '../../src/position/position.entity';

describe('Position Movement Entity', () => {
  const row = {
    [PositionRow.positionDate]: '1',
  };

  it('RowMapper', () => {
    const positionMovementMapper = new PositionMovementMapper();
    const movement = positionMovementMapper.map(row);
    expect(positionMovementMapper).toBeTruthy();
  });

});