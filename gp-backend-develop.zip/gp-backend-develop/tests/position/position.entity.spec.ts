import 'reflect-metadata';
import { PositionRowMapper, createPosition, positionFormatToDate } from '../../src/position/position.entity';
import { PositionRow } from '../../src/position/position.entity';
import { Position } from '../../src/position/position.entity';

describe('Position Entity', async () => {
  const row = {
    [PositionRow.positionDate]: '1',
    [PositionRow.typePerson]: 'F',
    [PositionRow.documentNumber]: '12312312312311',
    [PositionRow.agencyCode]: '2277',
  };

  const row1 = {
    [PositionRow.positionDate]: '20190506',
    [PositionRow.typePerson]: 'J',
    [PositionRow.documentNumber]: '12312312312311',
    [PositionRow.agencyCode]: '2277',
  };

  it('RowMapper', () => {
    const position = new PositionRowMapper();
    const mapper = position.map(row);
    const mapper1 = position.map(row1);
    expect(mapper).toBeTruthy();
    expect(mapper1).toBeTruthy();
  });

  it('CreatePosition', () => {
    const position: Position = createPosition();
    expect(position).toBeInstanceOf(Position);
  });

  it('positionFormatToDate', () => {
    let  position: Position = createPosition();
    position =  positionFormatToDate(position);
    expect(position).toBeInstanceOf(Position);
  });



});