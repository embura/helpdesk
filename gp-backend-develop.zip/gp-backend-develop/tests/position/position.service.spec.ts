// Common Imports
import 'reflect-metadata';
import { PositionService } from '../../src/position/position.service';
import * as sinon from 'sinon';
import { PositionRepository } from '../../src/position/position.repository';
import { ProductRepository } from '../../src/product/product.repository';
import { MovimentRepository } from '../../src/moviment/moviment.repository';
import { BaseDateProductRepository } from '../../src/base-date-product/base-date-product.repository';
import { SegmentRepository } from '../../src/segment/segment.repository';
import { CommnRepository } from '../../src/shared/repository/common.repository';
import { BaseDateProduct } from '../../src/base-date-product/base-date-product.entity';
import moment = require('moment');
import { Segment } from '../../src/segment/segment.entity';
import { Position, PositionDetail } from '../../src/position/position.entity';
import { Product } from '../../src/product/product.entity';
import { Moviment } from '../../src/moviment/moviment.entity';
import { IQuery } from '../../src/shared/common/query.interface';
import { stringify } from 'querystring';
import { PositionGroupDetail } from '../../src/position/position-group-detail';
// Indifitual Imports

describe('Position Service', () => {

  let positionService: PositionService;
  let positionRepository: sinon.SinonStubbedInstance<PositionRepository>;
  let productRepository: sinon.SinonStubbedInstance<ProductRepository>;
  let movimentRepository: sinon.SinonStubbedInstance<MovimentRepository>;
  let baseDateProductRepository: sinon.SinonStubbedInstance<BaseDateProductRepository>;
  let segmentRepository: sinon.SinonStubbedInstance<SegmentRepository>;

  beforeEach(() => {

    positionRepository = sinon.createStubInstance(PositionRepository);
    productRepository = sinon.createStubInstance(ProductRepository);
    movimentRepository = sinon.createStubInstance(MovimentRepository);
    baseDateProductRepository = sinon.createStubInstance(BaseDateProductRepository);
    segmentRepository = sinon.createStubInstance(SegmentRepository);

    positionService = new PositionService(
      positionRepository as any,
      productRepository as any,
      movimentRepository as any,
      baseDateProductRepository as any,
      segmentRepository as any
      );
    (positionService as any).repository = sinon.createStubInstance(CommnRepository);
  });

  describe('instance', () => {
    it('should instance', () => {
      expect(positionService).toBeTruthy();
    });
  });

  describe('findAll', () => {
    it('should return an array', async () => {
      const mockResult = Symbol('result');
      (positionService as any).repository.findAll.resolves(mockResult);

      const res = await positionService.findAll({});
      expect(res).toEqual(mockResult);
    });
  });

  describe('findPositionMovement', () => {
    it('should return an array', async () => {
      const segment1: Segment = new Segment();
      segment1.code = '1';
      const pos1: Position = new Position();
      pos1.id = 'PVD_0001';
      pos1.productSbkCode = '89';
      pos1.segmentCodeClient = '0001';
      const prod1: Product = new Product();
      prod1.id = '89';
      const mov1: Moviment = new Moviment();
      mov1.id = 'PVD_0001';

      await (positionService as any).repository.findAll.resolves([pos1]);
      (positionService as any).createProductsMap = () => new Map<string, Product>();
      (positionService as any).createMovementMap = () => new Map<string, Moviment[]>();
      (positionService as any).updatePositionByProduct = () => pos1;

      await movimentRepository.findAll.resolves([mov1]);
      await segmentRepository.findAll.resolves([segment1]);
      await productRepository.findAll.resolves([prod1]);

      await baseDateProductRepository.findOne.resolves(new BaseDateProduct());

      const res = await positionService.findPositionMovement({
        positionDate: moment().format('YYYYMMDD'),
      });

      expect(res.positions[0].id).toEqual(pos1.id);
    });

  });

  describe('bindBodyToPosition', () => {
    it('body to Position sucess', () => {

      const positionBody: any = {
        id: 'PVD_0001',
        isPrivate: false,
        productId: 100,
        aplicationDate: new Date(),
      };

      const position = positionService.bindBodyToPosition(positionBody);

      expect(positionBody.id).toEqual(position.id);

    });
  });

  describe('createMovementMap', () => {
    it('create Movement Map sucess', () => {

      const mov1 = new Moviment();
      mov1.globalId = 'PVD_0001';
      const mov2 = new Moviment();
      mov2.globalId = 'PVD_0001';

      const movs = [mov1, mov2];

      const movsMap = new Map<string, Moviment[]>();
      movsMap.set(mov1.globalId, movs);

      const movMap = positionService.createMovementMap(movs);

      expect(movMap).toEqual(movsMap);

    });
  });

  describe('createOrSearchParam', () => {
    it('create Or Search Param sucess', () => {

      const searchedText = 'IND SA';
      const arrSearch =  [
        `agencyCode:like:${searchedText}`,
        `accountCode:like:${searchedText}`,
        `sbkCodeId:like:${searchedText}`,
        `id:like:${searchedText}`,
        `productSbkCode:like:${searchedText}`,
      ];

      const search = positionService.createOrSearchParam(searchedText);
      expect(search).toEqual(arrSearch);
    });
  });

  describe('updatePositionByProduct', () => {
    it('update Position ByProduct sucess', () => {

      const pos = new Position();
      const prod = new Product();

      prod.groupProductName = 'Público';
      prod.productId = 111;
      prod.name = 'Tesouro selic';

      const search = positionService.updatePositionByProduct(pos, prod);
      expect(search.productId).toEqual(prod.productId);
    });
  });

  describe('queryParse', () => {
    it('query Parset sucess', () => {

      const query: IQuery = {
        initialApplicationDate: '20190501',
        endApplicationDate: '20190507',
        segmentList: ['1', '2', '3'] as any,
        filter: {
          customSearch: 'Joel',
          searchedText: '109323',
          orderBy: 4,
          sortBySituation: true,
        } as any,
      };
      const result =  {
        _between: 'aplicationDate:20190501:20190507',
        _in: 'segmentCodeClient:1,2,3',
        _or: [
          'agencyCode:like:Joel',
          'accountCode:like:Joel',
          'sbkCodeId:like:Joel',
          'id:like:Joel',
          'productSbkCode:like:Joel',
        ],
        sortBySituation: true,
      };

      const parse = positionService.queryParse(query);
      expect(parse).toEqual(result);
    });
  });

  describe('getOrder', () => {
    it('getOrder', () => {
      let search = positionService.getOrder(1);
      expect(search).toEqual([['productSbkCode', 'ASC']]);
      search = positionService.getOrder(2);
      expect(search).toEqual([['aplicationDate', 'DESC']]);
      search = positionService.getOrder(3);
      expect(search).toEqual([['aplicationDate', 'ASC']]);
      search = positionService.getOrder(4);
      expect(search).toEqual([['dueDate', 'ASC']]);
      search = positionService.getOrder(5);
      expect(search).toEqual([['updatedGrossValueAvailable', 'DESC']]);
      search = positionService.getOrder(6);
      expect(search).toEqual([['liquidityValue', 'DESC']]);
    });
  });

  describe('getOrder', () => {
    it('Order by ID ASC e DESC', () => {
      const pos1: Position = new Position();
      pos1.id = 'PVD_0001';
      pos1.productSbkCode = '89';
      pos1.segmentCodeClient = '0001';
      const pos2: Position = new Position();
      pos2.id = 'PVD_0002';
      pos2.productSbkCode = '89';
      pos2.segmentCodeClient = '0001';

      const positions: Position[] = [];

      positions.push(pos1);
      positions.push(pos2);

      let search = positionService.sortPositionByValue(positions, 'id', 'DESC');
      expect(search[0].id).toEqual(pos2.id);

      search = positionService.sortPositionByValue(positions, 'id', 'ASC');
      expect(search[0].id).toEqual(pos1.id);
    });
  });

  describe( 'sortGroupBySituation', () => {
    it('sort Group BySituation sucess', () => {
      const pos1: Position = new Position();
      pos1.id = 'PVD_0001';
      pos1.productSbkCode = 'CRA017002BE';
      pos1.segmentCodeClient = '0001';
      pos1.situation = 'ATIVO';
      pos1.groupName = 'Títulos Privados';

      const pos2: Position = new Position();
      pos2.id = 'PVD_0002';
      pos2.productSbkCode = 'BRSTNCNTB3B8';
      pos2.segmentCodeClient = '0001';
      pos2.situation = 'BLOQUEADA';
      pos1.groupName = 'Títulos Públicos';

      const pos3: Position = new Position();
      pos3.id = 'PVD_0002';
      pos3.productSbkCode = '89';
      pos3.segmentCodeClient = '0001';
      pos3.situation = 'CARÊNCIA';
      pos3.groupName = 'Emissões de Outros Bancos';

      const positions: Position[] = [];

      positions.push(pos3);
      positions.push(pos1);
      positions.push(pos2);

      const groups: Map<string, PositionGroupDetail> = new Map<string, PositionGroupDetail>();
      let positionGroupDetailTmp: PositionGroupDetail;

      positionGroupDetailTmp = new PositionGroupDetail();
      positionGroupDetailTmp.name = pos1.groupName;

      const positionDetail = new PositionDetail(pos1);
      positionGroupDetailTmp.add(positionDetail);

      groups.set(positionGroupDetailTmp.name, positionGroupDetailTmp);

      const search = positionService.sortGroupBySituation(groups);
      
      expect(search.get(pos1.groupName).operations[0].situation).toEqual(pos1.situation);
    });
  });
  
  
  describe( 'orderBySituation', () => {
    it('order By Situation sucess', () => {
      const pos1: Position = new Position();
      pos1.id = 'PVD_0001';
      pos1.productSbkCode = 'CRA017002BE';
      pos1.segmentCodeClient = '0001';
      pos1.situation = 'ATIVO';
      pos1.groupName = 'Títulos Privados';

      const pos2: Position = new Position();
      pos2.id = 'PVD_0002';
      pos2.productSbkCode = 'BRSTNCNTB3B8';
      pos2.segmentCodeClient = '0001';
      pos2.situation = 'BLOQUEADA';
      pos1.groupName = 'Títulos Públicos';

      const pos3: Position = new Position();
      pos3.id = 'PVD_0002';
      pos3.productSbkCode = '89';
      pos3.segmentCodeClient = '0001';
      pos3.situation = 'CARÊNCIA';
      pos3.groupName = 'Emissões de Outros Bancos';

      const positions: Position[] = [];

      positions.push(pos3);
      positions.push(pos1);
      positions.push(pos2);
      const search = positionService.orderBySituation(positions);

      expect(search[0].situation).toEqual(pos1.situation);
      expect(search[1].situation).toEqual(pos3.situation);
      expect(search[2].situation).toEqual(pos2.situation);
    });
  });

  describe( 'agroupGroupName', () => {
    it('agroup Group Name sucess', () => {
      const pos1: Position = new Position();
      pos1.id = 'PVD_0001';
      pos1.productSbkCode = 'CRA017002BE';
      pos1.segmentCodeClient = '0001';
      pos1.situation = 'ATIVO';
      pos1.groupName = 'Títulos Privados';

      const pos2: Position = new Position();
      pos2.id = 'PVD_0002';
      pos2.productSbkCode = 'BRSTNCNTB3B8';
      pos2.segmentCodeClient = '0001';
      pos2.situation = 'BLOQUEADA';
      pos1.groupName = 'Títulos Públicos';

      const pos3: Position = new Position();
      pos3.id = 'PVD_0003';
      pos3.productSbkCode = '89';
      pos3.segmentCodeClient = '0001';
      pos3.situation = 'CARÊNCIA';
      pos3.groupName = 'Emissões de Outros Bancos';

      const pos4: Position = new Position();
      pos4.id = 'PVD_0004';
      pos4.productSbkCode = '89';
      pos4.segmentCodeClient = '0001';
      pos4.situation = 'ATIVO';
      pos4.groupName = 'Emissões de Outros Bancos';

      const positions: Position[] = [];

      positions.push(pos3);
      positions.push(pos1);
      positions.push(pos2);
      positions.push(pos4);

      const search = positionService.agroupGroupName(positions);

      expect(search.get(pos1.groupName).operations[0].groupName).toEqual(pos1.groupName);
    });
  });

  describe('updatePositionByMovements', () => {
    it('update Position By Movements', () => {
      const pos1: Position = new Position();
      pos1.id = 'PVD_0001';
      pos1.productSbkCode = 'CRA017002BE';
      pos1.segmentCodeClient = '0001';
      pos1.situation = 'ATIVO';
      pos1.groupName = 'Títulos Privados';
      const mov1 = new Moviment();
      mov1.id = 'PVD_M_0001';
      mov1.globalId = 'PVD_0001';
      mov1.moviGFCode = 'NO';
      mov1.moviType = 'S';
      mov1.sourceSys = 'ONL';
      const movs: Moviment[] = [];

      pos1.irValue = 10;
      pos1.iofValue = 10;
      pos1.availableQuantity = 100;
      pos1.updatedNetValueAvailable = 100;
      pos1.updatedGrossValueAvailable = 100;
      pos1.liquidityValue = 100;

      mov1.tradedQuantity = 5;

      movs.push(mov1);

      const search = positionService.updatePositionByMovements(pos1, movs);

      let total = 0;
      movs.forEach(a => {
        total += a.tradedQuantity;
      });

      expect(search.availableQuantity).toEqual( pos1.availableQuantity - total);

    });
  });

});
