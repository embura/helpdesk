import 'reflect-metadata';

import { PositionGroupDetail } from '../../src/position/position-group-detail';
import { Position, PositionConsolidated, PositionDetail } from '../../src/position/position.entity';

describe('PositionGroup Details', () => {
  let positionGroupDetail: PositionGroupDetail;

  describe('getPenumperToExport', () => {

    it('should create', async () => {

      const position = new Position();
      const positionDetail = new PositionDetail(position);

      positionGroupDetail = new PositionGroupDetail();

      positionGroupDetail.add(positionDetail);

      expect(positionDetail).toBeTruthy();
    });

  });

});
