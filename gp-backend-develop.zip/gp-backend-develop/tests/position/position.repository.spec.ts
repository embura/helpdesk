import 'reflect-metadata';

import { PositionRepository } from '../../src/position/position.repository';
import { Position } from '../../src/position/position.entity';
import { createStubInstance } from 'sinon';
import { SqlHandler } from '../../src/shared/lib/database/query-handler';

describe('ImportFileService', () => {
  // Connection
  
  let positionRepository: PositionRepository;
  let position: Position;
  const mockResult = Symbol('test');

  beforeEach(() => {
    // Connection
    positionRepository = new PositionRepository();
    position = new Position();

    (positionRepository as any).queryHandler = createStubInstance(SqlHandler);
    (positionRepository as any).queryHandler.execute.resolves(mockResult);

    (positionRepository as any).commandHandler = createStubInstance(SqlHandler);
    (positionRepository as any).commandHandler.execute.resolves(mockResult);

  });

  describe('Instance PositionRepository', () => {
    it('should return install ', () => {

      expect(position).toBeTruthy();
      expect(positionRepository).toBeTruthy();
    });
  });

  describe('findByGlobalIdAndDate', () => {
    it('should create', () => {
      expect(position).toBeTruthy();
      expect(positionRepository).toBeTruthy();
    });
    it('gets message', async () => {
      const dateBase = new Date();
      const MockInput1 = '1';
      const result = await positionRepository.findByGlobalIdAndDate(MockInput1, dateBase);
      expect(result).toBe(mockResult);
    });
  });

  describe('getPenumperToExport', () => {
    it('should create', () => {
      expect(position).toBeTruthy();
      expect(positionRepository).toBeTruthy();
    });
    it('gets data', async () => {
      const fileDate = new Date();
      const MockInput = { fileDate };
      const result = await positionRepository.getPenumperToExport(MockInput);
      expect(result).toBe(mockResult);
    });
  });

  describe('parse create', () => {
    it('should create', () => {
      const MockInput = new Position();
      const result = positionRepository.create(MockInput);
      expect(result).toEqual(Promise.resolve());
    });
    it('parse SQL', async () => {
      const fileDate = new Date();
      const MockInput = new Position();
      const result = await positionRepository['parseCreate'](MockInput);
      expect(result).toBe('INTO GPOS.TB_POSI_TESO () VALUES ()');
    });
    it('parse SQL else', async () => {
      const fileDate = new Date();
      const MockInput = new Position();
      MockInput.dueDate = new Date('2019-01-01');
      const result = await positionRepository['parseCreate'](MockInput);
      expect(result).toBe(`INTO GPOS.TB_POSI_TESO (DT_VENC) VALUES (TO_DATE('20190101', 'YYYYMMDD'))`);
    });
    it('parse SQL else', async () => {
      const fileDate = new Date();
      const MockInput = new Position();
      MockInput.agencyCode = 123;
      const result = await positionRepository['parseCreate'](MockInput);
      expect(result).toBe(`INTO GPOS.TB_POSI_TESO (CD_AGEN_CLIE) VALUES (123)`);
    });
    it('parse SQL else', async () => {
      const fileDate = new Date();
      const MockInput = new Position();
      MockInput.clientName = 'test';
      const result = await positionRepository['parseCreate'](MockInput);
      expect(result).toBe(`INTO GPOS.TB_POSI_TESO (NM_CLIE) VALUES ('test')`);
    });

    it('should updatePosition', () => {
      const MockInput = new Position();
      const MockId = '1';
      const MockDate = new Date();
      const result = positionRepository.updatePosition(MockInput, MockId, MockDate);
      expect(result).toEqual(Promise.resolve());
    });

  });

});
