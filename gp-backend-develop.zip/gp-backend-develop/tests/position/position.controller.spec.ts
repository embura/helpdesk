import { PositionController } from '../../src/position/position.controller';
import { PositionService } from '../../src/position/position.service';
import { ResTester } from '../res-req.mock';
import * as sinon from 'sinon';
import { Position, PositionDetail } from '../../src/position/position.entity';
import { Pagination } from '../../src/shared/utils/pagination.model';
import { BaseDate } from '../../src/base-date/base-date.entity';
import { SystemStatus } from '../../src/shared/constants/status.enum';
import { HttpStatus, HttpCode } from '@nestjs/common';
import { HttpResponse } from '../../src/shared/http.response';
import { Status } from '../../src/shared/status.entity';
import { PositionMessage } from '../../src/position/position.msg';
import { PositionGroupDetail } from '../../src/position/position-group-detail';

let stubPositionService: sinon.SinonStubbedInstance<PositionService>;
let positionController: PositionController;

const sysDateToday = new BaseDate();
sysDateToday.id = new Date('2018-12-01T03:00:00');
sysDateToday.statusInt = SystemStatus.UpTodate;
const sysDateYesterday = new BaseDate();
sysDateYesterday.id = new Date('2018-12-01T03:00:00');
sysDateYesterday.statusInt = SystemStatus.UpTodate;
const posiMsg = PositionMessage;

describe('Find Client', () => {
  const pagination = new Pagination();
  let responseMock: ResTester;

  beforeEach(() => {
    stubPositionService = sinon.createStubInstance(PositionService);

    positionController = new PositionController(
      stubPositionService as any
    );
    responseMock = new ResTester();
  });

  describe('Update', () => {

    it('update position sucesso', async () => {
      const position = new Position();
      position.id = 'PVD_0001';
      position.penumper = '12345678';

      stubPositionService.positionUpdate.resolves(position);
      const responseUpdate = await positionController.update( responseMock.stub, position);
      responseUpdate.json = responseMock.json;

      expect(responseUpdate.json).toEqual(
        new HttpResponse(new Status(HttpStatus.OK, posiMsg.success.update), position)
      );
    });

    it('update position fail', async () => {
      const position = new Position();
      position.id = 'PVD_0001';
      position.penumper = '12345678';

      stubPositionService.positionUpdate.rejects({});
      const positionUpdated = await positionController.update( responseMock.stub, position);
      positionUpdated.json = responseMock.json;

      expect(positionUpdated.json).toEqual(new HttpResponse(new Status(HttpStatus.INTERNAL_SERVER_ERROR, undefined), {}));
    });

  });

  describe('findClientDetail', () => {

    it('no position date in query, need penumper', async () => {

      await stubPositionService.findPositionMovement.resolves({ positions: [ ], pagination });

      const res = await positionController.findClientDetail( responseMock.stub, {
        positionDate: '20190506',
        // penumper: '12345678',
      });

      res.json = responseMock.json;

      expect(res.json).toEqual(
        new HttpResponse(new Status(400, posiMsg.error.invalidRequired), 'penumper empty')
      );
    });

    it('no position date in query', async () => {

      await stubPositionService.findPositionMovement.resolves({ positions: [ ], pagination });

      const res = await positionController.findClientDetail( responseMock.stub, {
        positionDate: '20190506',
        penumper: '12345678',
      });

      res.json = responseMock.json;

      expect(res.json).toEqual(
        new HttpResponse(new Status(HttpStatus.OK, posiMsg.error.notFound), {})
      );
    });

    it('position date in query', async () => {
      const p1 = new Position();
      const p2 = new Position();
      p1.situation = '1';
      p2.situation = '2';
      p1.penumper = '12345678';
      p1.group = 'Público';

      await stubPositionService.findPositionMovement.resolves({ positions: [ p1, p2 ], pagination });
      const positionAgroupDetails = new Map<string, PositionGroupDetail>();
      const  positionGroupDetail = new PositionGroupDetail();
      positionAgroupDetails.set('Público', positionGroupDetail);

      (stubPositionService as any).agroupGroupName = () => {
        return positionAgroupDetails;
      };

      const res = await positionController.findClientDetail( responseMock.stub, {
        positionDate: '20190506',
        penumper: '12345678',
      });

      res.json = responseMock.json;

      expect(res.json['data'].groups).toEqual([positionAgroupDetails.get('Público')]);
      expect(res.json).toEqual(
        new HttpResponse(new Status(0, posiMsg.success.found), {
          groups: [...positionAgroupDetails.values()],
          pagination,
        })
      );
    });

  });

  describe('findProductDetail', () => {
    it('no position date in query', async () => {
      const pg = new Pagination();
      const positions: Position[] = [];
      const resPosiPages: {positions: Position[], pagination: Pagination} = { positions, pagination: pg };

      await stubPositionService.findByProductId.resolves(resPosiPages);
      (stubPositionService as any).orderBySituation = () => {
        return positions;
      };

      const res = await positionController.findProductDetail( responseMock.stub, {
        positionDate: '20190506',
        productSbkCode: 'CRA018003UX',
      });
      res.json = responseMock.json;

      expect(res.json).toEqual(
        new HttpResponse(new Status(HttpStatus.OK, posiMsg.error.notFound), {})
      );
    });

    it('position date in query', async () => {
      const p1 = new Position();
      const p2 = new Position();
      p1.situation = '1';
      p2.situation = '2';
      const pg = new Pagination();
      const positions: Position[] = [ p1, p2 ];
      const resPosiPages: {positions: Position[], pagination: Pagination} = { positions, pagination: pg };

      (stubPositionService as any).orderBySituation = () => positions;

      await stubPositionService.findByProductId.resolves(resPosiPages);

      const res = await positionController.findProductDetail( responseMock.stub, {
        positionDate: '20190506',
        productSbkCode: 'CRA018003UX',
      });
      res.json = responseMock.json;

      const positionsAgrouped = positions.map(posi => new PositionDetail(posi).getPosition());

      expect(res.json).toEqual(
        new HttpResponse(new Status(0, posiMsg.success.found), {
          products: {
            totalQuantity: positionsAgrouped.length,
            operations: positionsAgrouped,
          },
          pagination,
        })
      );

    });

  });

});