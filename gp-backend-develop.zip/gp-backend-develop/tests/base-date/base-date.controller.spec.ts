import 'reflect-metadata';
import * as sinon from 'sinon';
import { ResTester } from '../res-req.mock';
import { BaseDateRowMapper, BaseDate } from '../../src/base-date/base-date.entity';
import { BaseDateController } from '../../src/base-date/base-date.controller';
import { BaseDateService } from '../../src/base-date/base-date.service';
import { BaseDateProductService } from '../../src/base-date-product/base-date-product.service';
import { HttpStatus } from '@nestjs/common';
import { BaseDateProduct } from '../../src/base-date-product/base-date-product.entity';

describe('BaseDate Entity', () => {
  // mocks and stubs
  let stubDaseDateService: sinon.SinonStubbedInstance<BaseDateService>;
  let stubBaseDateProductService: sinon.SinonStubbedInstance<BaseDateProductService>;
  let responseMock: ResTester;
  // class to test
  let baseDateController: BaseDateController;

  // initializing
  beforeEach(() => {
    responseMock = new ResTester();
    stubDaseDateService = sinon.createStubInstance(BaseDateService);
    stubBaseDateProductService = sinon.createStubInstance(BaseDateProductService);

    baseDateController = new BaseDateController(
      stubDaseDateService as any,
      stubBaseDateProductService as any
    );

  });

  it('findLast', async () => {
    stubDaseDateService.findLast2.resolves(['correct', 'wrong']);

    await baseDateController.findLast(responseMock.stub, {});
    expect(responseMock.statusCode).toBe(HttpStatus.OK);
  });

  it('getFilesStatus', async () => {
    const resOne = new BaseDateProduct();
    stubDaseDateService.findLast2.resolves([{}]);
    stubBaseDateProductService.findByDate.resolves([]);

    await baseDateController.findLast(responseMock.stub, {});
    expect(responseMock.statusCode).toBe(HttpStatus.OK);
  });
});