import 'reflect-metadata';
import { BaseDateRowMapper } from '../../src/base-date/base-date.entity';

describe('BaseDate Entity', async () => {
  const row = {};
  it('RowMapper', () => {
    const baseDate = new BaseDateRowMapper();
    const mapper = baseDate.map(row);
    expect(mapper).toBeTruthy();
  });
});