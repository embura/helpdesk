import 'reflect-metadata';
import * as sinon from 'sinon';
import { BaseDateService } from '../../src/base-date/base-date.service';
import { BaseDateRepository } from '../../src/base-date/base-date.repository';

describe('BaseDate Entity', () => {
  let baseDateService: BaseDateService;
  let stubBaseDateRepository: sinon.SinonStubbedInstance<BaseDateRepository>;

  beforeAll(() => {
    stubBaseDateRepository = sinon.createStubInstance(BaseDateRepository);
    baseDateService = new BaseDateService(
      stubBaseDateRepository as any
    );
  });

  it('should create', async () => {
    stubBaseDateRepository.findByDate.resolves({});
    const res = await baseDateService.findByDate(new Date());
    expect(res).toBeTruthy();
  });

  it('should create', async () => {
    stubBaseDateRepository.findLast2.resolves({});
    const res = await baseDateService.findLast2();
    expect(res).toBeTruthy();
  });

  it('should create', async () => {
    stubBaseDateRepository.update.resolves({});
    const res = await baseDateService.update({} as any);
    expect(res).toBeTruthy();
  });

  it('should create', async () => {
    stubBaseDateRepository.create.resolves({});
    const res = await baseDateService.create({} as any);
    expect(res).toBeTruthy();
  });

});