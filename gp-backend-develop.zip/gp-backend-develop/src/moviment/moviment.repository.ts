import { Moviment, MovimentRow, MovimentRowMapper, MovimentTable } from './moviment.entity';
import { CommnRepository } from '../shared/repository/common.repository';
import { MovimentMessage } from './moviment.msg';
import { oracleErrorHandler } from '../shared/common/common.error';
import { dateToYYYMMMDD } from '../shared/utils/parse-date';
import { sourceColumnMovi } from '../exports/export.entity';
import { ProductRow, ProductTable } from '../product/product.entity';
import * as moment from 'moment';
import { Component } from '@nestjs/common';


@Component()
export class MovimentRepository extends CommnRepository<Moviment> {

  constructor() {
    super(
      MovimentRow,
      MovimentTable,
      null,
      MovimentMessage,
      new MovimentRowMapper()
    );
  }

  async findByEvent(entity: Moviment, evType: string): Promise<Moviment[]> {
    const query = `
    SELECT * FROM ${MovimentTable}
      WHERE ${MovimentRow.id} = '${entity.id}'
      AND ${MovimentRow.moviGFCode} = '${evType}'
      AND ${MovimentRow.sourceSys} = '${entity.sourceSys}'
  `;
    return this.queryHandler.execute(query)
      .catch(oracleErrorHandler(this.messages));
  }

  async findByGlobalIdAndDate(entity: Moviment): Promise<Moviment[]> {
    const query = `
      SELECT * FROM ${MovimentTable}
        WHERE ${MovimentRow.globalId} = '${entity.globalId}'
        AND TRUNC(${MovimentRow.dateBase}) = TO_DATE('${dateToYYYMMMDD(entity.dateBase)}', 'YYYYMMDD')
        AND ${MovimentRow.sourceSys} = '${entity.sourceSys}'
    `;
    return this.queryHandler.execute(query)
      .catch(oracleErrorHandler(this.messages));
  }

  async getDataToExport(fileInfo: any): Promise<any> {
    let query = `
      SELECT
      ${MovimentTable}.*,
      ${ProductTable}.${ProductRow.productId},
      ${ProductTable}.${ProductRow.groupProductCode},
      ${ProductTable}.${ProductRow.subProductCode} FROM ${MovimentTable}`;

    query += `
      INNER JOIN ${ProductTable}
      on ${MovimentTable}.${MovimentRow.productSdkCode} = ${ProductTable}.${ProductRow.id}
      WHERE ${sourceColumnMovi} = '${fileInfo.product}'
      AND TRUNC(${MovimentTable}.${MovimentRow.dateBase}) = TO_DATE('${dateToYYYMMMDD(fileInfo.fileDate)}', 'YYYYMMDD')
      AND TRUNC(${ProductTable}.${ProductRow.baseDate}) = TO_DATE('${dateToYYYMMMDD(fileInfo.fileDate)}', 'YYYYMMDD')
    `;
    return this.queryHandler.execute(query).catch(oracleErrorHandler(this.messages));
  }

  async create(entity: Moviment): Promise<string | number> {
    entity = this.cleanEntity(entity);
    const queryString = this.parseCreate(entity);
    const query = `INSERT ${queryString}`;
    await this.commandHandler.execute(query)
      .catch(oracleErrorHandler(this.messages));
    // .catch(x => console.log(x))

    return entity.id;
  }

  protected parseCreate(entity: Moviment): string {
    let into = '';
    let values = '';

    // tslint:disable-next-line:forin
    for (const k in entity) {
      if (!entity[k] || !this.TableRows[k]) {
        delete entity[k];
        continue;
      }
      if (Object.prototype.toString.call(entity[k]) === '[object Date]') {
        const stringDate = `TO_DATE('${dateToYYYMMMDD(entity[k] as any)}', 'YYYYMMDD')`;
        into += `${this.TableRows[k]}, `;
        values += `${stringDate}, `;
      } else if (typeof entity[k] === 'number') {
        into += `${this.TableRows[k]}, `;
        values += `${entity[k]}, `;
      } else {
        into += `${this.TableRows[k]}, `;
        values += `'${entity[k]}', `;
      }
    }
    into = into.slice(0, -2);
    values = values.slice(0, -2);
    return `INTO ${this.TableName} (${into}) VALUES (${values})`;
  }

  async update(entity: Moviment, id?: string | number): Promise<void> {

    this.sanitalizer.sanitalize(entity);

    if (id) {
      entity.oldId = id;
    }
    entity = this.cleanEntity(entity);
    const queryString = this.parseUpdate(entity, id);
    const query = `UPDATE ${queryString}`;
    const moviments = await this.commandHandler.execute(query, entity)
      .catch(oracleErrorHandler(this.messages));

    if (id) {
      delete entity.oldId;
    }

    console.info('update moviments: ', moviments);
  }

  protected cleanEntity(entity: Moviment): any {
    const cleanEntity: any = {};
    for (const param in entity) {
      if (entity[param] !== undefined) {
        cleanEntity[param] = entity[param];
      }
    }
    return cleanEntity;
  }

  protected parseUpdate(entity: Moviment, id?: string | number): string {
    let set = 'SET ';

    // tslint:disable-next-line:forin
    for (const k in entity) {
      if ((k === 'id' && !id) || !this.TableRows[k] || entity[k] === undefined) continue;
      if (Object.prototype.toString.call(entity[k]) === '[object Date]') {
        const stringDate = `TO_DATE('${dateToYYYMMMDD(entity[k] as any)}', 'YYYYMMDD')`;
        set += `${this.TableRows[k]} = ${stringDate}, `;
      } else {
        set += `${this.TableRows[k]} = :${k}, `;
      }
    }
    set = set.slice(0, -2);

    return `${this.TableName} ${set} WHERE ${this.TableRows.id} = ${id ? ':oldId' : ':id'}`;
  }

  async findMoviment(id: string, date: Date, evType: string, moviType: string): Promise<Moviment[]> {
    const query = `
    SELECT * FROM ${MovimentTable}
      WHERE ${MovimentRow.globalId} = '${id}'
      AND ${MovimentRow.moviGFCode} = '${evType}'
      AND ${MovimentRow.moviType} = '${moviType}'
      AND ${MovimentRow.dateBase} = TO_DATE(${moment(date).format('YYYYMMDD')}, 'YYYYMMDD')
  `;
    return this.queryHandler.execute(query)
      .catch(oracleErrorHandler(this.messages));
  }

}
