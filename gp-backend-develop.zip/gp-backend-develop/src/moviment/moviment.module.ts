import { Module } from '@nestjs/common';
import { MovimentService } from './moviment.service';
import { MovimentRepository } from './moviment.repository';
import { MovimentController } from './moviment.controller';

@Module({
  components: [
    MovimentService,
    MovimentRepository,
  ],
  controllers: [MovimentController],
  exports: [MovimentService],
})

export class MovimentModule { }
