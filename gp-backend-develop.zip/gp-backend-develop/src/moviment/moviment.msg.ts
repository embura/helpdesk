import { CategoryMessage, IMessage } from '../shared/common/message.model';

export const entityName: IMessage = {
  ptBr: 'Movimento',
  system: 'Moviment',
};

export const MovimentTag: IMessage = {
  ptBr : 'Movimento',
  system : 'Moviment',
};

export const MovimentMessage = new CategoryMessage(MovimentTag, entityName);