import { CommonEntity } from '../shared/common/entity';

import { Column } from '../shared/decorator/column.decorator';
import { RowMapper } from '../shared/repository/repository.interface';

export class Moviment extends CommonEntity {

  @Column('CD_GLOB_ID_EVEN')
  id: string;

  @Column('CD_GLOB_ID_OPER_REFE')
  globalId: string;

  @Column('DT_BASE_SIST')
  dateBase: Date;

  @Column('CD_ID_OPER_SBK')
  sdkCodeId: string;

  @Column('CD_PROD_SBK')
  productSdkCode: string;

  @Column('CD_ID_CAMP')
  campaignIDCode: string;

  @Column('DT_CVER')
  dateConv: Date;

  @Column('CD_PESS')
  penumper: string;

  @Column('DT_SOLI')
  dateSolic: Date;

  @Column('DT_EFET')
  dateEfet: Date;

  @Column('VL_LIQU_MOVI')
  netValue: number;

  @Column('VL_BRUT_MOVI')
  grossValue: number;

  @Column('VL_IR')
  irValue: number;

  @Column('VL_IOF')
  iofValue: number;

  @Column('CD_BANC_CLIE')
  bankCode: number;

  @Column('CD_AGEN_CLIE')
  branchCode: number;

  @Column('NR_CNTA_CLIE')
  accountCode: string;

  @Column('CD_DOCT_CLIE')
  documentNumber: string;

  @Column('TP_PESS_CLIE')
  typePerson: string;

  @Column('CD_CNAL_OPER')
  opChanCode: string;

  @Column('CD_USUA_OPER')
  opUserCode: string;

  @Column('CD_SITU_OPER')
  opStatusCode: string;

  @Column('SG_SIST_PROD_ORIG')
  sourceSys: string;

  @Column('CD_FATR_GERA_MOVI')
  moviGFCode: string;

  @Column('TP_MOVI')
  moviType: string;

  @Column('QT_NEGO')
  tradedQuantity: number;

  @Column('VL_TOTL_IMPS')
  taxValue: number;

  groupProductCode: string;
  subProductCode: string;
  productId: number;
}

export const MovimentRow = Object.freeze({
  id: 'CD_GLOB_ID_EVEN',
  globalId: 'CD_GLOB_ID_OPER_REFE',
  dateBase: 'DT_BASE_SIST',
  sdkCodeId: 'CD_ID_OPER_SBK',
  productSdkCode: 'CD_PROD_SBK',
  campaignIDCode: 'CD_ID_CAMP',
  dateConv: 'DT_CVER',
  penumper: 'CD_PESS',
  dateSolic: 'DT_SOLI',
  dateEfet: 'DT_EFET',
  netValue: 'VL_LIQU_MOVI',
  grossValue: 'VL_BRUT_MOVI',
  irValue: 'VL_IR',
  iofValue: 'VL_IOF',
  bankCode: 'CD_BANC_CLIE',
  branchCode: 'CD_AGEN_CLIE',
  accountCode: 'NR_CNTA_CLIE',
  documentNumber: 'CD_DOCT_CLIE',
  typePerson: 'TP_PESS_CLIE',
  opChanCode: 'CD_CNAL_OPER',
  opUserCode: 'CD_USUA_OPER',
  opStatusCode: 'CD_SITU_OPER',
  sourceSys: 'SG_SIST_PROD_ORIG',
  moviGFCode: 'CD_FATR_GERA_MOVI',
  moviType: 'TP_MOVI',
  tradedQuantity: 'QT_NEGO',
  taxValue: 'VL_TOTL_IMPS',
});

export const MovimentTable = 'GPOS.TB_MOVI_TESO';

export class MovimentRowMapper implements RowMapper<Moviment> {
  public map(row: any): Moviment {
    const moviment = new Moviment();
    moviment.id = row[MovimentRow.id];
    moviment.globalId = row[MovimentRow.globalId];
    moviment.sdkCodeId = row[MovimentRow.sdkCodeId];
    moviment.productSdkCode = row[MovimentRow.productSdkCode];
    moviment.penumper = row[MovimentRow.penumper];
    moviment.dateBase = row[MovimentRow.dateBase];
    moviment.dateConv = row[MovimentRow.dateConv];
    moviment.dateSolic = row[MovimentRow.dateSolic];
    moviment.dateEfet = row[MovimentRow.dateEfet];
    moviment.netValue = row[MovimentRow.netValue];
    moviment.grossValue = row[MovimentRow.grossValue];
    moviment.irValue = row[MovimentRow.irValue];
    moviment.iofValue = row[MovimentRow.iofValue];
    moviment.bankCode = row[MovimentRow.bankCode];
    moviment.branchCode = row[MovimentRow.branchCode];
    moviment.accountCode = row[MovimentRow.accountCode];
    moviment.documentNumber = row[MovimentRow.documentNumber];
    moviment.typePerson = row[MovimentRow.typePerson];
    moviment.opChanCode = row[MovimentRow.opChanCode];
    moviment.opUserCode = row[MovimentRow.opUserCode];
    moviment.opStatusCode = row[MovimentRow.opStatusCode];
    moviment.sourceSys = row[MovimentRow.sourceSys];
    moviment.moviGFCode = row[MovimentRow.moviGFCode];
    moviment.moviType = row[MovimentRow.moviType];
    moviment.campaignIDCode = row[MovimentRow.campaignIDCode];
    moviment.tradedQuantity = row[MovimentRow.tradedQuantity];
    moviment.productId = row[moviment.productId];
    moviment.groupProductCode = row[moviment.groupProductCode];
    moviment.subProductCode = row[moviment.subProductCode];

    moviment.taxValue = taxValue();

    function taxValue(): number {
      return moviment.iofValue + moviment.irValue;
    }

    return moviment;
  }
}