import { CommonController } from '../shared/common/common.controller';
import { Moviment } from './moviment.entity';
import { MovimentService } from './moviment.service';
import { MovimentMessage } from './moviment.msg';
import { Controller, Post, Res, Body, HttpStatus, HttpException } from '@nestjs/common';
import { Status } from '../shared/status.entity';
import { HttpResponse } from '../shared/http.response';
import { Response } from 'express';


@Controller('/transaction')
export class MovimentController extends CommonController<Moviment>{

  constructor(
    protected movimentService: MovimentService
  ) {
    super(movimentService, MovimentMessage);
  }

  @Post()
  async contract(@Res() res: Response, @Body() entity: Moviment): Promise<Response> {

    const responseController = (response: Response, statusCode: number, mensage: string, data?: any ): Response  => {
      return response.status(statusCode).json(
        new HttpResponse(new Status(statusCode, mensage), data)
      );
    };

    return this.movimentService.transaction(entity)
    .then( (result)  => {
      console.info('[MovementController] contract -  transaction: ', result);
      return responseController(res, HttpStatus.OK, this.messages.success.create, result);
    }).catch((error: HttpException) => {
      console.error('[MovementController] contract - transaction: ', {...error});
      return responseController(res, error.message.statusCode, error.message.message, {});
    });

  }
}
