import { CommonRepositoryService } from '../shared/common/repository.service';
import { Moviment, MovimentRow, MovimentTable, MovimentRowMapper } from './moviment.entity';
import { MovimentRepository } from './moviment.repository';
import { MovimentMessage } from './moviment.msg';
import { CommnRepository } from '../shared/repository/common.repository';
import { Order, Op } from '../shared/repository/repository.interface';
import { ProductRepository } from '../product/product.repository';
import { ServiceErrorHandler } from '../shared/common/common.error';
import { Component, BadRequestException, HttpStatus, HttpException, ConflictException, GoneException } from '@nestjs/common';
import { Position } from '../position/position.entity';

import moment = require('moment');
import { PositionService } from '../position/position.service';
import { SystemStatus } from '../system-status/system_status.enum';
import { SystemStatusService } from '../system-status/system_status.service';
import { BaseDateService } from '../base-date/base-date.service';



@Component()
export class MovimentService extends CommonRepositoryService<Moviment>{

  private msgConflit = 'Movimento já existe';

  constructor(
    protected readonly movimentRepository: MovimentRepository,
    protected readonly productRepository: ProductRepository,
    protected readonly positionService: PositionService,
    protected readonly systemStatusService: SystemStatusService,
    protected readonly baseDateService: BaseDateService
  ) {
    super();
    this.messages = MovimentMessage;
    this.repository = new CommnRepository(
      MovimentRow,
      MovimentTable,
      null,
      MovimentMessage,
      new MovimentRowMapper()
    );
    this.defaultOrder = ['id', Order.ASC];

  }

  async findByGlobalIdAndDate(movement: Moviment): Promise<Moviment[]> {
    const ret = await this.movimentRepository.findByGlobalIdAndDate(movement);
    return ret;
  }

  async findByEvent(movement: Moviment, evType: string): Promise<Moviment[]> {
    const ret = await this.movimentRepository.findByEvent(movement, evType);
    return ret;
  }

  async getDataToExport(fileInfo: any): Promise<Moviment[]> {

    const movements = await this.movimentRepository.getDataToExport(fileInfo);

    if (movements.length === 0) {
      return movements;
    }

    const sbkCode: string[] = [];

    movements.forEach((mov: Moviment) => {
      if (sbkCode.indexOf(mov.productSdkCode) === -1) {
        sbkCode.push(mov.productSdkCode);
      }
    });

    const products = await this.productRepository.findAll({
      where: {
        baseDate: fileInfo.fileDate,
        id: { [Op.in]: sbkCode },
      },
    });

    for (const movement of movements) {
      const product = products.filter(prod => prod.id === movement.productSdkCode);
      if (product.length > 0) {
        movement.groupProductCode = product[0].groupProductCode;
        movement.subProductCode = product[0].subProductCode;
        movement.productId = product[0].id;
      }
    }

    return movements;
  }

  async create(obj: Moviment): Promise<Moviment> {
    if (this.validation) {
      const newObj = Object.assign({}, obj);
      delete newObj.id;
      await this.validation.validate(newObj)
        .catch(ServiceErrorHandler);
    }

    await this.movimentRepository.create(obj);
    return obj;
  }

  async update(obj: Moviment): Promise<Moviment> {
    if (this.validation) {
      await this.validation.validate(obj)
        .catch(ServiceErrorHandler);
    }

    const persisted = await this.findByEvent(obj, 'NO');
    if (!persisted[0]) throw this.badRequest(this.messages.error.notFound);
    persisted[0].updateParams(obj);

    await Promise.all([
      this.movimentRepository.update(persisted[0]),
      // this.logService.update(persisted, id),
    ]);

    const updatedObj = await this.findByEvent(obj, 'ES');
    if (updatedObj[0]) {
      return;
    } else {
      throw new Error('Não foi estornado.');
    }
  }

  async findMoviment(id: string, date: Date, evType: string, moviType: string): Promise<Moviment[]> {
    return this.movimentRepository.findMoviment(id, date, evType, moviType);
  }

  async createPositionByMovement(movement: Moviment): Promise<Position> {
    const position: Position = new Position();
    const today = moment().format('YYYYMMDD');
    const positionLastDate = await this.positionService.getLastDatePosition(today);
    const clientName = await this.positionService.clientNamePosition(movement.penumper);

    console.info(`[MovementService]  createPositionByMovement - positionLastDate : `, positionLastDate);

    position.id = movement.globalId;
    position.sbkCodeId = movement.sdkCodeId;
    position.productSbkCode = movement.productSdkCode;
    position.bankCode = movement.bankCode;
    position.agencyCode = movement.branchCode;
    position.accountCode = movement.accountCode;
    position.typePerson = movement.typePerson;
    position.penumper = movement.penumper;
    position.availableQuantity = movement.tradedQuantity;
    position.irValue = 0;
    position.iofValue = 0;
    position.positionDate = moment(positionLastDate, 'YYYYMMDD').toDate();
    position.positionDate.setHours(2);
    position.initialTradedAmount = movement.tradedQuantity;

    position.percentageNegotiatedRate = Number(movement.percentageNegotiatedRate);
    position.negotiatedInitialUnitPrice = Number(movement.negotiatedInitialUnitPrice);

    position.aplicationDate = moment().toDate();
    position.aplicationDate.setHours(2);
    position.grossUnitPriceUpdated = Number(movement.negotiatedInitialUnitPrice);
    position.updatedGrossValueAvailable = movement.grossValue;
    position.updatedNetValueAvailable = movement.grossValue;
    position.blockedQuantity = 0;
    position.grossValueBlocked = 0;
    position.documentNumber = movement.documentNumber;
    position.liquidityDate = moment(movement.liquidityDate, 'YYYYMMDD').toDate();
    position.liquidityEndDate = moment(movement.liquidityDate, 'YYYYMMDD').toDate();
    position.dueDate = moment(movement.dueDate, 'YYYYMMDD').toDate();
    position.initialValue = Number(movement.initialValue);
    position.valueNetUnitPriceUpdated = Number(movement.negotiatedInitialUnitPrice);
    position.productLineAcronym = 'ONL';
    position.liquidityValue = movement.grossValue;

    position.accrualCashValue = movement.accrualCashValue;
    position.optionMTMValue = movement.optionMTMValue;
    position.campaignIDCode = movement.campaignIDCode;
    position.clientName = clientName;

    return position;
  }

  async transaction(entity: Moviment): Promise<Moviment> {

    const today = moment().format('YYYYMMDD');
    const baseDate = await this.baseDateService.getDefaultDate(today);
    const statusDefault = await this.systemStatusService.getStatus();

    if (statusDefault === SystemStatus.Blocked) {
      const systemBlock = 'Sistema Bloqueado';
      console.error(systemBlock);
      throw Error(systemBlock);
    }

    entity.dateBase = moment(baseDate).toDate();
    entity.sourceSys = 'ONL';
    entity = this.normalizeMovement(entity);

    if (entity.moviGFCode === 'ES') {
      return this.cancel(entity);
    } else {
      if (entity.id !== entity.globalId) {
        return this.repurchase(entity);
      } else {
        return this.contract(entity);
      }
    }
  }

  async cancel(movement: Moviment): Promise<Moviment> {
    const dateBase = moment(movement.dateBase).toDate();

    // cancel transaction
    delete movement.dateConv;
    delete movement.dateEfet;
    delete movement.dateSolic;
    delete movement.dateBase;

    const globalId = movement.globalId;
    const moviGFCode = 'NO';

    const [movements, pos] = await Promise.all([
      this.findMoviment(globalId, dateBase, moviGFCode, 'S'),
      this.positionService.findByGlobalIdAndDate(globalId, dateBase),
    ]);

    // Cancelar somente se não ouver transações feita na posição
    if (movement.id === movement.globalId && movements.length > 0) {
      const msgError = '[MovementService]Posição não pode ser estornada, devido ter transações anteriores!';
      console.error(msgError);
      throw new BadRequestException(msgError);
    }

    return this.update(movement)
      .then(async mov => {

        if (pos.length > 0 && movement.id === movement.globalId) {
          const position = this.cancelPosition(pos[0], movement);
          return this.positionService.update(position).then( result => {
            console.info('[MovementService] cancel - Position updated sucess: ', !!result);
            return mov;
          }).catch(err => {
            console.error('[MovementService] cancel - Position updated error: ', err);
            throw err;
          });
        }

      }).catch((error) => {
        const notFound = /Não foi possivel encontrar o registro/;

        if (notFound.test(error.message)) {
          throw new GoneException('Não foi possivel encontrar o registro');
        }

        console.error('[MovementService] update error: ', error);
        throw new HttpException(error, error.code);
      });
  }

  async contract(movement: Moviment): Promise<Moviment> {
    const mov = await this.findById(movement.id);

    if (mov) {
      throw new ConflictException(`[MovementService] contract - ${this.msgConflit}: id[${movement.id}]`);
    }

    return this.create(movement)
    .then(async (movNew: Moviment) => {
      console.info('[MovementService] Create new moviment: ', movNew);

      const position = await this.createPositionByMovement(movement);
      return this.positionService.create(position).then(posi => {
        console.info('[MovementService] Create new position :', position);
        return movNew;
      }).catch(err => {
        console.error('[MovementService] Create new position :', err);
        return ServiceErrorHandler(err);
      });
    }).catch( error => {
      const unique = /unique constraint/;

      if (unique.test(error.message)){
        error.statusCode = HttpStatus.CONFLICT;
        error.error = 'Conflict ';
        error.message = this.msgConflit;
      }
      console.error('[MovementService] Create new movement :', error);

        throw new HttpException(error, error.code);
      });

  }

  async repurchase(movement: Moviment): Promise<Moviment> {
    const mov = await this.findById(movement.id);

    if (mov) {
      throw new HttpException({
        statusCode: 409,
        error: 'Conflict ',
        message: this.msgConflit,
      }, 409);
    }

    // tslint:disable-next-line:prefer-const
    let [transactionsD0, initialPosition] = await Promise.all([
      this.findByGlobalIdAndDate(movement),
      this.positionService.findByGlobalIdAndDate(movement.globalId, movement.dateBase),
    ]);

    transactionsD0 = transactionsD0.filter(trans => trans.moviGFCode === 'NO');
    if (!initialPosition[0] && transactionsD0.length === 0) {
      throw new BadRequestException('Não existe posição para recompra.');
    }
    const quantitiesD0 = transactionsD0.reduce((total, transaction) => {
      const quantity = transaction.moviType === 'E' ? transaction.tradedQuantity : -(transaction.tradedQuantity);
      return total + quantity;
    }, 0);

    let totalAvailable;
    if (initialPosition[0]) {
      totalAvailable = quantitiesD0 + initialPosition[0].availableQuantity;
    } else {
      totalAvailable = quantitiesD0;
    }

    if (movement.tradedQuantity > totalAvailable){
      console.error('Quantidade negociada maior do que a permitida.');
      throw new BadRequestException('Quantidade negociada maior do que a permitida.');
    }

    return this.create(movement).then(resultCreateMovement => {
      console.info('[MovementService] Recompra - Sucess ', resultCreateMovement);
      return resultCreateMovement;
    }).catch(error => {
      const unique = /restrição exclusiva/;

      if (unique.test(error.message)) {
        error.statusCode = HttpStatus.CONFLICT;
        error.error = 'Conflict ';
        error.message = this.msgConflit;
      }

      console.error('[MovementService] Recompra', error);
      throw error;
    });
  }

  cancelPosition(position: Position, movement: Moviment): Position {
    // position.positionDate = movement.dateBase;
    position.id = movement.globalId;
    position.availableQuantity = 0;
    position.updatedNetValueAvailable = 0;
    position.updatedGrossValueAvailable = 0;
    position.initialTradedAmount = 0;
    console.info('[MovimnetService] cancelPosition - ID: ', position.id);
    return position;
  }

  normalizeMovement(entityMovement: Moviment): Moviment {

    const dateStr = 'YYYYMMDD';
    entityMovement.dateConv = entityMovement.dateConv ? moment(entityMovement.dateConv, dateStr).toDate() : null;
    entityMovement.dateEfet = entityMovement.dateEfet ? moment(entityMovement.dateEfet, dateStr).toDate() : null;
    entityMovement.dateSolic = entityMovement.dateSolic ? moment(entityMovement.dateSolic, dateStr).toDate() : null;
    entityMovement.dueDate = entityMovement.dueDate ? moment(entityMovement.dueDate, dateStr).toDate() : null;

    return entityMovement;
  }

}
