
export class ProductDetail {

  groupName: string;
  assetclass: {
    name: string,
    percentagem: string;
  };
  modality: string;
  underlying: string;
}