import { CommonController } from '../shared/common/common.controller';
import { Product } from './product.entity';
import { ProductService } from './product.service';
import { ProductMessage } from './product.msg';
import { Controller } from '@nestjs/common';
import { PositionService } from '../position/position.service';

@Controller('product')
export class ProductController extends CommonController<Product>{

  constructor(
    protected productService: ProductService,
    protected positionService: PositionService
  ) {
    super(productService, ProductMessage);
  }

}
