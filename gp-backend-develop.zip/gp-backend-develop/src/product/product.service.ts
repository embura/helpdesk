
import { CommonRepositoryService } from '../shared/common/repository.service';
import { Product, ProductRow, ProductTable, ProductRowMapper } from './product.entity';
import { ProductRepository } from './product.repository';
import { ProductMessage } from './product.msg';
import { CommnRepository } from '../shared/repository/common.repository';
import { Order, FindOrder } from '../shared/repository/repository.interface';
import { Component } from '@nestjs/common';

@Component()
export class ProductService extends CommonRepositoryService<Product>{

  protected order: FindOrder | undefined = ['productLineAcronym', Order.ASC];

  constructor(

    protected readonly productRepository: ProductRepository
  ) {
    super();
    this.messages = ProductMessage;
    this.repository = new CommnRepository(
      ProductRow,
      ProductTable,
      null,
      ProductMessage,

      new ProductRowMapper()
    );
  }

  async getDataToExport(fileInfo: any): Promise<Product[]> {
    return this.productRepository.getDataToExport(fileInfo);
  }

}
