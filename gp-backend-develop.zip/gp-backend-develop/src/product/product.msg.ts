import { CategoryMessage, IMessage } from '../shared/common/message.model';

export const entityName: IMessage = {
  ptBr: 'Produto',
  system: 'Product',
};

export const ProductTag: IMessage = {
  ptBr : 'Produto',
  system : 'Product',
};

export const ProductMessage = new CategoryMessage(ProductTag, entityName);