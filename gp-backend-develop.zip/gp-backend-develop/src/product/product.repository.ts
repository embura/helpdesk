import { Product, ProductRow, ProductRowMapper, ProductTable } from './product.entity';
import { CommnRepository } from '../shared/repository/common.repository';
import { ProductMessage } from './product.msg';
import { oracleErrorHandler } from '../shared/common/common.error';
import { dateToYYYMMMDD } from '../shared/utils/parse-date';
import { sourceColumnProd } from '../exports/export.entity';
import { Component } from '@nestjs/common';

@Component()
export class ProductRepository extends CommnRepository<Product> {

  constructor() {
    super(
      ProductRow,
      ProductTable,
      null,
      ProductMessage,

      new ProductRowMapper()
    );
  }

  async getDataToExport(fileInfo: any): Promise<Product[]> {
    let query = `
      SELECT * FROM ${ProductTable}
    `;
    query += `
      WHERE ${sourceColumnProd} = '${fileInfo.product}'
      AND TRUNC(DT_BASE_SIST) = TO_DATE('${dateToYYYMMMDD(fileInfo.fileDate)}', 'YYYYMMDD')
    `;

    return this.queryHandler.execute(query).then((productList: Product[]) => {
      return productList;
    }).catch(oracleErrorHandler(this.messages));
  }

}
