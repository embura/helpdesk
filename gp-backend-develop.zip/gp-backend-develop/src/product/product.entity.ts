import { CommonEntity } from '../shared/common/entity';

import { Column } from '../shared/decorator/column.decorator';
import { RowMapper } from '../shared/repository/repository.interface';

export class Product extends CommonEntity {

  @Column('CD_PROD_SBK')
  id: string;

  @Column('DT_BASE_SIST')
  baseDate: Date;

  @Column('CD_SUBP')
  subProductCode: string;

  @Column('CD_GRUP_PROD')
  groupProductCode: string;

  @Column('NM_SUBP')
  name: string;

  @Column('CD_CATG_SUBP')
  subProductCatCode: string;

  @Column('CD_GRAU_RISC_SUBP')
  subProductRiskCode: string;

  @Column('CD_PRAZ_SUBP')
  subProductTermCode: string;

  @Column('CD_OBRI_API')
  APIObrigCode: string;

  @Column('CD_SITU_SUBP')
  subProductSitCode: string;

  @Column('VL_MINI_APLI_SUBP')
  subProductAplMinValue: number;

  @Column('VL_MINI_RAPL_SUBP')
  subProductReaplMinValue: number;

  @Column('CD_USUA_ULTI_ATLZ')
  userCodeLastUpdate: string;

  @Column('DH_ULTI_ATLZ')
  lastUpdate: string;

  @Column('CD_VOLA')
  volCode: string;

  @Column('CD_EXPC_CRED')
  credExpCode: string;

  @Column('CD_RTNG_CRED')
  creditRatingCode: string;

  @Column('CD_GARA')
  collatCode: string;

  @Column('CD_DURA')
  durationCode: string;

  @Column('CD_PRAZ')
  termCode: string;

  @Column('CD_PERD_POTE')
  potLossCode: string;

  @Column('CD_INDX')
  indexCode: string;

  @Column('NR_RISC_EQVT')
  eqRisk: number;

  @Column('CD_LIQZ')
  liqCode: string;

  @Column('CD_RISC_FINA_ESPH')
  spainRiskCode: string;

  @Column('CD_RISC_FINA_BRSL')
  brazilRiskCode: string;

  @Column('CD_CMPX')
  complexityCode: string;

  @Column('NM_FAMI_PROD')
  familyProductName: string;

  @Column('NM_GRUP_PROD')
  groupProductName: string;

  @Column('NM_CLAS_ATIV_PROD')
  assetClassProductName: string;

  @Column('NM_MODA_PROD')
  modalityProductName: string;

  @Column('NM_SBJA_PROD')
  underlyingProductName: string;

  @Column('CD_DOCT_EMIS_PAPE')
  emmiterAssetDocumentCode: string;

  @Column('PC_COCN_MAXI_PRVT')
  maximunPercentageConcentrationPrivate: number;

  @Column('PC_COCN_MAXI_VARE')
  maximunPercentageConcentrationRetail: number;

  @Column('CD_CLAS_ATIV')
  assetClassCode: string;

  @Column('CD_GRAU_RISC_PRIV')
  privateRatingRiskCode: number;

  @Column('CD_NOTA_CRED')
  scoreCreditCode: string;

  @Column('SG_SIST_PROD')
  productLineAcronym: string;

  @Column('NR_SEQU_PROD_CPT')
  productId: number;

  @Column('IN_INVE_QULF')
  qualifiedInvestor: string;

}

export const ProductRow = Object.freeze({
  id: 'CD_PROD_SBK',
  baseDate: 'DT_BASE_SIST',
  subProductCode: 'CD_SUBP',
  productId: 'NR_SEQU_PROD_CPT',
  name: 'NM_SUBP',
  subProductCatCode: 'CD_CATG_SUBP',
  subProductRiskCode: 'CD_GRAU_RISC_SUBP',
  subProductTermCode: 'CD_PRAZ_SUBP',
  APIObrigCode: 'CD_OBRI_API',
  subProductSitCode: 'CD_SITU_SUBP',
  subProductAplMinValue: 'VL_MINI_APLI_SUBP',
  subProductReaplMinValue: 'VL_MINI_RAPL_SUBP',
  userCodeLastUpdate: 'CD_USUA_ULTI_ATLZ',
  lastUpdate: 'DH_ULTI_ATLZ',
  volCode: 'CD_VOLA',
  credExpCode: 'CD_EXPC_CRED',
  creditRatingCode: 'CD_RTNG_CRED',
  collatCode: 'CD_GARA',
  durationCode: 'CD_DURA',
  termCode: 'CD_PRAZ',
  potLossCode: 'CD_PERD_POTE',
  indexCode: 'CD_INDX',
  eqRisk: 'NR_RISC_EQVT',
  liqCode: 'CD_LIQZ',
  spainRiskCode: 'CD_RISC_FINA_ESPH',
  brazilRiskCode: 'CD_RISC_FINA_BRSL',
  complexityCode: 'CD_CMPX',

  familyProductName: 'NM_FAMI_PROD',
  groupProductName: 'NM_GRUP_PROD',
  assetClassProductName: 'NM_CLAS_ATIV_PROD',
  modalityProductName: 'NM_MODA_PROD',
  underlyingProductName: 'NM_SBJA_PROD',

  emmiterAssetDocumentCode: 'CD_DOCT_EMIS_PAPE',
  maximunPercentageConcentrationPrivate: 'PC_COCN_MAXI_PRVT',
  maximunPercentageConcentrationRetail: 'PC_COCN_MAXI_VARE',
  assetClassCode: 'CD_CLAS_ATIV',
  privateRatingRiskCode: 'CD_GRAU_RISC_PRIV',
  scoreCreditCode: 'CD_NOTA_CRED',
  groupProductCode: 'CD_GRUP_PROD',
  productLineAcronym: 'SG_SIST_PROD',
  qualifiedInvestor: 'IN_INVE_QULF',
});

export const ProductTable = 'GPOS.TB_PROD_TESO';

export class ProductRowMapper implements RowMapper<Product> {
  public map(row: any): Product {
    const product = new Product();
    product.id = row[ProductRow.id];
    product.baseDate = row[ProductRow.baseDate];
    product.productId = row[ProductRow.productId];
    product.subProductCode = row[ProductRow.subProductCode];
    product.name = row[ProductRow.name];
    product.subProductCatCode = row[ProductRow.subProductCatCode];
    product.subProductRiskCode = row[ProductRow.subProductRiskCode];
    product.subProductTermCode = row[ProductRow.subProductTermCode];
    product.APIObrigCode = row[ProductRow.APIObrigCode];
    product.subProductSitCode = row[ProductRow.subProductSitCode];
    product.subProductAplMinValue = row[ProductRow.subProductAplMinValue];
    product.subProductReaplMinValue = row[ProductRow.subProductReaplMinValue];
    product.userCodeLastUpdate = row[ProductRow.userCodeLastUpdate];
    product.lastUpdate = row[ProductRow.lastUpdate];
    product.volCode = row[ProductRow.volCode];
    product.credExpCode = row[ProductRow.credExpCode];
    product.creditRatingCode = row[ProductRow.creditRatingCode];
    product.collatCode = row[ProductRow.collatCode];
    product.durationCode = row[ProductRow.durationCode];
    product.termCode = row[ProductRow.termCode];
    product.potLossCode = row[ProductRow.potLossCode];
    product.indexCode = row[ProductRow.indexCode];
    product.eqRisk = row[ProductRow.eqRisk];
    product.liqCode = row[ProductRow.liqCode];
    product.spainRiskCode = row[ProductRow.spainRiskCode];
    product.brazilRiskCode = row[ProductRow.brazilRiskCode];
    product.complexityCode = row[ProductRow.complexityCode];

    product.familyProductName = row[ProductRow.familyProductName];
    product.groupProductName = row[ProductRow.groupProductName];
    product.assetClassProductName = row[ProductRow.assetClassProductName];
    product.modalityProductName = row[ProductRow.modalityProductName];
    product.underlyingProductName = row[ProductRow.underlyingProductName];

    product.emmiterAssetDocumentCode = row[ProductRow.emmiterAssetDocumentCode];
    product.maximunPercentageConcentrationPrivate = row[ProductRow.maximunPercentageConcentrationPrivate];
    product.maximunPercentageConcentrationRetail = row[ProductRow.maximunPercentageConcentrationRetail];
    product.assetClassCode = row[ProductRow.assetClassCode];
    product.privateRatingRiskCode = row[ProductRow.privateRatingRiskCode];
    product.scoreCreditCode = row[ProductRow.scoreCreditCode];
    product.groupProductCode = row[ProductRow.groupProductCode];
    product.productLineAcronym = row[ProductRow.productLineAcronym];
    // product.productsequenceCPT = row[ProductRow.productsequenceCPT];
    product.qualifiedInvestor = row[ProductRow.qualifiedInvestor];

    return product;
  }
}
