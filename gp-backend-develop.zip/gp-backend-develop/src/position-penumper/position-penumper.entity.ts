import { CommonEntity } from '../shared/common/entity';
import { Column } from '../shared/decorator/column.decorator';
import { RowMapper } from '../shared/repository/repository.interface';

import { Table } from '../shared/decorator/table.annotation';

export const PositionPenumperTable = 'GPOS.TB_POSI_TESO';

@Table(PositionPenumperTable)
export class PositionPenumper extends CommonEntity {
  @Column('CD_PESS')
  penumper: string;
}

export const PositionPenumperRow = Object.freeze({
  penumper: 'CD_PESS',
});

export class PositionPenumperRowMapper implements RowMapper<PositionPenumper> {
  public map(row: any): PositionPenumper {
    const entity = new PositionPenumper();
    entity.penumper = row[PositionPenumperRow.penumper];

    return entity;
  }
}