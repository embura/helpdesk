import { CommnRepository } from '../shared/repository/common.repository';
import { PositionPenumper, PositionPenumperRow, PositionPenumperRowMapper, PositionPenumperTable } from './position-penumper.entity';
import { PositionMessage } from '../position/position.msg';
import { dateToYYYMMMDD } from '../shared/utils/parse-date';
import { oracleErrorHandler } from '../shared/common/common.error';
import { SqlHandler } from '../shared/lib/database/query-handler';
import { Component } from '@nestjs/common';

@Component()
export class PositionPenumperRepository extends CommnRepository<PositionPenumper> {
  readonly positionQueryHandler: SqlHandler<PositionPenumper>;

  constructor() {
    super(
      PositionPenumperRow,
      PositionPenumperTable,
      null,
      PositionMessage,
      new PositionPenumperRowMapper()
    );
    this.positionQueryHandler = new SqlHandler(new PositionPenumperRowMapper());

  }

  async getPenumpers(dataBase: Date): Promise<PositionPenumper[]> {

    const query = `
        SELECT
      DISTINCT ${PositionPenumperRow.penumper}
          FROM ${PositionPenumperTable}
         WHERE TRUNC(DT_BASE_SIST) = TO_DATE('${dateToYYYMMMDD(dataBase)}', 'YYYYMMDD')`;

    return await this.positionQueryHandler.execute(query)
      .catch(oracleErrorHandler(this.messages));
  }
}