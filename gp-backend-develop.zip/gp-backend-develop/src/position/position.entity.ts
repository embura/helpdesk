import { CommonEntity } from '../shared/common/entity';
import { Column } from '../shared/decorator/column.decorator';
import * as moment from 'moment';
import { RowMapper } from '../shared/repository/repository.interface';
import { Table } from '../shared/decorator/table.annotation';

export const PositionTable = 'GPOS.TB_POSI_TESO';

@Table(PositionTable)
export class Position extends CommonEntity {

  @Column('DT_BASE_SIST')
  positionDate: Date;

  @Column('CD_GLOB_ID_POSI')
  id: string;

  @Column('CD_ID_OPER_SBK')
  sbkCodeId: string;

  @Column('CD_PROD_SBK')
  productSbkCode: string;

  /*Penumper*/
  @Column('CD_PESS')
  penumper: string;

  @Column('PC_TAXA_NEGO')
  percentageNegotiatedRate: number;

  @Column('VL_PU_INIC_NEGO')
  negotiatedInitialUnitPrice: number;

  @Column('QT_INIC_NEGO')
  initialTradedAmount: number;

  @Column('DT_APLI')
  aplicationDate: Date;

  @Column('QT_DISP')
  availableQuantity: number;

  @Column('VL_PU_BRUT_ATLZ')
  grossUnitPriceUpdated: number;

  @Column('VL_PU_LIQU_ATLZ')
  valueNetUnitPriceUpdated: number;

  @Column('VL_BRUT_SALD')
  updatedGrossValueAvailable: number;

  @Column('VL_LIQU_SALD')
  updatedNetValueAvailable: number;

  @Column('VL_IR')
  irValue: number;

  @Column('VL_IOF')
  iofValue: number;

  @Column('QT_BLOQ')
  blockedQuantity: number;

  @Column('VL_BRUT_BLOQ')
  grossValueBlocked: number;

  @Column('CD_BANC_CLIE')
  bankCode: number;

  @Column('CD_AGEN_CLIE')
  agencyCode: number;

  @Column('NR_CNTA_CLIE')
  accountCode: string;

  @Column('CD_DOCT_CLIE')
  documentNumber: string;

  @Column('DT_LIQZ')
  liquidityDate: Date;

  @Column('DT_FIM_LIQZ')
  liquidityEndDate: Date;

  @Column('VL_LIQZ')
  liquidityValue: number;

  @Column('TP_PESS_CLIE')
  typePerson: string;

  @Column('VL_INIC')
  initialValue: number;

  @Column('VL_ACCR_CAIX')
  accrualCashValue: number;

  @Column('VL_MTM_OPCA')
  optionMTMValue: number;

  @Column('CD_ID_CAMP')
  campaignIDCode: string;

  @Column('DT_VENC')
  dueDate: Date;

  @Column('SG_SIST_PROD')
  productLineAcronym: string;

  @Column('NM_CLIE')
  clientName: string;

  @Column('CD_SEGM_CLIE')
  segmentCodeClient: string;

  /***** IntegraçAo VR **********/
  @Column('VL_PU_BLOQ')
  unitPriceForBlock: number;

  @Column('CD_BANC_CLIE_CNTR')
  bankCodeClientContract: number;

  @Column('CD_AGEN_CLIE_CNTR')
  agencyCodeClientContract: number;

  @Column('NR_CNTR_CLIE_CNTR')
  contractClientNumber: number;

  @Column('CD_PROD_CLIE_CNTR')
  clientProductContract: string;

  @Column('CD_SUBP_CLIE_CNTR')
  subProductCodeContract: string;

  @Column('SG_MOED_DIVI')
  debtCode: string;

  @Column('DT_REFE_POSI')
  referenceDate: Date; // Data original da posição
  /***** IntegraçAo VR **********/

  /*****Column Products********/
  groupProductCode: string;
  subProductCode: string;
  productId: number;
  productName: string;
  /*****Column Products********/

  situation: string;
  upName: string;
  taxValue: number;

  getDataToExport: string;
  getDataToExportCPT: number;

  groupName: string;

  family: string;
  group: string;
  assetClass: string;
  modality: string;
  underlying: string;

  isPrivate = false;

}

export const PositionRow = Object.freeze({
  positionDate: 'DT_BASE_SIST',
  id: 'CD_GLOB_ID_POSI',
  sbkCodeId: 'CD_ID_OPER_SBK',
  productSbkCode: 'CD_PROD_SBK',
  penumper: 'CD_PESS',
  percentageNegotiatedRate: 'PC_TAXA_NEGO',
  negotiatedInitialUnitPrice: 'VL_PU_INIC_NEGO',
  initialTradedAmount: 'QT_INIC_NEGO',
  aplicationDate: 'DT_APLI',
  availableQuantity: 'QT_DISP',
  grossUnitPriceUpdated: 'VL_PU_BRUT_ATLZ',
  valueNetUnitPriceUpdated: 'VL_PU_LIQU_ATLZ',
  updatedGrossValueAvailable: 'VL_BRUT_SALD',
  updatedNetValueAvailable: 'VL_LIQU_SALD',
  irValue: 'VL_IR',
  iofValue: 'VL_IOF',
  blockedQuantity: 'QT_BLOQ',
  grossValueBlocked: 'VL_BRUT_BLOQ',
  bankCode: 'CD_BANC_CLIE',
  agencyCode: 'CD_AGEN_CLIE',
  accountCode: 'NR_CNTA_CLIE',
  documentNumber: 'CD_DOCT_CLIE',
  liquidityDate: 'DT_LIQZ',
  liquidityEndDate: 'DT_FIM_LIQZ',
  liquidityValue: 'VL_LIQZ',
  typePerson: 'TP_PESS_CLIE',
  initialValue: 'VL_INIC',
  accrualCashValue: 'VL_ACCR_CAIX',
  optionMTMValue: 'VL_MTM_OPCA',
  campaignIDCode: 'CD_ID_CAMP',
  dueDate: 'DT_VENC',
  productLineAcronym: 'SG_SIST_PROD',
  taxValue: 'VL_TOTL_IMPS',
  woLiquidityValue: 'VL_SEM_LIQZ',
  clientName: 'NM_CLIE',
  segmentCodeClient: 'CD_SEGM_CLIE',

  unitPriceForBlock: 'VL_PU_BLOQ',
  bankCodeClientContract: 'CD_BANC_CLIE_CNTR',
  agencyCodeClientContract: 'CD_AGEN_CLIE_CNTR',
  contractClientNumber: 'NR_CNTR_CLIE_CNTR',
  clientProductContract: 'CD_PROD_CLIE_CNTR',
  subProductCodeContract: 'CD_SUBP_CLIE_CNTR',
  debtCode: 'SG_MOED_DIVI',
  referenceDate: 'DT_REFE_POSI',

});

export class PositionRowMapper implements RowMapper<Position> {
  public map(row: any): Position {
    const SIZECONDEAG = 4;
    const position = new Position();
    let agencyCode: number = row[PositionRow.agencyCode];

    if (row[PositionRow.agencyCode]) {
      agencyCode = (row[PositionRow.agencyCode]).toString().padStart(SIZECONDEAG, '0');
    }

    position.positionDate = row[PositionRow.positionDate];
    position.id = row[PositionRow.id];
    position.sbkCodeId = row[PositionRow.sbkCodeId];
    position.productSbkCode = row[PositionRow.productSbkCode];
    position.penumper = row[PositionRow.penumper];
    position.percentageNegotiatedRate = row[PositionRow.percentageNegotiatedRate];
    position.negotiatedInitialUnitPrice = row[PositionRow.negotiatedInitialUnitPrice];
    position.initialTradedAmount = row[PositionRow.initialTradedAmount];
    position.aplicationDate = row[PositionRow.aplicationDate];
    position.availableQuantity = row[PositionRow.availableQuantity];
    position.grossUnitPriceUpdated = row[PositionRow.grossUnitPriceUpdated];
    position.valueNetUnitPriceUpdated = row[PositionRow.valueNetUnitPriceUpdated];
    position.updatedGrossValueAvailable = row[PositionRow.updatedGrossValueAvailable];
    position.updatedNetValueAvailable = row[PositionRow.updatedNetValueAvailable];
    position.irValue = row[PositionRow.irValue];
    position.iofValue = row[PositionRow.iofValue];
    position.blockedQuantity = row[PositionRow.blockedQuantity];
    position.grossValueBlocked = row[PositionRow.grossValueBlocked];
    position.bankCode = row[PositionRow.bankCode];
    position.agencyCode = agencyCode;
    position.accountCode = row[PositionRow.accountCode];
    position.documentNumber = formatDocument(row[PositionRow.typePerson], row[PositionRow.documentNumber]);
    position.liquidityDate = row[PositionRow.liquidityDate];
    position.liquidityEndDate = row[PositionRow.liquidityEndDate];
    position.liquidityValue = row[PositionRow.liquidityValue];
    position.typePerson = row[PositionRow.typePerson];
    position.initialValue = row[PositionRow.initialValue];
    position.accrualCashValue = row[PositionRow.accrualCashValue];
    position.optionMTMValue = row[PositionRow.optionMTMValue];
    position.campaignIDCode = row[PositionRow.campaignIDCode] === 'null' ?
      null : row[PositionRow.campaignIDCode];
    position.dueDate = row[PositionRow.dueDate];
    position.productLineAcronym = row[PositionRow.productLineAcronym];

    position.unitPriceForBlock = row[PositionRow.unitPriceForBlock];
    position.bankCodeClientContract = row[PositionRow.bankCodeClientContract];
    position.agencyCodeClientContract = row[PositionRow.agencyCodeClientContract];
    position.contractClientNumber = row[PositionRow.contractClientNumber];
    position.clientProductContract = row[PositionRow.clientProductContract];
    position.subProductCodeContract = row[PositionRow.subProductCodeContract];
    position.debtCode = row[PositionRow.debtCode];
    position.referenceDate = row[PositionRow.referenceDate];

    position.clientName = row[PositionRow.clientName];
    position.segmentCodeClient = row[PositionRow.segmentCodeClient];

    // position.productCode = row[PositionRow.productCode];

    position.situation = situation(position.liquidityDate, position.blockedQuantity);
    position.taxValue = taxValue();
    position.woLiquidityValue = woLiquidityValue();

    function taxValue(): number {
      return position.iofValue + position.irValue;
    }

    function woLiquidityValue(): number {
      return position.updatedGrossValueAvailable - position.liquidityValue;
    }

    function situation(liquidityDate: Date, blockedQuantity: number): string {
      if (blockedQuantity > 0) return 'Bloqueada';
      const today = moment();
      const liquidityDateMoment = moment(liquidityDate, 'YYYYMMDD');
      if (liquidityDateMoment.isAfter(today)) return 'Carência';
      return 'Ativo';
    }

    function formatDocument(typePerson: string, documentNumber: string): string {
      if (documentNumber) {
        typePerson = typePerson.toLocaleUpperCase();
        switch (typePerson) {
          case 'F':
            documentNumber = documentNumber.substr(-11, documentNumber.length);
            break;
          case 'J':
            documentNumber = documentNumber.substr(-14, documentNumber.length);
            break;
        }
      }

      return documentNumber;
    }

    return position;
  }
}

export class PositionConsolidated {
  constructor(position: Position, formatDateStr: string = 'YYYYMMDD') {
    this.position = positionFormatDate(position, formatDateStr);

  }
  private readonly position: Position;
  public getPosition(): any {
    return {
      positionDate: this.position.positionDate,
      aplicationDate: this.position.aplicationDate,
      id: this.position.id,
      productSbkCode: this.position.productSbkCode,
      penumper: this.position.penumper,
      typePerson: this.position.typePerson,
      dueDate: this.position.dueDate,
      indexer: this.position.indexer,
      quantity: this.position.quantity,
      value: this.position.value,
      situation: this.position.situation,
      modality: this.position.modality,
      grossUnitPriceUpdated: this.position.grossUnitPriceUpdated,
      groupName: this.position.groupName,
      productId: this.position.productId,
    };
  }
}

export function positionFormatDate(position: Position, formatDateStr: string = 'YYYYMMDD'): any {
  const hours12 = 12;
  const postionFormat = {
    positionDate: position.positionDate ? moment(position.positionDate).add(hours12, 'hours').format(formatDateStr) : null,
    aplicationDate: position.aplicationDate ? moment(position.aplicationDate).add(hours12, 'hours').format(formatDateStr) : null,
    dueDate: position.dueDate ? moment(position.dueDate).add(hours12, 'hours').format(formatDateStr) : null,
    liquidityDate: position.liquidityDate ? moment(position.liquidityDate).add(hours12, 'hours').format(formatDateStr) : null,
    liquidityEndDate: position.liquidityEndDate ? moment(position.liquidityEndDate).add(hours12, 'hours').format(formatDateStr) : null,
  };

  return Object.assign(position, postionFormat);
}

export function positionFormatToDate(position: Position, formatDateExpected: string = 'YYYYMMDD'): Position {
  const dateFormat = 'YYYY-DD-MM';
  position.positionDate = position.positionDate ? moment(position.positionDate, [formatDateExpected, dateFormat]).toDate() : null;
  position.aplicationDate = position.aplicationDate ? moment(position.aplicationDate, [formatDateExpected, dateFormat]).toDate() : null;
  position.dueDate = position.dueDate ? moment(position.dueDate, [formatDateExpected, dateFormat]).toDate() : null;
  position.liquidityDate = position.liquidityDate ? moment(position.liquidityDate, [formatDateExpected, dateFormat]).toDate() : null;
  position.liquidityEndDate = position.liquidityEndDate ? moment(position.liquidityDate, [formatDateExpected, dateFormat]).toDate() : null;
  position.referenceDate = position.referenceDate ? moment(position.referenceDate, [formatDateExpected, dateFormat]).toDate() : null;

  return position;
}

export class PositionDetail {
  constructor(position: Position, formatDateStr: string = 'YYYYMMDD') {
    this.position = positionFormatDate(position, formatDateStr);
  }
  private readonly position: Position;

  private fixed2Decimal(decimal: number): number {
    const positionIndex = 3;
    const decimalStr = decimal.toString();
    const pointIndex = decimalStr.indexOf('.');

    if (pointIndex === -1) return decimal;

    const positionEndString = pointIndex + positionIndex;
    return Number(decimalStr.substring(0, positionEndString));
  }

  public getPosition(): any {
    return {
      id: this.position.id,
      productId: this.position.productId,
      groupName: this.position.groupName,

      positionDate: this.position.positionDate,
      sbkCodeId: this.position.sbkCodeId,
      productSbkCode: this.position.productSbkCode,
      penumper: this.position.penumper,
      aplicationDate: this.position.aplicationDate,
      dueDate: this.position.dueDate,
      liquidityDate: this.position.liquidityDate,
      percentageNegotiatedRate: this.position.percentageNegotiatedRate,
      valueNetUnitPriceUpdated: this.position.valueNetUnitPriceUpdated,
      grossValueBlocked: this.position.grossValueBlocked,
      bankCode: this.position.bankCode,
      agencyCode: this.position.agencyCode,
      accountCode: this.position.accountCode,
      documentNumber: this.position.documentNumber,
      liquidityEndDate: this.position.liquidityEndDate,
      liquidityValue: this.position.liquidityValue,
      typePerson: this.position.typePerson,
      accrualCashValue: this.position.accrualCashValue,
      optionMTMValue: this.position.optionMTMValue,
      campaignIDCode: this.position.campaignIDCode,
      productLineAcronym: this.position.productLineAcronym,
      grossUnitPriceUpdated: this.position.grossUnitPriceUpdated,
      segmentCodeClient: this.position.segmentCodeClient,
      subProductCode: this.position.subProductCode,
      clientName: this.position.clientName,
      unitPrice: {
        initial: this.position.negotiatedInitialUnitPrice,
        current: this.position.grossUnitPriceUpdated,
      },
      quantity: {
        currentAvailable: this.position.availableQuantity,
        initial: this.position.initialTradedAmount,
        currentBlocked: this.position.blockedQuantity,
        current: this.position.availableQuantity + this.position.blockedQuantity,
      },
      value: {
        currentMainOpening: this.fixed2Decimal((this.position.availableQuantity + this.position.blockedQuantity)
          * this.position.grossUnitPriceUpdated),
        updatedLiquidBalance: this.fixed2Decimal(this.position.availableQuantity * this.position.valueNetUnitPriceUpdated),
        updatedNetValueAvailable: this.position.updatedNetValueAvailable,
        currentGross: this.position.updatedGrossValueAvailable,
        initial: this.position.initialValue,
        ir: this.position.irValue,
        iof: this.position.iofValue,
      },

      productCategories: {
        family: this.position.family,
        group: this.position.group,
        assetClass: this.position.assetClass,
        modality: this.position.modality,
        underlying: this.position.underlying,
        productName: this.position.productName,
      },

      groupProductCode: this.position.groupProductCode,

      situation: this.position.situation,
      taxValue: this.position.irValue + this.position.iofValue,
      woLiquidityValue: this.position.woLiquidityValue,
      modality: this.position.modality,

      isPrivate: this.position.isPrivate,
    };
  }
}

export function createPosition(): Position {
  const position = new Position();
  position.positionDate = new Date();
  position.id = '';
  position.sbkCodeId = '';
  position.productSbkCode = '';
  position.penumper = '';
  position.percentageNegotiatedRate = 0;
  position.negotiatedInitialUnitPrice = 0;
  position.initialTradedAmount = 0;
  position.aplicationDate = new Date();
  position.availableQuantity = 0;
  position.grossUnitPriceUpdated = 0;
  position.valueNetUnitPriceUpdated = 0;
  position.updatedGrossValueAvailable = 0;
  position.updatedNetValueAvailable = 0;
  position.irValue = 0;
  position.iofValue = 0;
  position.blockedQuantity = 0;
  position.grossValueBlocked = 0;
  position.bankCode = 0;
  position.agencyCode = 0;
  position.accountCode = '';
  position.documentNumber = '';
  position.liquidityDate = new Date();
  position.liquidityEndDate = new Date();
  position.liquidityValue = 0;
  position.typePerson = '';
  position.initialValue = 0;
  position.accrualCashValue = 0;
  position.optionMTMValue = 0;
  position.campaignIDCode = '';
  position.dueDate = new Date();
  position.productLineAcronym = '';
  position.clientName = '';
  position.segmentCodeClient = '';
  position.unitPriceForBlock = 0;
  position.bankCodeClientContract = 0;
  position.agencyCodeClientContract = 0;
  position.contractClientNumber = 0;
  position.clientProductContract = '';
  position.subProductCodeContract = '';
  position.debtCode = '';
  position.referenceDate = new Date(); // Data original da posição
  position.groupProductCode = '';
  position.subProductCode = '';
  position.productId = 0;
  position.productName = '';
  position.situation = '';
  position.upName = '';
  position.taxValue = 0;
  position.getDataToExport = '';
  position.getDataToExportCPT = 0;
  position.groupName = '';
  position.family = '';
  position.group = '';
  position.assetClass = '';
  position.modality = '';
  position.underlying = '';
  position.isPrivate = false;

  return position;
}