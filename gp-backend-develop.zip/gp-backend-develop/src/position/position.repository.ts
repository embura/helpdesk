import { Position, PositionRow, PositionRowMapper, PositionTable } from './position.entity';
import { CommnRepository } from '../shared/repository/common.repository';
import { PositionMessage } from './position.msg';
import { dateToYYYMMMDD } from '../shared/utils/parse-date';
import { oracleErrorHandler } from '../shared/common/common.error';
import { isDate, isNumber } from 'util';
import moment = require('moment');

import { Component } from '@nestjs/common';

@Component()
export class PositionRepository extends CommnRepository<Position> {

  constructor() {
    super(
      PositionRow,
      PositionTable,
      null,
      PositionMessage,
      new PositionRowMapper()
    );
  }

  async findByGlobalIdAndDate(id: string, dateBase: Date): Promise<Position[]> {
    const query = `
      SELECT * FROM ${PositionTable}
        WHERE ${PositionRow.id} = '${id}'
        AND TRUNC(${PositionRow.positionDate}) = TO_DATE('${dateToYYYMMMDD(dateBase)}', 'YYYYMMDD')
    `;
    return this.queryHandler.execute(query)
      .catch(oracleErrorHandler(this.messages));
  }

  async getPenumperToExport(fileInfo: any): Promise<any> {
    let query = `
    SELECT DISTINCT ${PositionTable}.CD_PESS, CD_SEGT_CLIE FROM ${PositionTable}`;
    query += `
      WHERE TRUNC(DT_BASE_SIST) = TO_DATE('${dateToYYYMMMDD(fileInfo.fileDate)}', 'YYYYMMDD')`;
    return await this.queryHandler.execute(query).catch(oracleErrorHandler(this.messages));
  }

  async create(entity: Position): Promise<string | number> {
    entity = this.cleanEntity(entity);
    const queryString = this.parseCreate(entity);
    const query = `INSERT ${queryString}`;

    await this.commandHandler.execute(query)
      .catch(oracleErrorHandler(this.messages));
    // .catch(x => console.log(x))

    return entity.id;
  }

  protected parseCreate(entity: Position): string {
    let into = '';
    let values = '';

    // tslint:disable-next-line:forin
    for (const key in entity) {
      if (!entity[key] || !this.TableRows[key]) {
        delete entity[key];
        continue;
      }
      if (Object.prototype.toString.call(entity[key]) === '[object Date]') {
        const stringDate = `TO_DATE('${dateToYYYMMMDD(entity[key] as any)}', 'YYYYMMDD')`;
        into += `${this.TableRows[key]}, `;
        values += `${stringDate}, `;
      } else if (typeof entity[key] === 'number') {
        into += `${this.TableRows[key]}, `;
        values += `${entity[key]}, `;
      } else {
        into += `${this.TableRows[key]}, `;
        values += `'${entity[key]}', `;
      }
    }
    into = into.slice(0, -2);
    values = values.slice(0, -2);
    return `INTO ${this.TableName} (${into}) VALUES (${values})`;
  }

  protected cleanEntity(entity: Position): any {
    const cleanEntity: any = {};
    for (const param in entity) {
      if (entity[param] !== undefined) {
        cleanEntity[param] = entity[param];
      }
    }
    return cleanEntity;
  }

  async updatePosition(position: Position, id: string, positionDate: Date): Promise<Position> {
    const query = this.parseUpdatePosition(position, id, positionDate);

    const resUpdate = await this.commandHandler.execute(query)
      .catch(oracleErrorHandler(this.messages));

    console.info('[PositionRepository] updatePosition: ', resUpdate);

    return position;
  }

  parseUpdatePosition(position: Position, id: string, positionDate: Date): string {
    let set = 'SET ';

    // tslint:disable-next-line:forin
    for (const k in position) {

      if (!position[k] || !this.TableRows[k]) {
        delete position[k];
        continue;
      }

      const column = this.TableRows[k];
      const columnValue = position[k];

      if (isDate(columnValue)) {
        set += `${column} = TO_DATE('${moment(columnValue).format('YYYYMMDD')}', 'YYYYMMDD'), `;
      } else if (isNumber(columnValue)) {
        set += `${column} = ${columnValue}, `;
      } else {
        set += `${column} = '${columnValue}', `;
      }
    }
    const where = ` WHERE ${this.TableRows['id']} = '${id}' \
    AND ${this.TableRows['positionDate']} = TO_DATE('${moment(positionDate).format('YYYYMMDD')}', 'YYYYMMDD')`;

    set = set.slice(0, -2);

    console.info('[PositionRepository] - parseUpdatePosition: query', JSON.stringify(`UPDATE ${this.TableName} ${set} ${where}`, null, 4) );

    return `UPDATE ${this.TableName} ${set} ${where}`;
  }

  async clientNamePosition(penumper: string): Promise<Position> {
    const query = `
      SELECT * FROM ${PositionTable}
        WHERE ${PositionRow.penumper} = '${penumper}'
        AND ${PositionRow.clientName} IS NOT NULL AND ROWNUM = 1
    `;

    return this.queryHandler.executeFirstOrNull(query).catch(oracleErrorHandler(this.messages));
  }

}
