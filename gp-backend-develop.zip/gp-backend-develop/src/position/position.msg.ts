import { CategoryMessage, IMessage } from '../shared/common/message.model';

export const entityName: IMessage = {
  ptBr: 'Posição',
  system: 'Position',
};

export const PositionTag: IMessage = {
  ptBr : 'Posição',
  system : 'Position',
};

export const PositionMessage = new CategoryMessage(PositionTag, entityName);