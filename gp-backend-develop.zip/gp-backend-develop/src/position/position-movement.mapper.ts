import { Moviment, MovimentRow } from '../moviment/moviment.entity';
import { Position, PositionRow } from './position.entity';
import { RowMapper } from '../shared/repository/repository.interface';
import * as moment from 'moment';
import { CommonEntity } from '../shared/common/entity';
import { Product, ProductRow } from '../product/product.entity';

export class PositionMovement extends CommonEntity {
  rows: number;
  position: Position = new Position();
  movement: Moviment = new Moviment();
  product: Product = new Product();
}

export class PositionMovementMapper implements RowMapper<PositionMovement> {
  public map(row: any): PositionMovement {

    const pMovement = new PositionMovement();
    const position = new Position();
    const movement = new Moviment();
    const product = new Product();

    pMovement.rows = row['LINES'];
    position.positionDate = row[PositionRow.positionDate];
    position.id = row[PositionRow.id];
    // position.productId = row[PositionRow.productId];
    // position.groupName = row[PositionRow.groupName];

    position.sbkCodeId = row[PositionRow.sbkCodeId];
    position.productSbkCode = row[PositionRow.productSbkCode];
    position.penumper = row[PositionRow.penumper];
    position.percentageNegotiatedRate = row[PositionRow.percentageNegotiatedRate];
    position.negotiatedInitialUnitPrice = row[PositionRow.negotiatedInitialUnitPrice];
    position.initialTradedAmount = row[PositionRow.initialTradedAmount];
    position.aplicationDate = row[PositionRow.aplicationDate];
    position.availableQuantity = row[PositionRow.availableQuantity];
    position.grossUnitPriceUpdated = row[PositionRow.grossUnitPriceUpdated];
    // position.valueUnitPriceUpdated = row[PositionRow.valueUnitPriceUpdated];
    position.updatedGrossValueAvailable = row[PositionRow.updatedGrossValueAvailable];
    position.updatedNetValueAvailable = row[PositionRow.updatedNetValueAvailable];
    position.irValue = row[PositionRow.irValue];
    position.iofValue = row[PositionRow.iofValue];
    position.blockedQuantity = row[PositionRow.blockedQuantity];
    position.grossValueBlocked = row[PositionRow.grossValueBlocked];
    position.bankCode = row[PositionRow.bankCode];
    position.agencyCode = row[PositionRow.agencyCode] ? (row[PositionRow.agencyCode]).toString().padStart(4, '0') : row[PositionRow.agencyCode];
    // position.accontCode = row[PositionRow.accontCode];
    position.documentNumber = row[PositionRow.documentNumber];
    position.liquidityDate = row[PositionRow.liquidityDate];
    position.liquidityEndDate = row[PositionRow.liquidityEndDate];
    position.liquidityValue = row[PositionRow.liquidityValue];
    position.typePerson = row[PositionRow.typePerson];
    position.initialValue = row[PositionRow.initialValue];
    position.accrualCashValue = row[PositionRow.accrualCashValue];
    position.optionMTMValue = row[PositionRow.optionMTMValue];
    position.campaignIDCode = row[PositionRow.campaignIDCode];
    position.dueDate = row[PositionRow.dueDate];
    position.productLineAcronym = row[PositionRow.productLineAcronym];
    // position.segmentName = row[PositionRow.segmentName];
    // position.subProductCode = row[PositionRow.subProductCode];
    position.clientName = row[PositionRow.clientName];
    position.segmentCodeClient = row[PositionRow.segmentCodeClient];

    position.situation = situation(position.liquidityDate, position.blockedQuantity);
    position.taxValue = taxValue(position.iofValue, position.irValue);
    position.woLiquidityValue = woLiquidityValue();

    movement.id = row[MovimentRow.id];
    movement.globalId = row[MovimentRow.globalId];
    movement.sdkCodeId = row[MovimentRow.sdkCodeId];
    movement.productSdkCode = row[MovimentRow.productSdkCode];
    movement.penumper = row[MovimentRow.penumper];
    movement.dateBase = row[MovimentRow.dateBase];
    movement.dateConv = row[MovimentRow.dateConv];
    movement.dateSolic = row[MovimentRow.dateSolic];
    movement.dateEfet = row[MovimentRow.dateEfet];
    movement.netValue = row[MovimentRow.netValue];
    movement.grossValue = row[MovimentRow.grossValue];
    movement.irValue = row[MovimentRow.irValue];
    movement.iofValue = row[MovimentRow.iofValue];
    movement.bankCode = row[MovimentRow.bankCode];
    movement.branchCode = row[MovimentRow.branchCode];
    movement.accountCode = row[MovimentRow.accountCode];
    movement.documentNumber = row[MovimentRow.documentNumber];
    movement.typePerson = row[MovimentRow.typePerson];
    movement.opChanCode = row[MovimentRow.opChanCode];
    movement.opUserCode = row[MovimentRow.opUserCode];
    movement.opStatusCode = row[MovimentRow.opStatusCode];
    movement.sourceSys = row[MovimentRow.sourceSys];
    movement.moviGFCode = row[MovimentRow.moviGFCode];
    movement.moviType = row[MovimentRow.moviType];
    movement.campaignIDCode = row[MovimentRow.campaignIDCode];
    movement.tradedQuantity = row[MovimentRow.tradedQuantity];
    // movement.subProductCode = row[MovimentRow.subProductCode];
    movement.taxValue = taxValue(movement.iofValue, movement.irValue);

    product.id = row[ProductRow.id];
    product.productId = row[ProductRow.productId];
    product.groupProductName = row[ProductRow.groupProductName];

    product.baseDate = row[ProductRow.baseDate];
    product.subProductCode = row[ProductRow.subProductCode];
    // product.sysOrigin = row[ProductRow.sysOrigin];
    // product.subProductName = row[ProductRow.subProductName];
    product.subProductCatCode = row[ProductRow.subProductCatCode];
    product.subProductRiskCode = row[ProductRow.subProductRiskCode];
    product.subProductTermCode = row[ProductRow.subProductTermCode];
    product.APIObrigCode = row[ProductRow.APIObrigCode];
    product.subProductSitCode = row[ProductRow.subProductSitCode];
    product.subProductAplMinValue = row[ProductRow.subProductAplMinValue];
    product.subProductReaplMinValue = row[ProductRow.subProductReaplMinValue];
    product.userCodeLastUpdate = row[ProductRow.userCodeLastUpdate];
    product.lastUpdate = row[ProductRow.lastUpdate];
    product.volCode = row[ProductRow.volCode];
    product.credExpCode = row[ProductRow.credExpCode];
    product.creditRatingCode = row[ProductRow.creditRatingCode];
    product.collatCode = row[ProductRow.collatCode];
    product.durationCode = row[ProductRow.durationCode];
    product.termCode = row[ProductRow.termCode];
    product.potLossCode = row[ProductRow.potLossCode];
    product.indexCode = row[ProductRow.indexCode];
    product.eqRisk = row[ProductRow.eqRisk];
    product.liqCode = row[ProductRow.liqCode];
    product.spainRiskCode = row[ProductRow.spainRiskCode];
    product.brazilRiskCode = row[ProductRow.brazilRiskCode];
    product.complexityCode = row[ProductRow.complexityCode];

    function taxValue(iofValue: number, irValue: number): number {
      return iofValue + irValue;
    }

    function woLiquidityValue(): number {
      return position.updatedGrossValueAvailable - position.liquidityValue;
    }

    function situation(liquidityDate: Date, blockedQuantity: number): string {
      if (blockedQuantity > 0) return 'Bloqueada';
      const today = moment();
      const liquidityDateMoment = moment(liquidityDate);
      if (liquidityDateMoment.isAfter(today)) return 'Carência';
      return 'Ativo';
    }

    pMovement.position = position;
    pMovement.movement = movement;
    pMovement.product = product;

    return pMovement;
  }
}