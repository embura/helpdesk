import { Position, PositionDetail, PositionConsolidated } from './position.entity';

export class PositionGroupDetail {

  name: string;
  totalQuantity: number = 0;
  totalApplied: number = 0.00;
  totalBalance: number = 0.00;
  availableBalance: number = 0.00;
  operations?: Position[] = [];

  add(position: PositionDetail | PositionConsolidated): void {
    const postionTmp = position.getPosition();
    this.operations.push(postionTmp);

    this.totalApplied = this.totalApplied + this.totalAppliedByPosition(position);
    this.totalBalance = this.totalBalance + +postionTmp.value.currentGross;
    this.availableBalance = this.availableBalance + +postionTmp.value.updatedLiquidBalance;
    this.totalQuantity = this.operations.length;
  }

  totalAppliedByPosition(position: PositionDetail | PositionConsolidated): number {
    let total: number = 0;
    const positionTmp = position.getPosition();
    total = positionTmp.unitPrice.initial * positionTmp.quantity.current;
    return total;
  }

}
