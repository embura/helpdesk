import { CommonRepositoryService } from '../shared/common/repository.service';
import { Position, PositionRow, PositionTable, PositionRowMapper, PositionDetail, createPosition } from './position.entity';
import { PositionRepository } from './position.repository';
import { PositionMessage } from './position.msg';
import { CommnRepository } from '../shared/repository/common.repository';
import { IQuery, queryStringToWhere } from '../shared/common/query.interface';
import { Order, Op } from '../shared/repository/repository.interface';
import { Moviment } from '../moviment/moviment.entity';
import { ProductRepository } from '../product/product.repository';
import { MovimentRepository } from '../moviment/moviment.repository';
import { Product } from '../product/product.entity';
import moment = require('moment');
import { PositionGroupDetail } from './position-group-detail';
import { Pagination } from '../shared/utils/pagination.model';
import { dateToYYYMMMDD, getDateToday } from '../shared/utils/parse-date';
import { ServiceErrorHandler } from '../shared/common/common.error';
import { SegmentRepository } from '../segment/segment.repository';
import { Segment } from '../segment/segment.entity';
import { BaseDateProductRepository } from '../base-date-product/base-date-product.repository';

import { Component } from '@nestjs/common';
import { parseBooleans } from 'xml2js/lib/processors';
import { isBoolean, isDate } from 'util';

@Component()
export class PositionService extends CommonRepositoryService<Position>{

  protected order: [string, Order][] = [['id', Order.DESC]];
  protected sortBySituation: boolean = true;

  constructor(
    protected readonly positionRepository: PositionRepository,
    protected readonly productRepository: ProductRepository,
    protected readonly movimentRepository: MovimentRepository,
    private readonly baseDateProductRepository: BaseDateProductRepository,
    private readonly segmentRepository: SegmentRepository
  ) {
    super();
    this.messages = PositionMessage;

    this.repository = new CommnRepository(
      PositionRow,
      PositionTable,
      null,
      PositionMessage,
      new PositionRowMapper()
    );

  }

  async findAll(param: IQuery): Promise<Position[]> {
    const where = queryStringToWhere(param);
    return this.repository.findAll(where);
  }

  async findPositionMovement(param: IQuery): Promise<{ positions: Position[], pagination: Pagination }> {
    const toDay = moment().format('YYYYMMDD');
    const positionDate = param.positionDate === toDay ? toDay : param.positionDate;
    param.positionDate = await this.getLastDatePosition(param.positionDate);
    param = this.queryParse(param);
    this.sortBySituation = (param.sortBySituation as any) === true;
    const wherePosition = queryStringToWhere(param);
    const pagination = new Pagination();

    // Somente pegar posições com data de aplicação igual ou anterior a data posição.
    wherePosition.where = Object.assign({
      [Op.and]: [
        {
          aplicationDate: { [Op.lte]: `TO_DATE('${positionDate}','YYYYMMDD')` },
        },
      ],
    }, wherePosition.where);

    console.info('[PositionService]  wherePosition: ', JSON.stringify(wherePosition.where) );

    wherePosition.order = this.order;

    if (wherePosition.where.positionDate) {
      wherePosition.where.positionDate = moment(param.positionDate, 'YYYYMMDD').toDate() as any;
    }

    const wherePositionUnlimit = Object.assign({}, wherePosition);
    delete wherePositionUnlimit.offset;
    delete wherePositionUnlimit.limit;
    delete wherePositionUnlimit.limit;

    const [positions, totalItems, segments] = await Promise.all([
      this.repository.findAll(wherePosition),
      this.repository.findAll(wherePositionUnlimit, 10000).then(posi => posi.length),
      this.segmentRepository.findAll({}),
    ]).catch(ServiceErrorHandler);
    if (positions.length === 0) {
      return { positions, pagination: null };
    }

    const segmentMap: Map<string, Segment> = new Map<string, Segment>();
    const sbkProductMap: Map<string, string> = new Map<string, string>();

    for (const segment of segments) {
      segmentMap.set(segment.code, segment);
    }

    for (const position of positions) {
      sbkProductMap.set(position.productSbkCode, `${position.productSbkCode}`);
    }

    const products$ = this.getProducts([...sbkProductMap.values()], param.positionDate);
    const movements$ = this.getMovements([...sbkProductMap.values()], param.positionDate);
    const [products, movements] = await Promise.all([products$, movements$]);

    const productsMap: Map<string, Product> = this.createProductsMap(products);
    const movementsMap: Map<string, Moviment[]> = this.createMovementMap(movements);

    for (let count = 0, size = positions.length; count < size; count++) {
      positions[count] = this.updatePositionByProduct(positions[count], productsMap.get(positions[count].productSbkCode));
      positions[count].isPrivate = segmentMap.has(positions[count].segmentCodeClient);

      if (movementsMap.has(positions[count].id)) {
        positions[count] = this.updatePositionByMovements(positions[count], movementsMap.get(positions[count].id));
      }
    }

    const pgQuery: any = Object.assign({}, param.pagination);

    pagination.currentPage = pgQuery.currentPage;
    pagination.itemPerPage = pgQuery.itemPerPage;

    pagination.update(totalItems);

    return { positions, pagination };
  }

  async getLastDatePosition(positionDate: string): Promise<string> {
    const todayString = dateToYYYMMMDD(getDateToday());
    const queryDateString = positionDate || todayString;

    console.info(`[PositionSerice] getLastDatePosition todayString[${todayString}]  queryDateString[${queryDateString}]`);

    if (todayString !== queryDateString) {
      return queryDateString;
    }

    const currentDate = await this.baseDateProductRepository.findOne({
      where: {
        statusInt: 4,
        fileNumber: 2,
      },
      order: [['baseDate', Order.DESC]],
    });

    if (currentDate && currentDate.baseDate) {
      const posiDate = moment(currentDate.baseDate).format('YYYYMMDD');
      console.info(`[PositionSerice] getLastDatePosition posiDate[${posiDate}]`);
      return posiDate;
    }

    console.info(`[PositionSerice] getLastDatePosition dateNow [${moment().format('YYYYMMDD')}]`);

    return moment().format('YYYYMMDD');
  }

  createProductsMap(productsList: Product[]): Map<string, Product> {
    const productsMap: Map<string, Product> = new Map<string, Product>();
    for (const product of productsList) {
      productsMap.set(product.id, product);
    }

    return productsMap;
  }

  createMovementMap(movementsList: Moviment[]): Map<string, Moviment[]> {
    const movementsMap: Map<string, Moviment[]> = new Map<string, Moviment[]>();
    for (const movement of movementsList) {

      if (movementsMap.has(movement.globalId)) {
        movementsMap.get(movement.globalId).push(movement);
      } else {
        movementsMap.set(movement.globalId, [movement]);
      }
    }

    return movementsMap;
  }

  updatePositionByProduct(position: Position, product: Product): Position {

    if (!product || !product.productId) {
      return null;
    }

    position.groupName = product.groupProductName;
    position.modality = product.modalityProductName;
    position.productId = product.productId;

    position.groupProductCode = product.groupProductCode;
    position.subProductCode = product.subProductCode;

    position.family = product.familyProductName;
    position.group = product.groupProductName;
    position.assetClass = product.assetClassProductName;
    position.underlying = product.underlyingProductName;
    position.productName = product.name;

    return position;
  }

  queryParse(query: IQuery): IQuery {

    let sortBySituation = false;

    if ('initialApplicationDate' in query && 'endApplicationDate' in query) {
      query._between = `aplicationDate:${query.initialApplicationDate}:${query.endApplicationDate}`;
      delete query.initialApplicationDate;
      delete query.endApplicationDate;
    }

    if ('segmentList' in query) {
      const segmentsList: string[] = [...query.segmentList];
      query._in = `segmentCodeClient:${segmentsList}`;
      delete query.segmentList;
    }

    // Produto, Global ID, nº SBK, ag e cc
    if ('filter' in query) {

      const filter = JSON.parse(JSON.stringify(query.filter));

      sortBySituation = 'sortBySituation' in filter && filter.sortBySituation === true;

      // TODO:muito pesado rever !
      if (('customSearch' in filter) && !!filter.customSearch) {
        const searchedText = (filter.customSearch as string).trim();

        if (searchedText) {
          query._or = this.createOrSearchParam(searchedText) as any;
        }
      }

      if (('orderBy' in filter)) {
        this.order = this.getOrder(filter.orderBy);
      }

      delete query.filter;
    }

    query = this.getPagination(query);

    return Object.assign({ sortBySituation }, query);
  }

  getPagination(query: IQuery): IQuery {
    if (query.pagination) {

      const pagination: any = Object.assign({}, query.pagination);

      const _offset = pagination.currentPage === 1 ? 0 : (pagination.itemPerPage * (pagination.currentPage - 1));
      const _limit = pagination.itemPerPage;

      query._offset = _offset.toString();
      query._limit = _limit.toString();
    }
    return query;
  }

  getOrder(orderBy?: number): [string, Order][] {

    // 1 Ordem alfabética - ordem alfabética de A a Z por Produto.
    // 2 mais recentes - ordenar por data de aplicação (mais novas para mais velhas)
    // 3 menos recentes - ordenar por data de aplicação  (mais velhas para mais novas)
    // 4 Vencimento próximo - ordenar por data de vencimento (mais novas para mais velhas)
    // 5 Maior principal remanecente - ordenar por Principal remanescente (trazendo o de maior valor para o de menor valor)
    // 6 Maior saldo liq. atualizado - ordenar por Saldo liq. atual (trazendo o de maior valor para o de menor valor)

    switch (orderBy) {
      case 1:
        return [['productSbkCode', Order.ASC]];
      case 2:
        return [['aplicationDate', Order.DESC]];
      case 3:
        return [['aplicationDate', Order.ASC]];
      case 4:
        return [['dueDate', Order.ASC]];
      case 5:
        return [['updatedGrossValueAvailable', Order.DESC]];
      case 6:
        return [['liquidityValue', Order.DESC]];
    }
  }

  createOrSearchParam(searchedText: string): Array<string> {
    const or: Array<string> = new Array();
    or.push(`agencyCode:like:${searchedText}`);
    or.push(`accountCode:like:${searchedText}`);
    or.push(`sbkCodeId:like:${searchedText}`);
    or.push(`id:like:${searchedText}`);
    or.push(`productSbkCode:like:${searchedText}`);
    return or;
  }

  sortGroupBySituation(groups: Map<string, PositionGroupDetail>): Map<string, PositionGroupDetail> {
    for (const [key] of groups) {
      groups.get(key).operations = this.orderBySituation(groups.get(key).operations);
    }
    return groups;
  }

  sortPositionByValue(positions: Position[], field: string, order = 'DESC'): Position[] {

    return positions.sort((a, b) => {
      const fieldA = a[field];
      const fieldB = b[field];

      if (order === 'ASC') {
        if (fieldB > fieldA) {
          return -1;
        }

        if (fieldA > fieldB) {
          return 1;
        }
        return 0;
      }

      if (fieldA > fieldB) {
        return -1;
      }

      if (fieldB > fieldA) {
        return 1;
      }
      return 0;

    });
  }

  sortGroup(groups: Map<string, PositionGroupDetail>): Map<string, PositionGroupDetail> {

    let field = this.order[0][0];
    const order = this.order[0][1];

    switch (field) {
      case 'updatedGrossValueAvailable':
        field = 'currentMainOpening';
        for (const [key] of groups) {
          groups.get(key).operations = this.sortPositionByValue(groups.get(key).operations, field, order);
        }
        break;
      case 'liquidityValue':
        field = 'updatedLiquidBalance';
        for (const [key] of groups) {
          groups.get(key).operations = this.sortPositionByValue(groups.get(key).operations, field, order);
        }
        break;
    }

    return groups;
  }

  orderBySituation(positions: Position[]): Position[] {
    const active: Position[] = [];
    const blocked: Position[] = [];
    const lack: Position[] = [];
    const ACTIVE = 'ATIVO';
    const BLOCKED = 'BLOQUEADA';
    const LACK = 'CARÊNCIA';

    for (const position of positions) {
      const situation = position.situation.toUpperCase();
      switch (situation) {
        case ACTIVE:
          active.push(position);
          break;
        case BLOCKED:
          blocked.push(position);
          break;
        case LACK:
          lack.push(position);
          break;
      }
    }

    return active.concat(lack).concat(blocked);
  }

  agroupGroupName(positionsList: Position[]): Map<string, PositionGroupDetail> {
    let groups: Map<string, PositionGroupDetail> = new Map<string, PositionGroupDetail>();
    let positionGroupDetailTmp: PositionGroupDetail;

    for (const position of positionsList) {

      if (!groups.has(position.groupName)) {
        positionGroupDetailTmp = new PositionGroupDetail();
        positionGroupDetailTmp.name = position.groupName;

        const positionDetail = new PositionDetail(position);
        positionGroupDetailTmp.add(positionDetail);

        groups.set(positionGroupDetailTmp.name, positionGroupDetailTmp);
      } else {
        positionGroupDetailTmp = groups.get(position.groupName);

        const positionDetail = new PositionDetail(position);
        positionGroupDetailTmp.add(positionDetail);

        groups.set(positionGroupDetailTmp.name, positionGroupDetailTmp);

      }
    }

    groups = this.sortGroup(groups);

    if (this.sortBySituation) {
      groups = this.sortGroupBySituation(groups);
    }

    return groups;
  }

  async getMovements(sbkCodeProductList: string[], date: string, format = 'YYYYMMDD'): Promise<Moviment[]> {

    const where = {
      dateBase: moment(date, format).toDate() as any,
      sourceSys: 'ONL',
      moviGFCode: { [Op.in]: ['NO', 'RT', 'RP'] },
      productSdkCode: { [Op.in]: sbkCodeProductList },
    };

    return this.movimentRepository.findAll({ where });
  }

  async getProducts(sbkCodeProductList: string[], date: string, format = 'YYYYMMDD'): Promise<Product[]> {
    const where = {
      baseDate: moment(date, format).toDate() as any,
      id: { [Op.in]: sbkCodeProductList },
    };
    const products = await this.productRepository.findAll({ where });
    console.info('[PositionService] getProducts products length ', products.length);
    return products;
  }

  updatePositionByMovements(position: Position, movements: Moviment[]): Position {
    let pos = Object.assign({}, position);
    if (!movements) {
      return pos;
    }

    for (const movement of movements) {
      pos = this.updatePositionByMovement(pos, movement);
    }

    return pos;
  }

  updatePositionByMovement(position: Position, movement: Moviment): Position {
    const pos = Object.assign({}, position);

    console.info(`[PositionService] updatePositionByMovement: position.id[${position.id}] movement.id[${movement.id}]`);

    if (movement && pos.id === movement.globalId) {
      if (movement.moviGFCode === 'NO' && movement.moviType === 'S' && movement.sourceSys === 'ONL') {
        pos.irValue = pos.irValue / (pos.availableQuantity / (pos.availableQuantity - movement.tradedQuantity));
        pos.iofValue = pos.iofValue / (pos.availableQuantity / (pos.availableQuantity - movement.tradedQuantity));
        pos.availableQuantity = pos.availableQuantity - movement.tradedQuantity;

        pos.updatedNetValueAvailable = (pos.valueNetUnitPriceUpdated * pos.availableQuantity);
        pos.updatedGrossValueAvailable = (pos.grossUnitPriceUpdated * pos.availableQuantity);
        pos.liquidityValue = (pos.valueNetUnitPriceUpdated * pos.availableQuantity);
      }
    }
    return pos;
  }

  async findByGlobalIdAndDate(id: string, dateBase: Date): Promise<Position[]> {
    console.info(`[PositionService] findByGlobalIdAndDate: id[${id}] dateBase[${dateBase.toLocaleString()}]`);
    return this.positionRepository.findByGlobalIdAndDate(id, dateBase);
  }

  async getDataToExport(fileInfo: any): Promise<Position[]> {

    console.info('[PositionService] getDataToExport start');

    const param: IQuery = {
      productLineAcronym: fileInfo.product,
      positionDate: fileInfo.fileDate,
    };

    const paramProduct: IQuery = {
      positionDate: fileInfo.fileDate,
    };

    const wherePosition = queryStringToWhere(param);

    const [products, positions] = await Promise.all([
      this.productRepository.findAll(paramProduct, 10000),
      this.repository.findAll(wherePosition, 100000),
    ]);

    const productsMap: Map<string, Product> = this.createProductsMap(products);
    console.info('[PositionService] getDataToExport products: ', products.length);

    let count = 0;
    for (const position of positions) {
      const productSbk = productsMap.get(position.productSbkCode);

      if (!productSbk) continue;

      positions[count] = this.updatePositionByProduct(position, productSbk);
      count++;
    }

    console.info('[PositionService] getDataToExport finish');

    return positions;
  }

  async getPenumperToExport(fileInfo: any): Promise<Position[]> {
    return this.positionRepository.getPenumperToExport(fileInfo);
  }

  async create(obj: Position): Promise<Position> {
    if (this.validation) {
      const newObj = Object.assign({}, obj);
      delete newObj.id;
      await this.validation.validate(newObj)
        .catch(err => {
          if (err.code) {
            throw err;
          }

          throw this.badRequest(err);
        });
    }

    await this.positionRepository.create(obj);
    return;
  }

  async findByProductId(paramPosition: IQuery): Promise<{ positions: Position[], pagination: Pagination }> {

    const baseDate = await this.getLastDatePosition(paramPosition.positionDate);

    const paramProd: IQuery = {
      baseDate: moment(baseDate, 'YYYYMMDD').toDate() as any,
      productId: paramPosition.productId,
    };

    paramPosition = this.queryParse(paramPosition);

    this.sortBySituation = (paramPosition.sortBySituation as any) === true;
    const whereProduct = queryStringToWhere(paramProd);

    delete paramPosition.productId;

    if (paramProd.productId) {
      const product = await this.productRepository.findOne(whereProduct).catch(ServiceErrorHandler);
      paramPosition.productSbkCode = product ? product.id : '';
    }

    return this.findPositionMovement(paramPosition)
      .catch(ServiceErrorHandler);
  }

  async positionUpdate(position: Position): Promise<Position> {

    const seg = position.segmentCodeClient || '';
    const dateStr = moment(position.positionDate).format('YYYYMMDD');
    const positionDateCurrentStr = await this.getLastDatePosition(dateStr);
    const positionDateCurrent = moment(positionDateCurrentStr).toDate();

    // tslint:disable-next-line:prefer-const
    let [posi, segment] = await Promise.all([
      this.repository.findOne({
        where: {
          id: position.id,
          positionDate: positionDateCurrent as any,
        },
        order: [['positionDate', Order.DESC]],
      }),
      this.segmentRepository.findOne({
        where: {
          code: seg,
        },
      }),
    ]);

    if (!posi) {
      throw Error(this.messages.error.notFound);
    }

    const positionDate: Date = posi.positionDate;
    posi = position;
    posi.positionDate = positionDate;

    let positionUpdated = await this.positionRepository.updatePosition(posi, posi.id, posi.positionDate)
      .catch(err => {
        console.error('[PositionService] Não foi possivel atualizar posição');
        throw err;
      });

    positionUpdated = await this.repository.findOne({
      where: { id: positionUpdated.id, },
      order: [['positionDate', Order.DESC]],
    });

    positionUpdated.isPrivate = !!segment;
    positionUpdated.subProductCode = positionUpdated.productSbkCode;

    return positionUpdated;
  }

  bindBodyToPosition(position: any): Position {
    const posiNew = createPosition();

    // tslint:disable-next-line: forin
    for (const key in position) {

      const type = typeof posiNew[key];
      const prop = position[key];

      switch (type) {
        case 'string':
          posiNew[key] = String(prop);
          break;
        case 'number':
          posiNew[key] = parseFloat(prop);
          break;
        case 'object':
          posiNew['key'] = isDate(prop) ? prop : moment(prop, ['YYYYMMDD']).toDate();
          break;
        case 'boolean':
          posiNew[key] = isBoolean(prop) ? prop : parseBooleans(prop);
          break;

        default:
          throw new Error(`property type error: property[${key}] type expect [${type}]`);
      }
    }

    return posiNew;
  }

  async clientNamePosition(penumper: string): Promise<string> {
    const position = await this.positionRepository.clientNamePosition(penumper);
    return position ? position.clientName : '';
  }

}
