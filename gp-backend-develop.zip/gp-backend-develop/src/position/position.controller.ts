import { CommonController } from '../shared/common/common.controller';
import { Position, PositionDetail, positionFormatToDate } from './position.entity';
import { PositionService } from './position.service';
import { PositionMessage } from './position.msg';
import { Controller, Post, Res, HttpStatus, Body, UsePipes, ValidationPipe } from '@nestjs/common';
import { Response } from 'express';
import { IQuery } from '../shared/common/query.interface';
import { ServiceErrorHandler } from '../shared/common/common.error';
import { HttpResponse } from '../shared/http.response';
import { Status } from '../shared/status.entity';
import { PositionGroupDetail } from './position-group-detail';

@Controller('position')
export class PositionController extends CommonController<Position>{

  private readonly positionService: PositionService;

  constructor(positionService: PositionService) {
    super(positionService, PositionMessage);
    this.positionService = positionService;
  }

  @Post('/client/detail')
  async findClientDetail(@Res() res: Response, @Body() query: IQuery): Promise<Response> {

    if (!('penumper' in query)) {
      return res.status(HttpStatus.BAD_REQUEST).json(
        new HttpResponse(new Status(400, this.messages.error.invalidRequired), 'penumper empty')
      );
    }

    const { positions, pagination} = await this.positionService.findPositionMovement(query)
      .catch(ServiceErrorHandler);

    if (!positions || positions.length === 0) {
      return res.status(HttpStatus.OK).json(
        new HttpResponse(new Status(HttpStatus.OK, this.messages.error.notFound), {})
      );
    }

    const groups: Map<string, PositionGroupDetail> = this.positionService.agroupGroupName(positions);

    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, this.messages.success.found), {
        groups: [...groups.values()],
        pagination,
      })
    );
  }

  @Post('/product/detail')
  async findProductDetail(@Res() res: Response, @Body() query: IQuery): Promise<Response> {

    const {positions, pagination} = await this.positionService.findByProductId(query);
    let positionsByProduct: Position[] = positions;

    if (!positionsByProduct || positionsByProduct.length === 0) {
      return res.status(HttpStatus.OK).json(
        new HttpResponse(new Status(HttpStatus.OK, this.messages.error.notFound), {})
      );
    }

    positionsByProduct = this.positionService.orderBySituation(positionsByProduct);

    const positionsAgrouped = positionsByProduct.map(posi => new PositionDetail(posi).getPosition());

    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, this.messages.success.found), {
        products: {
          totalQuantity: positionsAgrouped.length,
          operations: positionsAgrouped,
        },
        pagination,
      })
    );

  }

  @Post('/update')
  @UsePipes(new ValidationPipe({ transform: true }))
  async update(@Res() response: Response, @Body() position: Position): Promise<Response> {

    position = positionFormatToDate(position);
    position = this.positionService.bindBodyToPosition(position);

    return this.positionService.positionUpdate(position).then( (posi: Position) => {
      return response.status(HttpStatus.OK).json(
        new HttpResponse(new Status(HttpStatus.OK, this.messages.success.update), posi)
      );
    }).catch( err => {
      return response.status(HttpStatus.INTERNAL_SERVER_ERROR).json(
        new HttpResponse(new Status(HttpStatus.INTERNAL_SERVER_ERROR, err.message), {})
      );

    });
  }

}
