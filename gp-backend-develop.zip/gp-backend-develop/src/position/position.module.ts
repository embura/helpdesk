import { Module } from '@nestjs/common';
import { PositionService } from './position.service';
import { PositionRepository } from './position.repository';
import { PositionController } from './position.controller';

@Module({
  components: [
    PositionService,
    PositionRepository,
  ],
  controllers: [PositionController],
  exports: [PositionService],
})

export class PositionModule { }
