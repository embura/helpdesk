import { Get, Controller } from '@nestjs/common';
import * as fs from 'fs';
import { SqlHandler } from './shared/lib/database/query-handler';
@Controller()
export class AppController {

  protected readonly sqlHandler = new SqlHandler();

  @Get()
  root(): NodeJS.ProcessEnv {
    return process.env;
  }

  @Get('log')
  log(): string {
    // tslint:disable-next-line:no-console
    console.log(`+++++ process.cwd: ${process.cwd()} +++++`);
    return fs.readFileSync('./logs/all-logs.log', 'utf8');
  }

  @Get('_ah/tables')
  async listTables(): Promise<{}[]> {
    const tables = await this.sqlHandler
      .execute(`SELECT table_name FROM all_tables WHERE OWNER = 'GPOS'`)
      .then( table => table.map( (t: any) => `${t.TABLE_NAME}`));

    const ColumnSelector = `SELECT RPAD(COLUMN_NAME,30)||' '||DATA_TYPE||'('||DATA_LENGTH||')' as descr
          FROM all_tab_cols WHERE TABLE_NAME = UPPER(:tableName) and OWNER = 'GPOS'`;

    const res: any = {};
    for ( const table of tables) {
      const columns = await this.sqlHandler
        .execute(ColumnSelector, {tableName: table} as any)
       .then( cols => cols.map( (c: any) => `${c.DESCR}`));
      res[`GPOS.${table}`] = columns;
    }
    return res;
  }

}
