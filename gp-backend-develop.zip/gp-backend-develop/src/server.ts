// tslint:disable-next-line:no-var-requires
const probe = require('ca-apm-probe');
probe.start();
// tslint:disable-next-line:no-var-requires
const { applyLogger } = require('@snt-js-commons/log');
applyLogger('GPOS');

import { NestFactory } from '@nestjs/core';
import { ApplicationModule } from './app.module';
import * as bodyParser from 'body-parser';
import * as compression from 'compression';
import oracledb = require('oracledb');

import { LoggingInterceptor } from './server/interceptor/logging.interceptor';
import { ValidationPipe } from '@nestjs/common';
import { dbConfig } from './shared/lib/database/oracle.config';
import { systemLog } from './shared/utils/system-log.service';

// tslint:disable-next-line:no-console
console.log(`Start at Mode: '${process.env.NODE_ENV}'`);

async function bootstrap(): Promise<void> {
  const URL_PREFIX = '/gest-posicao/treasury-product-position/v1';
  await oracledb.createPool(dbConfig).catch( err => {
    // tslint:disable-next-line:no-console
    console.log('DB Connection Error', err);
  });
  const app = await NestFactory.create(ApplicationModule);

  app.useGlobalInterceptors(new LoggingInterceptor());
  app.useGlobalPipes(new ValidationPipe());
  app.setGlobalPrefix(URL_PREFIX);
  app.use(bodyParser.json());
  app.use(compression());

  process.on('warning', (warning) => {
    systemLog.error('[ERROR 1]  warning:', warning);
  });

  process.on('uncaughtException', (err) => {
    systemLog.error('[ERROR 2] There was an uncaught error', err);
  });

  process.on('unhandledRejection', (reason, p) => {
    systemLog.error('[ERROR 3] Unhandled Rejection at:', p, 'reason:', reason);
  });

  await app.listen(8080);
}
bootstrap();
