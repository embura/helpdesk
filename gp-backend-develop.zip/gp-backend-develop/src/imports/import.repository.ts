import { Component } from '@nestjs/common';
import { CommnRepository } from '../shared/repository/common.repository';
import { oracleErrorHandler } from '../shared/common/common.error';
import { Metadata } from '../metadata/metadata.entity';
import { dateToYYYMMMDD } from '../shared/utils/parse-date';
import * as moment from 'moment';
import { ImportMessage } from './import.msg';
import { PositionRow, PositionTable } from '../position/position.entity';
import { Product } from '../product/product.entity';
import { ProductService } from '../product/product.service';

import { PositionPenumperRepository } from '../position-penumper/position-penumper.repository';
import { BaseDateProductRepository } from '../base-date-product/base-date-product.repository';

@Component()
export class ImportRepository extends CommnRepository<any> {

  constructor(

    protected productService: ProductService,
    protected baseDateProductRepository: BaseDateProductRepository,
    protected positionPenumperRepository: PositionPenumperRepository) {
    super(
      null,
      null,
      null,
      ImportMessage,
      null
    );
  }

  async insertData(data: any[], fileInfo: any): Promise<any> {
    const baseDate = moment(fileInfo.fileDate, 'YYYYMMDD').toDate();
    const products: Product[] = await this.getAllProductsByDate(baseDate);
    let productsSbkCode: string[] = [];

    if (products && products.length > 0) {
      productsSbkCode = products.map(product => product.id);
    } else if (fileInfo.type === 'posi') {
      throw Error('Produtos não encontrados para a data ' + baseDate);
    }

    const queryStart = ` INSERT ALL`;
    const queryEnd = ` SELECT 1 FROM DUAL`;
    let queryInserts = '';

    let count = 0;

    for (const dataRow of data) {
      const tables =  this.createTables(dataRow);

      for (const table of Object.keys(tables)) {

        if (Metadata[table]) {
          if (Metadata[table].date) {
            tables[table].columns.push(`${Metadata[table].date}`);
            tables[table].values.push(`TO_DATE('${dateToYYYMMMDD(fileInfo.fileDate)}', 'YYYYMMDD')`);
          }
          if (Metadata[table].source) {
            tables[table].columns.push(`${Metadata[table].source}`);
            tables[table].values.push(`'${fileInfo.product}'`);
          }
        }

        if (fileInfo.type === 'posi' || fileInfo.type === 'movi') {

          const indexSBkcode: number = tables[table].columns.indexOf('CD_PROD_SBK');
          const sBkcode = tables[table].values[indexSBkcode];

          if (!this.hasProduct(sBkcode, productsSbkCode)) {
            continue;
          }
        }

        queryInserts += `
            INTO ${table} (${tables[table].columns.join(',')}) VALUES (${tables[table].values.join(',')})
          `;

        if (count > 0 && count % 100 === 0) {
          const query = queryStart + queryInserts + queryEnd;

          await this.commandHandler.execute(query)
            .then(res => {
              queryInserts = '';
            }).catch(oracleErrorHandler(this.messages));
        }

        count = count + 1;
      }
    }

    if (queryInserts.length > 0) {
      const query = queryStart + queryInserts + queryEnd;
      return this.commandHandler.execute(query)
        .catch(oracleErrorHandler(this.messages));
    }

    return 'OK';
  }

  createTables(dataRow: any): any{
    const tables: any = {};
    for (const field of dataRow) {
      if (!tables[field.table]) {
        tables[field.table] = {
          columns: [],
          values: [],
        };
      }

      tables[field.table].columns.push(field.column);
      field.value = this.formatValue(field);

      tables[field.table].values.push(field.value);
    }
    return tables;
  }

  formatValue(field: any): any {
    if (field.type.name === 'DT' && field.value !== '' && field.value !== 0) {
      field.value = `TO_DATE('${field.value}', '${field.type.mask}')`;
    } else if (field.type.name === 'A') {
      field.value = `'${field.value}'`;
    } else if (field.type.name === 'DT' && field.value === 0) {
      field.value = `${null}`;
    } else if (field.value === '') {
      field.value = `${null}`;
    }
    return field.value;
  }

  hasProduct(productSbkCode: string, productList: string[]): boolean {
    if (productSbkCode) {
      productSbkCode = productSbkCode.replace(/'/g, '');
    }

    const has = productList.indexOf(productSbkCode) >= 0;
    if (!has) {
      console.warn(`[Import Respository] Produto não resgistrado  SBK Code [${productSbkCode}]`);
    }
    return has;
  }

  async updateSegment(data: string[], fileInfo: any): Promise<boolean> {

    const registers: number = Number(data.pop().split(';')[0]);
    const dateCsv = moment(data.shift().split(';')[2], 'YYYYMMDD');
    const dateFile = moment(fileInfo.fileDate, 'YYYYMMDD');

    if ((registers - 1) !== data.length) {
      return Promise.reject('Quantidade de linhas divergentes');
    }

    if (dateCsv.format('YYYYMMDD') !== dateFile.format('YYYYMMDD')) {
      return Promise.reject('Data dos arquivos divergentes');
    }

    // Recupera a lista de segmentos na base.
    const penumpers = await this.positionPenumperRepository
      .getPenumpers(fileInfo.fileDate);

    for (const row of data) {
      const fields = row.split(';');

      // 0 - Qtd registro
      // 1 - Detalhe/Header
      // 2 - Codigo Segmento
      // 3 - Descricao Segmento
      // 4 - Penumper
      // 5 - Nome do Cliente

      let nameClient = fields[5];
      nameClient = nameClient ? nameClient.replace(/'|"/, ' ') : '';

      if (penumpers.filter(posiPenum => posiPenum.penumper === fields[4]).length > 0) {
        const query = `UPDATE ${PositionTable} SET
        ${PositionRow.segmentCodeClient} = '${fields[2]}',
        ${PositionRow.clientName} = '${nameClient}'
        WHERE ${PositionRow.penumper} = '${fields[4]}'`;

        await this.commandHandler.execute(query)
          .catch(oracleErrorHandler(this.messages));
      }
    }

    return true;
  }

  async getAllProductsByDate(baseDate: Date): Promise<Product[]> {
    const baseDateLast = await this.baseDateProductRepository.findOne({
      where: {
        fileNumber: 5,
        statusInt: 4,
        baseDate: baseDate as any,
      },
    });

    if (!baseDateLast || !baseDateLast.baseDate) {
      return [];
    }

    return await this.productService.findAll({ baseDate: baseDateLast.baseDate } as any, 10000);
  }
}
