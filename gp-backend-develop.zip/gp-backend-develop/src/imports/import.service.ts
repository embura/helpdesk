import { Component } from '@nestjs/common';
import { BaseDate } from '../base-date/base-date.entity';
import { BaseDateProduct } from '../base-date-product/base-date-product.entity';
import { BaseDateService } from '../base-date/base-date.service';
import { BaseDateProductService } from '../base-date-product/base-date-product.service';
import { File } from '../metadata/file/file.entity';
import { FileService } from '../metadata/file/file.service';
import { ImportParams } from './import.interface';
import { FieldService } from '../metadata/field/field.service';
import { FieldTypeService } from '../metadata/fieldType/fieldType.service';
import { ImportRepository } from './import.repository';
import { PositionService } from '../position/position.service';
import { SystemStatusService } from '../system-status/system_status.service';
import { SystemStatus } from '../shared/constants/status.enum';
import { getFileState } from './import.utils';

import { getDateToday } from '../shared/utils/parse-date';

@Component()
export class ImportFileService {

  private readonly headsFile: Map<string, { sequence: number, name: string }> =
    new Map<string, { sequence: number, name: string }>();

  constructor(

    public readonly importRepository: ImportRepository,
    public baseDateService: BaseDateService,
    public baseDateProductService: BaseDateProductService,
    public fileService: FileService,
    public fieldService: FieldService,
    public fieldTypeService: FieldTypeService,
    public positionService: PositionService,
    public systemStatusService: SystemStatusService
  ) {
  }

  async processRequest(request: ImportParams): Promise<string> {
    let returnMessage = 'Importação do arquivo concluída com sucesso.';
    const { filename } = request;
    const fileInfo = await this.fileService.parseFilename(filename);

    const baseDateLog = await this.baseDateService.findByDate(fileInfo.fileDate);
    if (!baseDateLog) {
      await this.baseDateService.initDate(fileInfo.fileDate);
    }

    // import file
    const baseDateProduct = new BaseDateProduct();
    baseDateProduct.product = fileInfo.product;
    baseDateProduct.baseDate = fileInfo.fileDate;
    baseDateProduct.fileNumber = fileInfo.id;
    baseDateProduct.statusInt = SystemStatus.NotInitialized;

    const fileImportLog = await this.baseDateProductService.findByPKs(baseDateProduct);
    if (fileImportLog.length !== 0) {
      return 'Arquivo já importado';
    }
    await this.baseDateProductService.create(baseDateProduct);

    try {
      if (fileInfo.id === 8) {
        const lines = await this.getCsvFile(request.content);
        await this.importRepository.updateSegment(lines, fileInfo);
      } else {
        await this.importFileTemp(fileInfo, request);
      }

      baseDateProduct.statusInt = SystemStatus.UpTodate;

      const baseDate = new BaseDate();
      baseDate.id = new Date();
      baseDate.statusInt = baseDateProduct.statusInt;

      // Somento arquivos de paramentros(id=5) e posição(id=2) vão alterar status do sistema
      if (fileInfo.id === 2){
        baseDate.statusInt = baseDateProduct.statusInt;

        console.info('[ImportService] baseDateService.update', baseDateProduct, baseDate);
        await this.baseDateService.update(baseDate);
      }

      await this.baseDateProductService.update(baseDateProduct);

    } catch (err) {
      baseDateProduct.statusInt = SystemStatus.Error;
      await this.baseDateProductService.update(baseDateProduct);
      // Somento arquivos de paramentros(id=5) e posição(id=2) vão alterar status do sistema
      if (fileInfo.id === 2 || fileInfo.id === 5){
        this.baseDateService.importErrorHandler(err, getDateToday());
      }

      returnMessage = err;
    }

    // updating systemStatus
    const newDateInfo = new BaseDate();
    newDateInfo.id = fileInfo.fileDate;
    try {
      const mustRun: File[] = await this.fileService.findAll({ run: '1' });

      const fileImportStatus: number[] = [];
      for (const fileMetadata of mustRun) {
        baseDateProduct.fileNumber = fileMetadata.id;
        const status = await this.baseDateProductService.findByPKs(baseDateProduct);
        if (status.length === 0) {
          fileImportStatus.push(0);
        } else {
          fileImportStatus.push(status[0].statusInt);
        }
      }

      newDateInfo.statusInt = getFileState(fileImportStatus);
      await this.baseDateService.update(newDateInfo);
    } catch (err) {
      this.baseDateService.importErrorHandler(err, newDateInfo.id);
    }

    return returnMessage;
  }

  async importFileTemp(fileInfo: any, request: ImportParams): Promise<any> {
    const fields = await this.fieldService.getFieldsWithTypes(fileInfo);

    let rows: string[] = await this.readFile(request);

    rows = rows.filter((row: string) => row.length > 0);
    let filteredRows;
    // TODO: COLOCAR EM CONFIG
    const COD_CPT_PROD: string = 'COD-CPT-PROD';
    const PARAMETOS: string = 'parametros';

    if (fileInfo.separator) {

      const headList = rows[1].split(fileInfo.separator);

      headList.forEach((value: string, index: number) => {
        const attr = { sequence: index, name: value };
        this.headsFile.set(value, attr);
      });

      this.headsFile.delete('00');

      filteredRows = rows.filter(
        (row: string) => row.startsWith(request.contentIdentifier)
      ).map(
        (row: any) => row.substring(request.contentIdentifier.length)
      );

      const rowPop = rows.pop();

      const size: string = rowPop ? rowPop.replace('T', '') : '0';

      if (filteredRows.length !== parseFloat(size)) {
        return Promise.reject(`Quantidade de registros (${filteredRows.length}) incompatível com o trailer (${parseFloat(size)}).`);
      }

      rows = filteredRows;
    }
    const data = [];
    for (const row of rows) {
      const dataRow = this.getDataRow(fields, row, fileInfo.separator);

      if (!dataRow) {
        console.error(`[ImportService] Position SKIP: `, row);
        continue;
      }

      data.push(dataRow);
    }

    if (fileInfo.separator && fileInfo.type === PARAMETOS) {

      const unique = data.map((fieldsData: any) => {

        const codCptProd = fieldsData.filter((field: any) => {
          return field.name === COD_CPT_PROD;
        });

        return codCptProd[0];
      }).map((field: any) => {

        return field.value;
      }).filter((e: any, i: any, a: any) => {
        return i === a.indexOf(e);
      });

      if (data.length !== unique.length) {
        console.error('Código de Produto duplicado no arquivo.');
      }
    }

    return this.insertData(data, fileInfo);
  }

  getDataRow(fields: any[], row: string, separator?: string): any {

    const newFields = [];

    for (let field of fields) {
      field = Object.assign({}, field);

      let rawValue;
      if (separator) {
        // csv
        if (!this.headsFile.has(field.name)) {
          throw new Error(`Parametro não encontrado no arquivo! Parametro[${field.name}]`);
        }

        const head = this.headsFile.get(field.name);
        rawValue = row.split(separator)[head.sequence - 1];

        rawValue = rawValue ? rawValue.toString().trim() : '';
        rawValue = rawValue.substring(0, field.size);
        field.value = rawValue;
      } else {
        // positional
        rawValue = row.substring(field.start_pos - 1, field.start_pos - 1 + field.size);
        field.value = this.removeFiller(rawValue, field);
      }

      if (field.type.decimals && field.type.digits) {
        const digits = field.value.substr(0, field.type.digits);
        const decimals = field.value.substr(field.type.digits, field.type.decimals);
        field.value = field.value ? parseFloat(`${digits}.${decimals}`).toFixed(field.type.decimals) : 0;
      }
      if ((field.type.name === 'B' || field.type.name === 'N' || field.type.name === 'DT') && field.value !== '') {
        field.value = parseFloat(field.value);
      }

      // TODO: Corrigir produtos
      if (field.name === 'IND-IQ' && (!field.value || field.value === 0 || field.value === '0') ){
        field.value = 'N';
        console.warn(`[ImportService] Campo ${field.name} do arquivo é obrigatório, mas não tem conteúdo: .`, row);
      }

      if (field.obrig === 1 && field.value === '') {
        console.warn(`[ImportService] Campo ${field.name} do arquivo é obrigatório, mas não tem conteúdo.`);
        return null;
      }
      newFields.push(field);

    }

    return newFields;
  }

  async insertData(data: any[], fileInfo: any): Promise<any> {
    return this.importRepository.insertData(data, fileInfo);
  }

  async readFile(request: ImportParams): Promise<string[]> {
    const positions: string = request.content;

    if (!positions) {
      console.warn('Arquivo SBK sem conteúdo');
      return [];
    }

    const cleanPositions = positions.replace(/\r/g, '');
    return cleanPositions.split('\n');
  }

  removeFiller(data: any, field: any): any {

    if (field.filler === ' ') {
      return data.trim();
    } else {
      const re = new RegExp('^' + field.filler + '+|' + field.filler + '+$', 'g');
      return data.replace(re, '');
    }
  }

  async getCsvFile(data: string): Promise<string[]> {
    const rows = data.toString();
    const lines = rows.replace(/[\r]/g, '');
    const linesArr: string[] = lines.split('\n');
    return linesArr.filter(l => !!l);
  }

  async startImportSegment(fileName: string, fileContent: string): Promise<string> {

    const lines = await this.getCsvFile(fileContent);
    const fileInfo = await this.fileService.parseFilename(fileName);

    const baseDate = new BaseDate();
    baseDate.id = fileInfo.fileDate;
    baseDate.statusInt = 1;

    const baseDateLog = await this.baseDateService.findByDate(fileInfo.fileDate);
    if (!baseDateLog) {
      await this.baseDateService.initDate(fileInfo.fileDate);
    }

    // import file
    const baseDateProduct = new BaseDateProduct();
    baseDateProduct.product = fileInfo.product;
    baseDateProduct.baseDate = fileInfo.fileDate;
    baseDateProduct.fileNumber = fileInfo.id;
    baseDateProduct.statusInt = SystemStatus.NotInitialized;

    const fileImportLog = await this.baseDateProductService.findByPKs(baseDateProduct);
    if (fileImportLog.length !== 0) {
      return 'Arquivo já importado';
    }
    await this.baseDateProductService.create(baseDateProduct);

    baseDate.statusInt = 2;
    // await this.baseDateService.update(baseDate);

    baseDateProduct.statusInt = 2;
    try {
      await this.baseDateProductService.update(baseDateProduct);
      baseDateProduct.statusInt = 4;
      await this.baseDateProductService.update(baseDateProduct);
      await this.importRepository.updateSegment(lines, fileInfo);

    } catch (err) {
      baseDateProduct.statusInt = 3;
      await this.baseDateProductService.update(baseDateProduct);
      baseDate.statusInt = 3;
      // await this.baseDateService.update(baseDate);
      console.error('[ImportService] Erro na importação');
      console.error(err);
      throw err;
    }

    return 'Arquivo importado com sucesso';
  }

}