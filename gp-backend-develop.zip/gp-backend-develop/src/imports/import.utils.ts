import { SystemStatus } from '../shared/constants/status.enum';

export function getFileState(fileDetails: number[]): number {
  if ( fileDetails.every( x => x === 0) ) {
    return SystemStatus.NotInitialized;
  }
  if ( fileDetails.some( x => x === 0) ) {
    return SystemStatus.Contingency;
  }
  if ( fileDetails.every( x => x === SystemStatus.UpTodate) ) {
    return SystemStatus.UpTodate;
  }
  if ( fileDetails.some( x => x === SystemStatus.Error ) ) {
    return SystemStatus.Error;
  }
  if (fileDetails.every( x => x < SystemStatus.Contingency)) {
    return SystemStatus.NotInitialized;
  }

  return SystemStatus.Contingency;
}