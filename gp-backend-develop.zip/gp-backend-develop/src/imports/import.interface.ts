export class ImportParams {
  filename: string;
  headerIdentifier?: string;
  contentIdentifier?: string;
  trailerIdenfier?: string;
  content: string;
}