import { Module } from '@nestjs/common';
import { ImportFileController } from './import.controller';
import { ImportFileService } from './import.service';
import { ImportRepository } from './import.repository';
import { PositionPenumperRepository } from '../position-penumper/position-penumper.repository';

@Module({
  imports: [],
  controllers: [ImportFileController],
  components: [ImportFileService, ImportRepository, PositionPenumperRepository],
  exports: [ImportFileService],
})
export class ImportModule {

}