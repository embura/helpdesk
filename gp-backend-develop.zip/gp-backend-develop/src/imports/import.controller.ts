import {
  Controller, Res, HttpStatus, Post, BadRequestException,
  UseInterceptors, FileInterceptor, UploadedFile, Req
} from '@nestjs/common';
import { Response, Request } from 'express';
import { ImportFileService } from './import.service';
import { HttpResponse } from '../shared/http.response';
import { Status } from '../shared/status.entity';
import { ImportParams } from './import.interface';
import { ServiceErrorHandler } from '../shared/common/common.error';

@Controller('/import')
export class ImportFileController {

  constructor(
    private importFileService: ImportFileService
  ) { }

  @Post()
  @UseInterceptors(FileInterceptor('file'))
  async import(
    @Res() res: Response,
    @UploadedFile() file: any,
    @Req() req: Request): Promise<Response> {

    const body: ImportParams = {
      contentIdentifier: req.body.contentIdentifier,
      headerIdentifier: req.body.headerIdentifier,
      trailerIdenfier: req.body.trailerIdenfier,
      filename: file.originalname,
      content: file.buffer.toString('utf-8'),
    };

    if (!body.filename) {
      throw new BadRequestException(`É necessário informar o parâmetro "filename".`);
    }

    if (typeof body.filename !== 'string') {
      throw new BadRequestException(`O nome do arquivo deve ser do tipo 'string', e conter a data e a extensão '.txt'.`);
    }

    const message = await this.importFileService.processRequest(body);

    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, message), ''));
  }

  @Post('segment')
  @UseInterceptors(FileInterceptor('file'))
  public async importSegment(
    @Res() res: Response,
    @UploadedFile() file: any,
    @Req() req: Request): Promise<Response> {

    const body: ImportParams = {
      contentIdentifier: req.body.contentIdentifier,
      headerIdentifier: req.body.headerIdentifier,
      trailerIdenfier: req.body.trailerIdenfier,
      filename: file.originalname,
      content: file.buffer.toString('utf-8'),
    };

    if (!body.filename) {
      throw new BadRequestException(`É necessário informar o parâmetro "filename".`);
    }

    if (typeof body.filename !== 'string') {
      throw new BadRequestException(`O nome do arquivo deve ser do tipo 'string', e conter a data e a extensão '.csv'.`);
    }
    const message = await this.importFileService.startImportSegment(body.filename, body.content).catch(ServiceErrorHandler);

    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, message), {
        filename: body.filename,
      }));
  }
}