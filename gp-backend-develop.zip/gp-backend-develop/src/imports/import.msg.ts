import { CategoryMessage, IMessage } from '../shared/common/message.model';

export const entityName: IMessage = {
  ptBr: 'Importação',
  system: 'Import',
};

export const ImportTag: IMessage = {
  ptBr: 'Importação',
  system: 'Import',
};

export const ImportMessage = new CategoryMessage(ImportTag, entityName);