import { IMessage, CategoryMessage } from '../shared/common/message.model';

const entityName: IMessage = {
  ptBr: 'Data base de Sistema - Produto',
  system: 'Base date Product',
};

export const BaseDateProductTag: IMessage = {
  ptBr: 'Data base de Sistema - Produto',
  system: 'Base date Product',
};

export const BaseDateProductMessage = new CategoryMessage(BaseDateProductTag, entityName);