
import { Table } from '../shared/decorator/table.annotation';
import { CommonEntity } from '../shared/common/entity';
import { Column } from '../shared/decorator/column.decorator';
import { RowMapper } from '../shared/repository/repository.interface';

@Table('GPOS.TB_DATA_BASE_SIST_PROD')
export class BaseDateProduct extends CommonEntity {

  @Column('SG_SIST_PROD')
  product: string;

  @Column('DT_BASE_SIST')
  baseDate: Date;

  @Column('NR_SEQU_ARQU_ITGR')
  fileNumber: number;

  @Column('CD_SITU_ITGR')
  statusInt: number;

}

export const BaseDateProductRow = Object.freeze({
  product: 'SG_SIST_PROD',
  baseDate: 'DT_BASE_SIST',
  fileNumber: 'NR_SEQU_ARQU_ITGR',
  statusInt: 'CD_SITU_ITGR',
});

export const BaseDateProductTable = 'GPOS.TB_DATA_BASE_SIST_PROD';

export class BaseDateProductRowMapper implements RowMapper<BaseDateProduct> {
	public map(row: any): BaseDateProduct {
    const baseDateProduct = new BaseDateProduct();
    baseDateProduct.product = row[BaseDateProductRow.product];
    baseDateProduct.baseDate = row[BaseDateProductRow.baseDate];
    baseDateProduct.fileNumber = row[BaseDateProductRow.fileNumber];
    baseDateProduct.statusInt = row[BaseDateProductRow.statusInt];
    return baseDateProduct;
	}
}
