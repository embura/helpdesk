
import { Component } from '@nestjs/common';
import { BaseDateProductMessage } from './base-date-product.msg';
import { BaseDateProduct, BaseDateProductRow, BaseDateProductTable, BaseDateProductRowMapper } from './base-date-product.entity';
import { CommonRepositoryService } from '../shared/common/repository.service';
import { CommnRepository } from '../shared/repository/common.repository';
import { BaseDateProductRepository } from './base-date-product.repository';
import { FileService } from '../metadata/file/file.service';

@Component()
export class BaseDateProductService extends CommonRepositoryService<BaseDateProduct>{

  constructor(
    protected readonly baseDateProductRepository: BaseDateProductRepository,
    protected fileService: FileService
  ) {
    super();
    this.messages = BaseDateProductMessage;
    this.repository = new CommnRepository(
      BaseDateProductRow,
      BaseDateProductTable,
      null,
      BaseDateProductMessage,

      new BaseDateProductRowMapper()
    );
  }

  async findByPKs(fileRow: BaseDateProduct): Promise<BaseDateProduct[]> {
    return this.baseDateProductRepository.findByPKs({
      product: fileRow.product,
      baseDate: fileRow.baseDate,
      fileNumber: fileRow.fileNumber,
     } as any);
  }

  async findByDate(date: Date, fileNumber?: number): Promise<BaseDateProduct[]> {
    const fileList: BaseDateProduct[] = await this.baseDateProductRepository.findByDate(date, fileNumber);

    return Promise.all(fileList.map(async (bdp: BaseDateProduct) => {
      bdp.fileName = (await this.fileService.findById(bdp.fileNumber)).name;
      delete bdp.baseDate;
      delete bdp.product;
      return bdp;
    }));
  }

  async update(baseDateProduct: BaseDateProduct): Promise<BaseDateProduct> {
    return this.baseDateProductRepository.update(baseDateProduct);
  }

  async create(baseDateProduct: BaseDateProduct): Promise<BaseDateProduct> {
    return this.baseDateProductRepository.create(baseDateProduct);
  }

}
