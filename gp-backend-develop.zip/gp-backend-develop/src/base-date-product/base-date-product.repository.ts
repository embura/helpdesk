import { CommnRepository } from '../shared/repository/common.repository';
import { oracleErrorHandler } from '../shared/common/common.error';
import { BaseDateProduct, BaseDateProductRow, BaseDateProductTable, BaseDateProductRowMapper } from './base-date-product.entity';
import { BaseDateProductMessage } from './base-date-product.msg';
import { dateToYYYMMMDD } from '../shared/utils/parse-date';
import { SqlHandler } from '../shared/lib/database/query-handler';
import { Component } from '@nestjs/common';

@Component()
export class BaseDateProductRepository extends CommnRepository<BaseDateProduct> {

  protected readonly customHandler: SqlHandler<any>;

  constructor() {
    super(
      BaseDateProductRow,
      BaseDateProductTable,
      null,
      BaseDateProductMessage,
      new BaseDateProductRowMapper()
    );
  }

  public async findByPKs(where: any): Promise<BaseDateProduct[]> {
    const query = `
      SELECT SG_SIST_PROD, DT_BASE_SIST, NR_SEQU_ARQU_ITGR, CD_SITU_ITGR
      FROM GPOS.TB_DATA_BASE_SIST_PROD
      WHERE SG_SIST_PROD = '${where.product}'
      AND DT_BASE_SIST = TO_DATE('${dateToYYYMMMDD(where.baseDate)}', 'YYYYMMDD')
      AND NR_SEQU_ARQU_ITGR = ${where.fileNumber}
    `;

    return await this.queryHandler.execute(query)
        .catch(oracleErrorHandler(this.messages));
  }

  public findByDate(date: Date, fileNumber?: number): Promise<BaseDateProduct[]> {
    let query = `
      SELECT *
      FROM GPOS.TB_DATA_BASE_SIST_PROD
      WHERE DT_BASE_SIST = TO_DATE('${dateToYYYMMMDD(date)}', 'YYYYMMDD')
    `;

    if (fileNumber) {
      query += ` AND NR_SEQU_ARQU_ITGR=${fileNumber}`;
    }

    return this.queryHandler.execute(query)
        .catch(oracleErrorHandler(this.messages));
  }

  public async update(baseDateProduct: BaseDateProduct): Promise<any> {
    const query = `
      UPDATE GPOS.TB_DATA_BASE_SIST_PROD
      SET
      CD_SITU_ITGR = ${baseDateProduct.statusInt}
      WHERE
      SG_SIST_PROD = '${baseDateProduct.product}'
      AND DT_BASE_SIST = TO_DATE('${dateToYYYMMMDD(baseDateProduct.baseDate)}', 'YYYYMMDD')
      AND NR_SEQU_ARQU_ITGR = ${baseDateProduct.fileNumber}
    `;

    return await this.commandHandler.execute(query)
        .catch(oracleErrorHandler(this.messages));
  }

  public async create(baseDateProduct: BaseDateProduct): Promise<any> {
    const query = `
    INSERT
      INTO GPOS.TB_DATA_BASE_SIST_PROD (
        SG_SIST_PROD,
        DT_BASE_SIST,
        CD_SITU_ITGR,
        NR_SEQU_ARQU_ITGR
      )
      VALUES (
        :product,
        TO_DATE('${dateToYYYMMMDD(baseDateProduct.baseDate)}', 'YYYYMMDD'),
        :statusInt,
        :fileNumber
      )
  `;

    const entity = {
      product: baseDateProduct.product,
      statusInt: baseDateProduct.statusInt,
      fileNumber: baseDateProduct.fileNumber,
    } as any;

    const res = await this.commandHandler.execute(query, entity)
      .catch(oracleErrorHandler(this.messages));

    return res;
  }

}
