import { Module } from '@nestjs/common';
import { BaseDateProductService } from './base-date-product.service';
import { BaseDateProductRepository } from './base-date-product.repository';

@Module({
  components: [
    BaseDateProductService,
    BaseDateProductRepository,
  ],
  exports: [BaseDateProductService],
})
export class BaseDateProductModule { }