import 'reflect-metadata';

import {
  Module, Global,
  NestModule,
  MiddlewaresConsumer,
  RequestMethod,
} from '@nestjs/common';

import { AppController } from './app.controller';
import { SharedModule } from './shared/shared.module';
import { HealthCheckController } from './server/health-check/health-check.controller';
import { HealthCheckService } from './server/health-check/health-check.service';
import { LoggerMiddleware } from './server/middleware/logger.middleware';
import { CorsMiddlweare } from './server/middleware/cors.middleware';
import { ImportModule } from './imports/import.module';
import { BaseDateModule } from './base-date/base-date.module';
import { BaseDateProductModule } from './base-date-product/base-date-product.module';
import { FieldModule} from './metadata/field/field.module';
import { FileModule } from './metadata/file/file.module';
import { FieldTypeModule } from './metadata/fieldType/fieldType.module';
import { ExportModule } from './exports/export.module';
import { PositionModule } from './position/position.module';
import { MovimentModule } from './moviment/moviment.module';
import { ProductModule } from './product/product.module';
import { SystemStatusModule } from './system-status/system_status.module';
import { IPOModule } from './ipo/ipo.module';
import { ClientModule } from './client/client-contact.module';
import { SegmentModule } from './segment/segment.module';

@Global()
@Module({
  imports: [
    SegmentModule,
    ClientModule,
    SharedModule,
    FileModule,
    FieldTypeModule,
    FieldModule,
    BaseDateModule,
    ExportModule,
    BaseDateProductModule,
    ImportModule,
    PositionModule,
    MovimentModule,
    ProductModule,
    SystemStatusModule,
    IPOModule,
  ],
  exports: [
    SharedModule,
    BaseDateModule,
    BaseDateProductModule,
    FileModule,
    FieldModule,
    FieldTypeModule,
    ExportModule,
    ImportModule,
    PositionModule,
    MovimentModule,
    ProductModule,
    SystemStatusModule,
    IPOModule,
  ],
  controllers: [AppController, HealthCheckController],
  components: [HealthCheckService],
})
export class ApplicationModule implements NestModule {
  configure(consumer: MiddlewaresConsumer): void {
    consumer.apply([LoggerMiddleware, CorsMiddlweare])
      .forRoutes({ path: '/**', method: RequestMethod.ALL });
  }
}
