import { Controller } from '@nestjs/common';
import { LogLiquiBase } from './log-liquibase.entitty';
import { CommonController } from '../shared/common/common.controller';
import { LogLiquiBaseService } from './log-liquibase.service';
import { LogLiquiBaseMessage } from './log-liquibase.msg';

@Controller('log-liquibase')
export class LogLiquiBaseController extends CommonController<LogLiquiBase> {

  constructor(protected readonly logLiquiBaseService: LogLiquiBaseService) {
    super(logLiquiBaseService, LogLiquiBaseMessage);
  }
}
