
import { Component } from '@nestjs/common';
import { CommonRepositoryService } from '../shared/common/repository.service';
import { CommnRepository } from '../shared/repository/common.repository';
import { LogLiquiBase, LogLiquiBaseRow, LogLiquiBaseTableName, LogLiquiBaseRowMapper } from './log-liquibase.entitty';
import { LogLiquiBaseMessage } from './log-liquibase.msg';
import { queryStringToWhere, IQuery } from '../shared/common/query.interface';
import { Order } from '../shared/repository/repository.interface';

@Component()
export class LogLiquiBaseService extends CommonRepositoryService<LogLiquiBase>{
  constructor() {
    super();
    this.messages = LogLiquiBaseMessage;
    this.repository = new CommnRepository<LogLiquiBase>(
      LogLiquiBaseRow,
      LogLiquiBaseTableName,
      null,
      LogLiquiBaseMessage,
      new LogLiquiBaseRowMapper()
    );
  }

  async findAll(param: IQuery): Promise<LogLiquiBase[]> {
    const where = queryStringToWhere(param);
    if (!where.order) {
      where.order = [['id', Order.ASC]];
    }
    return await this.repository.findAll(where);
  }

}
