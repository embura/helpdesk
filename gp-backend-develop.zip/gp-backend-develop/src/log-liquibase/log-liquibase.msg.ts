import { CategoryMessage, IMessage } from '../shared/common/message.model';

export const entityName: IMessage = {
  ptBr: 'Log do Liqui Base',
  system: 'LogLiquiBase',
};

export const LogLiquiBaseTag: IMessage = {
  ptBr : 'Log do Liqui Base',
  system : 'LogLiquiBase',
};

export const LogLiquiBaseMessage = new CategoryMessage(LogLiquiBaseTag, entityName);