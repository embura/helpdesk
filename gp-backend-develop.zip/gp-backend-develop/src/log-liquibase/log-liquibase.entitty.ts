import { CommonEntity } from '../shared/common/entity';

import { Column } from '../shared/decorator/column.decorator';
import { RowMapper } from '../shared/repository/repository.interface';
import { Table } from '../shared/decorator/table.annotation';

export const LogLiquiBaseTableName = 'GPOS.TB_LOG_LIQB';
export const LogLiquiBaseRow = Object.freeze({
  id: 'NR_SEQU_LOG_LIQB',
  command: 'TX_COMD_SQL',
  typeResult: 'TX_RESL_EXEC',
  result: 'TX_SITU_LOG',
  dateTime: 'DH_EXEC_COMD',
});

@Table(LogLiquiBaseTableName)
export class LogLiquiBase extends CommonEntity {

  @Column(LogLiquiBaseRow.id)
  id: number;

  @Column(LogLiquiBaseRow.command)
  command: string;

  @Column(LogLiquiBaseRow.typeResult)
  typeResult: string;

  @Column(LogLiquiBaseRow.result)
  descresultription: string;

  @Column(LogLiquiBaseRow.dateTime)
  dateTime: string;

}

export class LogLiquiBaseRowMapper implements RowMapper<LogLiquiBase> {
  public map(row: any): LogLiquiBase {
    const rowMapper = new LogLiquiBase();
    Object.keys(LogLiquiBaseRow).forEach((key: string) => {
      rowMapper[key] = row[(LogLiquiBaseRow as any)[key]];
    });
    return rowMapper;
  }
}
