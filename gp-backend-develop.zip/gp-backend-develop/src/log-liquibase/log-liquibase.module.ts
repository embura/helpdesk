import { Module } from '@nestjs/common';
import { LogLiquiBaseService } from './log-liquibase.service';
import { LogLiquiBaseController } from './log-liquibase.controller';

@Module({
  components: [LogLiquiBaseService],
  controllers: [LogLiquiBaseController],
  exports: [LogLiquiBaseService],
})

export class LogLiquiBaseModule { }
