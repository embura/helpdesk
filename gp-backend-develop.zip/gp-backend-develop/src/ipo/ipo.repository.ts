import { CommnRepository } from '../shared/repository/common.repository';
import { Component } from '@nestjs/common';
import { IPOMessage } from './ipo.msg';
import { IPOReserveRow, IPOTable, IPORowMapper, IPOReserve, IPOSequence } from './domain/ipo-reserve.entity';
import { oracleErrorHandler } from '../shared/common/common.error';

@Component()
export class IPORepository extends CommnRepository<IPOReserve> {

  constructor(  ) {
    super(
      IPOReserveRow,
      IPOTable,
      IPOSequence,
      IPOMessage,
      new IPORowMapper()
    );
  }

  async customUpdate(obj: IPOReserve): Promise<IPOReserve> {

    const persisted = await this.findOne({where: {contractCode: obj.contractCode}});
    persisted.updateParams(obj);

    this.sanitalizer.sanitalize(obj);

    const queryString = this.parseUpdate(obj);
    const query = `UPDATE ${queryString}`;
    await this.commandHandler.execute(query, obj)
        .catch(oracleErrorHandler(this.messages));

    return this.findOne({where: {contractCode: obj.contractCode}});
  }

  protected parseUpdate(entity: IPOReserve): string {
    let set = 'SET ';

    // tslint:disable-next-line:forin
    for (const k in entity) {
      if (k === 'contractCode' || !this.TableRows[k]) continue;
      set += `${this.TableRows[k]} = :${k}, `;
    }
    set = set.slice(0, -2);

    return `${this.TableName} ${set} WHERE ${this.TableRows.contractCode} = :contractCode`;
  }

}
