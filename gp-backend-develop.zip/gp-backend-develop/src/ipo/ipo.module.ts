import { Module } from '@nestjs/common';
import { IPOService } from './ipo.service';
import { IPORepository } from './ipo.repository';
import { IPOController } from './ipo.controller';
import {IPOCsvRepository } from './ipo-csv.repository';

const servicesToExport = [
  IPORepository,
  IPOService,
  IPOCsvRepository,
];

@Module({
  controllers: [
    IPOController,
  ],
  components: [
    ...servicesToExport,
  ],
  exports: [
    ...servicesToExport,
  ],
})
export class IPOModule {}
