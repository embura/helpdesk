import { CategoryMessage, IMessage } from '../shared/common/message.model';

export const IPOName: IMessage = {
  ptBr: 'Emissão Primaria',
  system: 'IPO',
};

export const IPOTag: IMessage = {
  ptBr: 'Emissão Primaria',
  system: 'IPO',
};

export const IPOMessage = new CategoryMessage(IPOTag, IPOName);
