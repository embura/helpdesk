import { IChannelBus } from './domain/ipo-reserve.model';
import { IPOCsv, IPOCsvTable, IPOCsvRow, IPOCsvRowMapper, IPOCsvSequence } from './domain/ipo-csv.entity';
import { CommnRepository } from '../shared/repository/common.repository';
import { Component } from '@nestjs/common';
import { IPOMessage } from './ipo.msg';
import { oracleErrorHandler } from '../shared/common/common.error';
import { BUS_API } from './../shared/constants/endpoints';
// tslint:disable-next-line:no-var-requires
const Client = require('node-rest-client').Client;

@Component()
export class IPOCsvRepository extends CommnRepository<IPOCsv> {
  client = new Client({
    connection: {
      rejectUnauthorized: false,
    },
  });
  readonly clientHeader = {
    headers: { 'Content-Type': 'application/json' },
  };

  constructor() {
    super(
      IPOCsvRow,
      IPOCsvTable,
      IPOCsvSequence,
      IPOMessage,
      new IPOCsvRowMapper()
    );
  }
  async customGetCSV(productId: string): Promise<any> {
    const query = `
    SELECT
    VL_UNIT_ACAO,
    QT_ACAO_NEGO,
    PC_TAXA_RESE_DESJ,
    NM_VEDR,
    CD_PESS_SOLI_RESE,
    CD_AGEN_CLIE,
    NR_CNTA_CLIE,
    IN_DEBT_COND_SALD,
    NR_DOCT_CLIE,
    CD_GLOB_CNTR,
    CD_PROD,
    TP_RENT_MINI_SOLI,
    CD_CNAL_RESE,
    CD_SITU_ITGR,
    DH_CRIA_RESE_SOLI_CPRA,
    DH_ALTR_RESE_SOLI_CPRA,
    NM_CLIE_SOLI_RESE,
    IN_PESS_VINC,
    CD_SEGM_CLIE,
    TP_PESS_CLIE,
    NR_MATR_VEDR,
    NM_CMRT,
    NR_MATR_CMRT,
    NM_EMAIL_CLIE,
    NR_TELF_CLIE,
    TP_FORZ_CPRA
    FROM GPOS.TB_RESE_EMIS_PRIM
    WHERE CD_PROD = ${productId}
    `;

    return await this.queryHandler.execute(query)
      .catch(oracleErrorHandler(this.messages));
  }

  public async channelBus(): Promise<IChannelBus[]> {
    return new Promise<IChannelBus[]>((resolve, reject) => {
      const endPoint = `${BUS_API}bus-monit/shared/channel/list`;
      console.info('[GPC] getChannelMapper endPoint: ', endPoint);

      this.client.get(endPoint, this.clientHeader, (data: { data: IChannelBus[] }) => {
        console.info('[GPC] getChannelMapper: ', data);
        resolve(data.data);
      }).on('error', (e: any) => {
        console.error('[GPC] getChannelMapper Err: ', e);
        reject(e);
      });
    });
  }

}
