import { CatalogRepository } from './../shared/repository/catalog/catalog.repository';
import { IPOCsvRepository } from './ipo-csv.repository';
import { ServiceErrorHandler } from '../shared/common/common.error';
import { CommonRepositoryService } from '../shared/common/repository.service';
import { IPOReserveModel, IReservePrimaryCsv, IChannelBus } from './domain/ipo-reserve.model';
import { Component, BadRequestException } from '@nestjs/common';
import { SystemStatus } from '../shared/constants/status.enum';
import { IPOReserve } from './domain/ipo-reserve.entity';
import { IPOMessage } from './ipo.msg';
import { Order } from '../shared/repository/repository.interface';
import { IQuery, queryStringToWhere } from '../shared/common/query.interface';
import { IPORepository } from './ipo.repository';
import { ConfirmType } from './domain/confirm.type';

@Component()
export class IPOService extends CommonRepositoryService<IPOReserve> {

  constructor(
    public readonly ipoRepository: IPORepository,
    public readonly ipoCsvRepository: IPOCsvRepository,
    public readonly catalogRepository: CatalogRepository
  ) {
    super();
    this.repository = ipoRepository as any;
    this.messages = IPOMessage;
    this.defaultOrder = ['createAt', Order.DESC];
  }

  async reserve(data: IPOReserveModel): Promise<IPOReserveModel> {
    const hasEntity = await this.ipoRepository.findAll({ where: { contractCode: data.contractCode } });
    if (hasEntity.length > 0) {
      throw new BadRequestException(IPOMessage.error.duplicatedCode);
    }

    const newReserve = IPOReserveModel.toEntity(data);
    if (data.confirmType === ConfirmType.paper) {
      newReserve.statusId = SystemStatus.Completed;
    }
    const id = await this.ipoRepository.create(newReserve);

    const saved = await this.ipoRepository.findOne({ where: { id } });

    return IPOReserveModel.fromEntity(saved);
  }

  async confirmContract(contractCode: string): Promise<IPOReserveModel> {
    const reserve = await this.ipoRepository.findOne({ where: { contractCode } });
    if (!reserve) {
      throw new BadRequestException(IPOMessage.error.notFound);
    }
    if (reserve.statusId === SystemStatus.Cancelled) {
      return IPOReserveModel.fromEntity(reserve);
    }
    reserve.statusId = SystemStatus.Completed;
    reserve.updateAt = new Date();
    await this.ipoRepository.customUpdate(reserve);

    return IPOReserveModel.fromEntity(reserve);
  }

  async cancelReservation(contractCode: string): Promise<string> {
    const contract = await this.ipoRepository.findOne({ where: { contractCode } });
    if (!contract) {
      throw new BadRequestException(IPOMessage.error.notFound);
    }
    if (contract.statusId !== SystemStatus.Cancelled) {
      contract.statusId = SystemStatus.Cancelled;
      contract.updateAt = new Date();
      await this.ipoRepository.customUpdate(contract)
        .catch(ServiceErrorHandler);
    }
    return 'success';
  }

  async findAllWithContacts(param: IQuery, maxRows = 10000): Promise<IPOReserveModel[]> {
    const where = queryStringToWhere(param);
    if (!where.order) {
      where.order = [['createAt', Order.DESC]];
    }
    const reserves = await this.ipoRepository.findAll(where, maxRows);
    const reserveModels =
      reserves.map(r => IPOReserveModel.fromEntity(r));

    return reserveModels;
  }
  async getChannel(channelCode: string, jsonChannel: Promise<IChannelBus[]>): Promise<string> {
    const code = Number(channelCode);
    let name = channelCode;
    await jsonChannel.then(element => {
      for (const el of element) {
        if (el.code === code) {
          name = el.name;
        }
      }
    });
    return name;
  }

  async getCsv(param: IQuery): Promise<IReservePrimaryCsv[]> {
    const csvReservePrimary: IReservePrimaryCsv[] = [];
    let groupName: string;
    let codProduct: string;
    const productId = param.productId;
    const jsonCpt = this.catalogRepository.getMappedProductsReservePrimary(productId);
    const jsonGpos = this.ipoCsvRepository.customGetCSV(productId);
    const jsonChannel = this.ipoCsvRepository.channelBus();

    await jsonCpt.then(element => {
      for (const el of element) {
        groupName = el.modalityName;
        codProduct = el['CD-SUBP'];
      }
    }).catch((err) => ServiceErrorHandler);

    await jsonGpos.then(async element => {
      for (const el of element) {
        const channel = await this.getChannel(el.channelCode, jsonChannel);
        csvReservePrimary.push({
          'PENUMPER': el.penumper,
          'CPF/CNPJ': el.document,
          'FAMÍLIA': groupName,
          'CÓDIGO': codProduct,
          'QUANTIDADE': el.quantity,
          'PU': el.pu,
          'TAXA': this.typeRate(el.rate, el.rentabilityType),
          'AGÊNCIA': el.agency,
          'CONTA': el.account,
          'BOLETA PBSYS': 'A00000000',
          'CARTEIRA': '0000000',
          'CONDICIONAL': (el.conditional === 'Y') ? 'S' : 'N',
          'SALES': el.sales,
          'GLOBAL ID': el.globalId,
          'ID': el.prodoctId,
          'TIPO DE RENTABILIDADE': el.rentabilityType,
          'CÓDIGO DO CANAL': channel,
          'STATUS': this.statusName(el.statusCode),
          'DATA CRIADO': el.createDate,
          'DATA ATUALIZADO': el.updateDate,
          'NOME CLIENTE': el.clientName,
          'PESSOA VINCULADA': el.isPersonaVinc,
          'SEGMENTO CLIENTE': el.clientSegment,
          'TIPO DOC': el.clientType,
          'CÓDIGO SALES': el.selesCode,
          'TRADER': el.traderName,
          'CÓDIGO TRADER': el.traderCode,
          'EMAIL': el.email,
          'TELEFONE': el.tel,
          'TIPO FORMALIZAÇÃO': el.formalizationType,
        });
      }
    }).catch((err) => ServiceErrorHandler);

    return csvReservePrimary;
  }

  public typeRate(rate: string, typeRate: string): any {
    if (typeRate === 'M') {
      return 'A mercado';
    } else {
      return rate.toString();
    }
  }
  public statusName(statusCode: number): any {
    switch (statusCode) {
      case (20):
        return 'Formalizado';
      case (21):
        return 'Pedente';
      case (22):
        return 'Cancelado';
      default:
        return 'Código não encontrado';
    }
  }
}
