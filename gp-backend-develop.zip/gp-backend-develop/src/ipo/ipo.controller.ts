import { Controller, Post, Body, Delete, UsePipes, Param, Query, Get, Put } from '@nestjs/common';
import { HttpResponse } from '../shared/http.response';
import { Status } from '../shared/status.entity';
import { IPOService } from './ipo.service';
import { IPOReserveModel } from './domain/ipo-reserve.model';
import { SchemaValidationPipe } from '../shared/pipe/validation.pipe';
import { IQuery } from '../shared/common/query.interface';
import { ServiceErrorHandler } from '../shared/common/common.error';
import * as json2csv from 'json2csv';
import { SystemStatus } from '../shared/constants/status.enum';

@Controller('ipo')
export class IPOController {

  private msgSucess = 'Reservado com sucesso.';
  constructor(
    private readonly ipoService: IPOService
  ) { }

  @Get()
  async findAll( @Query() query: IQuery): Promise<HttpResponse> {
    const reserveds = await this.ipoService.findAllWithContacts(query)
      .catch(ServiceErrorHandler);

    return new HttpResponse(new Status(0, this.msgSucess), reserveds);
  }

  @Get('csv')
  async findAllCSV( @Query() query: IQuery): Promise<any> {
    const csvJson = await this.ipoService.getCsv(query);
    const parser = new json2csv.Parser();
    return parser.parse(csvJson);
  }

  @Post('reserve')
  @UsePipes(new SchemaValidationPipe())
  public async reserve( @Body() newReserve: IPOReserveModel): Promise<HttpResponse> {
    const reserved = await this.ipoService.reserve(newReserve);

    return new HttpResponse(new Status(0, this.msgSucess), reserved);
  }

  @Put('reserve/:id/confirmation')
  public async confirmContract( @Param('id') contractId: string
    ): Promise<HttpResponse> {
    const reserve = await this.ipoService.confirmContract(contractId);

    if (reserve.status.id === SystemStatus.Cancelled) {
      this.msgSucess = 'Não é possível realizar a formalização, a operação foi cancelada.';
    }

    return new HttpResponse(new Status(0, this.msgSucess), reserve);
  }

  @Delete('reserve/:id')
  public async cancel( @Param('id') contractId: string): Promise<HttpResponse> {
    const response = await this.ipoService.cancelReservation(contractId);

    return new HttpResponse(new Status(0, this.msgSucess), response);
  }

}