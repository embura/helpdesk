import { IPOReserve } from './ipo-reserve.entity';
import { IsString, IsNumber, IsNotEmpty, IsBoolean, ValidateNested, IsEnum, Length } from 'class-validator';
import { ConfirmType, ConfirmTypeCode } from './confirm.type';
import { ClientType, ClientTypeCode } from './client.type';
import { Type, plainToClass, } from 'class-transformer';
import { enumValidationMsgBuilder } from '../../shared/builder/validation-message.builder';
import { ClientModel } from './client.model';
import { StaffModel } from './staff.model';
import { ReturnRateModel } from './return-rate.model';
import { codeToEnum } from '../../shared/utils/code-to-enum';
import { toBoolString, fromBoolString } from '../../shared/utils/bool-to-yes-no';
import { SystemStatus, StatusModel, SystemStatusCode } from '../../shared/constants/status.enum';
import { ReturnRateTypeCode } from './return-rate.type';

export class LiquidationAccountModel {
  @IsString() @Length(4) @IsNotEmpty()
  agency: string;
  @IsString() @IsNotEmpty()
  code: string;
  @IsBoolean() @IsNotEmpty()
  isDebitConditional: boolean;
}

export class IPOReserveModel {
  // response only
  status?: StatusModel;
  createAt?: Date;
  updateAt?: Date;

  // response and request
  @IsString() @IsNotEmpty()
  contractCode: string;
  @IsNumber() @IsNotEmpty()
  productId: number;
  @IsNumber() @IsNotEmpty()
  unitValue: number;
  @IsNumber() @IsNotEmpty()
  quantity: number;
  @IsEnum(ConfirmType, enumValidationMsgBuilder(ConfirmType)) @IsNotEmpty()
  confirmType: ConfirmType;
  @IsString() @IsNotEmpty()
  channelCode: string;

  @ValidateNested() @IsNotEmpty() @Type(() => ReturnRateModel)
  returnRate: ReturnRateModel;

  @ValidateNested() @IsNotEmpty() @Type(() => ClientModel)
  client: ClientModel;

  @ValidateNested() @IsNotEmpty() @Type(() => StaffModel)
  seller: StaffModel;

  @ValidateNested() @IsNotEmpty() @Type(() => StaffModel)
  trader: StaffModel;

  static toEntity(_data: IPOReserveModel): IPOReserve {
    const data = Object.assign({}, _data);

    let reserve = new IPOReserve();
    reserve.returnRateType = ReturnRateTypeCode[data.returnRate.type];
    reserve.returnRateRequest = data.returnRate.request;
    reserve.statusId = SystemStatus.Pending;
    reserve.confirmType = ConfirmTypeCode[data.confirmType];
    reserve.sellerCode = data.seller.code;
    reserve.sellerName = data.seller.name;
    reserve.traderCode = data.trader.code;
    reserve.traderName = data.trader.name;
    delete data.confirmType;
    delete data.seller;
    delete data.returnRate;
    delete data.trader;

    reserve.clientName = data.client.name;
    reserve.clientPenumper = data.client.penumper;
    reserve.clientIsInsider = toBoolString(data.client.isInsider);
    reserve.clientSegmentCode = data.client.segmentCode;
    reserve.clientType = ClientTypeCode[data.client.type];
    reserve.clientDocumentNumber = data.client.documentNumber;
    reserve.clientAccountAgency = +data.client.account.agency;
    reserve.clientAccountNumber = data.client.account.code;
    reserve.clientAccountIsDebitCond = toBoolString(data.client.account.isDebitConditional);
    reserve.clientContactEmail = data.client.contact.email;
    reserve.clientContactTel = data.client.contact.telephone;
    delete data.client;

    reserve = Object.assign(reserve, data);
    reserve.createAt = new Date();
    reserve.updateAt = new Date();

    return reserve;
  }

  static fromEntity(entity: IPOReserve): IPOReserveModel {

    const reserveInfo: IPOReserveModel = {
      contractCode: entity.contractCode,
      productId: entity.productId,
      unitValue: entity.unitValue,
      quantity: entity.quantity,
      status: {
        id: entity.statusId,
        desc: SystemStatusCode[entity.statusId],
      },
      seller: {
        code: entity.sellerCode,
        name: entity.sellerName,
      },
      trader: {
        code: entity.traderCode,
        name: entity.traderName,
      },
      returnRate: {
        type: entity.returnRateType as any,
        request: entity.returnRateRequest,
      },
      confirmType: codeToEnum(ConfirmTypeCode, entity.confirmType),
      channelCode: entity.ChannelCode,

      client: {
        penumper: entity.clientPenumper,
        name: entity.clientName,
        isInsider: fromBoolString(entity.clientIsInsider),
        segmentCode: entity.clientSegmentCode,
        type: entity.clientType === 'F' ? ClientType.fisic : ClientType.juridic,
        documentNumber: entity.clientDocumentNumber,
        account: {
          agency: entity.clientAccountAgency.toString().padStart(4, '0'),
          code: entity.clientAccountNumber,
          isDebitConditional: fromBoolString(entity.clientAccountIsDebitCond),
        },
        contact: {
          email: entity.clientContactEmail,
          telephone: entity.clientContactTel,
        },
      },
      createAt: entity.createAt,
      updateAt: entity.updateAt,
    };

    return plainToClass(IPOReserveModel, reserveInfo);
  }

}
export interface IReservePrimaryCsv {
  'PU': number;
  'QUANTIDADE': string;
  'TAXA': number;
  'SALES': string;
  'PENUMPER': string;
  'AGÊNCIA': number;
  'CONTA': string;
  'CONDICIONAL': string;
  'CPF/CNPJ': number;
  'FAMÍLIA': string;
  'CÓDIGO': string;
  'BOLETA PBSYS': string;
  'CARTEIRA': string;
  'GLOBAL ID': string;
  'ID': string;
  'TIPO DE RENTABILIDADE': string;
  'CÓDIGO DO CANAL': any;
  'STATUS': string;
  'DATA CRIADO': string;
  'DATA ATUALIZADO': string;
  'NOME CLIENTE': string;
  'PESSOA VINCULADA': string;
  'SEGMENTO CLIENTE': string;
  'TIPO DOC': string;
  'CÓDIGO SALES': string;
  'TRADER': string;
  'CÓDIGO TRADER': string;
  'EMAIL': string;
  'TELEFONE': string;
  'TIPO FORMALIZAÇÃO': string;
}
export interface IChannelBus {
  sequence: number;
  code: number;
  name: string;
  acronym: string;
}