export enum ClientType {
  fisic = 'F',
  juridic = 'J',
}

export const ClientTypeCode = Object.freeze<{ [key in ClientType ]: string }>({
  [ClientType.fisic]: 'F',
  [ClientType.juridic]: 'J',
});