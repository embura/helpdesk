import { IsString, IsNotEmpty } from 'class-validator';
import { ReserveStatusType } from './reserve-status.type';

export class ReserveStatusModel {
  @IsString()@IsNotEmpty()
  code: ReserveStatusType;
  desc: string;
}
