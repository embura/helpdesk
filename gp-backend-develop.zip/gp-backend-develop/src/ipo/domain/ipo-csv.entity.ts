
import { RowMapper } from '../../shared/repository/repository.interface';
import { CommonEntity } from '../../shared/common/entity';
import { Column } from '../../shared/decorator/column.decorator';
import { Table } from '../../shared/decorator/table.annotation';
// import { BooleanString } from '../../shared/utils/bool-to-yes-no';
// import { SystemStatus } from '../../shared/constants/status.enum';

export const IPOCsvRow = Object.freeze({
  pu: 'VL_UNIT_ACAO',
  quantity: 'QT_ACAO_NEGO',
  rate: 'PC_TAXA_RESE_DESJ',
  sales: 'NM_VEDR',
  penumper: 'CD_PESS_SOLI_RESE',
  agency: 'CD_AGEN_CLIE',
  account: 'NR_CNTA_CLIE',
  conditional: 'IN_DEBT_COND_SALD',
  document: 'NR_DOCT_CLIE',
  globalId: 'CD_GLOB_CNTR',
  productId: 'CD_PROD',
  rentabilityType: 'TP_RENT_MINI_SOLI',
  channelCode: 'CD_CNAL_RESE',
  statusCode: 'CD_SITU_ITGR',
  createDate: 'DH_CRIA_RESE_SOLI_CPRA',
  updateDate: 'DH_ALTR_RESE_SOLI_CPRA',
  clientName: 'NM_CLIE_SOLI_RESE',
  isPersonaVinc: 'IN_PESS_VINC',
  clientSegment: 'CD_SEGM_CLIE',
  clientType: 'TP_PESS_CLIE',
  selesCode: 'NR_MATR_VEDR',
  traderName: 'NM_CMRT',
  traderCode: 'NR_MATR_CMRT',
  email: 'NM_EMAIL_CLIE',
  tel: 'NR_TELF_CLIE',
  formalizationType: 'TP_FORZ_CPRA',

});
export const IPOCsvTable = 'GPOS.TB_RESE_EMIS_PRIM';
export const IPOCsvSequence = 'GPOS.SQ_RESE_EMIS_PRIM.NEXTVAL';

@Table(IPOCsvTable)
export class IPOCsv extends CommonEntity {

  @Column(IPOCsvRow.pu)
  pu: string;

  @Column(IPOCsvRow.quantity)
  quantity: string;

  @Column(IPOCsvRow.rate)
  rate: string;

  @Column(IPOCsvRow.sales)
  sales: string;

  @Column(IPOCsvRow.penumper)
  penumper: string;

  @Column(IPOCsvRow.agency)
  agency: string;

  @Column(IPOCsvRow.account)
  account: string;

  @Column(IPOCsvRow.conditional)
  conditional: string;

  @Column(IPOCsvRow.document)
  document: string;

  @Column(IPOCsvRow.globalId)
  globalId: string;

  @Column(IPOCsvRow.productId)
  productId: string;

  @Column(IPOCsvRow.rentabilityType)
  rentabilityType: string;

  @Column(IPOCsvRow.channelCode)
  channelCode: string;

  @Column(IPOCsvRow.statusCode)
  statusCode: number;

  @Column(IPOCsvRow.createDate)
  createDate: string;

  @Column(IPOCsvRow.updateDate)
  updateDate: string;

  @Column(IPOCsvRow.clientName)
  clientName: string;

  @Column(IPOCsvRow.isPersonaVinc)
  isPersonaVinc: string;

  @Column(IPOCsvRow.clientSegment)
  clientSegment: string;

  @Column(IPOCsvRow.clientType)
  clientType: string;

  @Column(IPOCsvRow.selesCode)
  selesCode: string;

  @Column(IPOCsvRow.traderName)
  traderName: string;

  @Column(IPOCsvRow.traderCode)
  traderCode: string;

  @Column(IPOCsvRow.email)
  email: string;

  @Column(IPOCsvRow.tel)
  tel: string;

  @Column(IPOCsvRow.formalizationType)
  formalizationType: string;
}

export class IPOCsvRowMapper implements RowMapper<IPOCsv> {
  public map(row: any): IPOCsv {
    const reserve = new IPOCsv();
    const keys = Object.keys(IPOCsvRow);

    for ( const k of keys) {
      reserve[k] = row[ (IPOCsvRow as any)[k] ];
    }

    return reserve;
  }
}