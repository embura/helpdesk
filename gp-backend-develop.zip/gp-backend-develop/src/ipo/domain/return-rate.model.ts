import { IsNotEmpty, IsEnum, IsNumber } from 'class-validator';
import { enumValidationMsgBuilder } from '../../shared/builder/validation-message.builder';
import { ReturnRateType } from './return-rate.type';

export class ReturnRateModel {
  @IsEnum(ReturnRateType, enumValidationMsgBuilder(ReturnRateType))@IsNotEmpty()
  type: ReturnRateType;
  @IsNumber()@IsNotEmpty()
  request: number;
}
