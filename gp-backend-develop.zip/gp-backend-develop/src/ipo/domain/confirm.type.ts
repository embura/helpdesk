export enum ConfirmType {
  telephone = 'telephone',
  telephonePDI = 'QUZ',
  mobile = 'mobile',
  mobilePDI = 'SID',
  mobileDirect = 'MBB',
  paper = 'paper',
  paperPDI = 'FOR',
  biometry = 'BIO',
  pinCode = 'PIN',
}

export const ConfirmTypeCode = Object.freeze<{ [key in ConfirmType ]: string }>({
  [ConfirmType.telephone]: 'T',
  [ConfirmType.telephonePDI]: 'T',
  [ConfirmType.mobile]: 'M',
  [ConfirmType.mobilePDI]: 'M',
  [ConfirmType.mobileDirect]: 'MD',
  [ConfirmType.paper]: 'G',
  [ConfirmType.paperPDI]: 'G',
  [ConfirmType.biometry]: 'BIO',
  [ConfirmType.pinCode]: 'PIN',
});
