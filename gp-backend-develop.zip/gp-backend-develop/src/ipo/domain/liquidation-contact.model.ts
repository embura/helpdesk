import { IsString, IsNotEmpty, IsNumber } from 'class-validator';

export class LiquidationContactModel {
  @IsString()@IsNotEmpty()
  email: string;
  @IsNumber()@IsNotEmpty()
  telephone: number;
}