export enum ReturnRateType {
  market = 'market',
  select = 'select',
}

export const ReturnRateTypeCode = Object.freeze<{ [key in ReturnRateType ]: string }>({
  [ReturnRateType.market]: 'M',
  [ReturnRateType.select]: 'S',
});