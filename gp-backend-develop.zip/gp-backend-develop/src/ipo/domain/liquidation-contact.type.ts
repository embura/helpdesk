export enum LiquidationContactType {
  email = 'email',
  telephone = 'telephone',
}

export const ContactTypeCode = Object.freeze<{ [key in LiquidationContactType ]: string }>({
  [LiquidationContactType.email]: 'E',
  [LiquidationContactType.telephone]: 'T',
});