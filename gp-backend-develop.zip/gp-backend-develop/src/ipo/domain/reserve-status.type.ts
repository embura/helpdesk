export enum ReserveStatusType {
  formalized = 'formalized',
  pending = 'pending',
  canceled = 'canceled',
}

export const ClientTypeCode = Object.freeze<{ [key in ReserveStatusType ]: number }>({
  [ReserveStatusType.formalized]: 20,
  [ReserveStatusType.pending]: 21,
  [ReserveStatusType.canceled]: 22,
});