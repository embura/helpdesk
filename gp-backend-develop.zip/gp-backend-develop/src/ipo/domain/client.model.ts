import { IsString, IsNotEmpty, IsBoolean, IsEnum, ValidateNested } from 'class-validator';
import { ClientType } from './client.type';
import { enumValidationMsgBuilder } from '../../shared/builder/validation-message.builder';
import { Type } from 'class-transformer';
import { LiquidationAccountModel } from './ipo-reserve.model';
import { LiquidationContactModel } from './liquidation-contact.model';

export class ClientModel {
  @IsString()@IsNotEmpty()
  name: string;
  @IsString()@IsNotEmpty()
  penumper: string;
  @IsBoolean()@IsNotEmpty()
  isInsider: boolean;
  @IsString()@IsNotEmpty()
  segmentCode: string;
  @IsEnum(ClientType, enumValidationMsgBuilder(ClientType))@IsNotEmpty()
  type: ClientType;
  @IsString()@IsNotEmpty()
  documentNumber: string; // CPF ou CNPJ

  @ValidateNested()@IsNotEmpty()@Type(() => LiquidationAccountModel)
  account: LiquidationAccountModel;

  @ValidateNested()@IsNotEmpty()@Type(() => LiquidationContactModel)
  contact: LiquidationContactModel;
}
