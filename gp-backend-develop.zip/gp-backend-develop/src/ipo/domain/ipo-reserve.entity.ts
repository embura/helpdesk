
import { RowMapper } from '../../shared/repository/repository.interface';
import { CommonEntity } from '../../shared/common/entity';
import { Column } from '../../shared/decorator/column.decorator';
import { Table } from '../../shared/decorator/table.annotation';
import { BooleanString } from '../../shared/utils/bool-to-yes-no';
import { SystemStatus } from '../../shared/constants/status.enum';

export const IPOReserveRow = Object.freeze({
  id: 'NR_SEQU_RESE_EMIS_PRIM',
  contractCode: 'CD_GLOB_CNTR',
  productId: 'CD_PROD',
  unitValue: 'VL_UNIT_ACAO',
  quantity: 'QT_ACAO_NEGO',
  returnRateType: 'TP_RENT_MINI_SOLI',
  returnRateRequest: 'PC_TAXA_RESE_DESJ',
  confirmType: 'TP_FORZ_CPRA',
  channelCode: 'CD_CNAL_RESE',
  statusId: 'CD_SITU_ITGR',
  sellerCode: 'NR_MATR_VEDR',
  sellerName: 'NM_VEDR',
  traderCode: 'NR_MATR_CMRT',
  traderName: 'NM_CMRT',
  createAt: 'DH_CRIA_RESE_SOLI_CPRA',
  updateAt: 'DH_ALTR_RESE_SOLI_CPRA',

  // // client
  clientName: 'NM_CLIE_SOLI_RESE',
  clientPenumper: 'CD_PESS_SOLI_RESE',
  clientIsInsider: 'IN_PESS_VINC',
  clientSegmentCode: 'CD_SEGM_CLIE',
  clientType: 'TP_PESS_CLIE',
  clientAccountAgency: 'CD_AGEN_CLIE',
  clientAccountNumber: 'NR_CNTA_CLIE',
  clientAccountIsDebitCond: 'IN_DEBT_COND_SALD',
  clientDocumentNumber: 'NR_DOCT_CLIE',
  clientContactEmail: 'NM_EMAIL_CLIE',
  clientContactTel: 'NR_TELF_CLIE',
});
export const IPOTable = 'GPOS.TB_RESE_EMIS_PRIM';
export const IPOSequence = 'GPOS.SQ_RESE_EMIS_PRIM.NEXTVAL';

@Table(IPOTable)
export class IPOReserve extends CommonEntity {

  @Column(IPOReserveRow.id)
  id?: number;

  @Column(IPOReserveRow.contractCode)
  contractCode: string;

  @Column(IPOReserveRow.productId)
  productId: number;

  @Column(IPOReserveRow.unitValue)
  unitValue: number;

  @Column(IPOReserveRow.quantity)
  quantity: number;

  @Column(IPOReserveRow.returnRateType)
  returnRateType: string;

  @Column(IPOReserveRow.returnRateRequest)
  returnRateRequest: number;

  @Column(IPOReserveRow.confirmType)
  confirmType: string;

  @Column(IPOReserveRow.channelCode)
  ChannelCode: string;

  @Column(IPOReserveRow.statusId)
  statusId: SystemStatus;

  @Column(IPOReserveRow.sellerCode)
  sellerCode: string;

  @Column(IPOReserveRow.sellerName)
  sellerName: string;

  @Column(IPOReserveRow.traderCode)
  traderCode: string;

  @Column(IPOReserveRow.traderName)
  traderName: string;

  @Column(IPOReserveRow.createAt)
  createAt: Date;

  @Column(IPOReserveRow.updateAt)
  updateAt: Date;

  // Client
  @Column(IPOReserveRow.clientName)
  clientName: string;

  @Column(IPOReserveRow.clientPenumper)
  clientPenumper: string;

  @Column(IPOReserveRow.clientIsInsider)
  clientIsInsider: BooleanString;

  @Column(IPOReserveRow.clientSegmentCode)
  clientSegmentCode: string;

  @Column(IPOReserveRow.clientType)
  clientType: string;

  @Column(IPOReserveRow.clientDocumentNumber)
  clientDocumentNumber: string;

  @Column(IPOReserveRow.clientAccountIsDebitCond)
  clientAccountIsDebitCond: BooleanString;

  @Column(IPOReserveRow.clientAccountAgency)
  clientAccountAgency: number;

  @Column(IPOReserveRow.clientAccountNumber)
  clientAccountNumber: string;

  @Column(IPOReserveRow.clientContactEmail)
  clientContactEmail: string;

  @Column(IPOReserveRow.clientContactTel)
  clientContactTel: number;
}

export class IPORowMapper implements RowMapper<IPOReserve> {
  public map(row: any): IPOReserve {
    const reserve = new IPOReserve();
    const keys = Object.keys(IPOReserveRow);

    for ( const k of keys) {
      reserve[k] = row[ (IPOReserveRow as any)[k] ];
    }

    return reserve;
  }
}