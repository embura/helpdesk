import { Module } from '@nestjs/common';
import { SystemStatusService } from './system_status.service';

@Module({
  imports: [],
  controllers: [],
  components: [SystemStatusService],
  exports: [SystemStatusService],
})
export class SystemStatusModule {

}