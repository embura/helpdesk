// import { CommonEntity } from '../shared/common/entity';
import { SystemStatus } from './system_status.enum';

export class SystemCache {
  public durationMinutes: number;
  public creation: Date;
  public status: SystemStatus;
  public baseDate: Date;
}