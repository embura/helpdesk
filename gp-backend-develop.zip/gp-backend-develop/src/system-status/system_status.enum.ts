export enum SystemStatus {
  WaitingImports,
  Open,
  Contingency,
  Blocked,
}