import { Component } from '@nestjs/common';
import { SystemCache } from './system_status.entity';
import { SystemStatus } from './system_status.enum';
import { BaseDateService } from '../base-date/base-date.service';
import { BaseDate } from '../base-date/base-date.entity';

@Component()
export class SystemStatusService {
  constructor(
    protected baseDateService: BaseDateService
  ){}

  public static systemCache: SystemCache = {
    status: SystemStatus.WaitingImports, // any status, just initialization
    creation: new Date(),
    durationMinutes: -1, // negative in order to force update in the first getStatus() call
    baseDate: null,
  };

  public async setCache(): Promise<void> {
    const baseDate: BaseDate = (await this.baseDateService.findLast2())[0];
    SystemStatusService.systemCache = await this.createSystemCache(baseDate.statusInt, baseDate.id);
  }

  private async createSystemCache(dateStatus: number, baseDate: Date): Promise<SystemCache> {
    const systemCache: SystemCache = {
      status: null,
      creation: new Date(),
      durationMinutes: 1,
      baseDate,
    };
    switch (dateStatus) {
      case 1:
        systemCache.status = SystemStatus.WaitingImports;
        break;
      case 2:
        systemCache.status = SystemStatus.WaitingImports;
        break;
      case 3:
        const yesterdayStatus = (await this.baseDateService.findLast2())[1].statusInt;
        if (yesterdayStatus !== 4) {
          systemCache.status = SystemStatus.Blocked;
        } else {
          systemCache.status = SystemStatus.Contingency;
        }
        // systemCache.durationMinutes = 2;
        break;
      case 4:
        systemCache.status = SystemStatus.Open;
        // systemCache.durationMinutes = 480;
        break;
      default:
        systemCache.status = SystemStatus.WaitingImports;
        break;
    }
    return systemCache;
  }

  public async getStatus(): Promise<SystemStatus> {
    if (!SystemStatusService.systemCache.status) {
      await this.setCache();
    }
    if (this.IsExpired()) {
      await this.setCache();
    }
    return SystemStatusService.systemCache.status;
  }

  public async getBaseDate(): Promise<Date> {
    return SystemStatusService.systemCache.baseDate;
  }

  private IsExpired(): boolean {
    if (!SystemStatusService.systemCache) {
      return true; // cache nao encontrado (primeira vez)
    }
    if (this.difference(
      SystemStatusService.systemCache.creation, SystemStatusService.systemCache.creation) > SystemStatusService.systemCache.durationMinutes
    ) {
      return true; // cache expirado
    }
    return false; // cache ativo
  }

  private difference(startTime: Date, endTime: Date): number {
    const diff = endTime.getTime() - startTime.getTime();
    const resultInMinutes = Math.round(diff / 60000);
    return resultInMinutes;
  }
}