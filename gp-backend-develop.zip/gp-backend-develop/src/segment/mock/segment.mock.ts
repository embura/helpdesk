import { Segment } from '../segment.entity';

export const segments: Segment[] = [
  {id: 66, code: '010', name: 'PF - PRIVATE'} as any,
  {id: 85, code: '136', name: 'CORPORATE 1 - PRIVATE'},
  {id: 94, code: '152', name: 'CORPORATE 2 - PRIVATE'},
  {id: 95, code: '153', name: 'CORPORATE - PRIVATE'},
  {id: 96, code: '154', name: 'PRIVATE-GLOBAL BANKING MARKETS (GBM)'},
  {id: 97, code: '181', name: 'PRIVATE-GOVERNOS'},
  {id: 98, code: '182', name: 'PRIVATE-INSTITUICOES'},
  {id: 101, code: '185', name: 'PRIVATE-EMPRESAS 3-MULTINACIONAL'},
  {id: 110, code: '269', name: 'PF - PRIVATE ULTRA HIGH NET WORTH'},
  {id: 111, code: '270', name: 'PF - PRIVATE HIGH NET WORTH'},
  {id: 112, code: '271', name: 'PF - PRIVATE BANKING'},
  {id: 113, code: '272', name: 'PF - PRIVATE BANKING AFFLUENT'},
  {id: 114, code: '273', name: 'PJ - PRIVATE ULTRA HIGH NET WORTH'},
  {id: 115, code: '274', name: 'PJ - PRIVATE HIGH NET WORTH'},
  {id: 116, code: '275', name: 'PJ - PRIVATE BANKING'},
  {id: 117, code: '276', name: 'PJ - PRIVATE BANKING AFFLUENT'},
];