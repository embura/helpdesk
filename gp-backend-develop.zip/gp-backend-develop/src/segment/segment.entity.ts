import { Table } from '../shared/decorator/table.annotation';
import { Column } from '../shared/decorator/column.decorator';
import { RowMapper } from '../shared/repository/repository.interface';

import { CommonEntity } from '../shared/common/entity';

export const SegmentTable = 'GPOS.TB_SEGM_CLIE_SEM_LIMI_CNTR';
export const SegmentRow = Object.freeze({
  id: 'NR_SEQU_SEGM_CLIE',
  code: 'CD_SEGM_CLIE',
  name: 'NM_SEGM_CLIE',
});

@Table(SegmentTable)
export class Segment extends CommonEntity {
  @Column(SegmentRow.id)
  id: number;

  @Column(SegmentRow.code)
  code: string;

  @Column(SegmentRow.name)
  name: string;
}

export class SegmentRowMapper implements RowMapper<Segment> {
	public map(row: any): Segment {
    const segment = new Segment();
    segment.id = row[SegmentRow.id];
    segment.name = row[SegmentRow.name];
    segment.code = row[SegmentRow.code];
    return segment;
	}
}