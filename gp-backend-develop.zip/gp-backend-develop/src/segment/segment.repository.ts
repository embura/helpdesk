import { SegmentMessage } from './segment.msg';
import { CommnRepository } from '../shared/repository/common.repository';
import { Segment, SegmentRow, SegmentTable, SegmentRowMapper } from './segment.entity';
import { Component } from '@nestjs/common';

@Component()
export class SegmentRepository extends CommnRepository<Segment> {

  constructor() {
    super(
      SegmentRow,
      SegmentTable,
      null,
      SegmentMessage,
      new SegmentRowMapper()
    );
  }

}
