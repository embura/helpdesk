import { Controller, Get, HttpStatus, Res, Param, Query } from '@nestjs/common';

import { Response } from 'express';
import { Status } from '../shared/status.entity';
import { HttpResponse } from '../shared/http.response';
import { SegmentRepository } from './segment.repository';
import { IQuery, queryStringToWhere } from '../shared/common/query.interface';
import { Order } from '../shared/repository/repository.interface';

@Controller('segment')
export class SegmentController  {
  constructor(private readonly segmentRepository: SegmentRepository) {
  }

  @Get() // test
  async findAll(@Res() res: Response, @Query() query: IQuery): Promise<Response> {
    const where = queryStringToWhere(query);
    if (!where.order) {
      where.order = [['code', Order.ASC]];
    }

    const segments = await this.segmentRepository.findAll(where);
    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, 'Todos segmentos privados encontrado.'), segments));
  }

  @Get(':segmentId') // test
  async findByid(@Res() res: Response, @Param('segmentId') segmentId: string ): Promise<Response> {
    const segment = await this.segmentRepository.findOne({
      where: { id: segmentId },
    });
    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, 'Segment encontrado.'), segment));
  }
}
