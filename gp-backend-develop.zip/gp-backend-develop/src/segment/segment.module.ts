import { Module } from '@nestjs/common';
import { SegmentController } from './segment.controller';

@Module({
  components: [
  ],
  controllers: [
    SegmentController,
  ],
  exports: [
  ],
})

export class SegmentModule { }
