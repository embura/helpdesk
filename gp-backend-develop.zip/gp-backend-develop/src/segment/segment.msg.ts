import { IMessage, CategoryMessage } from '../shared/common/message.model';

export const entityName: IMessage = {
  ptBr: 'Segments Private',
  system: 'Segment Private',
};

export const ClientContactTag: IMessage = {
  ptBr : 'Segmento',
  system : 'Segment',
};

export const SegmentMessage = new CategoryMessage(ClientContactTag, entityName);