import { Module } from '@nestjs/common';
import { TypeFormalizationService } from './type-formalization.service';
import { TypeFormalizationController } from './type-formalization.controller';

@Module({
  components: [TypeFormalizationService],
  controllers: [TypeFormalizationController],
  exports: [TypeFormalizationService],
})

export class TypeFormalizationModule { }
