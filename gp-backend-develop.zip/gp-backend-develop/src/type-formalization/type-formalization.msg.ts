import { CategoryMessage, IMessage } from '../shared/common/message.model';

export const entityName: IMessage = {
  ptBr: 'Tipo de Formalização',
  system: 'TypeFormalization',
};

export const TypeFormalizationTag: IMessage = {
  ptBr : 'Tipo de Formalização',
  system : 'TypeFormalization',
};

export const TypeFormalizationMessage = new CategoryMessage(TypeFormalizationTag, entityName);