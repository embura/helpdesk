
import { Component } from '@nestjs/common';
import { CommonRepositoryService } from '../shared/common/repository.service';
import { CommnRepository } from '../shared/repository/common.repository';
import { TypeFormalization, TypeFormalizationRow, TypeFormalizationTableName, TypeFormalizationRowMapper } from './type-formalization.entitty';
import { TypeFormalizationMessage } from './type-formalization.msg';
import { queryStringToWhere, IQuery } from '../shared/common/query.interface';
import { Order } from '../shared/repository/repository.interface';

@Component()
export class TypeFormalizationService extends CommonRepositoryService<TypeFormalization>{
  constructor() {
    super();
    this.messages = TypeFormalizationMessage;
    this.repository = new CommnRepository<TypeFormalization>(
      TypeFormalizationRow,
      TypeFormalizationTableName,
      null,
      TypeFormalizationMessage,
      new TypeFormalizationRowMapper()
    );
  }

  async findAll(param: IQuery): Promise<TypeFormalization[]> {
    const where = queryStringToWhere(param);
    if (!where.order) {
      where.order = [['typeFormalization', Order.ASC]];
    }
    return await this.repository.findAll(where);
  }

}
