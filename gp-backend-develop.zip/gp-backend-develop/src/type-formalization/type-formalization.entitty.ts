import { CommonEntity } from '../shared/common/entity';
import { Column } from '../shared/decorator/column.decorator';
import { RowMapper } from '../shared/repository/repository.interface';
import { Table } from '../shared/decorator/table.annotation';

export const TypeFormalizationTableName = 'GPOS.TB_TIPO_FORZ_CPRA';
export const TypeFormalizationRow = Object.freeze({
  typeFormalization: 'TP_FORZ_CPRA',
  nameFormalization: 'NM_FORZ_CPRA',
});

@Table(TypeFormalizationTableName)
export class TypeFormalization extends CommonEntity {

  @Column(TypeFormalizationRow.typeFormalization)
  typeFormalization: number;

  @Column(TypeFormalizationRow.nameFormalization)
  nameFormalization: string;

}

export class TypeFormalizationRowMapper implements RowMapper<TypeFormalization> {
  public map(row: any): TypeFormalization {
    const rowMapper = new TypeFormalization();
    Object.keys(TypeFormalizationRow).forEach((key: string) => {
      rowMapper[key] = row[(TypeFormalizationRow as any)[key]];
    });
    return rowMapper;
  }
}
