import { Controller } from '@nestjs/common';
import { TypeFormalization } from './type-formalization.entitty';
import { CommonController } from '../shared/common/common.controller';
import { TypeFormalizationService } from './type-formalization.service';
import { TypeFormalizationMessage } from './type-formalization.msg';

@Controller('type-formalization')
export class TypeFormalizationController extends CommonController<TypeFormalization> {

  constructor(protected readonly typeFormalizationService: TypeFormalizationService) {
    super(typeFormalizationService, TypeFormalizationMessage);
  }
}
