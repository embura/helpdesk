import { Component } from '@nestjs/common';
import { CommnRepository } from '../../shared/repository/common.repository';
import { ContractLimit, ContractLimitRow, ContractLimitTable, ContractLimitRowMapper } from './contract-limit.entity';
import { ContractLimitMessage } from './contract-limit.msg';

@Component()
export class ContractLimitRepository extends CommnRepository<ContractLimit> {

  constructor(  ) {
    super(
      ContractLimitRow,
      ContractLimitTable,
      undefined,
      ContractLimitMessage,
      new ContractLimitRowMapper()
    );
  }

}
