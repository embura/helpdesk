export const defaultContractLimit = 999000000;
export const maxContractPercent = 1;

export class ContractLimit {
  id: number;
  limit: string;

  constructor(id: number | string, defaultLimit: string = null) {
    this.id = +id;
    this.limit = defaultLimit ? defaultLimit : defaultContractLimit.toFixed(2);
  }
}