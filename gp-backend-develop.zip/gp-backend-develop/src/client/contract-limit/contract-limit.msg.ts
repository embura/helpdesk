import { IMessage, CategoryMessage } from '../../shared/common/message.model';

export const ContractLimitName: IMessage = {
  ptBr: 'Limite de Concentração',
  system: 'ContractLimit',
};

export const ContractLimitTag: IMessage = {
  ptBr: 'Limite de Concentração',
  system: 'ContractLimit',
};

export const ContractLimitMessage = new CategoryMessage(ContractLimitTag, ContractLimitName);
