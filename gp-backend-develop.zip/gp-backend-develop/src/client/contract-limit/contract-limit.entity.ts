
import { RowMapper } from '../../shared/repository/repository.interface';
import { CommonEntity } from '../../shared/common/entity';
import { Column } from '../../shared/decorator/column.decorator';
import { Table } from '../../shared/decorator/table.annotation';

export const ContractLimitRow = Object.freeze({
  id: 'NR_LIMI_COCN_GRUP',
  maxConcentration: 'PC_MAXI_COCN_GRUP',
  name: 'NM_GRUP_PROD',
});
export const ContractLimitTable = 'GPOS.TB_LIMI_COCN_GRUP';

@Table(ContractLimitTable)
export class ContractLimit extends CommonEntity {

  @Column(ContractLimitRow.id)
  id?: number;

  @Column(ContractLimitRow.maxConcentration)
  maxConcentration: number;

  @Column(ContractLimitRow.name)
  name: string;

}

export class ContractLimitRowMapper implements RowMapper<ContractLimit> {
  public map(row: any): ContractLimit {
    const reserve = new ContractLimit();
    const keys = Object.keys(ContractLimitRow);

    for ( const k of keys) {
      reserve[k] = row[ (ContractLimitRow as any)[k] ];
    }

    return reserve;
  }
}