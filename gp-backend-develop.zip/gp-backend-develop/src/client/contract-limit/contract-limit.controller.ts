import { Controller, Body, Post, Query } from '@nestjs/common';

import { ContactLimitService } from './contract-limit.service';
import { IpdiPositionEnvelopParams } from '../../shared/repository/pdi-position/pdi-position.envelop';
import { HttpResponse } from '../../shared/http.response';
import { Status } from '../../shared/status.entity';
// import { SchemaValidationPipe } from '../../shared/pipe/validation.pipe';

@Controller('client/contract/limit')
export class ContractLimitController  {

  constructor(protected readonly contactLimitService: ContactLimitService) {
  }

  @Post()
  // @UsePipes(new SchemaValidationPipe())
  async validate(
    @Body() queryParams: IpdiPositionEnvelopParams,
    @Query('maxPrivateConcentration') maxPrivateConcentration?: string ): Promise<HttpResponse> {
      const limit = await this.contactLimitService.getLimit(queryParams, maxPrivateConcentration);

      return new HttpResponse(new Status(0, 'Limite calculado com sucesso.'), limit);
  }
}
