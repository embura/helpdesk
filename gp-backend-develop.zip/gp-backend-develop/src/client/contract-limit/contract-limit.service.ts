import { Component } from '@nestjs/common';
import { CatalogRepository } from '../../shared/repository/catalog/catalog.repository';
import { IpdiPositionEnvelopParams } from '../../shared/repository/pdi-position/pdi-position.envelop';
// import { PdiPositionRepository } from '../../shared/repository/pdi-position/pdi-position.repository';
import { SegmentRepository } from '../../segment/segment.repository';
// 
import { GP001Props, IPayloadGP001 } from '../../shared/repository/catalog/product-payload.interface';
import { ContractLimit, maxContractPercent, defaultContractLimit } from './inerface/contract-limit.interface';
import { PositionService } from '../../position/position.service';
import { getDateToday, dateToYYYMMMDD } from '../../shared/utils/parse-date';
import { Position } from '../../position/position.entity';
import { ContractLimitRepository } from './contract-limit.repository';

@Component()
export class ContactLimitService {

  constructor(
    private readonly contractLimitRepository: ContractLimitRepository,
    private readonly segmentRepository: SegmentRepository,
    // private readonly pdiPositionRepository: PdiPositionRepository,
    private readonly catalogRepository: CatalogRepository,
    public readonly positionService: PositionService
  ) {
  }

  async getLimit(queryParam: IpdiPositionEnvelopParams, maxPrivateOption: string | undefined): Promise<ContractLimit[]> {
    // console.warn('[ContractLimitService] getLimit : ', queryParam, maxPrivateOption);

    if (
      queryParam.groupName &&
      queryParam.groupName === 'Títulos Públicos'
      ) {
      return queryParam.products.map(p => new ContractLimit(p.productId, '999000000'));
    }
    const segment = await this.segmentRepository.findAll({ where: { code: queryParam.segmentCode } });
    if (segment.length > 0) {
      return queryParam.products.map(d => new ContractLimit(d.productId));
    }

    if (queryParam.position.products && queryParam.position.products.length === 0) {
      console.warn('[ContractLimitService] getLimit - Não foram encontratos produtos');
      return queryParam.products.map(d => new ContractLimit(d.productId, '0'));
    }

    // Modeling input for concentration limit
    const productsParameter = queryParam.position.products[0];
    const positions = {
      products: {
        product: {
          code: productsParameter.product.code,
          subProducts: {
            subProduct: {
              totalGrossValue: productsParameter.product.subProducts.subProduct.totalGrossValue,
            },
          },
        },
      },
    };
    const productIds = queryParam.products.map(d => d.productId);
    const positionDate = dateToYYYMMMDD(getDateToday());

    const [products, posiPagi, maxPrivateLimit] = await Promise.all([
      this.getPayloadByProductIdsAndChannel(productIds, queryParam),
      this.positionService.findPositionMovement({ positionDate, penumper: queryParam.penumper }),
      this.contractLimitRepository.findOne({ where: { id: 1 } }),
    ]);

    const clientPositions = posiPagi.positions;

    const maxPrivateConcentration = maxPrivateOption ? +maxPrivateOption : maxPrivateLimit.maxConcentration;

    const limits = products.map(product => {
      const info = new ContractLimit(product.productId);
      const maxConcentration = +product[GP001Props.productConcentrationLimit] / 100;
      const currentPositionSum = getConsolidatedGrossValue(positions);
      const currentProductSum = getProductSum(clientPositions, product.productId);
      const currentPrivateSum = getGroupSum(clientPositions, 'Títulos Privados');
      // const privateGroupValue = getConsolidatedPrivateValue(positions);
      const privateGroupValue = getTotalGrossValue(positions);

      let productLimit = getConcentrationLimit(maxConcentration, currentPositionSum, currentProductSum);
      let privateLimit = getPrivateConcentrationLimit(maxPrivateConcentration, privateGroupValue, currentPrivateSum, maxConcentration);
      productLimit = Math.floor(productLimit * 100) / 100;
      privateLimit = Math.floor(privateLimit * 100) / 100;
      const limit = productLimit > privateLimit ? privateLimit : productLimit;
      info.limit = limit.toFixed(2);
      return info;
    });

    return limits;
  }

  getPayloadByProductIdsAndChannel(productIds: number[] | string[], queryParam: IpdiPositionEnvelopParams): Promise<IPayloadGP001[]> {
    if (queryParam.products[0].limit) {
      const products: IPayloadGP001[] = queryParam.products
        .map((p: any) => new IPayloadGP001({
          productId: p.productId,
          [GP001Props.productConcentrationLimit]: p.limit,
        })
        );
      console.info('[ContractLimitService] getPayloadByProductIdsAndChannel products:', products);
      return Promise.resolve(products);
    }

    return this.catalogRepository.getPayloadByProductIdsAndChannel(productIds, queryParam.channel.code);
  }

}

function getConsolidatedGrossValue(positions: any): number {
  if (!positions || !positions.products || !positions.products.product ){
    console.error('[ContractLimitService] getConsolidatedGrossValue positions empty', positions);
    return 0;
  }

  const productsRef = positions.products.product[0] || positions.products.product;
  if (!productsRef) {
    return 0;
  }

  const valueRef = productsRef.subProducts.subProduct[0] || productsRef.subProducts.subProduct;
  return valueRef ? +valueRef.totalGrossValue / 100 : 0;
}

function getTotalGrossValue(positions: any): number {
  if (
    positions &&
    positions.products &&
    positions.products.product &&
    positions.products.product.subProducts &&
    positions.products.product.subProducts.subProduct &&
    positions.products.product.subProducts.subProduct.totalGrossValue
    ){
      return positions.products.product.subProducts.subProduct.totalGrossValue / 100;
  }
  return 0;
}

// function getConsolidatedPrivateValue(positions: any): number {
//   let privateProducts;

//   if (!positions || !positions.products){
//     console.log('[ContractLimitService] getConsolidatedPrivateValue: position ou produtos nulos')
//     console.warn('[ContractLimitService] getConsolidatedPrivateValue: position ou produtos nulos');
//     return 0;
//   }

//   if (Array.isArray(positions.products.product)) {
//     privateProducts = positions.products.product.filter((p: any) => p.code === 'CPT02')[0];
//   } else if (positions.products.product && positions.products.product.code === 'CPT02') {
//     console.log('productCode', positions.products.product.code);
//     privateProducts = positions.products.product;
//   }

//   console.log('privateProducts', privateProducts);
//   if (!privateProducts) {
//     return 0;
//   }

//   if (Array.isArray(privateProducts.subProducts.subProduct)) {
//     let totalPrivateGrossValue = 0;
//     privateProducts.subProducts.subProduct.forEach((p: any) => {
//       totalPrivateGrossValue += +p.grossValue;
//     });
//     return totalPrivateGrossValue / 100;
//   }

//   return +privateProducts.subProducts.subProduct.totalGrossValue / 100;
// }

function getConcentrationLimit(maxProductConcentration: number, grossValue: number, newContractGrossValue: number): number {
  switch (true) {
    case maxProductConcentration >= maxContractPercent:
      return defaultContractLimit;
    case maxProductConcentration <= 0:
      return 0;
    default:
      const limit = (maxProductConcentration * grossValue - newContractGrossValue) / (maxContractPercent - maxProductConcentration);
      if (limit < 0) {
        return 0;
      }
      return limit;
  }
}

function getPrivateConcentrationLimit(
  maxProductConcentration: number,
  grossValue: number,
  newContractGrossValue: number, maxConcentration: number): number {
  switch (true) {
    case maxProductConcentration >= maxContractPercent:
      return defaultContractLimit;
    case maxProductConcentration <= 0:
      return 0;
    default:
      const limit = (maxProductConcentration * grossValue - newContractGrossValue) / (maxContractPercent - maxProductConcentration);
      if (limit < 0) {
        return 0;
      }

      return limit;
  }
}

function getProductSum(positions: Position[], needle: number): number {
  const positionsToCount = positions.filter(p => p.productId === needle);
  if (positionsToCount.length === 0) {
    return 0;
  }

  return positionsToCount
    .map(p => p.updatedGrossValueAvailable)
    .reduce((previous, current) => previous + current);
}

function getGroupSum(positions: Position[], needle: string): number {
  const positionsToCount = positions.filter(p => p.group === needle);
  if (positionsToCount.length === 0) {
    return 0;
  }

  return positionsToCount
    .map(p => p.updatedGrossValueAvailable)
    .reduce((previous, current) => previous + current);
}