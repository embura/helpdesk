import { Controller, Body, HttpStatus, HttpCode, Post } from '@nestjs/common';

import { IpdiPositionQueryarams } from '../../shared/repository/pdi-position/pdi-position.envelop';
import { ResponseObject } from '../../shared/status.entity';
import { PdiPositionRepository } from '../../shared/repository/pdi-position/pdi-position.repository';

@Controller('client/pdi-position')
export class PidControllerController  {

  constructor(protected readonly pdiPositonRepository: PdiPositionRepository) {
  }

  @Post()
  @HttpCode(HttpStatus.OK)
  async validate(@Body() queryParams: IpdiPositionQueryarams): Promise<ResponseObject<any>> {
    const limit = await this.pdiPositonRepository.findPositionByPenumper(queryParams);
    return new ResponseObject(0, 'Posição no OQ encontrado com sucesso.', limit);
  }

}
