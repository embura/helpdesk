import { Module } from '@nestjs/common';
import { ContractLimitController } from './contract-limit/contract-limit.controller';
import { ContactLimitService } from './contract-limit/contract-limit.service';
import { PidControllerController } from './pdi-position/pdi-position.controller';
import { ContractLimitRepository } from './contract-limit/contract-limit.repository';

@Module({
  components: [
    ContactLimitService,
    ContractLimitRepository,
  ],
  controllers: [
    ContractLimitController,
    PidControllerController,
  ],
  exports: [],
})

export class ClientModule { }
