export interface Operators {
  readonly [key: string]: number|string;
}

export enum Order {
  DESC = 'DESC',
  ASC = 'ASC',
}
export type FindOrder = [string, Order.ASC | Order.DESC];

export interface IFindOptions<T> {
  where?: WhereOptions<T>;
  order?: FindOrder[];
  limit?: number;
  offset?: number;
  logging?: boolean;
  // Todo: Implementing Assosiation
  // include?: Array<typeof Model | IIncludeOptions>;
}

export type WhereOptions<T> = {
  [P in keyof T]?: string | number | WhereLogic | WhereOptions<T[P]> | Array<WhereOptions<T>>;
};

export const Op = {
  eq: Symbol.for('eq'),
  in: Symbol.for('in'),
  like: Symbol.for('like'),
  lt: Symbol.for('lt'),
  lte: Symbol.for('lte'),
  gt: Symbol.for('gt'),
  gte: Symbol.for('gte'),
  between: Symbol.for('between'),
  or: Symbol.for('or'),
  and: Symbol.for('and'),
};

export type WhereLogic = Partial<{
  $eq: string | number,
  $in: Array<string | number>;
  $like: string;
  $lt: string | Date | number;
  $lte: string | Date | number;
  $gt: string | Date | number;
  $gte: string | Date | number;
  $between: string | Date | number;
  $or: Array<any>
  $and: Array<any>
}>;

export type LogicParam = Array<string | number> | string | number;

export interface TableRow extends Readonly<any> {
}

export interface RowMapper<T> {
  map(row: any): T;
}