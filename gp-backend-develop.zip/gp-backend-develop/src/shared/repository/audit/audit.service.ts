import { AuditMessage } from './audit.msg';
import { Audit, AuditAction } from './audit.entity';
import { AuditRepository } from './audit.repository';
import { CommonEntity } from '../../common/entity';
import { Component } from '@nestjs/common';
import { IQuery, queryStringToWhere } from '../../common/query.interface';
import { FindOrder, Order, Op } from '../repository.interface';
import { CategoryMessage } from '../../common/message.model';
import { TabelList } from '../../constants/table.constant';

@Component()
export class AuditService {

  protected messages: CategoryMessage = AuditMessage;

  constructor(
    private readonly auditRepository: AuditRepository) {

  }

  protected defaultOrder: FindOrder | undefined = ['name', Order.ASC];

  async create(obj: CommonEntity): Promise<void> {
    const creationDate = new Date(Date.now());
    const records: Promise<string | number>[] = [];
    const tableRows = obj.getColumns();

    Object.keys(obj).forEach((key): void => {
      if (!obj[key] || !tableRows[key]) return;
      const newRecord = new Audit();

      newRecord.name = key;
      newRecord.newValue = obj[key].toString();
      newRecord.tableId = TabelList[obj.getTableName()];
      newRecord.recordId = obj.id.toString();
      newRecord.actionType = AuditAction.Create;
      newRecord.actionDate = creationDate;

      records.push(
        this.auditRepository.create(newRecord)
      );
    });

    await Promise.all(records);
  }

  async update(oldRecord: CommonEntity, newRecord: CommonEntity): Promise<void> {
    const creationDate = new Date(Date.now());
    const records: Promise<string | number>[] = [];
    const tableRows = newRecord.getColumns();

    Object.keys(oldRecord).forEach((key): void => {
      if (oldRecord[key] === newRecord[key]) return;
      if (!tableRows[key]) return;

      const newAudit = new Audit();
      newAudit.name = key;
      newAudit.oldValue = oldRecord[key] ? oldRecord[key].toString() : undefined;
      newAudit.newValue = newRecord[key] ? newRecord[key].toString() : undefined;
      newAudit.tableId = TabelList[newRecord.getTableName()];
      newAudit.recordId = oldRecord.id.toString();
      newAudit.actionType = AuditAction.Edit;
      newAudit.actionDate = creationDate;

      if (!newAudit.oldValue) {
        delete newAudit.oldValue;
      }
      if (!newAudit.newValue) {
        delete newAudit.newValue;
      }

      records.push(
        this.auditRepository.create(newAudit)
      );
    });

    await Promise.all(records);
  }

  async destroy(oldRecord: CommonEntity): Promise<void> {
    const creationDate = new Date(Date.now());
    const records: Promise<string | number>[] = [];
    const tableRows = oldRecord.getColumns();

    Object.keys(oldRecord).forEach((key): void => {
      if (!tableRows[key]) return;

      const newRecord = new Audit();

      newRecord.name = key;
      delete newRecord.newValue;
      newRecord.tableId = TabelList[oldRecord.getTableName()];
      newRecord.recordId = oldRecord.id.toString();
      newRecord.actionType = AuditAction.Delete;
      newRecord.actionDate = creationDate;

      records.push(
        this.auditRepository.create(newRecord)
      );
    });

    await Promise.all(records).catch(console.log);
  }

  async findAll(param: IQuery, maxNumber: number = 100): Promise<Audit[]> {
    const where = queryStringToWhere(param);
    if (param.tableId === '61') {
      return this.findAllForms(param, maxNumber);
    }
    if (!where.order) {
      where.order = [this.defaultOrder];
    }
    return await this.auditRepository.findAll(where, maxNumber);
  }

  async findAllForms(param: IQuery, maxNumber: number = 100): Promise<Audit[]> {
    const where = queryStringToWhere(param);
    const idWhere = Object.assign({}, where);
    idWhere.where.id = 61;
    idWhere.where.name = 'formId';
    idWhere.where.oldValue = where.where.tableId;
    const formParams: Audit[] = await this.auditRepository.findAll(idWhere, maxNumber);

    const paramIds: string[] = [];
    for ( const f of formParams) {
      paramIds.push(f.recordId);
    }

    const entities = await this.auditRepository.findAll({
      [Op.or]: [
        { tableId: 61, recordId: {[Op.in]: paramIds } },
        { where },
      ],
    }, maxNumber);
    return entities;
  }

}
