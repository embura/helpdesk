import { LogAuditTag } from '../log.msg';
import { IMessage, CategoryMessage } from '../../common/message.model';

const entityName: IMessage = {
  ptBr: 'Log Auditoria',
  system: 'Audit Log',
};

export const AuditMessage = new CategoryMessage(LogAuditTag, entityName);
