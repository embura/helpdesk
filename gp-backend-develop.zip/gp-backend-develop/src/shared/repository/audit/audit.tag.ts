export const CSVLables = [
  {label: 'ID', value: 'id'},
  {label: 'Nome da Coluna', value: 'name'},
  {label: 'Valor Anterior', value: 'oldValue'},
  {label: 'Valor Novo', value: 'newValue'},
  {label: 'Sigla do Usuário', value: 'userId'},
  {label: 'ID da Tabela', value: 'tableId'},
  {label: 'Código do Registro', value: 'recordId'},
  {label: 'Tipo de Ação', value: 'actionType'},
  {label: 'Data da Ação', value: 'actionDate'},
];