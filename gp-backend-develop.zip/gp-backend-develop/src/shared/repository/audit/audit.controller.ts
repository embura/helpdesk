import * as json2csv from 'json2csv';
import { Controller, Get, Res, Query, HttpStatus } from '@nestjs/common';
import { AuditService } from './audit.service';
import { IQuery } from '../../common/query.interface';
import { Response } from 'express';
import { ServiceErrorHandler } from '../../common/common.error';
import { Status } from '../../status.entity';
import { HttpResponse } from '../../http.response';
import { AuditMessage } from './audit.msg';
import { Audit } from './audit.entity';
import { CSVLables } from './audit.tag';
import { translateEntityProperty } from '../../translation/translate';

@Controller('audit')
export class AuditController {

  constructor(private auditService: AuditService) { }

  @Get()
  async findAll(@Res() res: Response, @Query() query: IQuery): Promise<Response> {

    let entities = await this.auditService.findAll(query)
      .catch(ServiceErrorHandler) as Audit[];

    entities = entities.map(translateEntityProperty);

    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, AuditMessage.success.found), entities));

  }

  @Get('details')
  async findAllCSV(@Query() query: IQuery): Promise<string> {
    const csvParser = new json2csv.Parser<Audit[]>({fields: CSVLables, withBOM: true, delimiter: ';'});
    let entities = await this.auditService.findAll(query, 1000)
      .catch(ServiceErrorHandler) as Audit[];

    entities = entities.map(translateEntityProperty);

    return csvParser.parse(entities);

  }

}
