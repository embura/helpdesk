
import { RowMapper } from '../repository.interface';
import { CommonEntity } from '../../common/entity';
import { Table } from '../../decorator/table.annotation';
import { Column } from '../../decorator/column.decorator';

export enum AuditAction {
  Create = 'C' ,
  Edit = 'E',
  Delete = 'D',
}

@Table('CPT.TB_LOG_AUDI_ACAO')
export class Audit extends CommonEntity {
  @Column('NR_SEQU_LOG_AUDI_ACAO')
  id?: number;

  @Column('NM_COLU')
  name: string;

  @Column('TX_CNTD_ANTE_COLU')
  oldValue?: string;

  @Column('TX_CNTD_NOVO_COLU')
  newValue?: string;

  @Column('NR_MATR_USUA')
  userId: string;

  @Column('NR_SEQU_TABE')
  tableId: number;

  @Column('CD_REGT_TABE')
  recordId: string;

  @Column('TP_ACAO')
  actionType: AuditAction.Create | AuditAction.Edit | AuditAction.Delete;

  @Column('DT_ACAO')
  actionDate: Date;

}

export const AuditRow = Object.freeze({
  id: 'NR_SEQU_LOG_AUDI_ACAO',
  name: 'NM_COLU',
  oldValue: 'TX_CNTD_ANTE_COLU',
  newValue: 'TX_CNTD_NOVO_COLU',
  userId: 'NR_MATR_USUA',
  tableId: 'NR_SEQU_TABE',
  recordId: 'CD_REGT_TABE',
  actionType: 'TP_ACAO',
  actionDate: 'DT_ACAO',
});

export const AuditTable = 'CPT.TB_LOG_AUDI_ACAO';
export const AuditSequence = 'CPT.SQ_LOG_AUDI_ACAO.NEXTVAL';

export class AuditRowMapper implements RowMapper<Audit> {
	public map(row: any): Audit {
    const audit = new Audit();
    audit.id = row[AuditRow.id];
    audit.name = row[AuditRow.name];
    audit.oldValue = row[AuditRow.oldValue];
    audit.newValue = row[AuditRow.newValue];
    audit.tableId = row[AuditRow.tableId];
    audit.recordId = row[AuditRow.recordId];
    audit.actionType = row[AuditRow.actionType];
    audit.actionDate = row[AuditRow.actionDate];

		  return audit;
	}
}
