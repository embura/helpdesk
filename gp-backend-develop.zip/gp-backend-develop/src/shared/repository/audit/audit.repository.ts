import { CommnRepository } from '../common.repository';
import { Audit, AuditRowMapper, AuditSequence, AuditTable, AuditRow } from './audit.entity';
import { AuditMessage } from './audit.msg';
import { Component } from '@nestjs/common';

@Component()
export class AuditRepository extends CommnRepository<Audit> {

  constructor() {
    super(
      AuditRow,
      AuditTable,
      AuditSequence,
      AuditMessage,
      new AuditRowMapper()
    );
  }

}
