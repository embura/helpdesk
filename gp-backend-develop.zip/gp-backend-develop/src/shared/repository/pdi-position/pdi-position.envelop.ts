import { IsString, IsNotEmpty, ValidateNested, Allow, ArrayNotEmpty, IsNumber } from 'class-validator';
import { Type } from 'class-transformer';

export enum DocumentType {
  CNPJ = 'CNPJ',
  CPF = 'CPF',
}
export class ChannelCode {
  @IsString()@IsNotEmpty()
  code: string;
  @IsString()@IsNotEmpty()
  corporateCode: string;
}
export class IpdiPositionQueryarams {
  @IsString()@IsNotEmpty()
  penumper: string;

  @ValidateNested()@IsNotEmpty()@Type(() => ChannelCode)
  channel: ChannelCode;
}
export class Product {
  @IsNumber()@IsNotEmpty()
  productId: number;
  @Allow()
  limit?: number;
}

export class SubProduct {
  totalGrossValue: number;
}
export class SubProducts {
  subProduct: SubProduct;
}
export class ProductParameter {
  code: number;
  subProducts: SubProducts;
}
export class Products {
  product: ProductParameter;
}
export class Positions {
  products: Products[];
}
export class IpdiPositionEnvelopParams extends IpdiPositionQueryarams {
  @IsString()@IsNotEmpty()
  segmentCode: string;

  @ValidateNested()@ArrayNotEmpty()@Type(() => Product)
  products: Product[];

  @ValidateNested()@Type(() => Positions)
  position: Positions;

  @Allow()
  contractValue?: number;

  @IsString()@IsNotEmpty()
  groupName: string;
}

const envelopDeclaration = `<soapenv:Envelope
  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
  xmlns:v1="http://services.santander.com.br/bsb/treasury/treasurypositionmanagement/v1">`;

export function pdiPositionEnvelopBuilder(params: IpdiPositionQueryarams): string {
  return `${envelopDeclaration}
    <soapenv:Header>
      <v1:HubHeader Canal="89f17aa0f88e013408c70050569009ca"/>
    </soapenv:Header>
    <soapenv:Body>
      <v1:getPortfolioInvestment>
        <account>
            <bankCode></bankCode>
            <branchCode></branchCode>
            <number></number>
        </account>
        <channel>
            <code>${params.channel.code}</code>
            <corporateCode>${params.channel.corporateCode}</corporateCode>
        </channel>
        <customerCode>${params.penumper}</customerCode>
      </v1:getPortfolioInvestment>
    </soapenv:Body>
  </soapenv:Envelope>`;
}

// const param: IpdiPositionEnvelopParams = {
//   channelCode: '53',
//   penumper: '02897661',
//   documentNumber: '05003966806',
//   documentType: DocumentType.CNPJ,
// };