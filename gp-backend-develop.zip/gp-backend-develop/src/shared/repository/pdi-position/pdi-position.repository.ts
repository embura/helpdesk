import * as fetch from 'isomorphic-fetch';
import xml2js = require('xml2js');
import { pdiPositionEnvelopBuilder, IpdiPositionQueryarams } from './pdi-position.envelop';
import { SERVICE_HUB } from '../../constants/endpoints';
import { LogAsyncBench } from '../../utils/logger.decorator';

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

export class PdiPositionRepository {

  url = `${SERVICE_HUB}bsb/treasury/treasurypositionmanagement/v1?wsdl`;

  @LogAsyncBench()
  findPositionByPenumper(params: IpdiPositionQueryarams): Promise<any | never> {
    const request = {
      method: 'POST',
      headers: { 'content-type': 'text/xml;charset=utf-8' },
      body: pdiPositionEnvelopBuilder(params),
    };

    console.info('[PdiPositionRepository] request body: ', request.body);

    return fetch(this.url, request)
    .then((result: any) => result.text())
    .then((text: string) => {
      return new Promise( (resolve, reject) => {
        xml2js.parseString(text, {explicitArray: false, ignoreAttrs: true}, (err, result) => {
          if (err) {
            console.error('[PdiPositionRepository] err: ', err, result);
            reject(err);
            return;
          }

          const resultBody = result['soapenv:Envelope']['soapenv:Body']['NS1:getPortfolioInvestmentResponse'];
          if (resultBody.mensagemAltair && resultBody.mensagemAltair.erroAltair) {
            console.error('[PdiPositionRepository] Error erroAltair: ', resultBody);
            reject(resultBody.mensagemAltair.erroAltair);
            return;
          }
          console.info('[PdiPositionRepository] Sucess: ', resultBody);

          resolve(resultBody);
        });
      });
    });
  }
}

// export const pdiPositionRepository = new PdiPositionRepository();
