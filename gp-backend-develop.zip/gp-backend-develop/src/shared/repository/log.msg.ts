import { IMessage } from '../common/message.model';

export const LogAuditTag: IMessage = {
  ptBr: 'Log/Auditoria',
  system: 'Log/Audit',
};
