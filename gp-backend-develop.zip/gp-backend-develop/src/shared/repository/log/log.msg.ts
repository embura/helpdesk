import { LogAuditTag } from '../log.msg';
import { IMessage, CategoryMessage } from '../../common/message.model';

const entityName: IMessage = {
  ptBr: 'Log Registro',
  system: 'Regist Log',
};

export const LogMessage = new CategoryMessage(LogAuditTag, entityName);
