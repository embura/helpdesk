import { CommnRepository } from '../common.repository';
import { Log, LogRowMapper, LogSequence, LogTable, LogRow } from './log.entity';
import { LogMessage } from './log.msg';
import { Component } from '@nestjs/common';

@Component()
export class LogRepository extends CommnRepository<Log> {

  constructor() {
    super(
      LogRow,
      LogTable,
      LogSequence,
      LogMessage,
      new LogRowMapper()
    );
  }

}
