import { LogMessage } from './log.msg';
import { LogRepository } from './log.repository';
import { Log } from './log.entity';
import { CommonEntity } from '../../common/entity';
import { Component } from '@nestjs/common';
import { AuditService } from '../audit/audit.service';
import { CategoryMessage } from '../../common/message.model';
import { TabelList } from '../../constants/table.constant';
// import { AuditService } from '../audit/audit.service';
@Component()
export class LogService {

  protected messages: CategoryMessage = LogMessage;

  constructor(
    private readonly logRepository: LogRepository,
    private readonly auditService: AuditService
  ) {

  }

  async create(newRecord: CommonEntity): Promise<void> {
    const log = new Log();
    log.tableId = TabelList[newRecord.getTableName()];
    log.recordId = newRecord.id.toString();
    log.body = JSON.stringify(newRecord);

    await this.auditService.create(newRecord);
    await this.logRepository.create(log);
  }

  async update(newRecord: CommonEntity, id?: number | string ): Promise<void> {
    const newRecordId: string = id ? id.toString() : newRecord.id.toString();

    const currentLog = await this.logRepository.findOne({
      where: {
        tableId: TabelList[newRecord.getTableName()],
        recordId: newRecordId,
      },
    });

    currentLog.recordId = newRecord.id.toString();
    const oldRecord: CommonEntity = JSON.parse(currentLog.body);
    await this.auditService.update(oldRecord, newRecord);
    currentLog.body = JSON.stringify(newRecord);
    await this.logRepository.update(currentLog);
  }

  async destroy(currentRecord: CommonEntity): Promise<void> {
    const currentLog = await this.logRepository.findOne({
      where: {
        tableId: TabelList[currentRecord.getTableName()],
        recordId: currentRecord.id.toString(),
      },
    });
    const logToDelete = new Log();
    logToDelete.id = currentLog.id;

    this.logRepository.destroy(logToDelete).catch(console.log);
    this.auditService.destroy(currentRecord).catch(console.log);
  }

}
