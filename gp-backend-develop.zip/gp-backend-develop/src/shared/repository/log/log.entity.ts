
import { RowMapper } from '../repository.interface';
import { CommonEntity } from '../../common/entity';
import { Table } from '../../decorator/table.annotation';
import { Column, OracleType } from '../../decorator/column.decorator';

@Table('CPT.TB_LOG_REGT_ATUL')
export class Log extends CommonEntity {

  @Column('NR_SEQU_LOG_REGT_ATUL')
  id: number;

  @Column('TX_CNTD_REGT_TABE', OracleType.CLOB)
  body: string;

  @Column('NR_SEQU_TABE')
  tableId: number;

  @Column('CD_REGT_TABE')
  recordId: string;

}

export const LogRow = Object.freeze({
  id: 'NR_SEQU_LOG_REGT_ATUL',
  body: 'TX_CNTD_REGT_TABE',
  tableId: 'NR_SEQU_TABE',
  recordId: 'CD_REGT_TABE',
});

export const LogTable = 'CPT.TB_LOG_REGT_ATUL';
export const LogSequence = 'CPT.SQ_LOG_REGT_ATUL.NEXTVAL';

export class LogRowMapper implements RowMapper<Log> {
	public map(row: any): Log {
    const log = new Log();
    log.id = row[LogRow.id];
    log.body = row[LogRow.body];
    log.tableId = row[LogRow.tableId];
    log.recordId = row[LogRow.recordId];

		  return log;
	}
}
