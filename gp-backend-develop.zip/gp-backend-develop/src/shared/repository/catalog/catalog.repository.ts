
import { IPayloadGP001, IPayloadGP001ReservePrimary } from './product-payload.interface';
import { CATALOG_API } from '../../../shared/constants/endpoints';
import { LogAsyncBench } from '../../utils/logger.decorator';
// tslint:disable-next-line:no-var-requires
const Client = require('node-rest-client').Client;
const payloadPath = 'cat-produtos/treasury-product-catalog/v1/payload/payload-signature';

export class CatalogRepository {
  client = new Client({
    connection: {
      rejectUnauthorized: false,
    },
  });
  readonly clientHeader = {
    headers: {'Content-Type': 'application/json'},
  };

  @LogAsyncBench()
  async getMappedProductsReservePrimary(productId: string): Promise<IPayloadGP001ReservePrimary[]> {
    return new Promise<IPayloadGP001ReservePrimary[]>( (resolve, reject) => {
    const payloadId = 'GP001';
    const statusId = 10;
    const formId = 6;
    const product = productId;
    const endPoint = `${CATALOG_API}${payloadPath}?payloadId=${payloadId}&statusId=${statusId}&formId=${formId}&productId=${product}`;
    console.info('[CatalogRepository] getMappedProducts endPoint: ', endPoint);

    this.client.get(endPoint, this.clientHeader , (data: {data: IPayloadGP001ReservePrimary[]}) => {
      console.info('[CatalogRepository] getMappedProducts: ', data);
      resolve(data.data);
    }).on('error', (e: any) => {
        console.error('[CatalogRepository] getMappedProducts Err: ', e);
        reject(e);
      });
    });

  }
  async getMappedProducts(): Promise<IPayloadGP001[]> {
    return new Promise<IPayloadGP001[]>( (resolve, reject) => {
    const payloadId = 'GP002';
    const statusId = 10;
    const endPoint = `${CATALOG_API}${payloadPath}?payloadId=${payloadId}&statusId=${statusId}`;
    console.info('[CatalogRepository] getMappedProducts endPoint: ', endPoint);

    this.client.get(endPoint, this.clientHeader , (data: {data: IPayloadGP001[]}) => {
      console.info('[CatalogRepository] getMappedProducts: ', data);
      resolve(data.data);
    }).on('error', (e: any) => {
        console.error('[CatalogRepository] getMappedProducts Err: ', e);
        reject(e);
      });
    });

  }

  @LogAsyncBench()
  async getPayloadByProductIdsAndChannel(productIds: number[] | string[], channelId: string): Promise<IPayloadGP001[]> {
    return new Promise<IPayloadGP001[]>( (resolve, reject) => {
      const endPoint = `${CATALOG_API}${payloadPath}`;
      const query = {
        payloadId: 'GP001',
        statusId: 10,
        channelId,
        productIds,
      };
      console.info('[CatalogRepository] getPayloadByProductIdsAndChannel endPoint', endPoint);
      console.info('[CatalogRepository] getPayloadByProductIdsAndChannel query', query);

      const req = this.client.post(endPoint, {
        headers: {'Content-Type': 'application/json', 'userId': 'SRV_GPOS'},
        data: query,
      }, (data: {data: IPayloadGP001[]}) => {
        console.info('[CatalogRepository] getPayloadByProductIdsAndChannel data', data);
        resolve(data.data);
      });
      req.on('error', (e: any) => {
        console.error('[CatalogRepository] getPayloadByProductIdsAndChannel Err: ', e);
        reject(e);
      });
    });

  }
}
