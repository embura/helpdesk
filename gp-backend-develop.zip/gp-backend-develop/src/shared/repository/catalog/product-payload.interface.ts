export enum GP001Props {
  productConcentrationLimit = 'TP-CONC-MAX-VAR',
}
export class IPayloadGP001 {
  productId: number;
  [GP001Props.productConcentrationLimit]: string;

  constructor(payload: Partial<IPayloadGP001>) {
    Object.assign(this, payload);
  }

}
export interface IPayloadGP001ReservePrimary {
        productId: number;
       productName: string;
       familyName: string;
       groupName: string;
       assetClassName: string;
       modalityName: string;
       underlyingName: string;
       statusId: number;
       formId: number;
       'CD-PROD': string;
       'CD-CAT': string;
       'CD-GRAU-RISC': string;
       'CD-PRAZ': string;
       'CD-OBRI-API': string;
       'CD-SITU': string;
       'VL-MINI-APLI': string;
       'VL-MIN-REAP': string;
       'TP-VOLA': string;
       'TP-CRED': string;
       'TP-RATING-CRED': string;
       'TP-GARA': string;
       'TP-DURA': string;
       'TP-PRAZ-INVE': string;
       'TP-PERD-POTE': string;
       'TP-INDX': string;
       'TP-RISC-EQVT': string;
       'TP-LIQZ': string;
       'TP-RISC-FINA-ESPH': string;
       'TP-RISC-FINA-BRSL': string;
       'TP-CMPX': string;
       'TP-EMIS': string;
       'TP-CONC-MAX-VAR': string;
       'TP-CLA-ATV': string;
       'TP-REC': string;
       'TP-RATING-PRIVATE': string;
       'CD-SUBP': string;
       'TP-CONC-MAX-PRI': string;
       'CD-PROD-SBK': string;
       'IND-IQ': string;
}
