
import { Op, IFindOptions, FindOrder, WhereOptions, LogicParam, TableRow, RowMapper } from './repository.interface';
import { oracleErrorHandler } from '../common/common.error';
import { CommonEntity } from '../common/entity';
import { SequenceRowMapper, Sequence } from '../common/sequence.entity';
import { ISanitalizer } from '../common/sanitalizer.interface';
import { CommonSanitalization } from '../sanitalizations/common.sanitalization';
import { CategoryMessage } from '../common/message.model';
import { dateToYYYMMMDD } from '../utils/parse-date';
import { SqlHandler } from '../lib/database/query-handler';

export class CommnRepository<T extends CommonEntity> {

  protected readonly commandHandler: SqlHandler<T>;
  protected readonly queryHandler: SqlHandler<T>;
  private readonly sequenceQueryHandler: SqlHandler<Sequence>;
  protected readonly sanitalizer: ISanitalizer<T>;

  constructor(public readonly TableRows: TableRow,
              public readonly TableName: string,
              protected TableSequence: string,
              protected readonly messages: CategoryMessage,
              rowMapper: RowMapper<T>,
              sanitalizer?: ISanitalizer<T>) {
    this.queryHandler = new SqlHandler(rowMapper);
    this.commandHandler = new SqlHandler();
    this.sequenceQueryHandler = new SqlHandler(new SequenceRowMapper());

    this.sanitalizer = sanitalizer ? sanitalizer : new CommonSanitalization(TableRows);

    // this.andParser.bind(this);
    // this.orParser.bind(this);
  }

  private parseSymbol = {
    [Op.eq]: this.equalParser,
    [Op.in]: this.inParser,
    [Op.like]: this.likeParser,
    [Op.gt]: this.gtParser,
    [Op.gte]: this.gteParser,
    [Op.lt]: this.ltParser,
    [Op.lte]: this.lteParser,
    [Op.between]: this.betweenParser,
  };

  async create(newEntity: CommonEntity): Promise<string | number> | never {
    const entity = Object.assign({}, newEntity);
    console.info(`INSERT ${this.parseCreate(entity)}`);
    console.info(newEntity);
    this.sanitalizer.sanitalize(entity);

    if (this.TableSequence) {
      const sequence: Sequence = await this.getSequence();
      entity.id = sequence.id;
    }

    const queryString = this.parseCreate(entity);
    const query = `INSERT ${queryString}`;

    await this.commandHandler.execute(query, entity)
      .catch(oracleErrorHandler(this.messages));

    return entity.id;
  }

  async update(entity: CommonEntity, id?: string | number): Promise<void> {
    this.sanitalizer.sanitalize(entity);

    if (id) {
      entity.oldId = id;
    }

    const queryString = this.parseUpdate(entity, id);
    const query = `UPDATE ${queryString}`;
    await this.commandHandler.execute(query, entity)
      .catch(oracleErrorHandler(this.messages));

    if (id) {
      delete entity.oldId;
    }
  }

  async findOne(params?: IFindOptions<T>): Promise<T> {
    const query = this.parseParams(params);
    return this.queryHandler.executeFirstOrNull(query, undefined)
      .catch(oracleErrorHandler(this.messages));
  }

  async findAll(params?: IFindOptions<T>, maxRows: number = 100): Promise<T[]> {
    const query = this.parseParams(params);

    return this.queryHandler.execute(query, undefined)
      .catch(oracleErrorHandler(this.messages));
  }

  async destroy(newEntity: CommonEntity): Promise<void> {
    const entity = Object.assign({}, newEntity);
    this.sanitalizer.sanitalize(entity);
    const query = 'DELETE FROM ' + this.parserDelete(entity);
    await this.commandHandler.execute(query, entity)
      .catch(oracleErrorHandler(this.messages));
  }

  private parserDelete(entity: CommonEntity): string {
    let set = '';

    // tslint:disable-next-line:forin
    for (const k in this.TableRows) {
      if (entity[k] === undefined) continue;
      set += `${this.TableRows[k]} = :${k}, `;
    }
    set = set.slice(0, -2);
    return `${this.TableName} WHERE ${set}`;
  }

  private parseParams(params?: IFindOptions<T>): string {
    let whereQuery = '';
    let oderQuery = '';
    if (params) {
      whereQuery = `WHERE ${this.parseWhere(params.where)}`.replace(/WHERE\s*$/, '').trim();
      oderQuery = this.parseOrder(params.order);
    }

    return this.parseLimit(params, whereQuery, oderQuery);
  }

  private parseOrder(orders?: FindOrder[]): string {
    let result = '';
    if (!orders) {
      return result;
    }

    const totalColumns = orders.length;
    const hasMoreThanOneSortingColumn = totalColumns > 1;
    orders.forEach((order, index): void => {
      result += `${this.TableRows[order[0]]} ${order[1]}${hasMoreThanOneSortingColumn && index < totalColumns - 1 ? ', ' : ''}`;
    });

    result = 'ORDER BY ' + result;

    return result;
  }

  private parseWhere(where?: WhereOptions<any>): string {
    let result = '';
    if (!where) {
      return result;
    }

    const rootOperatoions = Object.getOwnPropertySymbols(where);
    if (rootOperatoions) {
      rootOperatoions.forEach(operation => {
        // result += '(' + this.rootOperator[operation](where[operation] as WhereOptions<T>[]) + ') AND ';
        if (operation === Op.or) {
          result += '(' + this.orParser(where[operation as any] as WhereOptions<T>[]) + ') AND ';
          return;
        }
        result += '(' + this.andParser(where[operation as any] as WhereOptions<T>[]) + ') AND ';
      });
    }

    Object.keys(where).forEach((k: string): void => {
      const param: any = where[k];
      const column = this.TableRows[k];

      const ops = this.getOperators(param);
      for (const op of ops) {
        result += this.parseSymbol[op as any](column, param, op) + ' AND ';
      }
    });

    // result = 'WHERE ' + result.replace(/AND\s*$/, '').trim();
    result = result.replace(/AND\s*$/, '').trim();

    return result;
  }

  private parseColumns(): string {
    let cols = '';
    Object.keys(this.TableRows).forEach(k => {
      switch (k) {
        case 'body':
          cols += `TO_CHAR(${this.TableRows[k]}) as ${this.TableRows[k]}, `;
          break;
        default:
          cols += `${this.TableRows[k]}, `;
      }
    });
    return cols.slice(0, -2);
  }

  private parseLimit(params: IFindOptions<T>, whereQuery: string, oderQuery: string): string {
    const columns = this.parseColumns();
    let result = `SELECT ${columns} FROM ${this.TableName} ${whereQuery}`.trim();
    result = `${result} ${oderQuery}`.trim();

    if (!params || (!params.limit && !params.offset)) {
      return result;
    }

    const offset = params.offset ? ` RN > ${params.offset} AND` : '';
    const _offsetCount = params.offset ? params.offset : 0;
    const limit = params.limit ? `RN < ${params.limit + _offsetCount + 1}` : '';
    const queryString = `WHERE${offset} ${limit}`.replace(/AND\s*$/, '');
    result = result.slice(7, result.length);
    return `SELECT ${columns} FROM (SELECT ROWNUM as RN, ${result}) ${queryString}`;
  }

  protected parseCreate(entity: CommonEntity): string {
    let into = '';
    let values = '';

    // tslint:disable-next-line:forin
    for (const k in entity) {
      if (entity[k] === undefined || !this.TableRows[k]) {
        delete entity[k];
        continue;
      }
      into += `${this.TableRows[k]}, `;
      values += `:${k}, `;
    }
    into = into.slice(0, -2);
    values = values.slice(0, -2);
    return `INTO ${this.TableName} (${into}) VALUES (${values})`;
  }

  protected parseUpdate(entity: CommonEntity, id?: string | number): string {
    let set = 'SET ';

    // tslint:disable-next-line:forin
    for (const k in entity) {
      if ((k === 'id' && !id) || !this.TableRows[k]) continue;
      set += `${this.TableRows[k]} = :${k}, `;
    }
    set = set.slice(0, -2);

    return `${this.TableName} ${set} WHERE ${this.TableRows.id} = ${id ? ':oldId' : ':id'}`;
  }

  private equalParser(column: string, param: LogicParam): string {
    if (typeof param === 'string') {
      param = `'${param}'`;
      return `${column} = ${param}`;
    }

    if (param instanceof Date) {
      param = `'${dateToYYYMMMDD(param)}'`;
      return `${column} = TO_DATE(${param}, 'YYYYMMDD')`;
    }

    return `${column} = ${param}`;
  }

  private inParser(column: string, param: any, op: symbol): string {
    const list = param[op];
    if (!(list instanceof Array)) {
      throw new TypeError('IN query requires an Array.');
    }

    const $in = list
      .reduce<string>((res: string, str: string): string => `${res}'${str}', `, '')
      .slice(0, -2);

    return `${column} IN (${$in})`;
  }

  private orParser(conditions: WhereOptions<T>[]): string {
    let result = '';
    conditions.forEach(cond => {
      result += `(${this.parseWhere(cond)}) OR `;
    });

    return result.replace(/OR\s*$/, '').trim();
  }

  private andParser(conditions: WhereOptions<T>[]): string {
    let result = '';
    conditions.forEach(cond => {
      result += `(${this.parseWhere(cond)}) AND `;
    });

    return result.replace(/AND\s*$/, '').trim();
  }

  private likeParser(column: string, param: any, op: symbol): string {
    return `UPPER(${column}) LIKE UPPER('%${param[op]}%')`;
  }

  // tslint:disable-next-line:ban-types
  private getOperators(param: Object): symbol[] {
    if (typeof param === 'string' || typeof param === 'number' || param instanceof Date) {
      return [Op.eq];
    }

    return Object.getOwnPropertySymbols(param);
  }

  private gtParser(column: string, param: any, op: symbol): string {
    return `${column} > ${param[op]}`;
  }

  private gteParser(column: string, param: any, op: symbol): string {
    return `${column} >= ${param[op]}`;
  }

  private ltParser(column: string, param: any, op: symbol): string {
    return `${column} < ${param[op]}`;
  }

  private lteParser(column: string, param: any, op: symbol): string {
    return `${column} <= ${param[op]}`;
  }

  private betweenParser(column: string, param: any, op: symbol): string {
    const list = param[op];

    if (!Array.isArray(list)) {
      throw new TypeError('BETWEEN operator requires an argument of Array data type.');
    }

    if (list.length !== 2) {
      throw new TypeError('BETWEEN operator requires the Array to contain exactly 2 items.');
    }

    if (typeof list[0] !== typeof list[1]) {
      throw new TypeError('BETWEEN operator requires the Array items to be of the same data type.');
    }

    return `(${column} BETWEEN ${list[0]} AND ${list[1]})`;
  }

  protected async getSequence(): Promise<Sequence> {
    const query = `SELECT ${this.TableSequence} FROM DUAL`;
    return this.sequenceQueryHandler.executeFirstOrNull(query, undefined)
      .catch(oracleErrorHandler(this.messages));
  }

  async destroyBy(options: WhereOptions<T>): Promise<void> {
    const query = this.parseDeleteBy(options);
    await this.commandHandler.execute(query, undefined)
      .catch(oracleErrorHandler(this.messages));
  }

  private parseDeleteBy(options: WhereOptions<T>, useAndOpForMoreThanOneColumn: boolean = true): string {
    let query = `DELETE FROM ${this.TableName} WHERE `;
    query += this.parseWhere(options);

    return query;
  }
}
