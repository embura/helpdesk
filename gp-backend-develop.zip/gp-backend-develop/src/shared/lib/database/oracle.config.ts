import * as fs from 'fs';
import { IConnection } from 'oracledb';
const { DATABASE_CONNECTION, DATABASE_USERNAME, DATABASE_PASSWORD } = process.env;

function initSession(connection: IConnection, requestedTag: any, cb: any): void {
  const preConfig = `ALTER SESSION SET NLS_SORT = BINARY_AI`;
  console.info(preConfig);
  connection.execute(preConfig);
  cb();
}

export const dbConfig: any = {
  user: fromFileOrRaw(DATABASE_USERNAME),
  password: fromFileOrRaw(DATABASE_PASSWORD),
  connectString: DATABASE_CONNECTION,
  poolMin: 10,
  poolMax: 20,
  poolTimeout: 30,
  poolIncrement: 2,
  sessionCallback: initSession,
  // stmtCacheSize?: number;
};

function fromFileOrRaw(target: string): string {
  if (fs.existsSync(target) ){
    return fs.readFileSync( target ).toString();
  }
  return target;
}