import oracledb = require('oracledb');
import {IExecuteOptions, IExecuteReturn } from 'oracledb';

import { CommonEntity } from '../../common/entity';
import { RowMapper } from '../../repository/repository.interface';

export class SqlHandler<T> {
  readonly retryCount = 3;
  static showSql = false;

  constructor(private readonly mapper?: RowMapper<T>) {
  }

	protected transform(row: any): T {
    if (this.mapper) {
      return this.mapper.map(row);
    }
		  return row;
  }

  async executeFirstOrNull(query: string, entity?: CommonEntity, options?: IExecuteOptions): Promise<T | null> {
    const result = await this.execute(query, entity, options);
    return result[0] ? result[0] : null;
  }

  async execute(query: string, entity?: CommonEntity, _options?: IExecuteOptions): Promise<T[]> {
    const options = Object.assign({}, _options);
    const binds = Object.assign({}, entity);
    delete binds.__proto__;
    options.outFormat = oracledb.OBJECT;
    options.autoCommit = true;

    if (SqlHandler.showSql){
      console.info('[QueryHandle][INFO] query: ', query);
      console.info('[QueryHandle][INFO] binds: ', binds);
    }

    const conn = await oracledb.getConnection();
    const result: IExecuteReturn = await this.sendToDatabase( () => conn.execute(query, binds, options) )
      .catch ((err: any) => {
        conn.close();
        console.error('[QueryHandle][ERROR] query: ', query);
        console.error('[QueryHandle][ERROR] binds: ', binds);
        throw new Error(`Database Execution Error: ${err}`);
      });

    conn.close();
    if (result.rows === undefined) {
      return [];
    }
    return this.transformAll(result.rows);
  }

  private transformAll(rows: any[]): any[] {
    return rows.map( r => this.transform( r ));
  }

  // tslint:disable-next-line:ban-types
  private sendToDatabase(func: Function): Promise<any> {
    let promise = Promise.reject().catch(() => func());
    for (let i = 0; i < this.retryCount; i++) {
      promise = promise.catch(err => {
        console.info('Database Execution Failure', err);
        console.info(`Database Execution Retrying: ${i + 1}`);
        return func();
      });
    }
    return promise;
  }
}