import { ISanitalizer } from '../common/sanitalizer.interface';
import { CommonEntity } from '../common/entity';
import { TableRow } from '../repository/repository.interface';

export class CommonSanitalization implements ISanitalizer<CommonEntity> {
  constructor(private readonly referenceType: TableRow) { }
  sanitalize(obj: CommonEntity): void {
    Object.keys(obj).forEach((key) => {
      const hasKey: string = Object.keys(this.referenceType).find(keyRet => keyRet === key);

      if (typeof (obj[key]) === 'string'){
        obj[key] = obj[key].trim();
      }

      if (!hasKey){
        delete obj[key];
      }
    });
  }
}