import { Writable } from 'stream';
// tslint:disable-next-line:no-var-requires
const Client = require('node-rest-client').Client;

export class BDMstream extends Writable {

  client = new Client();
  writable: true;

  // tslint:disable-next-line:ban-types
  write(message: string | Object): boolean {
    const log = Object.assign({}, logTemplate);
    if (typeof message === 'string') {
      const logInfo = JSON.parse(message);
      log.data.logmessage = logInfo.msg;
      // log.data.sendtime = logInfo.time;
    } else {
      log.data.logmessage = JSON.stringify(message);
    }

    const req = this.client.post('http://srvbigpvlbr13.bs.br.bsch:2276/run/PVD', log, (data: any, response: any) => {
      // tslint:disable-next-line:no-console
    });
    req.on('error', (e: any) => {
      // tslint:disable-next-line:no-console
      console.error('!! BDM error !!');
    });
    return false;
  }

}

export const logTemplate = {
  data: {
    api: 'user',
    // environment: process.env.NODE_ENV || 'production',
    url: 'getUser',
    request_id: '00002',
    projectname: 'GPOS',
    method: 'getUser',
    retcode: '400',
    status: 'ERROR',
    correlation_id: '12312',
    receivetime: 1231,
    processtime: 123,
    sendtime: '2018-05-05T11:11:10.898Z',
    queueduration: 55,
    executionduration: 122,
    totalduration: 177,
    operation: 'HUB',
    podname: '13212_W',
    region: '1',
    logmessage: 'Error time-out',
  },
  headers: {
    'Content-Type': 'application/json',
  },
};