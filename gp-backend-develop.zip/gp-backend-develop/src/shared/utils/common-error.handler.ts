
export function commonErrHadler( msg: string): (err: any) => never {
  return (err: any): never => {
    console.info(msg);
    console.error(err);
    throw err;
  };
}