import { Writable } from 'stream';
import * as bunyan from 'bunyan';

export class CleanStdOut extends Writable {
  write(message: string ): boolean {
    const level = bunyan.nameFromLevel[JSON.parse(message).level];

    const colorSet = {
      reset: '\x1b[0m',
      red: '\x1b[31m',
      green: '\x1b[32m',
      yellow: '\x1b[33m',
      blue: '\x1b[34m',
    };

    const colorBg = {
      bgBlack: '\x1b[40m',
      bgRed: '\x1b[41m',
      bgGreen: '\x1b[42m',
      bgYellow: '\x1b[43m',
      bgBlue: '\x1b[44m',
      bgMagenta: '\x1b[45m',
      bgCyan: '\x1b[46m',
      bgWhite: '\x1b[47m',
    };

    const color = (cor: string, type: string, msg: string, colorBackground = ''): void => {
      // tslint:disable-next-line:no-console
      console.log(`${cor}${colorBackground}[${type.toUpperCase()}]${colorSet.reset}${msg}`);
    };

    switch (level){
      case 'info':
        color(colorSet.green, level, JSON.parse(message).msg);
        break;
      case 'warn':
        color(colorSet.yellow, level, JSON.parse(message).msg);
        break;
      case 'error':
        color(colorSet.red, level, JSON.parse(message).msg, colorBg.bgYellow);
        break;
    }

    return true;
  }
}