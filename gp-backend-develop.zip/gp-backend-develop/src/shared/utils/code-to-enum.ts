export function codeToEnum<T>(codeMapper: any, code: string | number): T | never{
  const props = Object.keys(codeMapper);

  for ( const k of props) {
    if (codeMapper[k] === code) {
      return k as any;
    }
  }

  throw new TypeError(`There is no "${code}" in ${codeMapper}`);
}