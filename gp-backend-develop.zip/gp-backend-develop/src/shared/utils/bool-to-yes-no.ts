export enum BooleanString {
  Yes = 'Y',
  No = 'N',
}
export function toBoolString(value: boolean): BooleanString {
  return value ? BooleanString.Yes : BooleanString.No;
}

export function fromBoolString(value: BooleanString): boolean {
  if (value === 'Y') {
    return true;
  } else {
    return false;
  }
}