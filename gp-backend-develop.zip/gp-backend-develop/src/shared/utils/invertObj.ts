export function invertObj(obj: any): any {
  const inverted: any = {};
  const object: any = Object;
  for (const entry of object.entries(obj)) {
    inverted[entry[1]] = entry[0];
  }
  return inverted;
}