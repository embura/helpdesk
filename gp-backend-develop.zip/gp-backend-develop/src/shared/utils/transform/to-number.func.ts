export function toNumber(obj: any, defaultValue?: number): number {
  if ( (!obj || isNaN(obj)) && !defaultValue) {
    throw new TypeError('Object is not convertable to number. Please check the param or add a defaultValue.');
  }

  return obj ? +obj : defaultValue;
}