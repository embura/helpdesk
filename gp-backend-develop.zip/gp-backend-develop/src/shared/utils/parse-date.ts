export function dateToYYYMMMDD(dateObj: Date): string {

  if (Object.prototype.toString.call(dateObj) === '[object Date]' && isNaN(dateObj.getTime())) {
    dateObj = new Date();
  }

  const [dateString] = dateObj.toJSON().split('T');
  return dateString.replace(/-/g, '');
}

export function parseYYYYMMDD(dateString: number): Date {
  const dateStr = dateString.toString();
  return new Date(dateStr.substr(0, 4) as any, (dateStr.substr(4, 2) as any - 1), dateStr.substr(6, 2) as any);
}

export function getDateToday(): Date {
  const today = new Date();
  return new Date(today.toDateString());
}

export function getDateYesterday(): Date {
  const today = new Date();
  today.setDate(today.getDate() - 1);
  return new Date( today.toDateString() );
}