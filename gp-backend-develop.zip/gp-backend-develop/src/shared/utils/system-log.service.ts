import * as bunyan from 'bunyan';
import * as mkdirp from 'mkdirp';
import { CleanStdOut } from './clean-stdout.stream';

export const systemLog = SystemLogServiceBuilder();

function SystemLogServiceBuilder(): bunyan {
  mkdirp.sync('./logs');
  const streams: bunyan.Stream[] = [
    {
      level: 'debug',
      stream: new CleanStdOut(),       // log INFO and above to stdout
    },
    {
      level: 'info',
      path: './logs/all-logs.log',
    },
  ];

  if (process.env.NODE_ENV !== 'local' && process.env.NODE_ENV !== 'test') {
    streams.push({
      level: 'info',
      stream: process.stderr,
    });
  }

  // const loggerConfig = Object.assign(logTemplate, {streams});
  return bunyan.createLogger({
    name: 'GPOS',
    streams,
  });

}