
export interface AsyncBenchOptions {
  logToBDM: boolean;
}

export function LogAsyncBench(options?: AsyncBenchOptions): (target: any, name: string, descriptor: PropertyDescriptor) => void {
  return (target: any, name: string, descriptor: PropertyDescriptor): PropertyDescriptor => {
    const delegate = descriptor.value;

    // tslint:disable-next-line:typedef
    descriptor.value = async function() {
      const initTime = Date.now();
      const res = await delegate.apply(this, arguments);
      const logMessage = `[${name}] - ${Date.now() - initTime}ms`;
      // tslint:disable-next-line:no-console
      console.log(logMessage);
      if ( options && options.logToBDM && (process.env.NODE_ENV !== 'local' && process.env.NODE_ENV !== 'test')) {
        console.info(logMessage);
      }
      return res;
    };

    return descriptor;
  };
}
