export function isJSDate(obj: any): boolean {
  return obj instanceof Date;
}