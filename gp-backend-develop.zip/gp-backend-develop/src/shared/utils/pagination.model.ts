export class Pagination {

  public currentPage: number;
  public nextPage: number;
  public previousPage: number;
  public itemPerPage: number;
  public totalItems: number;
  public totalPages: number;

  constructor(){
    this.currentPage = 0;
    this.nextPage = 0;
    this.previousPage = 0;
    this.itemPerPage = 0;
    this.totalItems = 0;
    this.totalPages = 0;
  }

  update(totalItems: number): void {
    const total = Math.ceil(totalItems / this.itemPerPage);

    this.nextPage = this.currentPage < total ? this.currentPage + 1 : this.currentPage;
    this.previousPage = this.currentPage > 1 ? this.currentPage - 1 : 1;
    this.totalItems = totalItems;
    this.totalPages = total;
  }
}
