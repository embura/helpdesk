import { CommonEntity } from '../common/entity';
import { IValidation } from '../common/validation.interface';
import { CommnRepository } from '../repository/common.repository';
import { CategoryMessage } from '../common/message.model';

export class CodeValidation<T extends CommonEntity> implements IValidation<T> {
  constructor(private repository: CommnRepository<T>, private messages: CategoryMessage) { }

  async validate(obj: T, code?: string | number): Promise<void> {
    if (!code) {
      code = obj.code;
    }
    const hasEntity = await this.repository.findOne({where: {code}} as any);
    if (hasEntity && obj.id !== hasEntity.id) throw this.messages.error.duplicatedCode;
  }
}