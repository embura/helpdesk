import { IValidation } from '../common/validation.interface';
import { CommonEntity } from '../common/entity';
import { CommnRepository } from '../repository/common.repository';
import { CategoryMessage } from '../common/message.model';

export class NameValidation<T extends CommonEntity> implements IValidation<T> {
  constructor(private repository: CommnRepository<T>, private messages: CategoryMessage) { }
  async validate(obj: T, id?: string | number): Promise<void> {
    const name = obj.name.trim();
    const hasEntity = await this.repository.findOne({where: {name}} as any);
    if (hasEntity && hasEntity.id !== obj.id) throw this.messages.error.duplicatedName;
  }
}