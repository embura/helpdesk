export function enumValidationMsgBuilder(obj: any): {message: string} {
  const message = `must be one of each: ${Object.keys(obj)}`;
  return {message};
}