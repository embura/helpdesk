import { Module } from '@nestjs/common';
import { LogRepository } from './repository/log/log.repository';
import { LogService } from './repository/log/log.service';
import { AuditRepository } from './repository/audit/audit.repository';
import { AuditService } from './repository/audit/audit.service';
import { AuditController } from './repository/audit/audit.controller';
import { BaseDateRepository } from '../base-date/base-date.repository';
import { SegmentRepository } from '../segment/segment.repository';
import { PdiPositionRepository } from './repository/pdi-position/pdi-position.repository';
import { CatalogRepository } from './repository/catalog/catalog.repository';

const sharedModules = [
  PdiPositionRepository,
  CatalogRepository,
  SegmentRepository,
  BaseDateRepository,
  LogRepository,
  LogService,
  AuditRepository,
  AuditService,
];

const sharedControllers = [
  AuditController,
];

@Module({
    controllers: [ ...sharedControllers ],
    components: [...sharedModules],
    exports: [...sharedModules],
})
export class SharedModule {}