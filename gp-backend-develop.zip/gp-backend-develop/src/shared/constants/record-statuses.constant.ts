export class RecordStatuses {
  public static readonly ACTIVE: number = 10;
  public static readonly INACTIVE: number = 5;
  public static readonly EXCLUDED: number = 0;
}
