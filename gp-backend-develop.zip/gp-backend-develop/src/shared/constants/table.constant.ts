interface ITableList {
  readonly [key: string]: number;
}

export const TabelList: ITableList = {
};
