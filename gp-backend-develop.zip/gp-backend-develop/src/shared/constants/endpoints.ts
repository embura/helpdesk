const env: string = process.env.NODE_ENV || 'local';
const urlInvestHubPre = 'https://esb-invest.hub.santanderbr.pre.corp/';
export const END_POINTS = {
  production: 'https://cpt.paas.santanderbr.corp/',
  homolog: 'https://cpt.paas.santanderbr.pre.corp/',
  development: 'https://cpt.paas.isbanbr.dev.corp/',
  local: 'http://local.santanderbr.pre.corp:8002/',
};

export const END_POINTS_BUS = {
  production: 'https://bus.paas.santanderbr.corp/',
  homolog: 'https://bus.paas.santanderbr.pre.corp/',
  development: 'https://bus.paas.isbanbr.dev.corp/',
  local: 'https://bus.paas.santanderbr.pre.corp/',
};

export const HUB_END_POINTS = {
  production: 'https://esb-invest.hub.santanderbr.corp/',
  homolog: urlInvestHubPre,
  development: urlInvestHubPre,
  local: urlInvestHubPre,
};

export const CATALOG_API = `${(END_POINTS as any)[env]}`;
export const BUS_API = `${(END_POINTS_BUS as any)[env]}`;
export const SERVICE_HUB = `${(HUB_END_POINTS as any)[env]}`;