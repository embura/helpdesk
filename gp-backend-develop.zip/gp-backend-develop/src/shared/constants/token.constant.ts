export const DB_TOKEN = 'OracleConnectionToken';
export const PRODUCT_REPO_TOKEN = 'ProductRepositoryToken';
