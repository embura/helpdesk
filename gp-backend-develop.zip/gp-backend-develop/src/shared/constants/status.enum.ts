export enum SystemStatus {
  NotInitialized = 1,
  Contingency = 2,
  Error = 3,
  UpTodate = 4,
  Unavailable = 5,
  Completed = 20,
  Pending = 21,
  Cancelled = 22,
}

export enum SystemStatusMessage {
  OpenWithSuccess = 'Sistema aberto com sucesso.',
  AlreadyOpen = 'Sistema já foi aberto com sucesso.',
  SystemUnavailable = 'Sistema aberto com sucesso.',
}

export class StatusModel {
  id: SystemStatus;
  desc: string;
}

export const SystemStatusCode = Object.freeze<{ [key in SystemStatus ]: string }>({
  [SystemStatus.NotInitialized]: 'not-initialized',
  [SystemStatus.Contingency]: 'contingency',
  [SystemStatus.Error]: 'error',
  [SystemStatus.Unavailable]: 'unavailable',
  [SystemStatus.UpTodate]: 'up-to-date',
  [SystemStatus.Completed]: 'completed',
  [SystemStatus.Cancelled]: 'cancelled',
  [SystemStatus.Pending]: 'pending',
});