export class Status {

  public code: number;
  public message: string;

  constructor(code: number, message: string) {
    this.code = code;
    this.message = message;
  }

}

export class ResponseObject<T> {

  return: {
    code: number,
    message: string,
  };
  data: T;

  constructor(code: number, message: string, data: T) {
    this.return = { message, code };
    this.data = data;
  }

}