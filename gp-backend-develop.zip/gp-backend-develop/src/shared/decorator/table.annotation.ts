import { TABLE_NAME_KEY } from './decorator.constant';

export function Table(tableName: string): (target: any) => void {
  return (target: any): void => {

    Reflect.defineMetadata(TABLE_NAME_KEY, tableName, target.prototype);
  };
}