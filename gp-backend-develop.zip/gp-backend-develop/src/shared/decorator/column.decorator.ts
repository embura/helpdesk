import { COLUMN_NAME_KEY, COLUMN_DATA_TYPE_KEY } from './decorator.constant';

export enum OracleType {
  CLOB =  'CLOB',
}
type OracleDataType = OracleType.CLOB;

export function Column(columnName: string, type?: OracleDataType): (a: any, b: string) => void {
  return (target: any, propertyKey: string): void => {

    Reflect.defineMetadata(COLUMN_NAME_KEY, columnName, target, propertyKey);
    if (type) {
      Reflect.defineMetadata(COLUMN_DATA_TYPE_KEY, type, target, propertyKey);
    }
  };
}
