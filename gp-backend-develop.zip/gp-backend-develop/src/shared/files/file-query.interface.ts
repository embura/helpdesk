export interface IFileQuery {
  fileType: string;
  fileAcronym: string;
}