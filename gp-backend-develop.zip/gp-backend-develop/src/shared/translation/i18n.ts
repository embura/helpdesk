import { SystemDictionary, LangType, SysLang } from './system.dict';

class I18n {
  constructor(private lang: LangType) {}

  __(word: string): string {
    let res = word;
    if (SystemDictionary[word] && SystemDictionary[word][this.lang]) {
      res = SystemDictionary[word][this.lang];
    }
    return res;
  }

}

export const dictPt = new I18n(SysLang.ptBr);
