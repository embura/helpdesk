import { AuditAction } from '../repository/audit/audit.entity';

export const dictAction: { readonly [key: string]: string} = {
  [AuditAction.Create]: 'Criação',
  [AuditAction.Edit]: 'Edição',
  [AuditAction.Delete]: 'Deleção',
};

export const dictStatus: { readonly [key: string]: string} = {
  0: 'Excluido',
  5: 'Inativo',
  10: 'Ativo',
};
