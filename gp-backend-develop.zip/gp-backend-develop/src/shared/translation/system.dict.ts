export enum SysLang {
  ptBr = 'ptBr',
}

export type LangType = SysLang.ptBr;

export const SystemDictionary: DictionatyType = {
  id: {
    [SysLang.ptBr]: 'ID',
  },
  code: {
    [SysLang.ptBr]: 'Código',
  },
  name: {
    [SysLang.ptBr]: 'Nome',
  },
  date: {
    [SysLang.ptBr]: 'Data',
  },
  actionDate: {
    [SysLang.ptBr]: 'Data da Ação',
  },
  statusId: {
    [SysLang.ptBr]: 'Estado',
  },
};

export interface DictionatyType{
  [key: string]: {
    [SysLang.ptBr]: string;
  };
}
