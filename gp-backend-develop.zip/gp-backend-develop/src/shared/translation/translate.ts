import { Audit, AuditAction } from '../repository/audit/audit.entity';
import { dictPt } from './i18n';
import { dictAction, dictStatus } from './action.dict';

export function translateEntityProperty(audit: Audit): Audit {
  if (audit.name === 'statusId') {
    audit.newValue = audit.newValue ? dictStatus[audit.newValue] : audit.newValue;
    audit.oldValue = audit.oldValue ? dictStatus[audit.oldValue] : audit.oldValue;
  }
  audit.name = dictPt.__(audit.name);
  audit.actionType = dictAction[audit.actionType] as AuditAction;
  return audit;
}
