import { CommonEntity } from './entity';

export interface ISanitalizer<T> {
  sanitalize(obj: T | CommonEntity): void;
}