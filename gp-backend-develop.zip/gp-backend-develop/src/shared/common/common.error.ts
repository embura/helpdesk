import { InternalServerErrorException, BadRequestException, HttpStatus } from '@nestjs/common';
import { CategoryMessage } from './message.model';

export interface IServiceError {
  code: number;
  message: string;
}

export function ServiceErrorHandler<T>(err: IServiceError): never {
  console.error('[CommonError]ServiceErrorHandler: ', err.message);
  switch (err.code) {
    case HttpStatus.BAD_REQUEST:
      throw new BadRequestException(err.message);

    default:
      throw new InternalServerErrorException(err.message);
  }

}

export function oracleErrorHandler<T>(msg: CategoryMessage): (err: string) => never {
  return (err: string) => {
    const _err: IServiceError = {
      code: HttpStatus.INTERNAL_SERVER_ERROR,
      message: msg.error.oracle + err,
    };
    throw _err;
  };
}