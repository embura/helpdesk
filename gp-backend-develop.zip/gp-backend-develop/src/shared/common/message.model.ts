export const CategoryTag: IMessage = {
  ptBr: 'Categoria',
  system: 'Category',
};

export interface IMessage {
  readonly system: string;
  readonly ptBr: string;
}

export class CategoryMessage {

  success: {
    create: string,
    found: string,
    update: string,
    destroy: string,
  };
  error: {
    oracle: string,
    duplicatedName: string,
    duplicatedId: string,
    duplicatedCode: string,
    emptyName: string,
    notFound: string,
    constrains: string,
    invalidId: string,
    invalidOrder: string,
    invalidRequired: string,
    productFormCurrentlyInUse: string,
    excludedItem: string,
    canceledItem: string,
    [x: string]: string,
  };

  constructor(groupTag: IMessage, entity: IMessage) {
    this.success = {
      create: `[${groupTag.ptBr}] Novo registro ${entity.ptBr} foi criado com sucesso.`,
      found: `[${groupTag.ptBr}] Registro ${entity.ptBr} encontrado com sucesso `,
      update: `[${groupTag.ptBr}] Registro ${entity.ptBr} foi atualizado com sucesso.`,
      destroy: `[${groupTag.ptBr}] Registro ${entity.ptBr} foi excluido com sucesso.`,
    };

    this.error = {
      oracle: `[${entity.system}Service] Erro no sistema. Entre em contato com suporte técnico. - `,
      emptyName: `[${entity.system}Service] É necessário o nome do "${entity.system}".`,
      duplicatedName: `[${entity.system}Service] Encontrado o nome do "${entity.system}" existente.`,
      duplicatedId: `${entity.system} Encontrado o código do "${entity.system}" existente.`,
      duplicatedCode: `${entity.system} Encontrado o código do "${entity.system}" existente.`,
      notFound: `[${entity.system}Service] Não foi possivel encontrar o registro "${entity.system}".`,
      constrains: `[${entity.system}Service] Não foi possivel encontrar o registro relacionado ao "${entity.system}".`,
      invalidId: `[${entity.system}Service] Valor para o campo id inválido para "${entity.system}".`,
      invalidOrder: `[${entity.system}Service] Valor para o campo ordem inválido para "${entity.system}".`,
      invalidRequired: `[${entity.system}Service] Valor para o campo de obrigatoriedade inválido para "${entity.system}".`,
      productFormCurrentlyInUse : `[${entity.system}Service] O formulário não pode ser editado pois está em uso por um ou mais produtos.".`,
      excludedItem : `[${entity.system}Service] O item não pode ser alterado pois está excluído.".`,
      canceledItem: `[${entity.system}Service] O item não pode ser alterado pois está cancelado.".`,
    };
  }
}