export interface Mapper<T> {
  [ key: number ]: T;
}