import { TABLE_NAME_KEY, COLUMN_NAME_KEY, COLUMN_DATA_TYPE_KEY } from '../decorator/decorator.constant';
import { TableRow } from '../repository/repository.interface';

export class CommonEntity {
  [column: string]: any;

  getTableName(): string {
    return Reflect.getMetadata(TABLE_NAME_KEY, this);
  }

  getColumns(): TableRow {
    const keys = Object.keys(this);
    const column: TableRow = {};
    keys.forEach((k): void => {
      (column as any)[k] = Reflect.getMetadata(COLUMN_NAME_KEY, this, k);
    });
    return column;
  }

  getColumnType(key: string): string {
    return Reflect.getMetadata(COLUMN_DATA_TYPE_KEY, this, key);
  }

  updateParams(param: CommonEntity): void {
    // initialize
    Object.keys(this).forEach((key: string) => {
      this[key] = undefined;
    });

    // passing properties
    Object.keys(param).forEach((key: string) => {
      this[key] = param[key];
    });
  }
}
