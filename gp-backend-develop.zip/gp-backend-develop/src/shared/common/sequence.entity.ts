import { CommonEntity } from './entity';
import { RowMapper } from '../repository/repository.interface';

export class Sequence extends CommonEntity {
  id: string;
}

export const SequenceRow = Object.freeze({
  id: 'NEXTVAL',
});

export class SequenceRowMapper implements RowMapper<Sequence> {
  public map(row: any): Sequence {
    const sequence = new Sequence();
    sequence.id = row[SequenceRow.id];

    return sequence;
  }
}