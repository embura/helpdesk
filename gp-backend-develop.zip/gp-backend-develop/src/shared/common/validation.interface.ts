export interface IValidation<T> {
  validate(obj: T, id?: string | number): Promise<void>;
}