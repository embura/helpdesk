import { IServiceError } from './common.error';
import { CommnRepository } from '../repository/common.repository';
import { FindOrder, Order } from '../repository/repository.interface';
import { CommonEntity } from './entity';
import { IQuery, queryStringToWhere } from './query.interface';
import { IValidation } from './validation.interface';
import { CategoryMessage } from './message.model';

export class CommonRepositoryService<T extends CommonEntity>{

  protected defaultOrder: FindOrder | undefined = ['name', Order.ASC];
  protected messages: CategoryMessage;
  protected repository: CommnRepository<T>;
  protected validation: IValidation<T>;

  async create(obj: T): Promise<T> {
    if (this.validation) {
      const newObj = Object.assign({}, obj);
      delete newObj.id;
      await this.validation.validate(newObj)
        .catch(err => {
          if (err.code) {
            throw err;
          }

          throw this.badRequest(err);
        });
    }

    const id = await this.repository.create(obj);
    const newEntity = await this.findById(id);

    // await this.logService.create(newEntity);

    return newEntity;
  }

  async findById(id: number | string | Date): Promise<T> {
    const ret = this.repository.findOne({ where: { id } } as any);
    return ret;
  }

  async findByName(name: string): Promise<T> {
    return await this.repository.findOne({ where: { name } } as any);
  }

  async findAll(param: IQuery, maxRows = 100): Promise<T[]> {
    const where = queryStringToWhere(param);
    if (!where.order) {
      where.order = [this.defaultOrder];
    }
    return await this.repository.findAll(where, maxRows);
  }

  async update(obj: T, id?: number | string): Promise<T> {
    if (this.validation) {
      await this.validation.validate(obj)
        .catch(err => {
          if (err.code) {
            throw err;
          }

          throw this.badRequest(err);
        });
    }

    const persisted = await this.findById(id ? id : obj.id);
    if (!persisted) throw this.badRequest(this.messages.error.notFound);
    persisted.updateParams(obj);

    await Promise.all([
      this.repository.update(persisted, id),
      // this.logService.update(persisted, id),
    ]);

    return await this.findById(obj.id);
  }

  protected badRequest(msg: string): IServiceError {
    return {
      code: 400,
      message: msg,
    };
  }
}
