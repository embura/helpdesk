// Commom Imports
import {
  Get, Post, Body, Param, Res,
  BadRequestException, HttpStatus, Put, Query,
} from '@nestjs/common';
import { Response } from 'express';
import { ServiceErrorHandler } from './common.error';
import { HttpResponse } from '../http.response';
import { Status } from '../status.entity';
import { CommonRepositoryService } from './repository.service';
import { CommonEntity } from './entity';
import { IQuery } from './query.interface';
import { CategoryMessage } from './message.model';

export class CommonController<T extends CommonEntity> {

  constructor(
    protected readonly domainService: CommonRepositoryService<T>,
    protected readonly messages: CategoryMessage) {
  }

  @Get()
  async findAll(@Res() res: Response, @Query() query: IQuery): Promise<Response> {

    const entities = await this.domainService.findAll(query)
      .catch(ServiceErrorHandler);

    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, this.messages.success.found), entities));

  }

  @Post()
  async create(@Res() res: Response, @Body() entity: T): Promise<Response> {
    if (entity.name === ''){
      throw new BadRequestException(this.messages.error.emptyName);
    }

    const newEntity = await this.domainService.create(entity)
      .catch(ServiceErrorHandler);

    return res.status(HttpStatus.CREATED).json(
      new HttpResponse(new Status(0, this.messages.success.create), newEntity));
  }

  @Get(':id')
  async findById(@Res() res: Response, @Param('id') id: number): Promise<Response> {

    const entity = await this.domainService.findById(id)
      .catch(ServiceErrorHandler);

    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, this.messages.success.found), entity));
  }

  @Put()
  async update(@Res() res: Response, @Body() entity: T): Promise<Response> {
    if (entity.name === ''){
      throw new BadRequestException(this.messages.error.emptyName);
    }

    const newEntity = await this.domainService.update(entity)
      .catch(ServiceErrorHandler);

    return res.status(HttpStatus.OK)
      .json(new HttpResponse(new Status(0, this.messages.success.update), newEntity));
  }

  @Put(':id')
  async updateId(@Res() res: Response, @Body() entity: T, @Param('id') id: string): Promise<Response> {
    if (entity.name === ''){
      throw new BadRequestException(this.messages.error.emptyName);
    }

    const newEntity = await this.domainService.update(entity, id)
      .catch(ServiceErrorHandler);

    return res.status(HttpStatus.OK)
      .json(new HttpResponse(new Status(0, this.messages.success.update), newEntity));
  }

}
