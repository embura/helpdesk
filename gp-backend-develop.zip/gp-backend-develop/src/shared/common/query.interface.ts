import { IFindOptions, Order, Op, WhereOptions } from '../repository/repository.interface';

export interface IQuery {
  [key: string]: string;
}

export function queryStringToWhere(query: IQuery): IFindOptions<any> {
  const where: IFindOptions<any> = {
    where: {},
  };
  if (!query) {
    return undefined;
  }

  if (query._or) {
    if (query._or.constructor) {
      const orOperation: WhereOptions<any>[] = [];
      (query._or as any).forEach( parseOrOperation(orOperation));
      // tslint:disable
      where.where[Op.or as any] = orOperation;

    }
    delete query._or;
  }

  if (query._orderBy) {
    let order = Order.ASC;
    if (query._order === 'desc') {
      order = Order.DESC;
    }

    where.order = [
      [query._orderBy, order],
    ];
    delete query._order;
    delete query._orderBy;

  }

  if (query._likeColumn && query._likeValue) {
    where.where = { [query._likeColumn]: {[Op.like]: query._likeValue}  };
  }
  delete query._likeColumn;
  delete query._likeValue;

  if (query._limit) {
    where.limit = +query._limit;
    delete query._limit;
  }

  if (query._offset) {
    where.offset = +query._offset;
    delete query._offset;
  }

  if (query._between) {
    parserBetweenData(where.where, query._between);
    delete query._between;
  }

  if (query._in) {
    if (query._in.constructor) {
      const [column, value] = query._in.split(':');
      const values = value.split(',');
      
      where.where[Op.in as any] = [{ [column]: { [Op.in]: values } }];
      delete query._in;
    }
  }

  Object.keys(query).forEach(key => {
    where.where[key] = query[key];
  });

  if (!Object.keys(where.where).length && !Object.getOwnPropertySymbols(where.where).length) {
    delete where.where;
  }

  return where;
}

function parseOrOperation(orOperation: WhereOptions<any>[]): (keyValuePair: string) => void {

  return (keyValuePair: string): void => {
    const [key, operator, value] = keyValuePair.split(':');
    if (operator === 'like') {
      orOperation.push({ [key]: {[Op.like]: value} });
      return;
    }
    orOperation.push({ [key]: value });
  };

}

function parserBetweenData(where: WhereOptions<any>, _between: string ): void {
  const [column, from, until] = _between.split(':');
  const fromDate = `TO_DATE ('${from}', 'YYYY-MM-DD HH24MI')`;
  const untilDate = `TO_DATE ('${until}', 'YYYY-MM-DD HH24MI')`;
  where[column] = {
    [Op.between]: [ fromDate, untilDate ],
  };
}
