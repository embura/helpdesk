import { NestInterceptor, ExecutionContext } from '@nestjs/common';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';

export class LoggingInterceptor implements NestInterceptor {
  intercept(dataOrRequest: any, context: ExecutionContext, stream$: Observable<any>): Observable<any> {
    const now = Date.now();

    return stream$.do((data) => {
      const tag = `${dataOrRequest.method}:${dataOrRequest.originalUrl}`;
      const status = (data && data.req && data.req.res && data.req.res.statusCode) ? data.req.res.statusCode : 200;

      const responsInfo = `${tag} [status:${status} - ${Date.now() - now}ms]`;
      if (status > 400) {
        console.error(responsInfo);
        return;
      }
      console.info(responsInfo);
    });
  }

}