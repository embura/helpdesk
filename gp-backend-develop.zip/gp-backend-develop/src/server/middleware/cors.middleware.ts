import {
  ExpressMiddleware,
  NestMiddleware,
  Middleware,
} from '@nestjs/common';

@Middleware()
export class CorsMiddlweare implements NestMiddleware {
  resolve(): ExpressMiddleware {
    return (req, res, next) => {
      delete req.query['gw-app-key'];
      res.header('Access-Control-Allow-Origin', '*');
      res.header('Access-Control-Allow-Methods', '*');
      res.header('Access-Control-Allow-Headers', '*');
      res.header('host-nane', process.env.HOSTNAME || 'localhost');

      next();
    };
  }
}