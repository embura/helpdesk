import { HealthCheckQuery } from './query/health-check.query';
import { Component } from '@nestjs/common';

@Component()
export class HealthCheckService {

  private readonly healthCheckQuery: HealthCheckQuery;

  constructor() {
    this.healthCheckQuery = new HealthCheckQuery();
  }

  async healthCheck(): Promise<number[]> {
    return await this.healthCheckQuery.execute(this.healthCheckQuery.query);
  }

}