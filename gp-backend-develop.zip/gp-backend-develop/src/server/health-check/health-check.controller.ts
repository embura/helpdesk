import { HealthCheckService } from './health-check.service';
import { Controller, Get, Res, HttpStatus, ServiceUnavailableException } from '@nestjs/common';
import { Response } from 'express';
import { HttpResponse } from '../../shared/http.response';
import { Status } from '../../shared/status.entity';

@Controller('health')
export class HealthCheckController {

  constructor(private readonly healthCheckService: HealthCheckService) {}

  @Get()
  async healthCheck(@Res() res: Response): Promise<Response> {

    await this.healthCheckService.healthCheck().catch(err => {
      throw new ServiceUnavailableException('service is unhealthy.');
    });

    return res.status(HttpStatus.OK)
      .json(new HttpResponse(new Status(0, 'service is healthy'), { message: 'service is healthy' }));
  }

}
