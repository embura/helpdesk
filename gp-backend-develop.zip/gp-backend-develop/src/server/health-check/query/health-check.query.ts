import { SqlHandler } from '../../../shared/lib/database/query-handler';

export class HealthCheckQuery extends SqlHandler<number | null> {

  query = 'SELECT 1 as DUAL FROM DUAL';

  protected transform(row: any): number {
    return row.DUAL;
  }

}
