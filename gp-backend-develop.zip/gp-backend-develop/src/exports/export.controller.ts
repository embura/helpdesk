import { Controller, Res, BadRequestException, Query, Get } from '@nestjs/common';
import { Response } from 'express';
import { ExportFileService } from './export.service';
import { ServiceErrorHandler } from '../shared/common/common.error';

@Controller('/export')
export class ExportFileController {

  constructor(
    private exportFileService: ExportFileService
  ) { }

  @Get() //
  public async export(@Res() res: Response, @Query('filename') filename: string): Promise<Response> {
    const timeStampStart = new Date();

    if (!filename) {
      throw new BadRequestException(`É necessário informar o parâmetro "filename".`);
    }

    if (typeof filename !== 'string') {
      throw new BadRequestException(`O nome do arquivo deve ser do tipo 'string', e conter a data e a extensão '.txt'.`);
    }

    const dataString = await this.exportFileService
      .processRequest(filename)
      .then( dataStringArray => {
        const timeStampEnd = new Date();

        console.info('[export] tempo de processamento: ', timeStampEnd.getTime() - timeStampStart.getTime(), 'ms');

        return dataStringArray.join('\n');
      })
      .catch(ServiceErrorHandler);

    return res.send(dataString);
  }

  @Get('/penumper')
  public async exportPenumper(@Res() res: Response, @Query('filename') filename: string): Promise<Response> {

    const dataString = await this.exportFileService.savePenumper(filename)
      .then( dataStringArray => dataStringArray.join('\n'))
      .catch(ServiceErrorHandler);

    return res.send(dataString);
  }
}
