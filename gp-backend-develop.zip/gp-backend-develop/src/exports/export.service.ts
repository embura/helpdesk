import { Component } from '@nestjs/common';
import { BaseDateService } from '../base-date/base-date.service';
import { BaseDateProductService } from '../base-date-product/base-date-product.service';
import { FileService } from '../metadata/file/file.service';
import { ExportFilePath } from './export.interface';
import { FieldService } from '../metadata/field/field.service';
import { FieldTypeService } from '../metadata/fieldType/fieldType.service';
import { ImportFileService } from '../imports/import.service';
import { ExportHeader } from './export.entity';
import { MovimentService } from '../moviment/moviment.service';
import { PositionService } from '../position/position.service';
import { MovimentRow, Moviment } from '../moviment/moviment.entity';
import { invertObj } from '../shared/utils/invertObj';
import { PositionRow, Position } from '../position/position.entity';
import { dateToYYYMMMDD } from '../shared/utils/parse-date';
import { ProductRow, Product } from '../product/product.entity';
import { ProductService } from '../product/product.service';
import * as moment from 'moment';
import { isJSDate } from '../shared/utils/comparision.func';

import { commonErrHadler } from '../shared/utils/common-error.handler';

@Component()
export class ExportFileService {
  constructor(
    public baseDateService: BaseDateService,
    public importService: ImportFileService,
    public baseDateProductService: BaseDateProductService,
    public fileService: FileService,
    public fieldService: FieldService,
    public fieldTypeService: FieldTypeService,
    public movimentService: MovimentService,
    public productService: ProductService,
    public positionService: PositionService
  ) { }

  async processRequest(filename: ExportFilePath): Promise<string[]> {
    const fileInfo = await this.fileService.parseFilename(filename)
      .catch(commonErrHadler('[ExportFileService] fileService.parseFilename'));

    console.info('[ExportFileService] fileInfo: ', fileInfo);

    const dateSys = await this.baseDateService.findByDate(fileInfo.fileDate)
      .catch(commonErrHadler('[ExportFileService] baseDateService.findByDate'));

    console.info('[ExportFileService] dateSys: ', dateSys);

    if (!dateSys || dateSys.length === 0) {
      console.info('[ExportService] processRequest - Informações para esta data não existem no GPC.');
      throw new Error('Informações para esta data não existem no GPC.');
    }

    const { data, fields } = await this.getData(fileInfo)
      .catch(commonErrHadler('[ExportFileService] getData'));

    const dataString = this.arrayToString(data, fields, fileInfo);

    if ((fileInfo.type === 'movi' || fileInfo.type === 'posi') && data.length > 0) {
      const headerData = new ExportHeader(fileInfo, data.length).getHeader();
      let header = '';

      for (const field of headerData) {
        let content = field.data;
        content = content.toString();
        header += content.padStart(field.size, ExportHeader.defaultFiller());
      }
      dataString.unshift(header);
    }

    return dataString;
  }

  convertFieldToString(field: any, dataColumn: any, fileInfo: any): string{
    let content = ('' as any).padEnd(field.size, field.filler);
    switch (field.type.name) {
      case 'DT':
        if (isJSDate(dataColumn)) {
          content = (dateToYYYMMMDD(dataColumn) as any)
            .padEnd(field.size, field.filler);
        }
        break;
      case 'DT_F1':
        if (isJSDate(dataColumn)) {
          content = (moment(dataColumn, 'YYYYMMDD')
            .format(field.type.mask) as any)
            .padEnd(field.size, field.filler);
        }
        break;
      case 'N':
        if (dataColumn.toString().toUpperCase() === 'NA') {
          content = dataColumn.padStart(field.size, '0');
          break;
        }
        const dataColomZero = !!dataColumn ? dataColumn : 0;
        content = (parseFloat(dataColomZero).toString() as any).padStart(field.size, '0');
        break;
      case 'D':
        const dParts = dataColumn.toString().split('.');
        const left = dParts[0].padStart(field.type.digits, 0);
        let right = '';
        if (dParts[1]) {
          right = dParts[1].substring(0, field.type.decimals).padEnd(field.type.decimals, 0);
        } else {
          right = (right as any).padEnd(field.type.decimals, 0);
        }
        content = left + right;
        break;
      case 'TEXTZEROLEFT':
        content = dataColumn.toString().padStart(field.size, field.filler);
        break;
      default:
        content  = dataColumn.substring(0, field.size);
        content = content.toString().padEnd(field.size, field.filler);

        if (fileInfo.type === 'parametros' && field.name === 'NM-SUBP') {
          content = this.especialCharMask(dataColumn);
          content = content.toString().padEnd(field.size, field.filler);
        }
    }
    return content;
  }

  arrayToString(data: string[], fields: any[], fileInfo: any): string[]{
    return data.map((dataRow: any) => {
      const rowfields = Object.assign([], fields);
      let row: string = '01';

      if (fileInfo.type === 'parametros') {
        row = '';
      }

      rowfields.sort((a: any, b: any) => a.seq_pos - b.seq_pos);

      for (const field of rowfields) {
        const dataColumn = dataRow[field.key] || '';

        const content = this.convertFieldToString(field, dataColumn, fileInfo);

        if (content.length > field.size) {
          console.error(`${field.name} tem tamanho ${content.length}\
          conteudo import [${dataColumn}]  counteudo export[${content}] e o tamanho permitido para exportação é ${field.size}.`);
          continue;
        }

        row += content;
      }
      return row;
    });
  }

  async getData(fileInfo: any): Promise<any> {
    return new Promise(async (resolve, reject) => {
      try {
        const fields = await this.fieldService.getFieldsWithTypes(fileInfo);
        let data: Position[] | Moviment[] | Product[];

        console.info('[ExportService] getFieldsWithTypes finish');

        let entityMap: any;
        switch (fileInfo.type) {
          case 'posi':
            data = await this.positionService.getDataToExport(fileInfo);
            entityMap = invertObj(PositionRow);

            entityMap = Object.assign({
              NR_SEQU_PROD_CPT: 'productId',
              CD_GRUP_PROD: 'groupProductCode',
              CD_SUBP: 'subProductCode',
            }, entityMap);

            fields.forEach(field => {
              field.key = entityMap[field.column];
            });
            break;
          case 'movi':
            data = await this.movimentService.getDataToExport(fileInfo);
            entityMap = invertObj(MovimentRow);

            entityMap = Object.assign({
              NR_SEQU_PROD_CPT: 'productId',
              CD_GRUP_PROD: 'groupProductCode',
              CD_SUBP: 'subProductCode',
            }, entityMap);

            fields.forEach(field => {
              field.key = entityMap[field.column];
            });

            break;
          case 'penumper':
            data = await this.positionService.getPenumperToExport(fileInfo);
            entityMap = invertObj(PositionRow);

            fields.forEach(field => {
              field.key = entityMap[field.column];
            });
            break;
          case 'parametros':
            data = await this.productService.getDataToExport(fileInfo);
            entityMap = invertObj(ProductRow);
            fields.forEach(field => {
              field.key = entityMap[field.column];
            });
            break;
          default:
            throw new Error('Exportação desconhecida.');
        }

        console.info('[ExportFileService] getData finish');

        resolve({ data, fields });
      } catch (error) {
        console.error('[ExportFileService] [ERROR]: ', error);

        throw error;
      }
    });
  }

  async savePenumper(filename: ExportFilePath): Promise<string[]> {
    const fileInfo = await this.fileService.parseFilename(filename);
    const date_sys = await this.baseDateService.findByDate(fileInfo.fileDate);

    if (date_sys.length === 0) {
      throw (new Error('Informações para esta data não existem no GPC.'));
    }
    if (date_sys[0].statusInt !== 4) {
      throw (new Error('GPC não está atualizado para exportar informações desta data.'));
    }

    const { data } = await this.getData(fileInfo);
    const penumpers: string[] = [];
    penumpers.push(`00;${moment().format('YYYYMMDD')}`);
    penumpers.push('00;penumper');

    data.forEach((position: any) => {
      penumpers.push(String(`01;${position.penumper}`));
    });

    penumpers.push(String(penumpers.length - 2));

    return penumpers;
  }

  especialCharMask(especialChar: string): string {

    if (!especialChar) return '';

    especialChar = especialChar.toLowerCase();

    especialChar = especialChar.replace(/[áàãâä]/ui, 'a');
    especialChar = especialChar.replace(/[éèêë]/ui, 'e');
    especialChar = especialChar.replace(/[íìîï]/ui, 'i');
    especialChar = especialChar.replace(/[óòõôö]/ui, 'o');
    especialChar = especialChar.replace(/[úùûü]/ui, 'u');
    especialChar = especialChar.replace(/[ç]/ui, 'c');
    especialChar = especialChar.replace(/[^ -\/a-z0-9ª,]/i, '_');

    especialChar = especialChar.toUpperCase();

    especialChar = especialChar.replace(/ª/g, 'a');

    return especialChar;
  }

}