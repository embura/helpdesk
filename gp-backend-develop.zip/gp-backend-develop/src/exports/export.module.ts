import { Module } from '@nestjs/common';
import { ExportFileController } from './export.controller';
import { ExportFileService } from './export.service';

@Module({
  imports: [],
  controllers: [ExportFileController],
  components: [ExportFileService],
  exports: [ExportFileService],
})
export class ExportModule {

}