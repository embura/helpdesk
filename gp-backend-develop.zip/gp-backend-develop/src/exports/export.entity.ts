import { dateToYYYMMMDD } from '../shared/utils/parse-date';


export const tableMovi = 'GPOS.TB_MOVI_TESO';
export const tablePosi = 'GPOS.TB_POSI_TESO';
export const tableProd = 'GPOS.TB_POSI_TESO';
export const sourceColumnMovi = 'SG_SIST_PROD_ORIG';
export const sourceColumnPosi = 'SG_SIST_PROD';
export const sourceColumnProd = 'SG_SIST_PROD';

const defaultFiller = ' ';

export class ExportHeader {
  constructor(
    protected fileInfo: any,
    protected contentLength: number
  ){
  }

  static defaultFiller(): string {
    return defaultFiller;
  }

  getHeader(): any[] {
    console.info('[ExportHeader] getHeader');

    const self = this;
    return [
      {
        name: 'SEQ-REG-H',
        size: 2,
        data: '00',
      }, {
        name: 'FILLER',
        size: 1,
        data: defaultFiller,
      }, {
        name: 'TP-REG',
        size: 1,
        get data(): string {
          if (self.fileInfo.type === 'posi') {
            return 'S';
          } else {
            return 'M';
          }
        },
      }, {
        name: 'FILLER',
        size: 1,
        data: defaultFiller,
      }, {
        name: 'DATA',
        size: 10,
        data: dateToYYYMMMDD(this.fileInfo.fileDate),
      }, {
        name: 'FILLER',
        size: 1,
        data: defaultFiller,
      }, {
        name: 'QT-REG',
        size: 9,
        data: this.contentLength,
      }, {
        name: 'FILLER',
        size: 1,
        data: defaultFiller,
      }, {
        name: 'SG-SIST-H',
        size: 3,
        data: this.fileInfo.product,
      }, {
        name: 'FILLER',
        size: 471,
        data: defaultFiller,
      },
    ];
  }
}