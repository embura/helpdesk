import { Table } from '../shared/decorator/table.annotation';
import { CommonEntity } from '../shared/common/entity';
import { Column } from '../shared/decorator/column.decorator';
import { RowMapper } from '../shared/repository/repository.interface';

@Table('GPOS.TB_DATA_BASE_SIST')
export class BaseDate extends CommonEntity {

  @Column('DT_BASE_SIST')
  id: Date;

  @Column('CD_SITU_ITGR')
  statusInt: number;

}

export const BaseDateRow = Object.freeze({
  id: 'DT_BASE_SIST',
  statusInt: 'CD_SITU_ITGR',
});

export const BaseDateTable = 'GPOS.TB_DATA_BASE_SIST';

export class BaseDateRowMapper implements RowMapper<BaseDate> {
	public map(row: any): BaseDate {
    const baseDate = new BaseDate();
    baseDate.id = row[BaseDateRow.id];
    baseDate.statusInt = row[BaseDateRow.statusInt];
    return baseDate;
	}
}
