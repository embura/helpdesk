import { CommnRepository } from '../shared/repository/common.repository';
import { oracleErrorHandler } from '../shared/common/common.error';
import { BaseDate, BaseDateRow, BaseDateTable, BaseDateRowMapper } from './base-date.entity';
import { BaseDateMessage } from './base-date.msg';
import { dateToYYYMMMDD } from '../shared/utils/parse-date';
import { Order } from '../shared/repository/repository.interface';
import { getUnblockSystemCommand, getUnblockDateCommand } from './query/unblock-system.command';
import { Component } from '@nestjs/common';

@Component()
export class BaseDateRepository extends CommnRepository<BaseDate> {

  constructor() {
    super(
      BaseDateRow,
      BaseDateTable,
      null,
      BaseDateMessage,
      new BaseDateRowMapper()
    );
  }

  public async findByDate(where: any): Promise<any> {
    const query = `
      SELECT DT_BASE_SIST, CD_SITU_ITGR
      FROM GPOS.TB_DATA_BASE_SIST
      WHERE DT_BASE_SIST = TO_DATE('${dateToYYYMMMDD(where.id)}', 'YYYYMMDD')
    `;

    return await this.queryHandler.executeFirstOrNull(query)
        .catch(oracleErrorHandler(this.messages));
  }

  public findLast2(): Promise<any> {
    const query = `
      SELECT DT_BASE_SIST, CD_SITU_ITGR
      FROM GPOS.TB_DATA_BASE_SIST
      ORDER BY DT_BASE_SIST DESC
      FETCH FIRST 2 ROWS ONLY
    `;

    return this.queryHandler.execute(query)
        .catch(oracleErrorHandler(this.messages));
  }

  public async getLastStatus(): Promise<BaseDate> {
    return await this.findOne({
      order: [['id', Order.DESC]],
    });
  }

  public async update(baseDate: BaseDate): Promise<any> {
    const query = `
      UPDATE GPOS.TB_DATA_BASE_SIST
      SET
      CD_SITU_ITGR = ${baseDate.statusInt}
      WHERE
      DT_BASE_SIST = TO_DATE('${dateToYYYMMMDD(baseDate.id)}', 'YYYYMMDD')
    `;

    return await this.commandHandler.execute(query)
        .catch(oracleErrorHandler(this.messages));
  }

  public async create(baseDate: BaseDate): Promise<any> {
    const query = `
      INSERT
      INTO GPOS.TB_DATA_BASE_SIST (
        DT_BASE_SIST,
        CD_SITU_ITGR
      )
      VALUES (
        TO_DATE('${dateToYYYMMMDD(baseDate.id)}', 'YYYYMMDD'),
        ${baseDate.statusInt}
      )
    `;

    return await this.commandHandler.execute(query)
        .catch(oracleErrorHandler(this.messages));
  }

  public async unblockSystem(startDate: string, endDate: string): Promise<any> {
    const unblockDateQuery = getUnblockDateCommand(startDate, endDate);
    await this.commandHandler.execute(unblockDateQuery);
    const unblockSystemQuery = getUnblockSystemCommand(startDate, endDate);
    return this.commandHandler.execute(unblockSystemQuery);
  }

}
