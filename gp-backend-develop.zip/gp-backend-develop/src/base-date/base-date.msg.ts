import { IMessage, CategoryMessage } from '../shared/common/message.model';

const entityName: IMessage = {
  ptBr: 'Data base',
  system: 'Base date',
};

export const BaseDateTag: IMessage = {
  ptBr: 'Data base',
  system: 'Base date',
};

export const BaseDateMessage = new CategoryMessage(BaseDateTag, entityName);