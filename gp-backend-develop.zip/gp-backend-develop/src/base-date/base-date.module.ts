import { Module } from '@nestjs/common';
import { BaseDateService } from './base-date.service';
import { BaseDateController } from './base-date.controller';

@Module({
  components: [
    BaseDateService,
  ],
  exports: [BaseDateService],
  controllers: [BaseDateController],
})
export class BaseDateModule { }