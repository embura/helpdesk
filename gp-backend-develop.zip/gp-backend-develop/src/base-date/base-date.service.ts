
import { Component } from '@nestjs/common';
import { BaseDateMessage } from './base-date.msg';
import { BaseDate, BaseDateRow, BaseDateTable, BaseDateRowMapper } from './base-date.entity';
import { CommonRepositoryService } from '../shared/common/repository.service';
import { CommnRepository } from '../shared/repository/common.repository';
import { BaseDateRepository } from './base-date.repository';
import { Order } from '../shared/repository/repository.interface';
import { SystemStatus, SystemStatusMessage } from '../shared/constants/status.enum';
import { canOpenSystem, isSystemOpen } from './base-date.validator';
import moment = require('moment');
import { dateToYYYMMMDD, getDateToday } from '../shared/utils/parse-date';
import { ServiceErrorHandler } from '../shared/common/common.error';

@Component()
export class BaseDateService extends CommonRepositoryService<BaseDate>{

  constructor(
    protected readonly baseDateRepository: BaseDateRepository
  ) {
    super();
    this.messages = BaseDateMessage;
    this.repository = new CommnRepository<BaseDate>(
      BaseDateRow,
      BaseDateTable,
      null,
      BaseDateMessage,
      new BaseDateRowMapper()
    );
    // this.validation = new NameValidation(this.repository, BaseDateMessage);
  }

  async findByDate(date: Date): Promise<BaseDate> {
    try {
      const ret = await this.baseDateRepository.findByDate({
        id: date,
      } as any);
      return ret;
    } catch (err) {
      throw err;
    }
  }

  async findLast2(): Promise<BaseDate> {
    return this.baseDateRepository.findLast2()
      .catch(ServiceErrorHandler);
  }

  async update(baseDate: BaseDate): Promise<BaseDate> {
      return this.baseDateRepository.update(baseDate)
        .catch(ServiceErrorHandler);
  }

  importErrorHandler(err: any, date: Date): never {
    const errorDateInfo = new BaseDate();
    errorDateInfo.id = date;
    errorDateInfo.statusInt = SystemStatus.Error;
    this.update(errorDateInfo)
      .catch(e => { throw err; });

    throw err;
  }

  async create(baseDate: BaseDate): Promise<BaseDate> {
      return this.baseDateRepository.create(baseDate)
        .catch(ServiceErrorHandler);
  }

  async openSystem(): Promise<string> {
    let responseMessage = SystemStatusMessage.OpenWithSuccess;
    const newDate = new BaseDate();
    newDate.id = new Date();
    newDate.statusInt = SystemStatus.Contingency;
    const lastUpdate = await this.baseDateRepository.findOne({
      order: [['id', Order.DESC]],
    });

    if (isSystemOpen(lastUpdate)) {
      return SystemStatusMessage.AlreadyOpen;
    }
    if (!canOpenSystem(lastUpdate)) {
      newDate.statusInt = SystemStatus.Unavailable;
      responseMessage = SystemStatusMessage.SystemUnavailable;
    }

    await this.create(newDate);
    console.info('[DataBaseSerice] openSystem ', responseMessage);
    return responseMessage;
  }

  async unblockSystem(startDate: string, endDate: string): Promise<string> {
    await this.baseDateRepository.unblockSystem(startDate, endDate);
    return 'done';
  }

  async initDate(date: Date): Promise<void> {
    const baseDate = new BaseDate();
    baseDate.id = date;
    baseDate.statusInt = SystemStatus.NotInitialized;
    await this.create(baseDate);
  }

  async getDefaultDate(positionDate: string): Promise<string> {
    let todayString = dateToYYYMMMDD(getDateToday());
    const queryDateString = positionDate || todayString;

    console.info('[BaseDateService] getDefaultDate positionDate: ', positionDate);

    if (todayString !== queryDateString) {
      console.info('[BaseDateService] getDefaultDate queryDateString: ', queryDateString);
      return queryDateString;
    }

    const [statusToday, statusYesterday, beforeStatusYesterday] = await this.baseDateRepository.findAll({
      order: [['id', Order.DESC]],
    });

    if (statusToday && statusToday.statusInt === SystemStatus.UpTodate) {
      console.info('[BaseDateService] statusToday: ', statusToday);
      todayString = moment(statusYesterday.id).format('YYYYMMDD');
      return todayString;
    }

    if (statusYesterday && statusYesterday.statusInt === SystemStatus.UpTodate) {
      console.info('[BaseDateService] statusYesterday: ', statusYesterday);
      todayString = moment(beforeStatusYesterday.id).format('YYYYMMDD');
      return todayString;
    }

    console.info('[BaseDateService] getDefaultDate: ', todayString);
    return todayString;
  }

}
