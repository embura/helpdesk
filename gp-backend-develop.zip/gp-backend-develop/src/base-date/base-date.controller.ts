import { CommonController } from '../shared/common/common.controller';
import { BaseDate } from './base-date.entity';
import { BaseDateService } from './base-date.service';
import { BaseDateMessage } from './base-date.msg';
import { Controller, Get, Res, Query, HttpStatus, Param, Post, Body } from '@nestjs/common';
import { Response } from 'express';
import { IQuery } from '../shared/common/query.interface';
import { ServiceErrorHandler } from '../shared/common/common.error';
import { Status } from '../shared/status.entity';
import { HttpResponse } from '../shared/http.response';
import { parseYYYYMMDD } from '../shared/utils/parse-date';
import { BaseDateProductService } from '../base-date-product/base-date-product.service';
import moment = require('moment');
import { SqlHandler } from '../shared/lib/database/query-handler';

@Controller('status')
export class BaseDateController extends CommonController<BaseDate>{

  constructor(
    protected baseDateService: BaseDateService,
    protected baseDateProductService: BaseDateProductService
  ) {
    super(baseDateService, BaseDateMessage);
  }

  @Get()
  async findLast(@Res() res: Response, @Query() query: IQuery): Promise<Response> {
    const entities: any = await this.baseDateService.findLast2()
      .catch(ServiceErrorHandler);

    const entity: BaseDate = entities[0];

    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, this.messages.success.found), entity));

  }

  @Get('details')
  async getFilesStatus(@Res() res: Response, @Query('fileNumber') fileNumber?: number): Promise<any> {
    const lastDate: string = await this.baseDateService.getDefaultDate(moment().format('YYYYMMDD'));

    let dateCorrent: Date = new Date();

    if (lastDate) {
      dateCorrent = moment(lastDate).toDate();
    }

    const entity = await this.baseDateProductService.findByDate(dateCorrent, fileNumber)
      .catch(ServiceErrorHandler);

    if (fileNumber && entity.length > 0) {
      return res.status(HttpStatus.OK).json(entity[0].statusInt);
    } else {
      return res.status(HttpStatus.OK).json(
        new HttpResponse(new Status(0, this.messages.success.found), {
          date: dateCorrent,
          files: entity,
        }));
    }
  }

  @Get(':dateString')
  async findByDateString(@Res() res: Response, @Param('dateString') dateString: number): Promise<Response> {
    const date = parseYYYYMMDD(dateString);
    const entity = await this.baseDateService.findByDate(date)
      .catch(ServiceErrorHandler);

    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, this.messages.success.found), entity));
  }

  @Post('open')
  async openSystem(@Res() res: Response): Promise<Response> {
    const message = await this.baseDateService.openSystem()
      .catch(ServiceErrorHandler);

    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, message), undefined));
  }

  @Post('unblock')
  async unblockSystem(@Res() res: Response, @Body() body: any): Promise<Response> {
    const message = await this.baseDateService.unblockSystem(body.startDate, body.endDate)
      .catch(ServiceErrorHandler);

    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, message), undefined));
  }

  @Post('query')
  showSql(@Res() res: Response, @Body() body: any): Response {

    SqlHandler.showSql = body.showSql;
    return res.status(HttpStatus.OK).json(
      new HttpResponse(new Status(0, ''), {showSql: body.showSql}));
  }

}
