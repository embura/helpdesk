export function getUnblockDateCommand(startDate: string, endDate: string): string{
  return `
UPDATE GPOS.TB_DATA_BASE_SIST
   SET CD_SITU_ITGR = 4
 Where DT_BASE_SIST
   BETWEEN TO_DATE ('${startDate}', 'yyyy/mm/dd')
       AND TO_DATE ('${endDate}', 'yyyy/mm/dd')
`;
}

export function getUnblockSystemCommand(startDate: string, endDate: string): string{
  return `
UPDATE GPOS.TB_DATA_BASE_SIST_PROD
   SET CD_SITU_ITGR = 4
 Where SG_SIST_PROD = 'CPT'
     AND DT_BASE_SIST
 BETWEEN TO_DATE ('${startDate}', 'yyyy/mm/dd')
     AND TO_DATE ('${endDate}', 'yyyy/mm/dd')
`;
}
