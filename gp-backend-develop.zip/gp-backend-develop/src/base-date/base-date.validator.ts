import { SystemStatus } from '../shared/constants/status.enum';
import { BaseDate } from './base-date.entity';

export function canOpenSystem(lastDay: BaseDate): boolean {
  return lastDay && lastDay.statusInt === SystemStatus.UpTodate;
}

export function isSystemOpen(lastDay: BaseDate): boolean {
  const today = new Date();

  return lastDay && today.toDateString() === lastDay.id.toDateString();
}