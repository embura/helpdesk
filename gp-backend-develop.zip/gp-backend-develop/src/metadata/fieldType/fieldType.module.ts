import { Module } from '@nestjs/common';
import { FieldTypeService } from './fieldType.service';
import { FieldTypeRepository } from './fieldType.repository';

@Module({
  components: [
    FieldTypeService,
    FieldTypeRepository,
  ],
  exports: [FieldTypeService],
})
export class FieldTypeModule { }