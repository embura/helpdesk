import { CommnRepository } from '../../shared/repository/common.repository';
import { FieldType, FieldTypeRow, FieldTypeTable, FieldTypeRowMapper, FieldTypeSequence } from './fieldType.entity';
import { FieldTypeMessage } from './fieldType.msg';
import { Component } from '@nestjs/common';

@Component()
export class FieldTypeRepository extends CommnRepository<FieldType> {

  constructor() {
    super(
      FieldTypeRow,
      FieldTypeTable,
      FieldTypeSequence,
      FieldTypeMessage,
      new FieldTypeRowMapper()
    );
  }

}
