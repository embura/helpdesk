
import { Component } from '@nestjs/common';
import { FieldTypeMessage } from './fieldType.msg';
import { FieldType, FieldTypeRow, FieldTypeTable, FieldTypeRowMapper, FieldTypeSequence } from './fieldType.entity';
import { CommonRepositoryService } from '../../shared/common/repository.service';
import { CommnRepository } from '../../shared/repository/common.repository';
import { FieldTypeRepository } from './fieldType.repository';

@Component()
export class FieldTypeService extends CommonRepositoryService<FieldType>{

  constructor(
    protected readonly baseDateRepository: FieldTypeRepository
  ) {
    super();
    this.messages = FieldTypeMessage;
    this.repository = new CommnRepository<FieldType>(
      FieldTypeRow,
      FieldTypeTable,
      FieldTypeSequence,
      FieldTypeMessage,

      new FieldTypeRowMapper()
    );
  }

}
