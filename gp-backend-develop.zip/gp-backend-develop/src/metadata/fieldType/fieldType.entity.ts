
import { Table } from '../../shared/decorator/table.annotation';
import { CommonEntity } from '../../shared/common/entity';
import { Column } from '../../shared/decorator/column.decorator';
import { RowMapper } from '../../shared/repository/repository.interface';

@Table('GPOS.TB_TIPO_CAPO_ARQU_ITGR')
export class FieldType extends CommonEntity {

  @Column('NR_SEQU_TIPO_CAPO_ARQU_ITGR')
  id: number;

  @Column('NM_TIPO_CAPO')
  name: string;

  @Column('TX_FORM_CAPO_DATA')
  mask: string;

  @Column('QT_CASA_DECI_CAPO_DECI')
  decimals: number;

  @Column('QT_DIGI_CAPO_DECI')
  digits: number;

}

export const FieldTypeRow = Object.freeze({
  id: 'NR_SEQU_TIPO_CAPO_ARQU_ITGR',
  name: 'NM_TIPO_CAPO',
  mask: 'TX_FORM_CAPO_DATA',
  decimals: 'QT_CASA_DECI_CAPO_DECI',
  digits: 'QT_DIGI_CAPO_DECI',
});

export const FieldTypeTable = 'GPOS.TB_TIPO_CAPO_ARQU_ITGR';
export const FieldTypeSequence = 'GPOS.SQ_TIPO_CAPO_ARQU_ITGR';

export class FieldTypeRowMapper implements RowMapper<FieldType> {
	public map(row: any): FieldType {
    const field = new FieldType();
    field.id = row[FieldTypeRow.id];
    field.name = row[FieldTypeRow.name];
    field.mask = row[FieldTypeRow.mask];
    field.decimals = row[FieldTypeRow.decimals];
    field.digits = row[FieldTypeRow.digits];
    return field;
	}
}
