import { IMessage, CategoryMessage } from '../../shared/common/message.model';

const entityName: IMessage = {
  ptBr: 'Tipo de Campo',
  system: 'FieldType',
};

export const FieldTypeTag: IMessage = {
  ptBr: 'Tipo de Campo',
  system: 'FieldType',
};

export const FieldTypeMessage = new CategoryMessage(FieldTypeTag, entityName);