export const Metadata: any  = {
  'GPOS.TB_MOVI_TESO': {
    source: 'SG_SIST_PROD_ORIG',
    date: 'DT_BASE_SIST',
  },
  'GPOS.TB_POSI_TESO': {
    source: 'SG_SIST_PROD',
    date: 'DT_BASE_SIST',
  },
  'GPOS.TB_PROD_TESO': {
    source: 'SG_SIST_PROD',
    date: 'DT_BASE_SIST',
  },
};
