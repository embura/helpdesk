import { CommnRepository } from '../../shared/repository/common.repository';
import { Field, FieldRow, FieldTable, FieldRowMapper, FieldSequence } from './field.entity';
import { FieldMessage } from './field.msg';
import { Component } from '@nestjs/common';

@Component()
export class FieldRepository extends CommnRepository<Field> {

  constructor() {
    super(
      FieldRow,
      FieldTable,
      FieldSequence,
      FieldMessage,
      new FieldRowMapper()
    );
  }

}
