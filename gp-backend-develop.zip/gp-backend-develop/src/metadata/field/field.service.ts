
import { Component } from '@nestjs/common';
import { FieldMessage } from './field.msg';
import { Field, FieldRow, FieldTable, FieldRowMapper, FieldSequence } from './field.entity';
import { CommonRepositoryService } from '../../shared/common/repository.service';
import { CommnRepository } from '../../shared/repository/common.repository';
import { FieldTypeService } from '../fieldType/fieldType.service';

@Component()
export class FieldService extends CommonRepositoryService<Field>{

  constructor(
    protected fieldTypeService: FieldTypeService
  ) {
    super();
    this.messages = FieldMessage;
    this.repository = new CommnRepository<Field>(
      FieldRow,
      FieldTable,
      FieldSequence,
      FieldMessage,
      new FieldRowMapper()
    );
  }

  async getFieldsWithTypes(fileInfo: any): Promise<any[]> {
    const [fields, fieldTypes] = await Promise.all([
      this.findAll({ fileId: fileInfo.id }),
      this.fieldTypeService.findAll({}),
    ]);

    const newFields = fields.map((field: any) => {
      field.type = fieldTypes.find(type => type.id === field.type);
      return field;
    });
    return newFields;
  }

  async getFields(fileInfo: any): Promise<any[]> {
    const fields: Field[] = await this.findAll({ fileId: fileInfo.id });
    return fields;
  }

}
