import { IMessage, CategoryMessage } from '../../shared/common/message.model';

const entityName: IMessage = {
  ptBr: 'Campo',
  system: 'Field',
};

export const FieldTag: IMessage = {
  ptBr: 'Campo',
  system: 'Field',
};

export const FieldMessage = new CategoryMessage(FieldTag, entityName);