import { Module } from '@nestjs/common';
import { FieldService } from './field.service';
import { FieldRepository } from './field.repository';

@Module({
  components: [
    FieldService,
    FieldRepository,
  ],
  exports: [FieldService],
})
export class FieldModule { }