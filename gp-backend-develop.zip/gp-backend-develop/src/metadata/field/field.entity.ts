
import { Table } from '../../shared/decorator/table.annotation';
import { CommonEntity } from '../../shared/common/entity';
import { Column } from '../../shared/decorator/column.decorator';
import { RowMapper } from '../../shared/repository/repository.interface';

@Table('GPOS.TB_CAPO_ARQU_ITGR')
export class Field extends CommonEntity {

  @Column('NR_SEQU_CAPO_ARQU_ITGR')
  id: number;

  @Column('NR_SEQU_ARQU_IMPO')
  fileId: number;

  @Column('NM_LOGI_CAPO')
  name: string;

  @Column('NM_TABE')
  table: string;

  @Column('NM_COLU_TABE')
  column: string;

  @Column('QT_TAMA_CAPO')
  size: number;

  @Column('TX_CTER_FILLER_CAPO')
  filler: string;

  @Column('NR_SEQU_TIPO_CAPO_ARQU_IMPO')
  type: number;

  @Column('NR_POSI_INIC_CAPO')
  start_pos: number;

  @Column('NR_ORDE_CAPO')
  seq_pos: number;

  @Column('IN_CAPO_OBRI')
  obrig: number;

}

export const FieldRow = Object.freeze({
  id: 'NR_SEQU_CAPO_ARQU_ITGR',
  fileId: 'NR_SEQU_ARQU_IMPO',
  name: 'NM_LOGI_CAPO',
  table: 'NM_TABE',
  column: 'NM_COLU_TABE',
  size: 'QT_TAMA_CAPO',
  filler: 'TX_CTER_FILLER_CAPO',
  type: 'NR_SEQU_TIPO_CAPO_ARQU_IMPO',
  start_pos: 'NR_POSI_INIC_CAPO',
  seq_pos: 'NR_ORDE_CAPO',
  obrig: 'IN_CAPO_OBRI',
});

export const FieldTable = 'GPOS.TB_CAPO_ARQU_ITGR';
export const FieldSequence = 'GPOS.SQ_CAPO_ARQU_ITGR';

export class FieldRowMapper implements RowMapper<Field> {
	public map(row: any): Field {
    const field = new Field();
    field.id = row[FieldRow.id];
    field.fileId = row[FieldRow.fileId];
    field.name = row[FieldRow.name];
    field.table = row[FieldRow.table];
    field.column = row[FieldRow.column];
    field.size = row[FieldRow.size];
    field.filler = row[FieldRow.filler];
    field.type = row[FieldRow.type];
    field.start_pos = row[FieldRow.start_pos];
    field.seq_pos = row[FieldRow.seq_pos];
    field.obrig = row[FieldRow.obrig];
    return field;
	}
}
