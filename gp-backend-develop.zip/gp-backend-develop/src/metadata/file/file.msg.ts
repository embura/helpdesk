import { IMessage, CategoryMessage } from '../../shared/common/message.model';

const entityName: IMessage = {
  ptBr: 'Arquivo',
  system: 'File',
};

export const FileTag: IMessage = {
  ptBr: 'Arquivo',
  system: 'File',
};

export const FileMessage = new CategoryMessage(FileTag, entityName);