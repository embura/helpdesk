import { Module } from '@nestjs/common';
import { FileService } from './file.service';
import { FileRepository } from './file.repository';

@Module({
  components: [
    FileService,
    FileRepository,
  ],
  exports: [FileService],
})
export class FileModule { }