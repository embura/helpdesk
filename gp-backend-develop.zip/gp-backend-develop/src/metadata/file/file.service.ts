
import { Component } from '@nestjs/common';
import { FileMessage } from './file.msg';
import { File, FileRow, FileTable, FileRowMapper, FileSequence } from './file.entity';
import { CommonRepositoryService } from '../../shared/common/repository.service';
import { CommnRepository } from '../../shared/repository/common.repository';
import { FileRepository } from './file.repository';
import { IQuery, queryStringToWhere } from '../../shared/common/query.interface';
import { parseYYYYMMDD } from '../../shared/utils/parse-date';

@Component()
export class FileService extends CommonRepositoryService<File>{

  constructor(
    protected readonly fileRepository: FileRepository
  ) {
    super();
    this.messages = FileMessage;
    this.repository = new CommnRepository<File>(
      FileRow,
      FileTable,
      FileSequence,
      FileMessage,

      new FileRowMapper()
    );
  }

  async findAll(param: IQuery): Promise<File[]> {
    const where = queryStringToWhere(param);
    if (!where.order) {
      where.order = [this.defaultOrder];
    }
    return await this.repository.findAll(where);
  }

  async findByNameLike(name: string): Promise<File[]> {
    return await this.fileRepository.findByNameLike(name);
  }

  async parseFilename(filename: string): Promise<any> {
    const params = filename.split('_');

    if (params[0] && params[0] === 'E2' && params[1]) {
      params[2] = params[1].replace('SEGMENTO', '');
      params[1] = 'segmento';
    }

    const [fileDateString, ] = params[params.length - 1].split('.');
    if (params.length > 4 || params.length < 3) {
      throw new Error(`O nome o arquivo não está de acordo com o padrão.`);
    }

    let fileDataResults, product, type;
    if (filename.startsWith('gpc') && params.length === 4) {
      const exprt = params[0];
      product = params[1];
      type = params[2];
      fileDataResults = await this.findByNameLike(`${exprt}_${product}_${type}`);
    } else {
      product = params[0];
      type = params[1];
      fileDataResults = await this.findByNameLike(`${product}_${type}_`);
    }

    if (fileDataResults.length !== 1) {
      throw new Error(`
      Deve existir apenas um registro para o arquivo '${filename}' no sistema. Foram encontrado(s) ${fileDataResults.length}.
      `);
    }

    return {
      product: 'CPT',
      type,
      fileDate: parseYYYYMMDD(+fileDateString),
      id: fileDataResults[0].id,
      separator: fileDataResults[0].separator,
    };
  }

}
