import { CommnRepository } from '../../shared/repository/common.repository';
import { File, FileRow, FileTable, FileRowMapper, FileSequence } from './file.entity';
import { FileMessage } from './file.msg';
import { oracleErrorHandler } from '../../shared/common/common.error';
import { Component } from '@nestjs/common';

@Component()
export class FileRepository extends CommnRepository<File> {

  constructor() {
    super(
      FileRow,
      FileTable,
      FileSequence,
      FileMessage,
      new FileRowMapper()
    );
  }

  public async findByNameLike(name: string): Promise<File[]> {
    const query = `
      SELECT *
      FROM GPOS.TB_ARQU_ITGR
      WHERE "NM_ARQU_ITGR" LIKE '${name}%'
    `;

    return await this.queryHandler.execute(query)
        .catch(oracleErrorHandler(this.messages));
  }

}
