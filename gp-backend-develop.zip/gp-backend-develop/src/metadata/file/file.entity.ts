
import { Table } from '../../shared/decorator/table.annotation';
import { CommonEntity } from '../../shared/common/entity';
import { Column } from '../../shared/decorator/column.decorator';
import { RowMapper } from '../../shared/repository/repository.interface';

@Table('GPOS.TB_ARQU_ITGR')
export class File extends CommonEntity {

  @Column('NR_SEQU_ARQU_ITGR')
  id: number;

  @Column('NM_ARQU_ITGR')
  name: string;

  @Column('TX_SEPA_ARQU_ITGR')
  separator: string;

  @Column('TX_FORM_DATA_ARQU_ITGR')
  dateFormat: string;

  @Column('IN_PROC_ARQU')
  run: number;

}

export const FileRow = Object.freeze({
  id: 'NR_SEQU_ARQU_ITGR',
  name: 'NM_ARQU_ITGR',
  separator: 'TX_SEPA_ARQU_ITGR',
  dateFormat: 'TX_FORM_DATA_ARQU_ITGR',
  run: 'IN_PROC_ARQU',
});

export const FileTable = 'GPOS.TB_ARQU_ITGR';
export const FileSequence = 'GPOS.SQ_ARQU_ITGR';

export class FileRowMapper implements RowMapper<File> {
	public map(row: any): File {
    const file = new File();
    file.id = row[FileRow.id];
    file.name = row[FileRow.name];
    file.separator = row[FileRow.separator];
    file.dateFormat = row[FileRow.dateFormat];
    file.run = row[FileRow.run];
    return file;
	}
}
