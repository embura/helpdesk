#!/bin/bash



echo '#### [Start Build - ./ci/build.sh] ####'



npm i

npm run build

cp -r node_modules app/node_modules

cp -r package.json app/package.json

cp -r config app/config



echo '#### [Finish Build - ./ci/build.sh] ####'



