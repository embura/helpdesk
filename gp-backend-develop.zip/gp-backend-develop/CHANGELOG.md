# Change Log

## [v5.0.1] - 2019-06-04
### Change
- Data de vencimento do movimento e posição

## [v5.0.0] - 2019-06-03
### Change
- Nova estrura de versionamento


## [v3.4.0] - 2019-05-22
### Fix
- Nome da campanha

## [v3.2.9] - 2019-06-03
### Fix
- Ajuste na criação de posição online, colunas ID da campanha e nome do cliente


## [v2.2.0] - 2019-04-08
### Change
- Database consult query is Accent and Case Insensitive

## [v2.1.2] - 2019-03-28
### Fix
- Docker config

## [v2.1.0] - 2019-03-28
### Change
- IPO Reserv

## [v2.1.0] - 2018-12-26
### Change
- IPO Reserve


## [v1.2.0] - 2018-12-03
### Feat
- PDI Position


## [v1.1.0] - 2018-11-26
### Change
- DB to v4
- Segment now uses database
### Feat
- Private segments


## [v1.0.1] - 2018-11-13
### Fix
- Ajuste data base D-1


## [v0.3.0] - 2018-10-22
### Change
- Export return was changed from file to string
### Feat
- [BaseDate] Added an endpoint to open the system


## [v0.2.1] - 2018-10-04
### Change
- TypeScript is now 3.1


## [v0.2.0] - 2018-10-04
### Change
- NODE_ENV is now 'local' for local environment
### Feat
- Access log


## [v0.1.0] - 2018-09-21
### Change
- DataBase v2


## [v0.1.0] - 2018-09-21
### Feat
- Reserva de IPO
- CHANGELOG.md
### Change
- App version

