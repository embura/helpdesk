export function applyLogger(appName: any): any;
