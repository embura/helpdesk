#!/bin/bash

cd $IMAGE_SCRIPTS_HOME
# exec ./control.sh start
exec ./control.sh start