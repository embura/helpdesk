[![build status](https://gitlab.produbanbr.corp/BR-SNT-PVD/backend-cpt/badges/develop/build.svg)](https://gitlab.produbanbr.corp/BR-SNT-PVD/backend-cpt/commits/develop)

[![coverage report](https://gitlab.produbanbr.corp/BR-SNT-PVD/backend-cpt/badges/develop/coverage.svg)](https://gitlab.produbanbr.corp/BR-SNT-PVD/backend-cpt/commits/develop)

## Basics

Base URL: http://localhost:8080/cat-produtos/treasury-product-stock/v1/

```terminal
git -c http.sslVerify=false clone https://gitlab.produbanbr.corp/BR-SNT-PVD/gp-backend.git
git config http.sslVerify false
```